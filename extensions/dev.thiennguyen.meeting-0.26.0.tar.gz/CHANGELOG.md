# Changelog

## [0.26.0] - 2026-11-27

### Changed

- **Start, Chats and Libraries stay in place while the sidebar scrolls.** They stand under the title bar while the meetings scroll under them, and stay while you search, so the results no longer jump up into their place. A faint line under them darkens as the first meetings go under.
- **A section's heading stays in sight while its meetings go by.** Pinned, Folders, Today, Yesterday and the other headings hold at the top of the list until the next one takes their place. An open folder holds its name under Folders while its meetings go by, and while you search, a found meeting holds its name under its day while its matching lines go by.

## [0.25.1] - 2026-11-27

### Fixed

- **A long meeting's summary is written again.** With a model that writes long answers, such as Claude Sonnet, the summary of a long meeting could fail with "The model's answer could not be read as notes" after trying twice. The summary, and Clean Up and Translate All with the text model, are no longer held to a fixed length: each model writes up to its own limit, and an answer that is still cut short is read again in two parts. **Best with Lumi 1.104.0**, which holds each answer to its own model's limit.

## [0.25.0] - 2026-11-27

### Fixed

- **The call-ended card shows its buttons in full.** Continue Recording no longer sits on the card's edge: the buttons have a row of their own under the words, and the meeting's name gets the card's whole width. The countdown also runs on once the pointer leaves the card, where it could stay stopped.
- **Listen Again no longer says "Stopping…" for good after Lumi restarts.** If Lumi quit, restarted for an update or crashed while a meeting was heard again, or Meeting Notes was switched off, the meeting showed "Stopping…" with no way out for a quarter of an hour. It now opens as it was left, and Listen Again is there to press again. A summary being written in parts is put right the same way.
- **Up Next no longer says "Waiting to join" for a join that can't start.** If Meeting Notes was switched off or Lumi quit while Join and Take Notes waited for the call, the card went on waiting. It now offers Join and Take Notes again.
- **The menu bar stops counting a meeting Lumi cut off.** A meeting being recorded when Lumi quit or Meeting Notes was switched off is saved up to that moment as soon as Meeting Notes is back, and Live Captions says so as before.
- **The next call is offered Take Notes after a switch-off.** An offer Lumi took down no longer holds back the one for another call.

Meeting Notes starts nothing again by itself: what was cut short is a press away. **Needs Lumi 1.103.0.**

## [0.24.0] - 2026-11-27

### Added

- **One person heard as two is put right as you name them.** When Lumi gives one person two speaker numbers, name the second after the first: pick them in the list, type their name or address, or type Your Name. The card asks **Merge Speaker 2 into Lan Pham?**, says what becomes of the lines, and **Merge** makes the two one speaker. It works in Live Captions while the meeting is recorded, in the inspector and beside a name in the transcript. What that speaker says afterwards goes to the same person, and Undo takes it back. A merge saves no voice profile.

### Changed

- **Everyone invited stays in the naming list.** Someone another speaker is already named after is no longer left out: their avatar takes that speaker's colour, and the row says which speaker they are.
- **Merge Into works while a meeting is recorded.** Assign To still waits until the meeting ends.

### Fixed

- **Translate All with Apple Translation no longer stops at a line in two languages.** Such a line is translated a few sentences at a time, each from its own language, and the lines after it are translated too.
- **A meeting's last lines are kept when saving them at the end fails for a moment.** The captions panel sends them again until they are saved, with a model switch or the first translation made in the last seconds.
- **A meeting is no longer ended as lost while Lumi asks a question before it starts listening.** If the question stayed up for more than a minute and a half, the meeting was closed, and the recording that followed could not be stopped from the menu bar.
- **Join and Take Notes no longer starts notes for tomorrow's meeting.** For a call more than 4 hours away, Meeting Notes says it cannot wait that long and opens nothing.
- **Try Again and Regenerate work in a chat across meetings.**
- **Cancel stops a download that Download and Start began in Live Captions.** If Lumi cannot stop it, the panel says why.

## [0.23.3] - 2026-11-26

### Changed

- **Save Now is the call-ended card's main button.** It is what the countdown does anyway. The other button now reads **Continue Recording**.

## [0.23.2] - 2026-11-26

### Fixed

- **The call-ended card no longer shows a scroll bar.** The card that appears when a call ends is one row again: the heading takes at most two lines, and the line under it keeps to one, with a long meeting name cut short. Before, it could come up a few points too short, with its text clipped and a scroll bar drawn over it.

### Changed

- **The call-ended card has no Show More.** It is the countdown, **Keep Recording** and **Save Now**. What was heard is in Meeting Notes once the meeting is saved.

## [0.23.1] - 2026-11-26

### Changed

- **A film on the store page.** Meeting Notes' page in Lumi's Extension Store now shows a short video of it at work: Up Next, Live Captions and Live Translation, then Ask, Refine, Translate All, Summary, Libraries and Export.

## [0.23.0] - 2026-11-26

### Changed

- **A file opens in a window of its own.** A PDF, a document or a picture in an Ask chat or a library opens in a File Preview window you move, size and close like any other window. Opening another file shows it in the same window, and the window opens where you left it. It used to open in a box drawn over the page, whose green button covered the window's own buttons.

### Fixed

- **"N of N lines changed" lines up with the transcript.** In Changes, the count starts on the same edge as the words under it, with the key to the marks at the right, and VoiceOver reads it.

## [0.22.0] - 2026-11-26

### Added

- **Up Next on the Start page.** Your calendar's next meetings, as far ahead as Settings › Calendar › Up Next says: Today, Today and Tomorrow (the default), Next 7 Days, or Don't Show. The next one is a card with its people and one button, **Join and Take Notes** (**Take Notes** for a meeting in a room). Press a later one to see its people, its agenda and the last meeting of its series. **Needs Lumi 1.102.0.**
- **Join and Take Notes waits for the join.** It opens the call, and the notes start only once the call's app, or a browser on its site, is using the microphone and playing sound, so the lobby and the wait are left out. Until then the card says "Waiting to join" with Cancel, and so does Lumi's menu.
- **A Calendar pane in Settings.** Access, the calendars read, Name Meetings After Calendar Events and Up Next, in a pane of their own after General.

### Changed

- **The card after a call ends counts down.** When the call's app lets go of the microphone, the card says "The Zoom call ended — Saving “Design Review” in 20 s" around a ring, with **Keep Recording** and **Save Now**, and **Show More** for what was heard. Nothing is saved while you point at the card or press in it.
- **Get Started is ticked off by you.** **Mark All Done** puts it away, and the tour ticks itself at its end. The Start page's header and foot stay put while its columns scroll.
- **The meeting's toolbar.** Ask comes first and shares a capsule with Details; Appearance and Search each stand alone, in the same place on every page.

### Fixed

- **A pop-up's second press closes its menu.** Pressing the button of an open menu — the source pop-up above Start in Live Captions, Settings' model pop-ups, Template or Model in a summary, a line's More — closed the menu and opened it again, or left it open. It now only closes it, as a Mac pop-up does.
- **"“X” ended N minutes ago" no longer cuts into a meeting that runs over.** It came five minutes after the event's end while the call was still on. It now also waits until nothing has been said for two minutes, and says so.

## [0.21.0] - 2026-11-25

### Added

- **A line said in another language shows which.** In a meeting in English, a line said in Vietnamese starts with a small "VI"; point at it for the language's whole name. VoiceOver reads each line in its own language's voice, in Live Captions too.

### Changed

- **Names, times and avatars follow the text size.** ⌘+ and ⌘− now size a speaker's name, time and avatar and the Translate chip with the words, so a name never reads smaller than its translation. In Paragraphs, translations hang off a thin bar, so they no longer read as a second paragraph by the same speaker.
- **Plainer words for the transcript as it was made.** "Heard live" and "as heard" are now **Original**: "Originally Speaker 2" on a struck name in Changes, **Copy Original Transcript**, "Back to Original." After Listen Again, the foot says "1 new speaker found" where it said "1 speaker told apart again".

### Fixed

- **A line and its translation light up as clearly in Dark as in Light.** Pointing at a sentence lit it and its translation only faintly in Dark. The highlight is now as strong as Apple's own in each appearance, a lit translation takes the text's colour, and Playing and Selected are stronger in Dark so Selected still stands out most.
- **Refine and Translate… no longer runs into the sentence before it** at the foot of a transcript cleaned up as the meeting ended ("no AI.Refine and Translate…").

## [0.20.0] - 2026-11-25

### Added

- **Narrow a question across all your meetings.** Four chips above the field on the Chats page pick what the question reads:
  - **When:** today, yesterday, this or last week, this month, or a range of days picked on a calendar.
  - **People:** the meetings where they spoke, or only what they said.
  - **Meetings:** any you pick.
  - **Reads:** transcripts and summaries, summaries only, or transcripts only.

  Beside the chips, how many meetings that is. A question says above it what it read, and a chat keeps what its last question read when you open it again. **Needs Lumi 1.101.0.**
- **Ask about several meetings at once.** ⌘-click meetings in the sidebar, or ⇧-click for a run of them, then press **Ask About These**. Right-click a folder for **Ask About This Folder**. Chats opens with those meetings picked.

### Changed

- **Asking across all your meetings reads their summaries too.** A meeting's summary goes in beside its transcript when it is written, edited or another version is shown, and comes out when it is deleted. Questions such as "every decision we made" or "all the upcoming deadlines" now find more of what was said. Summaries written before this go in over your next few questions across meetings.

### Fixed

- **A long meeting from an earlier version opens again.** Opening one stopped with "storage.put refused: this run already made 200 host calls" after an update, because each sentence's language was asked of Lumi one at a time. They are now asked all at once. **Needs Lumi 1.101.0.**
- **A cite in an answer across all your meetings shows when it was said.** Every such chip read "00:00" and the meeting's title with the date after it. It now shows the line's own time and the meeting's title as it is now, and is greyed once that meeting is deleted. While the answer is still being written, it is already that meeting's chip rather than a greyed link.

## [0.19.1] - 2026-11-25

### Fixed

- Refine and Translate's time for Translate All is closer to what it takes. It counted fewer parts and calls than Translate All makes, and left out what the AI writes besides the translations.

## [0.19.0] - 2026-11-25

### Added

- **Slash commands in Ask.** Type `/` in Ask, or press the `/` button beside @, to pick a command:
  - **Lumi's own:** `/clear` starts a new chat and keeps this one, `/compact` summarizes the earlier messages, `/retry` asks the last question again, `/title` renames the chat, and `/think` sets how hard it thinks.
  - **Meeting Notes' own:** `/actions`, `/decisions`, `/open` and `/email [to whom]`.
  - **In Live Captions:** also `/missed`, `/sofar` and `/suggest`.
  - **Needs Lumi 1.100.0.**
- **Back and Forward.** After a citation, a mention or a quote opens something else, ‹ and › at the start of the toolbar take you back to what you were reading, and forward again. ⌘[ and ⌘] do the same. A chat comes back scrolled to where you left it. In Live Captions, Ask has them at the top of the chat.

### Changed

- **A citation is a small token,** set after the punctuation it belongs to, as a footnote mark is. A long name is cut short, and its tooltip says it in full.

### Fixed

- A citation of a chat or a meeting that has since been deleted is struck through. It used to be only dimmed.
- In Live Captions, a citation, a mention or a quote of another meeting's chat opens Meeting Notes on that chat. It used to do nothing.
- Back to Summary shows only when you went from the summary to a line, and not when the transcript was already open.

## [0.18.0] - 2026-11-24

### Changed

- **A citation plays and shows each passage of it.** A time in the Summary, a citation in Ask, or one under Live Captions can stand for lines far apart. Lines said one after another are now one passage, and each passage has its own time, Play and Show in Transcript. Play stops at the end of its passage.
- **A file's preview is a window of its own**, as Quick Look's. Move it by its title bar, size it from its corner, fill the window with its green button, and keep working in the page behind it. In Libraries it shows the file you select.
- **An answer says when it searched your libraries by their words.** If Lumi's embedding model stops, Ask still answers, and a line under the answer says so, with Lumi Models… to try the model again. Needs Lumi 1.99.0.

### Fixed

- A menu taller than the window, such as Text Model with a long list, scrolls instead of running past the window's edge.
- Libraries shows that it is loading, and why it could not, with Try Again, instead of an empty page.
- Record… in Get Started opens Settings on Speakers with My Voice's recording, not on the pane Settings was last left on.

## [0.17.0] - 2026-11-24

### Added

- **Ask AI.** Ask about a meeting while it is happening or after it, and get an answer that cites the lines it came from: press a citation to open the meeting at that line. Ask stands beside or under the transcript in the window (⌘J), and folds under Live Captions, where What Did I Miss?, Summary So Far and Suggest a Question are one press away. Lumi's assistant answers with the AI you set up in Lumi, keeps your chats on this Mac, and asks before anything leaves it. Needs Lumi 1.98.0.
- **Chats.** Lumi names each chat from its first answer; in the window, press its name to rename it. Every chat of every meeting is on the Chats page, where you can also ask across all your meetings and select many chats to delete at once. Branch in New Chat goes on from any answer; @ mentions another chat and Quote brings a message into your question; Summarize Earlier Messages shortens a long chat.
- **Files and libraries.** Drop, paste or add files to a chat, and an answer cites the place in them, shown in a preview. The Libraries page keeps files in libraries, laid out as Finder does; mention a library with @ and the chat searches it.
- **Settings › Ask:** where Ask stands, the model a new chat asks and how hard it thinks, the language it answers in, Suggested Questions, About Me, and how long chats are kept, with Delete All Chats….
- **⌘+ ⌘− ⌘0** make a chat's words bigger, smaller and back, as Mail does.

### Changed

- **The live captions' ⋯ menu is shorter and changes things in place.** Appearance (Dark, Light or Match macOS), Text Size and Visible Lines are one row each, three buttons to pick from, and a new Opacity row sets the Background Opacity, filled as far as the captions are opaque. Each moves the captions as you choose and leaves the menu up. Click Through Captions is in the menu too, beside Speaker Labels and Show My Captions. Speech Model is one line naming the model in use; press it for the list. Open Meeting Notes and Settings… are at the foot.
- **Captions can be drawn in a colour of your own.** Text Color and Translation Color, in ⋯ and in Settings › Captions, each offer Yellow, Green, Blue and Pink beside the default, every one in a shade that reads on the captions' dark or light background; a colour you pick follows the captions when their Appearance changes.
- **The 文A button shows Live Translation is on by its colour**, on no blue ground of its own.

### Fixed

- Opening a meeting no longer opens its title for editing.
- A transcript line's language is read from its words, not from the language the model heard.
- A menu lights one row at a time, and none until the pointer or a key reaches it.

## [0.16.0] - 2026-11-22

### Added

- **Quit Meeting Notes**, last in the menu bar item's panel and in its menu. It switches Meeting Notes off in Lumi — its item, its windows and everything it watches for go — and leaves Lumi running. A meeting being transcribed is stopped and saved first, its last words included, and Meeting Notes goes once it is: the row says Saving and Quitting… meanwhile. A paused meeting is ended as Stop ends it. Open Meeting Notes from Applications, Spotlight or the Dock, or switch it on under Extensions in Lumi, to have it back.

### Changed

- **The Details button is an info symbol (ⓘ)** and says Show Details or Hide Details, the name its panel's heading already uses. It drew a sidebar and said Show Inspector.

## [0.15.0] - 2026-11-22

### Added

- **An event's notes in the inspector.** The agenda or anything else written in the notes of the event a meeting is linked to shows under the event, in Notes: its first eight lines and Show All, selectable to copy. What Teams, Zoom or Google Meet pastes under it — the link, the meeting ID, the passcode, the dial-in numbers — is folded under Joining Info until you open it. A meeting linked to its event before this has the notes read the first time you open it. Needs Lumi 1.97.0.
- **A summary says who wrote it.** “Summarized by Claude Opus in Lumi Meeting Notes” — the model that wrote it, or AI where it isn’t known — stands on its own line over the footnote under every summary, Lumi’s mark before it.

### Changed

- **A summary being written shows Lumi's mark**, the bolt in its diamond, painted in the colours of the ring turning round it, where the ✦ stood. No Summary Yet has it too.
- **The summary's mark moves between its places instead of jumping.** Summarize in No Summary Yet glides the mark up to where it works; its bolt flashes and a diamond grows out of it, turning square, into the ring that turns while the summary is written. Stop, from the middle of the page or from the line over the notes, glides it back down as it is, and once it is there the ring shrinks into the diamond as it turns; a run that fails goes back into Couldn't Write the Summary the same way. The line over the notes fades where it stood once the summary is kept or a Regenerate is stopped, and the notes slide into its room — as they slide and dim when a Regenerate's line comes in over them. The ring slows as the model thinks, and stands faint while it waits on you, from the angle it is at rather than jumping to another. With Reduce Motion on, each is simply there.
- **A summary written from the refined transcript says only that** under it, without “heard again”.

### Fixed

- **With Reduce Motion on, the summary's mark holds still while the model thinks.** Its glow went on turning and breathing.
- **Open works right after Meeting Notes is updated.** For a few seconds after an update, the windows it loads ahead took every call it could make at once, and opening Meeting Notes was refused.

## [0.14.1] - 2026-11-22

### Changed

- **The Start page's footer is the copyright alone**, beside Lumi's mark. The link to lumikeys.app is gone from it; Settings › About still has Website.

## [0.14.0] - 2026-11-22

### Added

- **The window opens on a Start page**, as VS Code's Welcome page does: Start Transcription, Search, New Folder, Live Captions and Settings; your recent meetings; what's left to set up; and what's new in this version. It no longer opens the newest meeting by itself. Start, at the top of the sidebar, brings you back to it from a meeting.

### Changed

- **The Welcome tour ends with one button, Open Meeting Notes**, which opens the window on its Start page; Take the tour again moves to the window's foot. Done, which only closed the tour, is gone.

### Fixed

- **A pop-up you can't use now looks it.** In Refine and Translate, Clean Up's Model with Light chosen, and Translate All's Language and Translate With while it's off, kept their full colour beside their greyed-out names, as if they could still be changed; so did Export's Template, Paper Size, Words and Translations. They're greyed out with their names now, as the Speech Model pop-up already was — and so is every other pop-up in Meeting Notes when it's off, and Export's Your Name field when the file has no "Me".
- **The event button's menu lines up as a Mac menu does.** "Events around …" starts at the menu's edge, where the checkmark stands, rather than indented as if it could be chosen, and Open in Calendar has a calendar symbol, its label in line with the events' names. The Calendars pop-up in Settings heads each account the same way.

## [0.13.0] - 2026-11-22

### Added

- **Name a speaker right in Live Captions.** Click their name and a popover opens above the captions, which hold still while you type. Click outside to keep the name; Cancel or Escape keeps nothing.
- **Speakers carry their email address**, from the invitation or typed with the name. The inspector and exported minutes show it, a merge takes it along, and a voice profile keeps it (Settings › Speakers › Edit).
- **Rest the pointer on a person to see their card**, as in Microsoft Teams: what the meeting knows of them — the invitation, the lines they said, their voice profile — and their email address, which a press copies.
- **Hide Invited, in Export’s Customization**, leaves the people invited out of exported minutes. Who spoke is still listed.

### Changed

- **Choose what Live Captions hears above Start Transcription** — where it listens, the languages, the speech model — and name the meeting before it starts, after the calendar event on now. A missing model is one press, Download and Start, with its progress in the button. Starting keeps the captions as they were, a paused meeting has one Resume, and menus open under the button you press.
- **The inspector is a Mac inspector’s form**: rounded groups under titles, Speakers second, each speaker’s Name and Merge Into as buttons on its row. Duration counts up while a meeting is heard, and a meeting that invited more than ten people lists ten and Show All.
- **Naming a speaker offers the people invited as a list you find in**, in the window and in Live Captions: type, or use ↓, ↑ and Return. It stays five rows high however many were invited. The name you pick becomes a chip; take it away with its × or Backspace before typing another.
- **Avatars show two letters, as Teams draws them**, for speakers and the people invited, who each keep a colour of their own.
- **Translate beside a bubble or a line translates it, shows it, or translates it again**, and leaves Show Translations as it is.
- **Scroll to Top and Scroll to Bottom show while you scroll**, and go a moment after you stop.
- **A summary item’s menu has icons**, and the summary’s footnote asks you to double-check what the AI wrote.

### Fixed

- **A meeting whose recording failed or was cut off can be scrubbed through again**; it was kept as 0 s long. Meetings already affected mend when they open.
- **Cancelling a start leaves no meeting behind**, and Live Captions shows Start again once the meeting opens in the window, not “Saved”.
- **Resume under paused captions takes a click with Click Through Captions on.**
- **Listen Again hears with Apple Speech when you choose it**, and says why when another model must. Settings and Live Captions say so too when a Second Language rules Apple Speech out.
- **Only the line under the pointer shows its buttons.** Lines already in the language you translate into show no Translate, and Clean Up, Listen Again and Translate All show their progress on the Transcript tab alone.

## [0.12.0] - 2026-11-21

### Added

- **Words While Speaking**, in Settings › Transcription: choose the model that writes the grey words while someone talks — Apple Speech, or Nemotron 3.5 Streaming, which hears both of a meeting's languages. Speech Recognition still writes each line when they pause, so the words come steadily and the graphics chip is mostly free for the call, though they're less accurate until the pause. Same as Speech Recognition, as before, is the default; a model not on this Mac downloads when you pick it, and a change applies from the next meeting. Needs Lumi 1.95.
- **Translate While Speaking**, in Settings › Translation: with Live Translation on, each sentence is translated before the speaker pauses, as before. Turn it off to translate only each finished line.

### Changed

- **Chat shows a line's actions as you point at it**: Play, Translate, Copy and More beside the bubble, as Paragraphs and Lines show them. The View popover's help is one line.
- **Click a line to play it**, and again to pause it, under the pointing hand; ⌘-click or ⇧-click selects lines. A click used to select and a double-click to play. A line with no audio still selects on a click.
- **Play is Pause while its line plays**, in every layout, and Play again goes on where it stopped. The bars that show a turn playing stand at the speaker's outer edge in Chat, and in place of the speaker's initial in Paragraphs and Lines, so nothing moves when a line starts or stops, and Name… coming and going under the pointer leaves no gap beside them.
- **Your own turns in Chat read "0:32 Me"**, your name at the bubble's edge as other speakers' names are at theirs.
- **Chat's bubbles stop at a comfortable line length** on a wide window — about 65 characters, at every text size.
- **Unlink a meeting's event by pressing it again** in the event menu, where it is ticked; None is gone.
- **In Live Captions, a speaker not known yet is three blinking dots**, as the main window shows words still being heard, where a still "…" stood.

### Fixed

- **A turn says which sentences are not translated yet.** In Chat and Paragraphs, a sentence with no translation shows Translate where its translation would be, a press away; half a turn's translation read as all of it.
- **A finished meeting opens at its start**, not on its last lines. A meeting being transcribed still follows what is said.
- **The bar for several selected lines no longer hides the last ones.**
- In Chat, words fade under the speaker's name as they scroll past it, rather than being cut at its edge.
- **The event menu fits what it holds.** With no event near the meeting it is its heading and Open in Calendar, no wider than they are.
- **With translations beside the words, each language's name stands over its column**, in Lines and Paragraphs. On a wide window the original language's name stood well left of its words.

## [0.11.0] - 2026-11-21

### Added

- **Merge speakers and assign lines.** When one person was heard as two, right-click a line and choose Merge “Speaker 3” Into, or press Merge… beside the speaker in the inspector. When a line went to the wrong person, Assign To moves it — or every selected line — to anyone in the meeting, to you, or to a New Speaker. Both have Undo, and both wait until the meeting ends.

### Fixed

- **Name… opens its card whole**, in the transcript over the turns below it — upward near the transcript's foot — and in the inspector, with no scrollbar of its own. In Lines, a turn's header now holds at the top as you scroll, and its text follows View's size.
- **Listen Again keeps My Voice.** On a call heard again, someone beside you at your microphone was folded into your lines as Me; now, as in Live Captions, only your voice is Me and anyone else there stays their own speaker. In a room, your lines are Me too.

## [0.10.0] - 2026-11-21

### Added

- **A Welcome tour on a fresh install.** The microphone and system audio, your language and its speech model (downloading in the background), your calendar, your name, Keep Audio and summaries, and the keys that start a meeting. Again from Settings › About › Welcome Tour….
- **Pin and folders.** Right-click a meeting to Pin it or Move To a folder, or drag it there. New Folder (⇧⌘N) is named in place, folders keep the order you drag them, and Delete Folder keeps its meetings, with Undo. Sort By date, title or length. The meeting being transcribed stays at the top, in Now.
- **Export… (⇧⌘E) makes a PDF, HTML, Markdown or plain text file** from one sheet: a template — Standard, Minutes or Columns — and the paper; the summary, any version of it, or Summarize… or Regenerate… there; the transcript refined or as heard, its translations (Translate… if there are none yet) and timestamps. Customization names you another way in that file, or leaves out the AI models' names. The preview is the file: PDF and HTML zoom, Markdown and plain text copy — Markdown's Formatted view as rich text. An HTML file has its own Light, Dark and System. Every file ends with "Made with Lumi Meeting Notes". Saved, the message names the file and its folder, with Show in Finder.
- **Your Name in place of "Me"** in every meeting, earlier ones too: Settings › Speakers › Your Name.
- **Quick Translate.** In a meeting with nothing translated, the translate button translates it at once into your Settings' language with your translator, a ring round it showing how far.
- **Meetings named after their calendar events** (Settings › General › Calendar). The event button beside the date links another event or opens it in Calendar; the inspector shows who was invited. Reads your calendar, never changes it.
- **Offers for meetings in a room** as a calendar event with a place starts (Settings › General › Offer For › In-Person Meetings); a call still heard 5 minutes after its event ends offers Stop and Save.
- **Add to Reminders** from the Action Items heading: the items you tick, with a date. Done in Reminders shows done here.

### Changed

- **The sidebar slides** out and in (⌘B), its button beside New Folder.
- **The window shows its name**, Lumi Meeting Notes, at the middle of its title bar.

### Fixed

- **Settings › Storage** gives the transcripts' size without the audio, always shows the Audio section, and Delete All Audio works with hundreds of meetings.
- **Messages** stay at the middle of the window's foot.
- **The Summary tab** shows a spinner, not No Summary Yet, while the summary is read.

Needs Lumi 1.94.0.

## [0.9.0] - 2026-11-20

### Added

- **Refine and Translate.** In the Transcript tab, Refine and Translate… cleans up a meeting that has ended. Light takes out ums and words said twice, on this Mac, with no AI. Full also fixes punctuation, grammar and your Custom Vocabulary terms with the text model you choose, and leaves out any change that would alter what was said. Translate All translates every line not yet translated, or all of them again once every line is. The sheet says how long it takes and which AI calls go where before you start; Stop keeps what's done.
- **Original, Changes and Refined.** See the refined words, what refining changed — taken out struck through, put in underlined — or the words as heard. Revert to Original puts lines, or the whole meeting, back as heard. ⌘Z undoes the last refine or revert, and ⇧⌘Z redoes it. Copy and Export take the version shown.
- **Listen Again.** Hears a meeting's kept audio again with a stronger speech model on this Mac, for truer words and speakers: on a call your lines stay Me, and someone the live transcript mixed up is told apart. The words heard live stay as Original, and the summary's times follow the new lines.
- **Meetings clean themselves up as they end.** Settings › Transcription › After a Meeting: Light by default, for meetings of 3 minutes or more; Full and Listen Again can follow, with the models you choose.
- **Volume in the player.** A speaker button mutes playback; hover over it for a volume slider.
- **⌘B shows or hides the sidebar.**
- **A Changelog tab** beside About on Meeting Notes' page in Lumi's Settings.

### Changed

- **Start Transcription shows Live Captions and closes the Meeting Notes window**, wherever you press it, so you follow the meeting over the call; open Meeting Notes again to read along. To keep the window, set Settings › General › When Transcription Starts to Keep Window Open.
- **Show Translations beside View.** A translate button shows or hides translations, and turns Live Translation on or off while a meeting is heard.
- **Summary choices wait for Regenerate.** A new template, model or language no longer rewrites the summary at once.
- **Icons in the meeting menus**, as macOS menus have them.

### Fixed

- **Settings… opens Meeting Notes Settings.** With the Meeting Notes window in front, Meeting Notes › Settings… and ⌘, open its Settings window and leave the window where it is.
- **The View and date popovers open over the transcript**, no longer under a speaker's name held at the top.

## [0.8.2] - 2026-11-20

### Added

- **Escape closes Settings.** A menu or a sheet open in it, a shortcut being recorded, or a field you're typing in takes Escape first; press it again to close the window.

### Changed

- **A summary writes itself in as the model writes it.** While the transcript is read, the Summary tab shows what's happening where "No Summary Yet" stood, with Stop, and a long meeting's progress fills the ring round its mark. When the model starts writing, the mark moves up to a line that stays at the top as you scroll, and the overview and each item appear as they're written. Regenerate keeps the summary you have, dimmed, until the new one starts.
- **Live Translation keeps up with a long turn.** Each sentence is translated as soon as it's said, while the speaker goes on, instead of once they pause; the rest of the caption follows when it ends. A sentence heard differently a moment later is translated again. With macOS translating (Settings › Translation Engine), the words still being said are translated too, dimmed, and replaced as more is said, then by the caption's own translation when it ends; the AI is never asked for these.
- **Live Captions are ready from the moment Lumi starts**, as the menu bar item's panel is, so the first meeting shows them at once. Lumi's Preload switch for Meeting Notes covers them too.
- **Live Captions step out of the way while you're in the Meeting Notes window watching the meeting being heard**, since the window already shows its words, and come back over every app as soon as you switch to another app or close the window (closing needs Lumi 1.93.0). Start or Resume pressed in the window starts the meeting from there, without the captions flashing up first. Captions you hid yourself stay hidden, and they stay put while Live Translation is by the AI.
- **A meeting is summarized by itself as it ends.** Settings › Summaries' Automatically Summarize When a Meeting Ends, on unless you turn it off, writes the summary with the Default Template as the Meeting Notes window opens on a meeting of 3 minutes or more, in place of Offer to Summarize; Lumi's card at a call's end offers Resume. Set as Default under Templates picks the template.
- **Templates says which are built in**: they're listed under BUILT-IN, yours under YOUR TEMPLATES. A built-in opens with View…, and − says why it can't delete one.
- **The menu bar item's panel has no Live Captions or Live Translation switch any more.** Show Live Captions appears there while you record and the captions are out of sight, and the Meeting Notes window's translate button turns Live Translation on and off while it shows the meeting being heard.
- **A meeting that ends opens in the Meeting Notes window**, and Live Captions go away, instead of staying up to say it was saved: stopped, ended after a pause, or stopped by itself when the call ended.

### Fixed

- **The menu bar item no longer goes on showing a recording after it stopped**: now and then its wave kept moving beside a clock standing at the meeting's last second, with nothing being heard.

## [0.8.1] - 2026-11-19

### Changed

- **A long Chat bubble's speaker stays in sight across the column**, on a band in the window's own background at the top of the transcript, with the words passing under it, instead of floating over them.

### Fixed

- **The inspector's speakers no longer look switched off.** They were drawn at a faint strength, as were Save Voice Profile and a summary template's fields; they're at full strength now, their checkboxes drawn as a Mac's, and a speaker you uncheck is dimmed so the ones shown stand out.
- **Nothing shows above what stays at the transcript's top**: a sliver of words used to peek over a held turn's header or a bubble's speaker.

## [0.8.0] - 2026-11-19

### Added

- **Choose how the transcript reads.** View, beside the tabs, lays it out as Chat (bubbles, yours on the right, as Messages draws them), Paragraphs or Lines, with translations below the words or side by side, four text sizes (⌘+ ⌘−), and Timestamps, Follow Along While Playing and Speaker Colors.
- **Select lines and act on them.** Click, ⇧- or ⌘-click, or ↑ ↓; ⌘C copies, ⌘A selects all, Return plays. Several selected get a bar with Play, Copy and Translate; right-click for Copy with Names and Times, Select Whole Turn, Name and Hide. Name… beside an unnamed speaker names them right there.
- **Follow along while it plays**: the line heard is lit and kept in sight; scroll away and Back to Now Playing returns to it.
- **See who spoke where on the player's scrubber**: point at it and the turn under the pointer lights up, with a tooltip naming the speaker, the time a click plays from, and when the turn starts and ends. ⇧-click plays the turn from its start.
- **Appearance in the toolbar**: a click goes System, Light, Dark; right-click to pick one. The same setting as Settings › General.
- **Every speech model that heard a meeting**, with when it took over, in Details, under the title and in exports.
- **Search finds what was said** in every meeting's transcript, translations and summary. The sidebar shows the meetings that hold your words, their matches and two of their lines: click one to open the meeting there. Without accents a word finds every accent ("hop" finds họp, hộp and hợp); quotes keep a phrase in order.
- **Move from match to match** with ‹ › beside the search, Return or ⌘G (⇧⌘G back), the summary's matches included; each tab says how many it holds. ⌘F goes to the search.
- **Click Through Captions**, in Settings › Live Captions: the captions' text lets clicks, scrolls and hovers through to what's under it; the bar and the panel's edges still take them.
- **Keys for Start, Pause and Stop Transcription**: ⌃⌥⌘1, ⌃⌥⌘2 and ⌃⌥⌘3 in every app, as the menu bar item's rows. Change or clear them in Settings › General › Shortcuts.

### Changed

- **Transcript and Summary are two tabs** under the meeting's title, ⌘1 and ⌘2; the title heads the page over the date and who spoke. Point at a summary's time to read its lines; click it to see them in the transcript, and Back to Summary (⌘[) to return. The player stays under both tabs, and a meeting opens on the tab you left. ⌥⌘S is gone with the pane.
- **The transcript opens as Chat**, headed by when it was heard, the model and the language, with quiets of 15 s or more said between turns. A long bubble keeps its speaker's name in sight as you scroll through it.
- **A meeting where nothing was said says so**, in place of the tabs.

### Fixed

- **Stop on a paused meeting shows it saved** in the window open beside it.
- **The toolbar's buttons work while the search is open**, and the empty field stays open, so the toolbar doesn't move under your pointer; click elsewhere or press Escape to close it.
- **Share is off when there's nothing to share**, as Show Translations is.
- **A meeting is named by the first speech model that heard it**, not the one a change left it on.
- **A narrow transcript stays readable**: translations go under the words, and Lines lets its buttons go.

## [0.7.0] - 2026-11-19

### Added

- **Summarize a meeting.** A Summary pane under the transcript writes an overview, the action items and the sections of a template — General, 1:1, Stand-up, Interview, Customer Call or one of your own — each item with the time it was said: click the time to see those lines in the transcript. Template, model and language are right above it; choosing another writes a new version, and the one before stays a click away with your edits. Edit any item in place, tick action items, choose who owns them; Copy Summary and Copy Action Items paste as Markdown. The summary is written by the text model you set up in Lumi, on this Mac or online — Lumi asks before anything leaves it — and the meeting takes the summary's title while it still has the one Meeting Notes gave it. Drag the pane taller or shorter, make it larger, or fold it away with ⌥⌘S. Needs Lumi 1.92.0.
- **Long meetings are read in parts** when the model you chose can't read them whole, then put together, with a bar of how far it got, the time left and Stop. A stretch that couldn't be read is said at the top of the summary.
- **No text model yet?** Summarize offers one to download, in Lumi's own panel, and goes on once it's ready.
- **Settings › Summaries**: the Text Model, the template and language a summary starts with, and your own templates — a name, instructions, and the sections you want in your order.
- **Summarize from the card when a call ends.** For notes of 3 minutes or more, Lumi's card offers Summarize instead of Resume, and the window opens on the meeting writing it. Turn it off in Settings › Summaries.
- **Exports include the summary.** Export as Markdown or Plain Text puts the summary ahead of the transcript, each item with the time of what it came from; Share › Copy Summary copies it.

### Changed

- **The player is a bar at the foot of the transcript**, in the same place whatever the window shows, with no Close; Space plays and pauses.
- **Scroll to Top and Scroll to Bottom** appear as you scroll a long transcript or summary; Home, End, ⌘↑ and ⌘↓ go there too.
- **Alerts' buttons are drawn as macOS's**, one line each.
- **Live Captions step back while you work in Meeting Notes.** With the Meeting Notes or Settings window in use, the captions no longer cover it: they go behind it, and float over every app again as soon as you go back to another app, or when you click them. Needs Lumi 1.91.0.

### Fixed

- **Menus are drawn in macOS's appearance.** The model pop-ups' menus in Settings, their submenus and Live Captions' ⋯ menu follow macOS's light or dark, as a Mac menu does; they used to follow Lumi's Appearance where you had set it apart from macOS.
- **Live Captions stay in sight over an app in full screen.** They now follow you onto every desktop and over every app in full screen; they used to stay behind on the desktop the meeting was started from, so a call watched in full screen showed no captions.

## [0.6.0] - 2026-11-18

### Added

- **Escape hides Live Captions** once you have clicked the panel, as its Hide button does; with its ⋯ menu open, Escape closes the menu first.
- **Choose and download models in Settings.** Speech Recognition, Speakers Model and Text Model are pop-ups that offer every model Lumi knows: ready on this Mac or online — Lumi Models, Apple Speech, apps such as Ollama and LM Studio, services you have a key for, Claude Code — the ones Lumi can download, with their sizes, and the ones that can't run here, saying why. A provider's models, and the ones that can't run here, open in a submenu beside the menu, as a Mac menu's do. Lumi asks before anything is downloaded; it comes down with a bar, with Cancel where the download can be stopped (macOS's own language downloads can't be), and Meeting Notes uses it once it's ready. Transcription's On This Mac shows the speech model, the speakers model and the translation together. Your choice is kept by Lumi, which shows it under Settings › AI › Extensions & Privacy, where Use My Default puts it back. Needs Lumi 1.90.0.

### Changed

- **Settings shows its name on the title bar's top row**, Meeting Notes Settings, beside the window's buttons, with the panes' buttons under it, as a Mac app's settings window does; it stays the same whichever pane is open.

## [0.5.0] - 2026-11-18

### Added

- **Record Your Voice in English or Vietnamese.** Switch the text to read between English and Tiếng Việt; it starts in your Spoken Language, and Meeting Notes listens in the language you read.

### Changed

- **The Meeting Notes window keeps up with Live Captions.** A meeting being recorded shows in the window as Live Captions shows it, the line being said included, the moment it changes — speaker names and translations too — instead of up to half a minute behind. Needs Lumi 1.90.0; with an older Lumi the window catches up as before.
- **Open Meeting Notes in Live Captions' ⋯ menu opens the meeting being recorded** — or the one paused — rather than whichever meeting the window showed last.

### Fixed

- **Notes stop when the call ends, however you started them.** Notes started with Start Transcription, the menu or a shortcut during a Teams, Zoom, Google Meet or other call now stop and save when that call ends, as notes started from the "Take Notes" offer always did; they used to go on after the call. And notes started after one call has ended are no longer stopped because of it.
- **Record Your Voice is seen whole.** The Speakers pane keeps Settings tall enough for it, so it no longer runs off the bottom of the window; and should its text ever be longer than the window, the text scrolls between the title and the buttons, so Record, Stop and Save stay in reach.

## [0.4.0] - 2026-11-18

### Changed

- **Live Captions move smoothly.** New words glide the captions up instead of jumping them a line at a time; a line heard again shorter no longer pulls everything back down, and only the words a correction changed fade in — words it drops from the end fade out, and words it moves fade back in where they now stand rather than sliding — so you keep your place while reading. Latest glides back down too. With Reduce Motion on, the captions move as before.
- **Live Captions keep their size for a notice.** A notice — a language pack to download, Lumi's recording limit — floats over the top of the captions instead of making the panel taller, so the newest line stays in sight and the panel stays where you put it.

### Fixed

- **A speaker's name held at the top of Live Captions stays put** while their long turn is still being heard; it used to drop and slide back each time the line changed.

## [0.3.0] - 2026-11-18

### Added

- **Meeting Notes in Applications**: open it from Spotlight, the Dock or Launchpad, and its window opens, ready to start a meeting. Opened while Meeting Notes is switched off, it switches it on first.
- Needs Lumi 1.89.0.

## [0.2.0] - 2026-11-18

### Changed

- **A new look, after Apple's design guidelines.** The window keeps your meetings on a floating sidebar, the open meeting's commands as toolbar buttons, and its details, speakers and translation in an inspector; the player floats over the transcript, with skip, speed and Mute Me.
- **Start Transcription is at the foot of the sidebar.** While a meeting is recorded it becomes the recording time with Pause and Stop — click the time to go back to the meeting from any other.
- **Settings has a window of its own**, with panes for General, Transcription, Captions, Translation, Speakers, Storage and About.
- **Live Captions stay out of the way.** While you read, the panel shows the captions, the recording time and Lumi's mark — nothing else. Point at it and the controls come in: click the red time to stop. The panel keeps its size, is frosted glass in its own appearance and turns solid under the pointer.
- **Translate a caption** from the button it shows when you point at it.

### Added

- **Copy one line**, with who said it, from its hover buttons or its menu.
- **Open the meeting being recorded** by clicking its card in the menu bar panel.
- **Full screen**: the sidebar's button and the recorder move into the corner the window buttons leave.

### Fixed

- Meeting Notes no longer asks Lumi for too much at once every time a meeting being recorded is saved.

## [0.1.0] - 2026-10-25

### Added

- **Live captions for your meetings**, in a panel that floats above your call: what is said, as it is said, with **speaker identification** — saved voice profiles by name, everyone else as Speaker 1, 2, 3 — and your own lines as Me.
- **Meetings in two languages**: set a Second Language in Settings, and each line is written in whichever of the two it was said in. Translation translates each line from its own language and leaves the lines already in the language you translate into.
- **Translation on request**: click a caption to translate it, or turn on **Live Translation**, with Apple Translation on this Mac or the AI model you set up in Lumi.
- **Every meeting saved as a transcript** in the Meeting Notes window, to read, copy or export as Markdown or plain text.
- **Read what one speaker said**: click a speaker above a transcript to show only their lines, click others to add theirs, and Reset shows everyone again. The chevron beside a speaker names it, right there.
- **Voice profiles**: name a speaker during or just after a meeting and save the profile, and Meeting Notes identifies them in every meeting after.
- **My Voice**: record your own voice in Settings, with the steps and a text to read, so in a call your lines are Me and anyone else heard by your microphone is shown as another speaker.
- **Listen back to a meeting**: with Keep Audio on, each meeting's audio is kept with its transcript. Click a line's time to hear it from there, the line being heard lit, at 1×, 1.5× or 2×, and in a call **Mute Myself** plays it without your microphone; Save Audio… writes it as an .m4a, into a folder you choose in Settings or wherever you pick. Delete All Audio in Settings removes it and keeps the transcripts.
- **Long meetings**: a recording runs up to two hours by default; set **Longest Recording** in Settings, up to eight hours, and **Auto-Resume at Recording Limit** goes on in the same meeting once it is reached.
- Hints as you point at a button, a speaker or a caption, and why a button is off — in the captions panel too.
- **Notices a meeting starting**: when Microsoft Teams, Zoom, FaceTime or another call app — or Google Meet, Teams or Zoom in a browser — starts using your microphone, a **Take Notes** button comes up at the top right of your screen. Meeting Notes never starts by itself. When the call ends, the notes stop and are saved, with **Resume** if it was too soon — or it asks first, or keeps recording, as you choose in Settings, where each call app has a switch (Slack is off, since it holds the microphone outside huddles too) and the meeting sites are a list you can edit.
- Opens from its own menu bar item, or with ⌃⌥⌘M.
- Needs Lumi 1.65.0.

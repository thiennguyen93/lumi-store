function e(){let e=window.lumiOffer;if(e)return e;let t=new URLSearchParams(location.search).get(`data`)??JSON.stringify({meeting:`9f2c0a1b2c3d4e5f`,heading:`The Zoom call ended`,title:`Design Review`}),n={leftMs:15e3,lifeMs:15e3,running:!0,held:!1,at:performance.now()};return queueMicrotask(()=>window.dispatchEvent(new CustomEvent(`lumi-offer`,{detail:n}))),{data:t,get life(){return n},press:(e,t)=>console.info(`dev: press ${e} ${t??``}`),hold:()=>{}}}var t=e(),n=(()=>{try{let e=JSON.parse(t.data??`{}`);return{meeting:e.meeting??``,heading:e.heading||`The call ended`,title:e.title??``}}catch{return{meeting:``,heading:`The call ended`,title:``}}})(),r=window.matchMedia(`(prefers-reduced-motion: reduce)`),i=17,a=2*Math.PI*i,o=document.getElementById(`card`);o.innerHTML=`
  <div class="ended-row">
    <div class="ended-ring" aria-hidden="true">
      <svg viewBox="0 0 40 40"><circle class="track" cx="20" cy="20" r="${i}"/><circle class="fill" cx="20" cy="20" r="${i}" stroke-dasharray="${a}" transform="rotate(-90 20 20)"/></svg>
      <span class="ended-count"></span>
    </div>
    <div class="ended-words">
      <div class="ended-heading"></div>
      <div class="ended-said" aria-live="polite"></div>
    </div>
  </div>
  <div class="ended-acts">
    <button type="button" class="ended-button" data-press="keep">Continue Recording</button>
    <button type="button" class="ended-button primary" data-press="save">Save Now</button>
  </div>
`;var s=o.querySelector(`.fill`),c=o.querySelector(`.ended-count`),l=o.querySelector(`.ended-said`);o.querySelector(`.ended-heading`).textContent=n.heading;var u=n.meeting;o.querySelector(`[data-press="keep"]`).addEventListener(`click`,()=>t.press(`keep-recording`,JSON.stringify({meeting:u}))),o.querySelector(`[data-press="save"]`).addEventListener(`click`,()=>t.press(`stop-and-save`,JSON.stringify({meeting:u})));function d(e){return Math.max(0,e.leftMs-(e.running?performance.now()-e.at:0))}var f=t.life,p=0;function m(e,t=``){l.firstElementChild||(l.innerHTML=`<span class="what"></span><span class="tail"></span>`),l.querySelector(`.what`).textContent=e,l.querySelector(`.tail`).textContent=t}function h(){if(p=0,!f)return;let e=d(f),t=Math.ceil(e/1e3),i=r.matches?t*1e3:e;s.style.strokeDashoffset=String(a*(1-Math.min(1,i/Math.max(1,f.lifeMs)))),c.textContent=String(t),m(`Saving ${n.title?`“${n.title}”`:`the notes`}`,f.running?``:` when you move away`),f.running&&e>0&&(p=requestAnimationFrame(h))}window.addEventListener(`lumi-offer`,e=>{f=e.detail,p&&cancelAnimationFrame(p),h()}),h();
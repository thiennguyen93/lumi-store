import{O as e,d as t}from"./jsx-runtime-S_R7ohp4.js";import{n}from"./protocol-CUooD8jj.js";var r=e();function i(){let e=()=>{let e=document.documentElement.dataset.theme;return e===`dark`||e===`light`?e:matchMedia(`(prefers-color-scheme: dark)`).matches?`dark`:`light`},[t,n]=(0,r.useState)(e);return(0,r.useEffect)(()=>{let t=matchMedia(`(prefers-color-scheme: dark)`),r=()=>n(e());t.addEventListener(`change`,r);let i=new MutationObserver(r);return i.observe(document.documentElement,{attributes:!0,attributeFilter:[`data-theme`]}),()=>{t.removeEventListener(`change`,r),i.disconnect()}},[]),t}var a=`# Meeting Notes — live captions for meetings, with speaker identification,
# translation on request, and every meeting kept as a transcript.
#
# Lumi hears the call and the microphone, tells the voices apart and
# transcribes them; everything about the captions, the meetings and their
# window is this extension's. The design is the 0.1 plan; the windows and
# menus follow the approved mock.

[extension]
id = "dev.thiennguyen.meeting"
name = "Meeting Notes"
version = "0.26.0"
description = "Live captions for your meetings, with speaker identification and translation on request."
author = "Thien Nguyen"
summary = "Live captions for your meetings, in the language they are spoken, with speaker identification: voices you saved a profile for by name, everyone else as Speaker 1, 2, 3. Translate any caption with a click, or turn on Live Translation. Every meeting is saved on this Mac as a transcript to read, copy or export. Transcription, speaker identification and translation run on this Mac unless you choose an online model, and Lumi asks before anything leaves it."
homepage = "https://lumikeys.app/extensions/dev.thiennguyen.meeting/"
# The store page's pictures, 1280 × 800, published beside the package —
# Lumi's installer ignores the key. Taken from the dev mock's store pages
# (\`?store=call\` and \`?store=window\`, web/src/dev/store.tsx, where the
# mock writes the summary, and \`?ask=store\` Ask's answers, as a model
# would) with lumi-store's preview server, from the spec and scenes
# beside them (shots/promo.json, shots/scenes/), which stay here with the
# source. Picture 7's PDF is the component's own layout
# (shots/minutes.rs). Taken with Chrome's TZ set so the clock reads
# mid-morning.
# The store page's film, on YouTube (Lumi's installer ignores the key,
# as it does the pictures). Made in lumi-store-videos, films/d-launch.
video = "https://youtu.be/-q1dCJIzbEk"
screenshots = ["shots/1-captions.png", "shots/2-translate.png", "shots/3-ask.png", "shots/4-summary.png", "shots/5-transcript.png", "shots/6-files.png", "shots/7-export.png", "shots/8-private.png"]
# 1.64.0: \`transcribe\` with a call's two streams, speaker identification
# and voice profiles (\`voices\`), and \`audio-levels\`. 1.65.0: the menu bar
# item's animated icon while transcribing (\`menu-bar-item.set-animated\`),
# which the component imports, so a 1.64.0 Lumi would refuse to load it;
# and \`recordings.keep\`, each part's audio kept as a file of this
# extension's own (\`keep-audio\`). A debug Lumi measures floors as the next
# minor release, so a dev build of 1.64.0 takes it.
# 1.89.0: the \`launcher\` capability and \`[launcher]\` below — the app in
# Applications — which an older Lumi refuses. What set the floor before it
# is said above.
# 1.90.0: \`models\` — each task's models listed, downloaded from Settings'
# pop-ups in Lumi's panel, and Meeting Notes' own choice kept by Lumi — which
# the component imports, so an older Lumi would refuse to load it.
# 1.91.0: \`ui.set-floating\` — Live Captions let down behind the Meeting Notes
# or Settings window the person is working in — another import.
# 1.92.0: \`ai.limits\` — what a call to the chosen model takes, so a meeting
# is read whole when it fits and in parts only past that — which the summary
# imports. Lumi 1.91.0 shipped without it and refuses the component.
# 1.93.0: \`transcribe.complete-with\` — a meeting's kept audio heard again
# (Listen Again), its progress told to the window and a call's two sides
# heard apart — another import.
# 1.95.0: \`transcribe.start-live\` and \`models.live-text\` — Words While
# Speaking, the grey words written by a second, lighter model while Speech
# Recognition writes each line — another import.
# 1.97.0: \`calendar.notes\` — the notes of the event a meeting is linked to,
# its agenda shown in the inspector — another import.
# 1.98.0: \`agent-preview1\`, Lumi's agent, which Ask AI runs on behind its
# flag (\`src/ask.rs\`) — another import. (Lumi agent A1, 2026-11-22: the
# release that carries the preview; to be confirmed when it ships.)
# 1.100.0: \`agent.send\` and \`agent.slash-commands\`, slash commands in Ask
# (\`[[agent.slash-command]]\` below) — two more imports.
# 1.101.0: \`translation.detect-many\`, every sentence of a meeting's lines
# told apart in one call (\`words::written_all\`), where a call a sentence
# ran an old meeting's first open out of its 200 — another import. Also
# \`agent.library-put-with\`, \`agent.library-facts\` and \`agent.send-with\`:
# each meeting's time, people and kind kept beside it in \`meetings\`, and an
# ask across meetings narrowed to the ones picked (\`ask::ScopeAsked\`).
# 1.102.0: \`offer.keep\`, \`offer.spend\`, \`offer.let-go\` and the \`kept-press\`
# event, and the \`audio-output-use\` capability and event — Join and Take
# Notes waits for the join (\`calendar::take_notes_for\`, \`join_check\`) — and
# \`offer.show-view\` / \`offer.is-up\`, the call-ended card's page
# (\`detect::heard\`). An older Lumi refuses the capability.
# 1.103.0: the \`interrupted\` event — what Lumi cut short when Meeting Notes
# was switched off or Lumi quit, put right (\`src/interrupted.rs\`) — which an
# older Lumi refuses by name.
min-lumi-version = "1.103.0"
# speech + microphone + system-audio: a call's two sides, Me and the others.
# voices: speakers named where a saved voice profile speaks
# (\`speakers: named\`), and saving a profile the person names.
# audio-levels: the panel's input level bars — loudness only, no bands.
# ai: the AI model as the Translation Engine beside Apple Translation.
# clipboard: Copy Transcript in the Meeting Notes window.
# menu, menu-bar-item: the item in the menu bar, its panel and its menu.
# preload: the item's panel and the captions loaded ahead, so the first click
# and the first meeting show them at once.
# keep-audio: each part's audio kept, with Keep Audio on, to listen back to.
# microphone-use: which apps have a microphone open, so a call starting is
# noticed (\`src/detect.rs\`) — never what they hear.
# microphone-sites: which site a browser using the microphone shows, by host,
# so Google Meet or Teams in a browser is noticed too.
# audio-output-use (Lumi 1.102.0): which apps play audio — with the
# microphone, the join itself: Up Next's Join and Take Notes spends its kept
# press once the call both listens and plays (\`calendar::join_holds\`), so a
# lobby is not in the notes. Never what they play.
# offer: "Microsoft Teams is using your microphone — Take Notes", a line and a
# button Lumi draws; the press starts the notes. Never a start by itself. A press
# kept for a join (\`offer.keep\`, Lumi 1.102.0) starts them as that press.
# calendar (Lumi 1.94.0): the event a meeting is, to name it and know who was
# invited (\`src/calendar.rs\`) — read with Meeting Notes' own Calendars grant,
# asked from Settings' switch or the header's Link Calendar Event….
# reminders (Lumi 1.94.0): a summary's action items added to Reminders, and
# whether those are done (\`src/reminders.rs\`), with its own Reminders grant.
# timers: woken as a meeting in a room starts, to offer Take Notes for it.
capabilities = ["speech", "microphone", "system-audio", "voices", "audio-levels", "ai", "clipboard", "menu", "menu-bar-item", "preload", "keep-audio", "microphone-use", "microphone-sites", "audio-output-use", "offer", "launcher", "calendar", "reminders", "timers"]
# How long a meeting is recorded before it stops by itself: two hours, where
# Lumi starts an extension that says nothing at half an hour. The person
# moves it on Meeting Notes' Permissions sheet, and theirs then holds.
longest-recording-minutes = 120
# The item's menu opens the window first; a right-click opens it directly.
# Lumi's own Settings… row is left out: the settings are in the window.
menu-bar-item-right-click = "open"
menu-bar-item-settings = false
# The window the settings live in (Lumi 1.93.0): the app menu's Settings…
# (⌘,), drawn under "Meeting Notes" while the Meeting Notes window is in
# front, opens it, as the window's Settings button does. Lumi's menu takes
# ⌘, before the page hears it, so this is the only way the key reaches
# them; without it Settings… opened Meeting Notes' page in Lumi, whose
# Settings tab is hidden below.
settings-window = "settings"
# The captions panel's ⋯ menu put away — a row chosen, Escape, a press
# anywhere else — told to the captions panel, which is solid while it is up.
# And which apps use a microphone, the whole set as it changes: a meeting
# starting or ending (\`src/detect.rs\`). The calendars changing (the next
# meeting in a room may be another), Reminders changing (an action item done
# there), and the in-person timer (Lumi 1.94.0). A press kept for a join
# ending (\`kept-press\`, Lumi 1.102.0): Up Next's Join and Take Notes, run or
# not (\`calendar::kept_ended\`). Which apps play audio (\`audio-output-use\`,
# Lumi 1.102.0): with the microphone, the join we spend that press on
# (\`calendar::join_check\`). What Lumi cut short (\`interrupted\`, Lumi
# 1.103.0): a refine or a summary under way, a join waited for, the meeting
# being heard, an offer up — gone when Meeting Notes was switched off or
# Lumi quit, told at the switch back on or the next launch.
events = ["window-closed", "microphone-use", "audio-output-use", "calendar-changed", "reminders-changed", "timer", "kept-press", "interrupted"]

# Meeting Notes in Applications (Lumi 1.89.0): opening it from Spotlight, the
# Dock or Launchpad switches Meeting Notes on if it was off, then opens its
# main window, where a meeting is started.
[launcher]
opens = "window"
window = "main"

[[command]]
name = "open"
label = "Open Meeting Notes"
icon = "icons/notebook-text.svg"

# The item's menu rows of the same names, from a key (the [[shortcut]]s
# below). Each does what its row does — Start goes on in a paused meeting, as
# the menu's Resume; Stop ends a paused one — and does nothing where the menu
# has no such row (\`live::start_command\`).
[[command]]
name = "start"
label = "Start Transcription"
icon = "icons/audio-lines.svg"

[[command]]
name = "pause"
label = "Pause Transcription"
icon = "icons/pause.svg"

[[command]]
name = "stop"
label = "Stop Transcription"
icon = "icons/square.svg"

[[command]]
name = "start-stop"
label = "Start or Stop Transcription"
icon = "icons/audio-lines.svg"

[[command]]
name = "toggle-captions"
label = "Show or Hide Live Captions"
icon = "icons/captions.svg"

# Take notes of the meeting found — the offer's button and the menu's row
# (\`src/detect.rs\`) — or resume the meeting an offer names. Start only: a
# stale press never stops anything.
[[command]]
name = "take-notes"
label = "Take Notes"
icon = "icons/audio-lines.svg"

# Stop the meeting an offer names — "The call ended", "Nothing heard for 10
# minutes" — and only if it is the one being heard.
[[command]]
name = "stop-and-save"
label = "Stop and Save"
icon = "icons/square.svg"

# Go on recording past the call — the call-ended card's Keep Recording,
# shown while the notes wait to be saved — and only the meeting it names.
[[command]]
name = "keep-recording"
label = "Keep Recording"
icon = "icons/audio-lines.svg"

# Summarize the meeting a call-ended card names — the card's Summarize, for
# meetings of 3 minutes or more — or, from a shortcut, the newest meeting
# that has ended: the window opens on it and writes its summary there
# (\`src/summary.rs\`).
[[command]]
name = "summarize"
label = "Summarize Last Meeting"
icon = "icons/sparkles.svg"

# The caption just said, translated under it on the panel. No key of its
# own; a row in Lumi's Shortcuts pane can run it.
[[command]]
name = "translate-last"
label = "Translate Last Caption"
icon = "icons/languages.svg"

# Extension-scoped, armed at install, in every profile. Recorded and changed
# in the window's Settings, the one place they are set
# (\`POST /__lumi__/shortcut-recording\`, \`PUT /__lumi__/shortcuts\`), so
# Lumi's Shortcuts tab is hidden below.
[[shortcut]]
command = "open"
key = "ctrl+alt+cmd+m"

[[shortcut]]
command = "toggle-captions"
key = "ctrl+alt+cmd+c"

# Start, Pause and Stop on ⌃⌥⌘ and the digits, in the menu's order: ⌃⌥⌘S
# and ⌃⌥⌘P are Sticky's and Floating Browser's keys, and macOS's own ⌃⌥⌘
# keys (8, comma, period — Accessibility's, shipped off) are none of these.
# A key somebody holds at install is not armed; Settings says who has it.
[[shortcut]]
command = "start"
key = "ctrl+alt+cmd+1"

[[shortcut]]
command = "pause"
key = "ctrl+alt+cmd+2"

[[shortcut]]
command = "stop"
key = "ctrl+alt+cmd+3"

# The live captions. Floats over every app (focus = false: never takes the
# keyboard, up until put away), kept while hidden so the transcription goes
# on, where the person left it. HUD glass, which blurs what is behind it as
# the HIG pass's mock does, in the panel's own Appearance (the page tells
# Lumi, \`look\`); the page paints its tint over it at the opacity the person
# chose.
[[window]]
name = "captions"
title = "Live Captions"
path = "captions.html"
kind = "panel"
position = "bottom-right"
focus = false
material = "hud"
width = 720
height = 156
min-width = 360
min-height = 72
keep-alive = true
# Loaded ahead, as the item's panel is: the captions show at once when the
# first meeting after Lumi starts begins, rather than a beat later (the
# owner, 2026-11-19). The page is the kept page it always was, hidden till
# shown; its first \`state\` (\`loaded\`) now runs at launch, so a meeting cut
# off when Lumi stopped is saved then, not at the next meeting.
preload = true
remember-frame = true
# On every desktop, over every app in full screen. A panel otherwise stays
# on the desktop it was shown on, and an app put in full screen is a
# desktop of its own: the captions were left behind on the desktop the
# meeting was started from while the person watched the call in full
# screen. Lumi 1.65.0; an older Lumi ignores the key.
all-desktops = true
# With Click Through Captions on, the captions' text lets every click, scroll
# and hover through to what is under it — the call, a shared slide — while
# the bar, its buttons, the strip and the edges take them (\`click-through\`,
# Lumi 1.78.0; the page names what takes, \`web/src/captions/clickThrough.ts\`).
click-through = true

# ⋯'s menu on the live captions, and the pop-ups' above Start: a panel of
# its own, so it opens whole over every app however few lines the captions
# show, and the captions can still be dragged up to the menu bar — a band
# around them (\`overhang\`) kept them that far from it. It hangs from the
# button pressed, its left edge on the button's, as a pop-up's menu does —
# the page names the button's box first (\`/__lumi__/anchor-box\`) — and over
# it where the display has no room below. It stood at the pointer, so the
# same pop-up opened its menu wherever on its words it was pressed (the
# owner, 2026-11-21: "match a select's dropdown"). It takes the keyboard,
# as a menu does: Escape or a press anywhere else puts it away, and the
# arrows walk its rows. A Mac menu's glass; kept and loaded ahead so it
# opens at once, fitted by its page. No button for it anywhere: only ⋯ and
# the pop-ups know where it goes.
[[window]]
name = "captions-menu"
title = "Live Captions Menu"
path = "captions-menu.html"
kind = "panel"
position = "window"
anchor = { window = "captions", at = "start", side = "below" }
material = "popover"
width = 280
height = 180
keep-alive = true
preload = true
listed = false

# Naming a speaker from the captions panel: a popover of its own over the
# panel, its arrow down onto the column of the label pressed — the page
# names that box (\`/__lumi__/anchor-box\`): the label's width at the panel's
# top edge — so what the speaker is saying stays in sight while the person
# works out who it is (the owner's pick, 2026-11-21, of three mocked: A).
# The window's inspector's naming card on the HIG's popover: a press
# outside puts it away keeping the name typed. It takes the keyboard to be
# typed in, and hands it back to whatever had it when it goes. Kept and
# loaded ahead, so it opens at once; it reads what it was opened for
# (\`name-asked\`) each time it is shown, and fits itself to it.
[[window]]
name = "speaker-name"
title = "Name Speaker"
path = "speaker-name.html"
kind = "panel"
position = "window"
anchor = { window = "captions", at = "center", side = "above" }
material = "popover"
arrow = true
focus = true
width = 300
height = 200
keep-alive = true
preload = true
listed = false

# The lines an Ask answer cites, peeked at from Live Captions: a popover of
# its own over the captions panel, its arrow on the time hovered — the page
# names that box (\`/__lumi__/anchor-box\`). Drawn inside the captions panel,
# the card was cut by the panel's own edges (2026-11-23). It never takes the
# keyboard, so a hover leaves it where it was; the captions panel tells it
# what to show and puts it away. Kept and loaded ahead, so it opens at once.
[[window]]
name = "cite-peek"
title = "Cited Lines"
path = "cite-peek.html"
kind = "panel"
position = "window"
anchor = { window = "captions", at = "center", side = "above" }
material = "popover"
arrow = true
focus = false
width = 300
height = 120
keep-alive = true
preload = true
listed = false

# Settings' model pop-ups' menu — Speech Recognition, Speakers Model, Text
# Model: every model Lumi knows for the task, as long as its list. A panel
# of its own hanging from the pop-up pressed, as a pop-up's menu does: the
# page names the button's box (\`/__lumi__/anchor-box\`, Lumi 1.72.0) and Lumi
# stands the panel under it, its right edge on the button's — over it when
# the display has no room below. Being a panel, it opens whole over
# everything as tall as the screen allows, rather than inside the Settings
# window, which had to grow for it or have it scroll. It takes the keyboard
# as a menu does: Escape or a press anywhere else puts it away. Kept and
# loaded ahead, so it opens at once; it reads which task it was opened for
# (\`model-menu-asked\`) and the task's models each time it is shown, and fits
# itself to them.
[[window]]
name = "model-menu"
title = "Models"
path = "model-menu.html"
kind = "panel"
position = "window"
# Beside Settings, or the Meeting Notes window, whichever asked (Lumi
# 1.93.0): the Refine sheet picks Listen Again's speech model in it too.
anchor = { window = ["settings", "main"], at = "end", side = "below" }
material = "popover"
width = 320
height = 240
keep-alive = true
preload = true
listed = false

# A submenu of the model menu — a provider's models, what can't run here —
# beside the row it came from, as a Mac submenu opens: Lumi stands it to the
# menu's right, or left where the display has no room, its first row level
# with that row (the menu names the row's box, \`/__lumi__/anchor-box\`). It
# never takes the keyboard, so the menu stays up and keeps it; the menu walks
# the submenu's rows with the arrows by telling it (\`/__lumi__/post\`), and a
# row clicked is a press. It goes when the menu goes. The menu tells it the
# rows to draw, so it opens at once without reading the models itself.
[[window]]
name = "model-submenu"
title = "Models"
path = "model-submenu.html"
kind = "panel"
position = "window"
anchor = { window = "model-menu", at = "start", side = "trailing", follow = true }
focus = false
material = "popover"
width = 240
height = 120
keep-alive = true
preload = true
listed = false

# What a click on the menu bar item opens, under it (option C of the mock):
# Start or Stop Transcription, three switches, the last meetings, and the
# window. Lumi's popover glass with an arrow at the item, Gõ tiếng Việt's
# arrangement; kept loaded and loaded ahead so the first click opens it at
# once, and fitted by its page to what it shows. With it, the item's menu
# answers VoiceOver; a right-click still opens the window.
[[window]]
name = "popover"
title = "Meeting Notes"
path = "popover.html"
kind = "panel"
position = "menu-bar-item"
anchor = { at = "center" }
material = "popover"
arrow = true
keep-alive = true
preload = true
width = 320
height = 300

# The extension's own window: the meetings. Opened from the item's panel, a
# right-click on the item, the shortcut and the captions panel. Kept and
# loaded ahead (Lumi 1.65.0), as an app's window is: closing it hides it, and
# it opens at once, as it was — loaded when Lumi starts, under the same
# switch as the item's panel.
[[window]]
name = "main"
# The name its title bar shows too (\`.mw-title\`), so the Window menu and
# Mission Control say what the window does (the owner, 2026-11-21).
title = "Lumi Meeting Notes"
path = "index.html"
titlebar = "unified"
width = 960
height = 640
min-width = 720
min-height = 460
remember-frame = true
keep-alive = true
preload = true

# Settings, as a Mac app's are: a window of its own with a pane per toolbar
# button — General, Calendar, Transcription, Captions, Translation,
# Summaries, Ask, Speakers, Storage, and About, which has no app menu to live in since the menu bar's About is
# Lumi's. It was a view of the main window; Apple's guidelines keep settings
# out of an app's main window. The page fits the window's height to each
# pane, so it is not resizable; and close is all a settings window needs:
# minimise and zoom are greyed (the owner's choice, 2026-11-18, over
# \`window-buttons = "close"\`, which takes them off the title bar — a greyed
# pair keeps the row every Mac window has). It opens
# where it was left, and is kept while it is closed so the pane and the
# place in it stay. On install it opens on Transcription, whose On This Mac
# is what a first meeting needs.
[[window]]
name = "settings"
title = "Meeting Notes Settings"
path = "settings.html"
titlebar = "unified"
# The title's row: the window's name centred on it, the traffic lights on it
# too, as a Mac app's settings window has them; the page draws the panes'
# buttons under it.
titlebar-height = 32
# Wide enough for ten panes' buttons in one row (Calendar, 2026-11-25, was
# the tenth; 680 held nine).
width = 760
height = 560
resizable = false
maximizable = false
minimizable = false
remember-frame = true
keep-alive = true

# A file of an Ask chat or a library, in a window of its own (the owner's
# pick of three mocked layouts, 2026-11-26). It was a box drawn in the page
# with traffic lights drawn on it, and its green button zoomed those onto
# the window's own. Here macOS draws the title bar and runs its buttons,
# and the page draws the file's name and facts on it, as Settings does.
# One window, as Quick Look's: opening another file replaces the one shown.
# Kept and loaded ahead, so a chip or a cite pressed opens it at once —
# which is why it is one window, since a declaration with copies can be
# neither. Its first opening is wherever macOS puts a new window; after
# that, where it was left. Beside the main window waits on Lumi.
[[window]]
name = "preview"
title = "File Preview"
path = "preview.html"
titlebar = "unified"
titlebar-height = 38
width = 640
height = 640
min-width = 360
min-height = 280
remember-frame = true
keep-alive = true
preload = true

# The Welcome tour (the owner's mock, 2026-11-20): what a first meeting
# needs — the microphone and system audio, the speech model, the calendar,
# the person's name and keys — each asked or downloaded from a press in it,
# then a finish. Opened by a fresh install (\`installed\`, src/lib.rs), never
# by an update, and again from Settings › About › Welcome Tour… and Lumi's
# About page. Laid out for this size and no other, as Clipboard Manager's,
# Screenshot's, Selection Bar's and Gõ tiếng Việt's tours are: a stage on
# top, the words under it, a footer. The page draws the title on the
# traffic lights' row, as Settings does, so a download going on behind the
# tour has a place at its right end. Not kept: each opening reads where
# things stand afresh, from the first step.
[[window]]
name = "welcome"
title = "Welcome to Meeting Notes"
path = "welcome.html"
titlebar = "unified"
titlebar-height = 32
width = 680
height = 600
resizable = false
maximizable = false

# Lumi's page for the extension shows its Changelog and About: settings
# and shortcuts live in the Settings window. The [[settings]] below still
# hold the values — Lumi keeps and checks them, every page hears
# \`lumi:settings\` — only their tab is hidden.
#
# The Changelog is Lumi's own tab, drawn from the CHANGELOG.md the package
# carries, as Metronome's is — no \`[tabs.changelog]\` at all. It was hidden
# while the Settings window's About › What's New was the one place to read
# it; that page stays, and the tab is where somebody looking at the
# extension in Lumi's Settings expects the history, beside every other
# extension's.
[tabs.settings]
hidden = true

[tabs.shortcuts]
hidden = true

# Every value is the Mac's, not a profile's: the person's languages and the
# captions' look do not change with a Lumi profile. Values arrive as text,
# the way Lumi's own form saves them; the window draws them all.

# The Meeting Notes window's look, apart from the captions panel's (\`look\`).
# The item's panel keeps macOS's: its glass is drawn by macOS.
# Ask AI (\`src/ask.rs\`, behind \`extension:meeting:ask\`): the meeting
# assistant, Lumi's agent with Meeting Notes' words
# (\`meeting-notes-ask-ai-tech.md\` §5.1). One for the window and the captions:
# a chat keeps its agent, and Open in Meeting Notes continues the captions'
# chat in the window. The captions' brevity is each ask's note and length.
[[agent]]
name = "meeting"
label = "Meeting Assistant"
description = "Answers from your meetings, citing the lines it read."
instructions = "agents/meeting.md"
thinking = "off"
max-tokens = 2048
reading = "fit"
grounding = "sources"
libraries = ["lumi", "meetings"]

# The agent's own slash commands (Lumi 1.100.0), beside Lumi's /clear,
# /compact, /retry, /title and /think. The three one-press asks are
# handled: Lumi gives them back to \`ask.rs\`, which asks them as their chip
# does — and only while a meeting is heard, so the window's menu leaves them
# out. The rest are prompts Lumi asks, from ui/commands/.
[[agent.slash-command]]
name = "missed"
description = "What did I miss?"
handled = true

[[agent.slash-command]]
name = "sofar"
description = "Summary so far"
handled = true

[[agent.slash-command]]
name = "suggest"
description = "Suggest a question to ask now"
handled = true

[[agent.slash-command]]
name = "actions"
description = "My action items"
prompt = "commands/actions.md"

[[agent.slash-command]]
name = "decisions"
description = "What was decided"
prompt = "commands/decisions.md"

[[agent.slash-command]]
name = "open"
description = "What's still open"
prompt = "commands/open.md"

[[agent.slash-command]]
name = "email"
description = "Draft a follow-up email"
argument-hint = "[to whom]"
prompt = "commands/email.md"

[[settings]]
name = "appearance"
label = "Appearance"
kind = "segmented"
default = "system"
scope = "mac"

[[settings.options]]
value = "dark"
label = "Dark"

[[settings.options]]
value = "light"
label = "Light"

[[settings.options]]
value = "system"
label = "Match macOS"

[[settings]]
name = "hear"
label = "Audio Source"
kind = "select"
default = "call-everything"
scope = "mac"

[[settings.options]]
value = "call-everything"
label = "System audio and microphone"

[[settings.options]]
value = "call-app"
label = "One app and microphone"

[[settings.options]]
value = "microphone"
label = "Microphone only"

# A language id ("en"); the window draws it as a picker.
[[settings]]
name = "language"
label = "Spoken Language"
kind = "text"
default = "en"
scope = "mac"

# A second language spoken in the meetings, a language id, or empty for
# none: Lumi hears each line in whichever of the two it was said in. The
# window draws it as a picker beside Spoken Language.
[[settings]]
name = "secondLanguage"
label = "Second Language"
kind = "text"
default = ""
scope = "mac"

# The two languages last chosen together, "en,vi", kept by the captions'
# Languages pop-up when one of them is chosen alone, so the pop-up can still
# offer the two (\`web/src/captions/look.ts\`'s \`languageChoices\`). Nothing
# else reads it: what a meeting is heard in is the two settings above.
[[settings]]
name = "languagePair"
label = "Language Pair"
kind = "text"
default = ""
scope = "mac"

# Before Lumi 1.90.0 kept Meeting Notes' own model per task (\`models.choose\`),
# its id was this setting's: an update hands it to Lumi once and clears it
# (\`src/catalog.rs\`). Kept declared so that value can still be read; nothing
# writes it since.
[[settings]]
name = "speechModel"
label = "Speech Model"
kind = "text"
default = ""
scope = "mac"

# Words While Speaking: the model that writes the grey words while someone
# talks — an id from Lumi's \`models.live-text\`, Apple Speech as
# \`apple-speech:apple-speech\` — or empty for Same as Speech Recognition,
# whose model writes both. The window draws it as a pop-up under Speech
# Recognition; Meeting Notes keeps it, since no task of Lumi's names these
# models (\`src/catalog.rs\`). Read as a meeting begins: a meeting gone on in
# keeps what it began with.
[[settings]]
name = "wordsWhileSpeaking"
label = "Words While Speaking"
kind = "text"
default = ""
scope = "mac"

# One term a line, sent to the speech model as hints.
[[settings]]
name = "jargon"
label = "Custom Vocabulary"
kind = "textarea"
default = ""
scope = "mac"

[[settings]]
name = "speakers"
label = "Identify Speakers"
kind = "bool"
default = "true"
scope = "mac"

[[settings]]
name = "lines"
label = "Visible Lines"
kind = "segmented"
default = "3"
scope = "mac"

[[settings.options]]
value = "2"
label = "2"

[[settings.options]]
value = "3"
label = "3"

[[settings.options]]
value = "4"
label = "4"

[[settings]]
name = "size"
label = "Text Size"
kind = "segmented"
default = "regular"
scope = "mac"

[[settings.options]]
value = "small"
label = "Small"

[[settings.options]]
value = "regular"
label = "Regular"

[[settings.options]]
value = "large"
label = "Large"

[[settings]]
name = "look"
label = "Appearance"
kind = "segmented"
default = "dark"
scope = "mac"

[[settings.options]]
value = "dark"
label = "Dark"

[[settings.options]]
value = "light"
label = "Light"

[[settings.options]]
value = "system"
label = "Match macOS"

[[settings]]
name = "opacity"
label = "Background Opacity"
kind = "slider"
default = "75"
min = 25
max = 100
step = 5
scope = "mac"

[[settings]]
name = "labels"
label = "Speaker Labels"
kind = "bool"
default = "true"
scope = "mac"

[[settings]]
name = "showMe"
label = "Show My Captions"
kind = "bool"
default = "true"
scope = "mac"

[[settings]]
name = "clickThrough"
label = "Click Through Captions"
kind = "bool"
default = "false"
scope = "mac"

# The captions' words' colours, each a name from a few suggestions, never a
# colour: the name means the shade of it that reads on the panel's ground,
# dark or light (\`web/src/captions/colours.ts\`). Picked in ⋯ and in
# Settings › Captions.
[[settings]]
name = "textColor"
label = "Text Color"
kind = "select"
default = "default"
scope = "mac"

[[settings.options]]
value = "default"
label = "Default"

[[settings.options]]
value = "yellow"
label = "Yellow"

[[settings.options]]
value = "green"
label = "Green"

[[settings.options]]
value = "blue"
label = "Blue"

[[settings.options]]
value = "pink"
label = "Pink"

[[settings]]
name = "translationColor"
label = "Translation Color"
kind = "select"
default = "default"
scope = "mac"

[[settings.options]]
value = "default"
label = "Default"

[[settings.options]]
value = "yellow"
label = "Yellow"

[[settings.options]]
value = "green"
label = "Green"

[[settings.options]]
value = "blue"
label = "Blue"

[[settings.options]]
value = "pink"
label = "Pink"

[[settings]]
name = "autoTranslate"
label = "Live Translation"
kind = "bool"
default = "false"
scope = "mac"

# With Live Translation on: each finished sentence of a line translated while
# it is still being said, before the speaker pauses. Off, only each line is,
# once it lands.
[[settings]]
name = "translateWhileSpeaking"
label = "Translate While Speaking"
kind = "bool"
default = "true"
scope = "mac"

[[settings]]
name = "translateWith"
label = "Translation Engine"
kind = "select"
default = "mac"
scope = "mac"

[[settings.options]]
value = "mac"
label = "Apple Translation"

[[settings.options]]
value = "ai"
label = "AI Model"

# A language id ("vi"); the window draws it as a picker of the languages
# Apple Translation lists.
[[settings]]
name = "translateInto"
label = "Target Language"
kind = "text"
default = "vi"
scope = "mac"

# As \`speechModel\`, for the text model: handed to Lumi once, then cleared.
[[settings]]
name = "aiModel"
label = "AI Model"
kind = "text"
default = ""
scope = "mac"

[[settings]]
name = "goOn"
label = "Auto-Resume at Recording Limit"
kind = "bool"
default = "true"
scope = "mac"

# Every start — the window's Start or Resume, the item's panel's, the
# menu's, a key's, an offer's Take Notes — closes the Meeting Notes window
# (put away, its page kept) and brings Live Captions up over every app (the
# owner, 2026-11-20; \`popover::show_for_start\`). Off, the window is left as
# it is: a start elsewhere brings the captions up, and a start pressed in the
# window keeps them out of its way until the person leaves it.
[[settings]]
name = "closeOnStart"
label = "Close Window When Transcription Starts"
kind = "bool"
default = "true"
scope = "mac"

# Your Name (Settings › Speakers): what names Me in place of "Me" — in the
# transcript, the captions, the summary and what its AI reads, a copy and a
# file — in every meeting, those before it too (\`meeting::my_name\`). Empty
# is "Me".
[[settings]]
name = "myName"
label = "Your Name"
kind = "text"
default = ""
scope = "mac"

# Each part's audio, kept as Lumi's file of this extension's own and played
# in the window. Only new meetings follow it: audio already kept stays until
# it is deleted.
[[settings]]
name = "keepAudio"
label = "Keep Audio"
kind = "bool"
default = "true"
scope = "mac"

# Where Save Audio… writes a meeting's audio once the person chose a folder
# in Settings; with none chosen it asks with Lumi's Save panel each time.
[[folder]]
name = "audio"
label = "Save meeting audio to"

# Summaries (\`src/summary.rs\`), drawn in Settings › Summaries. The Default
# Template, by id: a built-in's, or one of the person's own.
[[settings]]
name = "summaryTemplate"
label = "Default Template"
kind = "text"
default = "general"
scope = "mac"

# Where a new summary's Language pop-up starts: \`same\` for the meeting's own,
# or a language id.
[[settings]]
name = "summaryLanguage"
label = "Summary Language"
kind = "text"
default = "same"
scope = "mac"

# A meeting of 3 minutes or more is summarized with the Default Template as
# the window opens on it at its end (it was Lumi's card at a call's end
# offering Summarize, \`offerSummary\`, until 0.8.2).
[[settings]]
name = "autoSummary"
label = "Automatically Summarize When a Meeting Ends"
kind = "bool"
default = "true"
scope = "mac"

# Refine Transcript (\`src/refine.rs\`), drawn in Settings › Transcription ›
# After a Meeting. What cleans a meeting's transcript up by itself as it
# ends, for meetings of 3 minutes or more: Light at once, with no AI; Full
# then the text model below, once the window shows the meeting. The words
# as heard are always kept.
[[settings]]
name = "refineClean"
label = "Clean Up Transcript"
kind = "select"
default = "light"
scope = "mac"

[[settings.options]]
value = "off"
label = "Off"

[[settings.options]]
value = "light"
label = "Light — No AI"

[[settings.options]]
value = "full"
label = "Full — With AI"

# The text model Full uses by itself, by id: on this Mac or online (the
# owner, 2026-11-20). Empty for Meeting Notes' Text Model.
[[settings]]
name = "refineModel"
label = "Clean Up Model"
kind = "text"
default = ""
scope = "mac"

# Listen Again as a meeting ends: its kept audio heard again by a stronger
# speech model, after the summary (\`src/listen.rs\`). Off by default (the
# owner's R2): it uses this Mac for minutes.
[[settings]]
name = "refineListen"
label = "Listen Again"
kind = "bool"
default = "false"
scope = "mac"

# The speech model Listen Again hears with, by id. Empty for Lumi's own
# choice for Meeting Notes.
[[settings]]
name = "refineSpeech"
label = "Speech Model for Listen Again"
kind = "text"
default = ""
scope = "mac"

# The person's own templates, as JSON, written by Settings › Summaries'
# editor through the component, which holds them to the editor's rules.
[[settings]]
name = "summaryTemplates"
label = "Templates"
kind = "textarea"
default = "[]"
scope = "mac"

# Ask AI (behind its feature flag, \`src/features.rs\`): where Ask stands in
# the Meeting Notes window — a panel in Details' place (A1), or a pane under
# the transcript (A2). Both, the person choosing (the owner, 2026-11-22).
[[settings]]
name = "askLayout"
label = "Show Ask"
kind = "select"
default = "panel"
scope = "mac"

[[settings.options]]
value = "panel"
label = "Beside the Transcript"

[[settings.options]]
value = "pane"
label = "Under the Transcript"

# The model a new chat asks, by id; empty for Meeting Notes' Text Model
# (Settings › Summaries). A chat's own pick, and its last, come first.
[[settings]]
name = "askModel"
label = "Ask Model"
kind = "text"
default = ""
scope = "mac"

# How hard a new chat's model thinks, where it can (\`ask-thinking-tech.md\`
# §9.2): Lumi's four levels, Off unless the person chose. A chat keeps the
# level its last question asked at, and its composer's chip changes it.
[[settings]]
name = "askThinking"
label = "Thinking"
kind = "select"
default = "off"
scope = "mac"

[[settings.options]]
value = "off"
label = "Off"

[[settings.options]]
value = "low"
label = "Low"

[[settings.options]]
value = "medium"
label = "Medium"

[[settings.options]]
value = "high"
label = "High"

# The answer's language: \`question\` (the question's own, which Lumi
# detects), \`meeting\`, \`target\` (Translation's Target Language), or a
# language id.
[[settings]]
name = "askLanguage"
label = "Answer In"
kind = "text"
default = "question"
scope = "mac"

# Sent with every question, online too: who the person is, for "my action
# items". Your Name stays the name; this is the rest. At most 300
# characters, held by the pane and by the component.
[[settings]]
name = "aboutMe"
label = "About Me"
kind = "textarea"
default = ""
scope = "mac"

# A new chat's suggested questions, and Live Captions' one-press asks.
[[settings]]
name = "askSuggestions"
label = "Suggested Questions"
kind = "bool"
default = "true"
scope = "mac"

# How long a chat is kept (the spec's §6.2): with its meeting, 30 days, or
# only while the meeting is heard — those asked during it go at its end.
# A change applies to new chats.
[[settings]]
name = "keepChats"
label = "Keep Chats"
kind = "select"
default = "meeting"
scope = "mac"

[[settings.options]]
value = "meeting"
label = "With the Meeting"

[[settings.options]]
value = "month"
label = "For 30 Days"

[[settings.options]]
value = "during"
label = "Only During the Meeting"

# Meeting detection (\`src/detect.rs\`). Offer to take notes when a call app or
# a meeting site starts using the microphone — never start by itself.
[[settings]]
name = "askStart"
label = "When a Meeting Starts"
kind = "select"
default = "ask"
scope = "mac"

[[settings.options]]
value = "ask"
label = "Offer to take notes"

[[settings.options]]
value = "never"
label = "Do nothing"

# When the call app of a recording started for it lets go of the microphone
# for 20 seconds. A recording started by hand with no call app is never ended.
[[settings]]
name = "atEnd"
label = "When a Meeting Ends"
kind = "select"
default = "stop"
scope = "mac"

[[settings.options]]
value = "stop"
label = "Stop and save"

[[settings.options]]
value = "ask"
label = "Ask first"

[[settings.options]]
value = "nothing"
label = "Keep recording"

# Bundle ids of call apps not offered for, one per line. Slack by default: it
# holds the microphone at times with no huddle.
[[settings]]
name = "quietApps"
label = "Don't Offer For"
kind = "text"
default = "com.tinyspeck.slackmacgap"
scope = "mac"

# The hosts that make a browser using the microphone a meeting, one per line,
# \`*.\` for any subdomain.
# Name Meetings After Calendar Events (Settings › Calendar): a meeting takes
# the name of the event it overlaps, and keeps who was invited
# (\`src/calendar.rs\`). Off until the person turns it on, once the calendars
# are allowed (Settings › Calendar's Allow…, or Up Next's).
[[settings]]
name = "calendarNames"
label = "Name Meetings After Calendar Events"
kind = "bool"
default = "false"
scope = "mac"

# The calendars left out of naming meetings, Up Next and in-person offers, by
# id, one per line — "auto" for the first rule: every calendar but Birthdays
# and subscriptions such as holidays (\`calendar::kept\`).
[[settings]]
name = "calendarsOff"
label = "Calendars Left Out"
kind = "text"
default = "auto"
scope = "mac"

# Get Started's steps ticked by hand on the Start page, or the tour taken to
# its last page, one per line — \`speech\`, \`voice\`, \`tour\` — as VS Code's
# walkthrough boxes (the owner, 2026-11-25). Every step ticked, by hand or
# done, puts Get Started away.
[[settings]]
name = "startDone"
label = "Get Started Done"
kind = "text"
default = ""
scope = "mac"

# Up Next (Settings › Calendar › Start Page): how far ahead the Start page
# lists the calendar's events, to join and take notes in one press — or not
# at all (\`calendar::upcoming\`; the page works out the days' ends where the
# person is). Today and tomorrow by default (the owner, 2026-11-25).
[[settings]]
name = "upNext"
label = "Up Next"
kind = "select"
default = "tomorrow"
scope = "mac"

[[settings.options]]
value = "today"
label = "Today"

[[settings.options]]
value = "tomorrow"
label = "Today and Tomorrow"

[[settings.options]]
value = "week"
label = "Next 7 Days"

[[settings.options]]
value = "off"
label = "Don't Show"

# In-Person Meetings (Settings › General › Offer For): offer Take Notes as an
# event with people and a place starts and no call app is heard (D6, on).
[[settings]]
name = "offerInPerson"
label = "Offer for In-Person Meetings"
kind = "bool"
default = "true"
scope = "mac"

# The Reminders list the last action items went to; empty for the person's
# default list.
[[settings]]
name = "remindersList"
label = "Reminders List"
kind = "text"
default = ""
scope = "mac"

[[settings]]
name = "meetingSites"
label = "Meeting Sites"
kind = "text"
default = "meet.google.com\\nteams.microsoft.com\\nteams.live.com\\nteams.cloud.microsoft\\nzoom.us\\n*.zoom.us\\n*.webex.com\\nwhereby.com"
scope = "mac"
`,o=`# Changelog

## [0.26.0] - 2026-11-27

### Changed

- **Start, Chats and Libraries stay in place while the sidebar scrolls.** They stand under the title bar while the meetings scroll under them, and stay while you search, so the results no longer jump up into their place. A faint line under them darkens as the first meetings go under.
- **A section's heading stays in sight while its meetings go by.** Pinned, Folders, Today, Yesterday and the other headings hold at the top of the list until the next one takes their place. An open folder holds its name under Folders while its meetings go by, and while you search, a found meeting holds its name under its day while its matching lines go by.

## [0.25.1] - 2026-11-27

### Fixed

- **A long meeting's summary is written again.** With a model that writes long answers, such as Claude Sonnet, the summary of a long meeting could fail with "The model's answer could not be read as notes" after trying twice. The summary, and Clean Up and Translate All with the text model, are no longer held to a fixed length: each model writes up to its own limit, and an answer that is still cut short is read again in two parts. **Best with Lumi 1.104.0**, which holds each answer to its own model's limit.

## [0.25.0] - 2026-11-27

### Fixed

- **The call-ended card shows its buttons in full.** Continue Recording no longer sits on the card's edge: the buttons have a row of their own under the words, and the meeting's name gets the card's whole width. The countdown also runs on once the pointer leaves the card, where it could stay stopped.
- **Listen Again no longer says "Stopping…" for good after Lumi restarts.** If Lumi quit, restarted for an update or crashed while a meeting was heard again, or Meeting Notes was switched off, the meeting showed "Stopping…" with no way out for a quarter of an hour. It now opens as it was left, and Listen Again is there to press again. A summary being written in parts is put right the same way.
- **Up Next no longer says "Waiting to join" for a join that can't start.** If Meeting Notes was switched off or Lumi quit while Join and Take Notes waited for the call, the card went on waiting. It now offers Join and Take Notes again.
- **The menu bar stops counting a meeting Lumi cut off.** A meeting being recorded when Lumi quit or Meeting Notes was switched off is saved up to that moment as soon as Meeting Notes is back, and Live Captions says so as before.
- **The next call is offered Take Notes after a switch-off.** An offer Lumi took down no longer holds back the one for another call.

Meeting Notes starts nothing again by itself: what was cut short is a press away. **Needs Lumi 1.103.0.**

## [0.24.0] - 2026-11-27

### Added

- **One person heard as two is put right as you name them.** When Lumi gives one person two speaker numbers, name the second after the first: pick them in the list, type their name or address, or type Your Name. The card asks **Merge Speaker 2 into Lan Pham?**, says what becomes of the lines, and **Merge** makes the two one speaker. It works in Live Captions while the meeting is recorded, in the inspector and beside a name in the transcript. What that speaker says afterwards goes to the same person, and Undo takes it back. A merge saves no voice profile.

### Changed

- **Everyone invited stays in the naming list.** Someone another speaker is already named after is no longer left out: their avatar takes that speaker's colour, and the row says which speaker they are.
- **Merge Into works while a meeting is recorded.** Assign To still waits until the meeting ends.

### Fixed

- **Translate All with Apple Translation no longer stops at a line in two languages.** Such a line is translated a few sentences at a time, each from its own language, and the lines after it are translated too.
- **A meeting's last lines are kept when saving them at the end fails for a moment.** The captions panel sends them again until they are saved, with a model switch or the first translation made in the last seconds.
- **A meeting is no longer ended as lost while Lumi asks a question before it starts listening.** If the question stayed up for more than a minute and a half, the meeting was closed, and the recording that followed could not be stopped from the menu bar.
- **Join and Take Notes no longer starts notes for tomorrow's meeting.** For a call more than 4 hours away, Meeting Notes says it cannot wait that long and opens nothing.
- **Try Again and Regenerate work in a chat across meetings.**
- **Cancel stops a download that Download and Start began in Live Captions.** If Lumi cannot stop it, the panel says why.

## [0.23.3] - 2026-11-26

### Changed

- **Save Now is the call-ended card's main button.** It is what the countdown does anyway. The other button now reads **Continue Recording**.

## [0.23.2] - 2026-11-26

### Fixed

- **The call-ended card no longer shows a scroll bar.** The card that appears when a call ends is one row again: the heading takes at most two lines, and the line under it keeps to one, with a long meeting name cut short. Before, it could come up a few points too short, with its text clipped and a scroll bar drawn over it.

### Changed

- **The call-ended card has no Show More.** It is the countdown, **Keep Recording** and **Save Now**. What was heard is in Meeting Notes once the meeting is saved.

## [0.23.1] - 2026-11-26

### Changed

- **A film on the store page.** Meeting Notes' page in Lumi's Extension Store now shows a short video of it at work: Up Next, Live Captions and Live Translation, then Ask, Refine, Translate All, Summary, Libraries and Export.

## [0.23.0] - 2026-11-26

### Changed

- **A file opens in a window of its own.** A PDF, a document or a picture in an Ask chat or a library opens in a File Preview window you move, size and close like any other window. Opening another file shows it in the same window, and the window opens where you left it. It used to open in a box drawn over the page, whose green button covered the window's own buttons.

### Fixed

- **"N of N lines changed" lines up with the transcript.** In Changes, the count starts on the same edge as the words under it, with the key to the marks at the right, and VoiceOver reads it.

## [0.22.0] - 2026-11-26

### Added

- **Up Next on the Start page.** Your calendar's next meetings, as far ahead as Settings › Calendar › Up Next says: Today, Today and Tomorrow (the default), Next 7 Days, or Don't Show. The next one is a card with its people and one button, **Join and Take Notes** (**Take Notes** for a meeting in a room). Press a later one to see its people, its agenda and the last meeting of its series. **Needs Lumi 1.102.0.**
- **Join and Take Notes waits for the join.** It opens the call, and the notes start only once the call's app, or a browser on its site, is using the microphone and playing sound, so the lobby and the wait are left out. Until then the card says "Waiting to join" with Cancel, and so does Lumi's menu.
- **A Calendar pane in Settings.** Access, the calendars read, Name Meetings After Calendar Events and Up Next, in a pane of their own after General.

### Changed

- **The card after a call ends counts down.** When the call's app lets go of the microphone, the card says "The Zoom call ended — Saving “Design Review” in 20 s" around a ring, with **Keep Recording** and **Save Now**, and **Show More** for what was heard. Nothing is saved while you point at the card or press in it.
- **Get Started is ticked off by you.** **Mark All Done** puts it away, and the tour ticks itself at its end. The Start page's header and foot stay put while its columns scroll.
- **The meeting's toolbar.** Ask comes first and shares a capsule with Details; Appearance and Search each stand alone, in the same place on every page.

### Fixed

- **A pop-up's second press closes its menu.** Pressing the button of an open menu — the source pop-up above Start in Live Captions, Settings' model pop-ups, Template or Model in a summary, a line's More — closed the menu and opened it again, or left it open. It now only closes it, as a Mac pop-up does.
- **"“X” ended N minutes ago" no longer cuts into a meeting that runs over.** It came five minutes after the event's end while the call was still on. It now also waits until nothing has been said for two minutes, and says so.

## [0.21.0] - 2026-11-25

### Added

- **A line said in another language shows which.** In a meeting in English, a line said in Vietnamese starts with a small "VI"; point at it for the language's whole name. VoiceOver reads each line in its own language's voice, in Live Captions too.

### Changed

- **Names, times and avatars follow the text size.** ⌘+ and ⌘− now size a speaker's name, time and avatar and the Translate chip with the words, so a name never reads smaller than its translation. In Paragraphs, translations hang off a thin bar, so they no longer read as a second paragraph by the same speaker.
- **Plainer words for the transcript as it was made.** "Heard live" and "as heard" are now **Original**: "Originally Speaker 2" on a struck name in Changes, **Copy Original Transcript**, "Back to Original." After Listen Again, the foot says "1 new speaker found" where it said "1 speaker told apart again".

### Fixed

- **A line and its translation light up as clearly in Dark as in Light.** Pointing at a sentence lit it and its translation only faintly in Dark. The highlight is now as strong as Apple's own in each appearance, a lit translation takes the text's colour, and Playing and Selected are stronger in Dark so Selected still stands out most.
- **Refine and Translate… no longer runs into the sentence before it** at the foot of a transcript cleaned up as the meeting ended ("no AI.Refine and Translate…").

## [0.20.0] - 2026-11-25

### Added

- **Narrow a question across all your meetings.** Four chips above the field on the Chats page pick what the question reads:
  - **When:** today, yesterday, this or last week, this month, or a range of days picked on a calendar.
  - **People:** the meetings where they spoke, or only what they said.
  - **Meetings:** any you pick.
  - **Reads:** transcripts and summaries, summaries only, or transcripts only.

  Beside the chips, how many meetings that is. A question says above it what it read, and a chat keeps what its last question read when you open it again. **Needs Lumi 1.101.0.**
- **Ask about several meetings at once.** ⌘-click meetings in the sidebar, or ⇧-click for a run of them, then press **Ask About These**. Right-click a folder for **Ask About This Folder**. Chats opens with those meetings picked.

### Changed

- **Asking across all your meetings reads their summaries too.** A meeting's summary goes in beside its transcript when it is written, edited or another version is shown, and comes out when it is deleted. Questions such as "every decision we made" or "all the upcoming deadlines" now find more of what was said. Summaries written before this go in over your next few questions across meetings.

### Fixed

- **A long meeting from an earlier version opens again.** Opening one stopped with "storage.put refused: this run already made 200 host calls" after an update, because each sentence's language was asked of Lumi one at a time. They are now asked all at once. **Needs Lumi 1.101.0.**
- **A cite in an answer across all your meetings shows when it was said.** Every such chip read "00:00" and the meeting's title with the date after it. It now shows the line's own time and the meeting's title as it is now, and is greyed once that meeting is deleted. While the answer is still being written, it is already that meeting's chip rather than a greyed link.

## [0.19.1] - 2026-11-25

### Fixed

- Refine and Translate's time for Translate All is closer to what it takes. It counted fewer parts and calls than Translate All makes, and left out what the AI writes besides the translations.

## [0.19.0] - 2026-11-25

### Added

- **Slash commands in Ask.** Type \`/\` in Ask, or press the \`/\` button beside @, to pick a command:
  - **Lumi's own:** \`/clear\` starts a new chat and keeps this one, \`/compact\` summarizes the earlier messages, \`/retry\` asks the last question again, \`/title\` renames the chat, and \`/think\` sets how hard it thinks.
  - **Meeting Notes' own:** \`/actions\`, \`/decisions\`, \`/open\` and \`/email [to whom]\`.
  - **In Live Captions:** also \`/missed\`, \`/sofar\` and \`/suggest\`.
  - **Needs Lumi 1.100.0.**
- **Back and Forward.** After a citation, a mention or a quote opens something else, ‹ and › at the start of the toolbar take you back to what you were reading, and forward again. ⌘[ and ⌘] do the same. A chat comes back scrolled to where you left it. In Live Captions, Ask has them at the top of the chat.

### Changed

- **A citation is a small token,** set after the punctuation it belongs to, as a footnote mark is. A long name is cut short, and its tooltip says it in full.

### Fixed

- A citation of a chat or a meeting that has since been deleted is struck through. It used to be only dimmed.
- In Live Captions, a citation, a mention or a quote of another meeting's chat opens Meeting Notes on that chat. It used to do nothing.
- Back to Summary shows only when you went from the summary to a line, and not when the transcript was already open.

## [0.18.0] - 2026-11-24

### Changed

- **A citation plays and shows each passage of it.** A time in the Summary, a citation in Ask, or one under Live Captions can stand for lines far apart. Lines said one after another are now one passage, and each passage has its own time, Play and Show in Transcript. Play stops at the end of its passage.
- **A file's preview is a window of its own**, as Quick Look's. Move it by its title bar, size it from its corner, fill the window with its green button, and keep working in the page behind it. In Libraries it shows the file you select.
- **An answer says when it searched your libraries by their words.** If Lumi's embedding model stops, Ask still answers, and a line under the answer says so, with Lumi Models… to try the model again. Needs Lumi 1.99.0.

### Fixed

- A menu taller than the window, such as Text Model with a long list, scrolls instead of running past the window's edge.
- Libraries shows that it is loading, and why it could not, with Try Again, instead of an empty page.
- Record… in Get Started opens Settings on Speakers with My Voice's recording, not on the pane Settings was last left on.

## [0.17.0] - 2026-11-24

### Added

- **Ask AI.** Ask about a meeting while it is happening or after it, and get an answer that cites the lines it came from: press a citation to open the meeting at that line. Ask stands beside or under the transcript in the window (⌘J), and folds under Live Captions, where What Did I Miss?, Summary So Far and Suggest a Question are one press away. Lumi's assistant answers with the AI you set up in Lumi, keeps your chats on this Mac, and asks before anything leaves it. Needs Lumi 1.98.0.
- **Chats.** Lumi names each chat from its first answer; in the window, press its name to rename it. Every chat of every meeting is on the Chats page, where you can also ask across all your meetings and select many chats to delete at once. Branch in New Chat goes on from any answer; @ mentions another chat and Quote brings a message into your question; Summarize Earlier Messages shortens a long chat.
- **Files and libraries.** Drop, paste or add files to a chat, and an answer cites the place in them, shown in a preview. The Libraries page keeps files in libraries, laid out as Finder does; mention a library with @ and the chat searches it.
- **Settings › Ask:** where Ask stands, the model a new chat asks and how hard it thinks, the language it answers in, Suggested Questions, About Me, and how long chats are kept, with Delete All Chats….
- **⌘+ ⌘− ⌘0** make a chat's words bigger, smaller and back, as Mail does.

### Changed

- **The live captions' ⋯ menu is shorter and changes things in place.** Appearance (Dark, Light or Match macOS), Text Size and Visible Lines are one row each, three buttons to pick from, and a new Opacity row sets the Background Opacity, filled as far as the captions are opaque. Each moves the captions as you choose and leaves the menu up. Click Through Captions is in the menu too, beside Speaker Labels and Show My Captions. Speech Model is one line naming the model in use; press it for the list. Open Meeting Notes and Settings… are at the foot.
- **Captions can be drawn in a colour of your own.** Text Color and Translation Color, in ⋯ and in Settings › Captions, each offer Yellow, Green, Blue and Pink beside the default, every one in a shade that reads on the captions' dark or light background; a colour you pick follows the captions when their Appearance changes.
- **The 文A button shows Live Translation is on by its colour**, on no blue ground of its own.

### Fixed

- Opening a meeting no longer opens its title for editing.
- A transcript line's language is read from its words, not from the language the model heard.
- A menu lights one row at a time, and none until the pointer or a key reaches it.

## [0.16.0] - 2026-11-22

### Added

- **Quit Meeting Notes**, last in the menu bar item's panel and in its menu. It switches Meeting Notes off in Lumi — its item, its windows and everything it watches for go — and leaves Lumi running. A meeting being transcribed is stopped and saved first, its last words included, and Meeting Notes goes once it is: the row says Saving and Quitting… meanwhile. A paused meeting is ended as Stop ends it. Open Meeting Notes from Applications, Spotlight or the Dock, or switch it on under Extensions in Lumi, to have it back.

### Changed

- **The Details button is an info symbol (ⓘ)** and says Show Details or Hide Details, the name its panel's heading already uses. It drew a sidebar and said Show Inspector.

## [0.15.0] - 2026-11-22

### Added

- **An event's notes in the inspector.** The agenda or anything else written in the notes of the event a meeting is linked to shows under the event, in Notes: its first eight lines and Show All, selectable to copy. What Teams, Zoom or Google Meet pastes under it — the link, the meeting ID, the passcode, the dial-in numbers — is folded under Joining Info until you open it. A meeting linked to its event before this has the notes read the first time you open it. Needs Lumi 1.97.0.
- **A summary says who wrote it.** “Summarized by Claude Opus in Lumi Meeting Notes” — the model that wrote it, or AI where it isn’t known — stands on its own line over the footnote under every summary, Lumi’s mark before it.

### Changed

- **A summary being written shows Lumi's mark**, the bolt in its diamond, painted in the colours of the ring turning round it, where the ✦ stood. No Summary Yet has it too.
- **The summary's mark moves between its places instead of jumping.** Summarize in No Summary Yet glides the mark up to where it works; its bolt flashes and a diamond grows out of it, turning square, into the ring that turns while the summary is written. Stop, from the middle of the page or from the line over the notes, glides it back down as it is, and once it is there the ring shrinks into the diamond as it turns; a run that fails goes back into Couldn't Write the Summary the same way. The line over the notes fades where it stood once the summary is kept or a Regenerate is stopped, and the notes slide into its room — as they slide and dim when a Regenerate's line comes in over them. The ring slows as the model thinks, and stands faint while it waits on you, from the angle it is at rather than jumping to another. With Reduce Motion on, each is simply there.
- **A summary written from the refined transcript says only that** under it, without “heard again”.

### Fixed

- **With Reduce Motion on, the summary's mark holds still while the model thinks.** Its glow went on turning and breathing.
- **Open works right after Meeting Notes is updated.** For a few seconds after an update, the windows it loads ahead took every call it could make at once, and opening Meeting Notes was refused.

## [0.14.1] - 2026-11-22

### Changed

- **The Start page's footer is the copyright alone**, beside Lumi's mark. The link to lumikeys.app is gone from it; Settings › About still has Website.

## [0.14.0] - 2026-11-22

### Added

- **The window opens on a Start page**, as VS Code's Welcome page does: Start Transcription, Search, New Folder, Live Captions and Settings; your recent meetings; what's left to set up; and what's new in this version. It no longer opens the newest meeting by itself. Start, at the top of the sidebar, brings you back to it from a meeting.

### Changed

- **The Welcome tour ends with one button, Open Meeting Notes**, which opens the window on its Start page; Take the tour again moves to the window's foot. Done, which only closed the tour, is gone.

### Fixed

- **A pop-up you can't use now looks it.** In Refine and Translate, Clean Up's Model with Light chosen, and Translate All's Language and Translate With while it's off, kept their full colour beside their greyed-out names, as if they could still be changed; so did Export's Template, Paper Size, Words and Translations. They're greyed out with their names now, as the Speech Model pop-up already was — and so is every other pop-up in Meeting Notes when it's off, and Export's Your Name field when the file has no "Me".
- **The event button's menu lines up as a Mac menu does.** "Events around …" starts at the menu's edge, where the checkmark stands, rather than indented as if it could be chosen, and Open in Calendar has a calendar symbol, its label in line with the events' names. The Calendars pop-up in Settings heads each account the same way.

## [0.13.0] - 2026-11-22

### Added

- **Name a speaker right in Live Captions.** Click their name and a popover opens above the captions, which hold still while you type. Click outside to keep the name; Cancel or Escape keeps nothing.
- **Speakers carry their email address**, from the invitation or typed with the name. The inspector and exported minutes show it, a merge takes it along, and a voice profile keeps it (Settings › Speakers › Edit).
- **Rest the pointer on a person to see their card**, as in Microsoft Teams: what the meeting knows of them — the invitation, the lines they said, their voice profile — and their email address, which a press copies.
- **Hide Invited, in Export’s Customization**, leaves the people invited out of exported minutes. Who spoke is still listed.

### Changed

- **Choose what Live Captions hears above Start Transcription** — where it listens, the languages, the speech model — and name the meeting before it starts, after the calendar event on now. A missing model is one press, Download and Start, with its progress in the button. Starting keeps the captions as they were, a paused meeting has one Resume, and menus open under the button you press.
- **The inspector is a Mac inspector’s form**: rounded groups under titles, Speakers second, each speaker’s Name and Merge Into as buttons on its row. Duration counts up while a meeting is heard, and a meeting that invited more than ten people lists ten and Show All.
- **Naming a speaker offers the people invited as a list you find in**, in the window and in Live Captions: type, or use ↓, ↑ and Return. It stays five rows high however many were invited. The name you pick becomes a chip; take it away with its × or Backspace before typing another.
- **Avatars show two letters, as Teams draws them**, for speakers and the people invited, who each keep a colour of their own.
- **Translate beside a bubble or a line translates it, shows it, or translates it again**, and leaves Show Translations as it is.
- **Scroll to Top and Scroll to Bottom show while you scroll**, and go a moment after you stop.
- **A summary item’s menu has icons**, and the summary’s footnote asks you to double-check what the AI wrote.

### Fixed

- **A meeting whose recording failed or was cut off can be scrubbed through again**; it was kept as 0 s long. Meetings already affected mend when they open.
- **Cancelling a start leaves no meeting behind**, and Live Captions shows Start again once the meeting opens in the window, not “Saved”.
- **Resume under paused captions takes a click with Click Through Captions on.**
- **Listen Again hears with Apple Speech when you choose it**, and says why when another model must. Settings and Live Captions say so too when a Second Language rules Apple Speech out.
- **Only the line under the pointer shows its buttons.** Lines already in the language you translate into show no Translate, and Clean Up, Listen Again and Translate All show their progress on the Transcript tab alone.

## [0.12.0] - 2026-11-21

### Added

- **Words While Speaking**, in Settings › Transcription: choose the model that writes the grey words while someone talks — Apple Speech, or Nemotron 3.5 Streaming, which hears both of a meeting's languages. Speech Recognition still writes each line when they pause, so the words come steadily and the graphics chip is mostly free for the call, though they're less accurate until the pause. Same as Speech Recognition, as before, is the default; a model not on this Mac downloads when you pick it, and a change applies from the next meeting. Needs Lumi 1.95.
- **Translate While Speaking**, in Settings › Translation: with Live Translation on, each sentence is translated before the speaker pauses, as before. Turn it off to translate only each finished line.

### Changed

- **Chat shows a line's actions as you point at it**: Play, Translate, Copy and More beside the bubble, as Paragraphs and Lines show them. The View popover's help is one line.
- **Click a line to play it**, and again to pause it, under the pointing hand; ⌘-click or ⇧-click selects lines. A click used to select and a double-click to play. A line with no audio still selects on a click.
- **Play is Pause while its line plays**, in every layout, and Play again goes on where it stopped. The bars that show a turn playing stand at the speaker's outer edge in Chat, and in place of the speaker's initial in Paragraphs and Lines, so nothing moves when a line starts or stops, and Name… coming and going under the pointer leaves no gap beside them.
- **Your own turns in Chat read "0:32 Me"**, your name at the bubble's edge as other speakers' names are at theirs.
- **Chat's bubbles stop at a comfortable line length** on a wide window — about 65 characters, at every text size.
- **Unlink a meeting's event by pressing it again** in the event menu, where it is ticked; None is gone.
- **In Live Captions, a speaker not known yet is three blinking dots**, as the main window shows words still being heard, where a still "…" stood.

### Fixed

- **A turn says which sentences are not translated yet.** In Chat and Paragraphs, a sentence with no translation shows Translate where its translation would be, a press away; half a turn's translation read as all of it.
- **A finished meeting opens at its start**, not on its last lines. A meeting being transcribed still follows what is said.
- **The bar for several selected lines no longer hides the last ones.**
- In Chat, words fade under the speaker's name as they scroll past it, rather than being cut at its edge.
- **The event menu fits what it holds.** With no event near the meeting it is its heading and Open in Calendar, no wider than they are.
- **With translations beside the words, each language's name stands over its column**, in Lines and Paragraphs. On a wide window the original language's name stood well left of its words.

## [0.11.0] - 2026-11-21

### Added

- **Merge speakers and assign lines.** When one person was heard as two, right-click a line and choose Merge “Speaker 3” Into, or press Merge… beside the speaker in the inspector. When a line went to the wrong person, Assign To moves it — or every selected line — to anyone in the meeting, to you, or to a New Speaker. Both have Undo, and both wait until the meeting ends.

### Fixed

- **Name… opens its card whole**, in the transcript over the turns below it — upward near the transcript's foot — and in the inspector, with no scrollbar of its own. In Lines, a turn's header now holds at the top as you scroll, and its text follows View's size.
- **Listen Again keeps My Voice.** On a call heard again, someone beside you at your microphone was folded into your lines as Me; now, as in Live Captions, only your voice is Me and anyone else there stays their own speaker. In a room, your lines are Me too.

## [0.10.0] - 2026-11-21

### Added

- **A Welcome tour on a fresh install.** The microphone and system audio, your language and its speech model (downloading in the background), your calendar, your name, Keep Audio and summaries, and the keys that start a meeting. Again from Settings › About › Welcome Tour….
- **Pin and folders.** Right-click a meeting to Pin it or Move To a folder, or drag it there. New Folder (⇧⌘N) is named in place, folders keep the order you drag them, and Delete Folder keeps its meetings, with Undo. Sort By date, title or length. The meeting being transcribed stays at the top, in Now.
- **Export… (⇧⌘E) makes a PDF, HTML, Markdown or plain text file** from one sheet: a template — Standard, Minutes or Columns — and the paper; the summary, any version of it, or Summarize… or Regenerate… there; the transcript refined or as heard, its translations (Translate… if there are none yet) and timestamps. Customization names you another way in that file, or leaves out the AI models' names. The preview is the file: PDF and HTML zoom, Markdown and plain text copy — Markdown's Formatted view as rich text. An HTML file has its own Light, Dark and System. Every file ends with "Made with Lumi Meeting Notes". Saved, the message names the file and its folder, with Show in Finder.
- **Your Name in place of "Me"** in every meeting, earlier ones too: Settings › Speakers › Your Name.
- **Quick Translate.** In a meeting with nothing translated, the translate button translates it at once into your Settings' language with your translator, a ring round it showing how far.
- **Meetings named after their calendar events** (Settings › General › Calendar). The event button beside the date links another event or opens it in Calendar; the inspector shows who was invited. Reads your calendar, never changes it.
- **Offers for meetings in a room** as a calendar event with a place starts (Settings › General › Offer For › In-Person Meetings); a call still heard 5 minutes after its event ends offers Stop and Save.
- **Add to Reminders** from the Action Items heading: the items you tick, with a date. Done in Reminders shows done here.

### Changed

- **The sidebar slides** out and in (⌘B), its button beside New Folder.
- **The window shows its name**, Lumi Meeting Notes, at the middle of its title bar.

### Fixed

- **Settings › Storage** gives the transcripts' size without the audio, always shows the Audio section, and Delete All Audio works with hundreds of meetings.
- **Messages** stay at the middle of the window's foot.
- **The Summary tab** shows a spinner, not No Summary Yet, while the summary is read.

Needs Lumi 1.94.0.

## [0.9.0] - 2026-11-20

### Added

- **Refine and Translate.** In the Transcript tab, Refine and Translate… cleans up a meeting that has ended. Light takes out ums and words said twice, on this Mac, with no AI. Full also fixes punctuation, grammar and your Custom Vocabulary terms with the text model you choose, and leaves out any change that would alter what was said. Translate All translates every line not yet translated, or all of them again once every line is. The sheet says how long it takes and which AI calls go where before you start; Stop keeps what's done.
- **Original, Changes and Refined.** See the refined words, what refining changed — taken out struck through, put in underlined — or the words as heard. Revert to Original puts lines, or the whole meeting, back as heard. ⌘Z undoes the last refine or revert, and ⇧⌘Z redoes it. Copy and Export take the version shown.
- **Listen Again.** Hears a meeting's kept audio again with a stronger speech model on this Mac, for truer words and speakers: on a call your lines stay Me, and someone the live transcript mixed up is told apart. The words heard live stay as Original, and the summary's times follow the new lines.
- **Meetings clean themselves up as they end.** Settings › Transcription › After a Meeting: Light by default, for meetings of 3 minutes or more; Full and Listen Again can follow, with the models you choose.
- **Volume in the player.** A speaker button mutes playback; hover over it for a volume slider.
- **⌘B shows or hides the sidebar.**
- **A Changelog tab** beside About on Meeting Notes' page in Lumi's Settings.

### Changed

- **Start Transcription shows Live Captions and closes the Meeting Notes window**, wherever you press it, so you follow the meeting over the call; open Meeting Notes again to read along. To keep the window, set Settings › General › When Transcription Starts to Keep Window Open.
- **Show Translations beside View.** A translate button shows or hides translations, and turns Live Translation on or off while a meeting is heard.
- **Summary choices wait for Regenerate.** A new template, model or language no longer rewrites the summary at once.
- **Icons in the meeting menus**, as macOS menus have them.

### Fixed

- **Settings… opens Meeting Notes Settings.** With the Meeting Notes window in front, Meeting Notes › Settings… and ⌘, open its Settings window and leave the window where it is.
- **The View and date popovers open over the transcript**, no longer under a speaker's name held at the top.

## [0.8.2] - 2026-11-20

### Added

- **Escape closes Settings.** A menu or a sheet open in it, a shortcut being recorded, or a field you're typing in takes Escape first; press it again to close the window.

### Changed

- **A summary writes itself in as the model writes it.** While the transcript is read, the Summary tab shows what's happening where "No Summary Yet" stood, with Stop, and a long meeting's progress fills the ring round its mark. When the model starts writing, the mark moves up to a line that stays at the top as you scroll, and the overview and each item appear as they're written. Regenerate keeps the summary you have, dimmed, until the new one starts.
- **Live Translation keeps up with a long turn.** Each sentence is translated as soon as it's said, while the speaker goes on, instead of once they pause; the rest of the caption follows when it ends. A sentence heard differently a moment later is translated again. With macOS translating (Settings › Translation Engine), the words still being said are translated too, dimmed, and replaced as more is said, then by the caption's own translation when it ends; the AI is never asked for these.
- **Live Captions are ready from the moment Lumi starts**, as the menu bar item's panel is, so the first meeting shows them at once. Lumi's Preload switch for Meeting Notes covers them too.
- **Live Captions step out of the way while you're in the Meeting Notes window watching the meeting being heard**, since the window already shows its words, and come back over every app as soon as you switch to another app or close the window (closing needs Lumi 1.93.0). Start or Resume pressed in the window starts the meeting from there, without the captions flashing up first. Captions you hid yourself stay hidden, and they stay put while Live Translation is by the AI.
- **A meeting is summarized by itself as it ends.** Settings › Summaries' Automatically Summarize When a Meeting Ends, on unless you turn it off, writes the summary with the Default Template as the Meeting Notes window opens on a meeting of 3 minutes or more, in place of Offer to Summarize; Lumi's card at a call's end offers Resume. Set as Default under Templates picks the template.
- **Templates says which are built in**: they're listed under BUILT-IN, yours under YOUR TEMPLATES. A built-in opens with View…, and − says why it can't delete one.
- **The menu bar item's panel has no Live Captions or Live Translation switch any more.** Show Live Captions appears there while you record and the captions are out of sight, and the Meeting Notes window's translate button turns Live Translation on and off while it shows the meeting being heard.
- **A meeting that ends opens in the Meeting Notes window**, and Live Captions go away, instead of staying up to say it was saved: stopped, ended after a pause, or stopped by itself when the call ended.

### Fixed

- **The menu bar item no longer goes on showing a recording after it stopped**: now and then its wave kept moving beside a clock standing at the meeting's last second, with nothing being heard.

## [0.8.1] - 2026-11-19

### Changed

- **A long Chat bubble's speaker stays in sight across the column**, on a band in the window's own background at the top of the transcript, with the words passing under it, instead of floating over them.

### Fixed

- **The inspector's speakers no longer look switched off.** They were drawn at a faint strength, as were Save Voice Profile and a summary template's fields; they're at full strength now, their checkboxes drawn as a Mac's, and a speaker you uncheck is dimmed so the ones shown stand out.
- **Nothing shows above what stays at the transcript's top**: a sliver of words used to peek over a held turn's header or a bubble's speaker.

## [0.8.0] - 2026-11-19

### Added

- **Choose how the transcript reads.** View, beside the tabs, lays it out as Chat (bubbles, yours on the right, as Messages draws them), Paragraphs or Lines, with translations below the words or side by side, four text sizes (⌘+ ⌘−), and Timestamps, Follow Along While Playing and Speaker Colors.
- **Select lines and act on them.** Click, ⇧- or ⌘-click, or ↑ ↓; ⌘C copies, ⌘A selects all, Return plays. Several selected get a bar with Play, Copy and Translate; right-click for Copy with Names and Times, Select Whole Turn, Name and Hide. Name… beside an unnamed speaker names them right there.
- **Follow along while it plays**: the line heard is lit and kept in sight; scroll away and Back to Now Playing returns to it.
- **See who spoke where on the player's scrubber**: point at it and the turn under the pointer lights up, with a tooltip naming the speaker, the time a click plays from, and when the turn starts and ends. ⇧-click plays the turn from its start.
- **Appearance in the toolbar**: a click goes System, Light, Dark; right-click to pick one. The same setting as Settings › General.
- **Every speech model that heard a meeting**, with when it took over, in Details, under the title and in exports.
- **Search finds what was said** in every meeting's transcript, translations and summary. The sidebar shows the meetings that hold your words, their matches and two of their lines: click one to open the meeting there. Without accents a word finds every accent ("hop" finds họp, hộp and hợp); quotes keep a phrase in order.
- **Move from match to match** with ‹ › beside the search, Return or ⌘G (⇧⌘G back), the summary's matches included; each tab says how many it holds. ⌘F goes to the search.
- **Click Through Captions**, in Settings › Live Captions: the captions' text lets clicks, scrolls and hovers through to what's under it; the bar and the panel's edges still take them.
- **Keys for Start, Pause and Stop Transcription**: ⌃⌥⌘1, ⌃⌥⌘2 and ⌃⌥⌘3 in every app, as the menu bar item's rows. Change or clear them in Settings › General › Shortcuts.

### Changed

- **Transcript and Summary are two tabs** under the meeting's title, ⌘1 and ⌘2; the title heads the page over the date and who spoke. Point at a summary's time to read its lines; click it to see them in the transcript, and Back to Summary (⌘[) to return. The player stays under both tabs, and a meeting opens on the tab you left. ⌥⌘S is gone with the pane.
- **The transcript opens as Chat**, headed by when it was heard, the model and the language, with quiets of 15 s or more said between turns. A long bubble keeps its speaker's name in sight as you scroll through it.
- **A meeting where nothing was said says so**, in place of the tabs.

### Fixed

- **Stop on a paused meeting shows it saved** in the window open beside it.
- **The toolbar's buttons work while the search is open**, and the empty field stays open, so the toolbar doesn't move under your pointer; click elsewhere or press Escape to close it.
- **Share is off when there's nothing to share**, as Show Translations is.
- **A meeting is named by the first speech model that heard it**, not the one a change left it on.
- **A narrow transcript stays readable**: translations go under the words, and Lines lets its buttons go.

## [0.7.0] - 2026-11-19

### Added

- **Summarize a meeting.** A Summary pane under the transcript writes an overview, the action items and the sections of a template — General, 1:1, Stand-up, Interview, Customer Call or one of your own — each item with the time it was said: click the time to see those lines in the transcript. Template, model and language are right above it; choosing another writes a new version, and the one before stays a click away with your edits. Edit any item in place, tick action items, choose who owns them; Copy Summary and Copy Action Items paste as Markdown. The summary is written by the text model you set up in Lumi, on this Mac or online — Lumi asks before anything leaves it — and the meeting takes the summary's title while it still has the one Meeting Notes gave it. Drag the pane taller or shorter, make it larger, or fold it away with ⌥⌘S. Needs Lumi 1.92.0.
- **Long meetings are read in parts** when the model you chose can't read them whole, then put together, with a bar of how far it got, the time left and Stop. A stretch that couldn't be read is said at the top of the summary.
- **No text model yet?** Summarize offers one to download, in Lumi's own panel, and goes on once it's ready.
- **Settings › Summaries**: the Text Model, the template and language a summary starts with, and your own templates — a name, instructions, and the sections you want in your order.
- **Summarize from the card when a call ends.** For notes of 3 minutes or more, Lumi's card offers Summarize instead of Resume, and the window opens on the meeting writing it. Turn it off in Settings › Summaries.
- **Exports include the summary.** Export as Markdown or Plain Text puts the summary ahead of the transcript, each item with the time of what it came from; Share › Copy Summary copies it.

### Changed

- **The player is a bar at the foot of the transcript**, in the same place whatever the window shows, with no Close; Space plays and pauses.
- **Scroll to Top and Scroll to Bottom** appear as you scroll a long transcript or summary; Home, End, ⌘↑ and ⌘↓ go there too.
- **Alerts' buttons are drawn as macOS's**, one line each.
- **Live Captions step back while you work in Meeting Notes.** With the Meeting Notes or Settings window in use, the captions no longer cover it: they go behind it, and float over every app again as soon as you go back to another app, or when you click them. Needs Lumi 1.91.0.

### Fixed

- **Menus are drawn in macOS's appearance.** The model pop-ups' menus in Settings, their submenus and Live Captions' ⋯ menu follow macOS's light or dark, as a Mac menu does; they used to follow Lumi's Appearance where you had set it apart from macOS.
- **Live Captions stay in sight over an app in full screen.** They now follow you onto every desktop and over every app in full screen; they used to stay behind on the desktop the meeting was started from, so a call watched in full screen showed no captions.

## [0.6.0] - 2026-11-18

### Added

- **Escape hides Live Captions** once you have clicked the panel, as its Hide button does; with its ⋯ menu open, Escape closes the menu first.
- **Choose and download models in Settings.** Speech Recognition, Speakers Model and Text Model are pop-ups that offer every model Lumi knows: ready on this Mac or online — Lumi Models, Apple Speech, apps such as Ollama and LM Studio, services you have a key for, Claude Code — the ones Lumi can download, with their sizes, and the ones that can't run here, saying why. A provider's models, and the ones that can't run here, open in a submenu beside the menu, as a Mac menu's do. Lumi asks before anything is downloaded; it comes down with a bar, with Cancel where the download can be stopped (macOS's own language downloads can't be), and Meeting Notes uses it once it's ready. Transcription's On This Mac shows the speech model, the speakers model and the translation together. Your choice is kept by Lumi, which shows it under Settings › AI › Extensions & Privacy, where Use My Default puts it back. Needs Lumi 1.90.0.

### Changed

- **Settings shows its name on the title bar's top row**, Meeting Notes Settings, beside the window's buttons, with the panes' buttons under it, as a Mac app's settings window does; it stays the same whichever pane is open.

## [0.5.0] - 2026-11-18

### Added

- **Record Your Voice in English or Vietnamese.** Switch the text to read between English and Tiếng Việt; it starts in your Spoken Language, and Meeting Notes listens in the language you read.

### Changed

- **The Meeting Notes window keeps up with Live Captions.** A meeting being recorded shows in the window as Live Captions shows it, the line being said included, the moment it changes — speaker names and translations too — instead of up to half a minute behind. Needs Lumi 1.90.0; with an older Lumi the window catches up as before.
- **Open Meeting Notes in Live Captions' ⋯ menu opens the meeting being recorded** — or the one paused — rather than whichever meeting the window showed last.

### Fixed

- **Notes stop when the call ends, however you started them.** Notes started with Start Transcription, the menu or a shortcut during a Teams, Zoom, Google Meet or other call now stop and save when that call ends, as notes started from the "Take Notes" offer always did; they used to go on after the call. And notes started after one call has ended are no longer stopped because of it.
- **Record Your Voice is seen whole.** The Speakers pane keeps Settings tall enough for it, so it no longer runs off the bottom of the window; and should its text ever be longer than the window, the text scrolls between the title and the buttons, so Record, Stop and Save stay in reach.

## [0.4.0] - 2026-11-18

### Changed

- **Live Captions move smoothly.** New words glide the captions up instead of jumping them a line at a time; a line heard again shorter no longer pulls everything back down, and only the words a correction changed fade in — words it drops from the end fade out, and words it moves fade back in where they now stand rather than sliding — so you keep your place while reading. Latest glides back down too. With Reduce Motion on, the captions move as before.
- **Live Captions keep their size for a notice.** A notice — a language pack to download, Lumi's recording limit — floats over the top of the captions instead of making the panel taller, so the newest line stays in sight and the panel stays where you put it.

### Fixed

- **A speaker's name held at the top of Live Captions stays put** while their long turn is still being heard; it used to drop and slide back each time the line changed.

## [0.3.0] - 2026-11-18

### Added

- **Meeting Notes in Applications**: open it from Spotlight, the Dock or Launchpad, and its window opens, ready to start a meeting. Opened while Meeting Notes is switched off, it switches it on first.
- Needs Lumi 1.89.0.

## [0.2.0] - 2026-11-18

### Changed

- **A new look, after Apple's design guidelines.** The window keeps your meetings on a floating sidebar, the open meeting's commands as toolbar buttons, and its details, speakers and translation in an inspector; the player floats over the transcript, with skip, speed and Mute Me.
- **Start Transcription is at the foot of the sidebar.** While a meeting is recorded it becomes the recording time with Pause and Stop — click the time to go back to the meeting from any other.
- **Settings has a window of its own**, with panes for General, Transcription, Captions, Translation, Speakers, Storage and About.
- **Live Captions stay out of the way.** While you read, the panel shows the captions, the recording time and Lumi's mark — nothing else. Point at it and the controls come in: click the red time to stop. The panel keeps its size, is frosted glass in its own appearance and turns solid under the pointer.
- **Translate a caption** from the button it shows when you point at it.

### Added

- **Copy one line**, with who said it, from its hover buttons or its menu.
- **Open the meeting being recorded** by clicking its card in the menu bar panel.
- **Full screen**: the sidebar's button and the recorder move into the corner the window buttons leave.

### Fixed

- Meeting Notes no longer asks Lumi for too much at once every time a meeting being recorded is saved.

## [0.1.0] - 2026-10-25

### Added

- **Live captions for your meetings**, in a panel that floats above your call: what is said, as it is said, with **speaker identification** — saved voice profiles by name, everyone else as Speaker 1, 2, 3 — and your own lines as Me.
- **Meetings in two languages**: set a Second Language in Settings, and each line is written in whichever of the two it was said in. Translation translates each line from its own language and leaves the lines already in the language you translate into.
- **Translation on request**: click a caption to translate it, or turn on **Live Translation**, with Apple Translation on this Mac or the AI model you set up in Lumi.
- **Every meeting saved as a transcript** in the Meeting Notes window, to read, copy or export as Markdown or plain text.
- **Read what one speaker said**: click a speaker above a transcript to show only their lines, click others to add theirs, and Reset shows everyone again. The chevron beside a speaker names it, right there.
- **Voice profiles**: name a speaker during or just after a meeting and save the profile, and Meeting Notes identifies them in every meeting after.
- **My Voice**: record your own voice in Settings, with the steps and a text to read, so in a call your lines are Me and anyone else heard by your microphone is shown as another speaker.
- **Listen back to a meeting**: with Keep Audio on, each meeting's audio is kept with its transcript. Click a line's time to hear it from there, the line being heard lit, at 1×, 1.5× or 2×, and in a call **Mute Myself** plays it without your microphone; Save Audio… writes it as an .m4a, into a folder you choose in Settings or wherever you pick. Delete All Audio in Settings removes it and keeps the transcripts.
- **Long meetings**: a recording runs up to two hours by default; set **Longest Recording** in Settings, up to eight hours, and **Auto-Resume at Recording Limit** goes on in the same meeting once it is reached.
- Hints as you point at a button, a speaker or a caption, and why a button is off — in the captions panel too.
- **Notices a meeting starting**: when Microsoft Teams, Zoom, FaceTime or another call app — or Google Meet, Teams or Zoom in a browser — starts using your microphone, a **Take Notes** button comes up at the top right of your screen. Meeting Notes never starts by itself. When the call ends, the notes stop and are saved, with **Resume** if it was too soon — or it asks first, or keeps recording, as you choose in Settings, where each call app has a switch (Slack is off, since it holds the microphone outside huddles too) and the meeting sites are a list you can edit.
- Opens from its own menu bar item, or with ⌃⌥⌘M.
- Needs Lumi 1.65.0.
`;function s(e,t){let n=e.split(/^\[extension\]\s*$/m)[1]?.split(/^\[/m)[0]??``;for(let e of n.split(`
`)){let n=e.match(/^([A-Za-z0-9_-]+)\s*=\s*"([^"]*)"\s*$/);if(n?.[1]===t)return n[2]??``}return``}var c={Added:`New Features`,Changed:`Improvements`,Fixed:`Bug Fixes`,Removed:`Removed`,Deprecated:`Deprecated`,Security:`Security`};function l(e){return e.split(/^## /m).slice(1).map(e=>{let[t=``,...n]=e.split(`
`),[,r=``,i=``]=t.match(/^\[([^\]]+)\]\s*-\s*(\S+)/)??[],a=[];for(let e of n)e.startsWith(`### `)?a.push({kind:e.slice(4).trim(),changes:[]}):e.startsWith(`- `)&&(a.length===0&&a.push({kind:``,changes:[]}),a[a.length-1].changes.push(e.slice(2).trim()));return{version:r,date:i,parts:a.filter(e=>e.changes.length>0)}}).filter(e=>e.version!==``&&e.parts.length>0)}function u(e){return e.split(/(\*\*[^*]+\*\*)/).filter(e=>e!==``).map(e=>e.startsWith(`**`)&&e.endsWith(`**`)&&e.length>4?{text:e.slice(2,-2),bold:!0}:{text:e,bold:!1})}function d(e){let t=new Date(`${e}T12:00:00`);return/^\d{4}-\d{2}-\d{2}$/.test(e)&&!Number.isNaN(t.getTime())?t.toLocaleDateString(`en-GB`,{day:`numeric`,month:`long`,year:`numeric`}):e}function f(e){return e.replace(/^https?:\/\//,``).replace(/[/?#].*$/,``)}var p=!1,m=!1,h=!1,g=!1;function _(e){fetch(`/__lumi__/close-guard`,{method:`PUT`,body:JSON.stringify({held:e})}).catch(()=>{})}function v(e){e!==g&&(g=e,_(e))}function y(e,t){n(t===void 0?{m:`float`,floating:e}:{m:`float`,floating:e,recede:t}).catch(()=>{})}function b(e){if(m=e,!h)return y(!e);y(!e,e?p?!0:void 0:!1)}function x(e){let t=p;p=e,h&&e&&!t&&m&&y(!1,!0)}function S(e=!1){h=e;let r=e?t(`lumi:close-requested`,()=>{n({m:`close-main`}).then(e=>!e.ok&&_(!1)).catch(()=>_(!1))}):()=>{},i=()=>void fetch(`/__lumi__/keyboard`).then(e=>e.ok?e.json():null).then(e=>{typeof e?.held==`boolean`&&b(e.held)}).catch(()=>{});i();let a=[t(`lumi:keyboard`,e=>b(!!e?.held)),t(`lumi:shown`,()=>{i(),g&&_(!0)}),r,t(`lumi:hidden`,()=>b(!1))];return()=>a.forEach(e=>e())}export{f as a,l as c,a as d,i as f,c as i,u as l,x as n,d as o,S as r,s,v as t,o as u};
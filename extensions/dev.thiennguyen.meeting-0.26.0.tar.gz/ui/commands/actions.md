List my action items from this meeting, each with its owner and due date where one was said, citing the line it comes from.

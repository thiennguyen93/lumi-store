List the decisions made in this meeting, each citing the line it was made in.

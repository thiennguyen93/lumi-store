List what is still open or undecided in this meeting, each citing the line that raised it.

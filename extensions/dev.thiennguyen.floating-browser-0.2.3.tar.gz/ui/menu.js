// The menu under Floating Browser's item in the menu bar, behaving as a
// macOS menu does — and the pill's menu of the tabs, the same page in a
// window of its own (`tabs`), which the component gives the tabs' rows and
// Close, the browser's ×, alone (`rows_of`). The rows are the component's
// (`menu_rows`, src/lib.rs):
// asked for when the page loads and told again (`lumi:message`) whenever
// they change — the panel keeps its page while put away, so it draws and
// sizes itself for the next opening while nobody is looking, and opens on
// its first frame at the size its rows want.
//
// As a macOS menu:
// - one row lit at a time, by the pointer or by the arrows alike — ↓ from
//   nothing lights the first row and ↑ the last, and both go round; nothing
//   is lit when it opens, and the pointer leaving the menu puts the light
//   out;
// - a row is chosen when the button comes up on it, so a press can slide
//   from one row to another; Return or Space chooses the lit row, or closes
//   the menu when none is;
// - typing a row's first letters lights it, the letters forgotten after a
//   second's pause;
// - a chosen row blinks once before the menu goes, so the eye sees which;
// - a row that cannot be chosen never lights.
//
// Escape and a press anywhere else put it away (Lumi's, for this panel).

"use strict";

const menu = document.getElementById("menu");

// Which menu this page is — the icon's (`menu`) or the pill's (`tabs`) — as
// Lumi names the window in the page's address, for menu.css: the pill's is
// narrower, its titles cut sooner.
document.documentElement.dataset.window = new URLSearchParams(location.search).get("window") || "";

/** The rows as last drawn: `{id, label, checked, disabled, url, icon,
 *  sound}` each, or `{separator: true}`. */
let rows = [];
/** The index in `rows` of the row lit now, or -1. */
let lit = -1;
/** A row was chosen: the blink is under way and the menu about to go. */
let choosing = false;
/** Type-ahead: what was typed so far, and when the last letter was. */
let typed = "";
let typedAt = 0;
/** The size the panel was last asked to be, so a redraw that changes
 *  nothing asks nothing. */
let asked = "";

/** How long the letters typed are remembered, as macOS's type select. */
const TYPED_FOR = 1000;
/** The blink: the light out, then on again, each this long. */
const BLINK = 70;

/** One of this extension's own requests (`run_ui`). */
async function call(request) {
  const answer = await fetch("/__lumi__/call", { method: "POST", body: JSON.stringify(request) });
  const text = await answer.text();
  if (!answer.ok) throw new Error(text);
  return text ? JSON.parse(text) : null;
}

// ---- Drawing -----------------------------------------------------------------

const SVG = "http://www.w3.org/2000/svg";

/** An icon of `paths` (SVG path data) in a `box`-square view. */
function glyph(className, box, paths) {
  const picture = document.createElementNS(SVG, "svg");
  picture.setAttribute("class", className);
  picture.setAttribute("viewBox", `0 0 ${box} ${box}`);
  picture.setAttribute("aria-hidden", "true");
  for (const each of paths) {
    const path = document.createElementNS(SVG, "path");
    path.setAttribute("d", each);
    picture.append(path);
  }
  return picture;
}

/** macOS's check, drawn: the menu font's own is a picture AppKit draws. */
const CHECK = ["M1.6 5.5 4.1 8 8.5 2.1"];
/** Lucide's (ISC): the globe for a site with no icon found, and the
 *  speakers the browser's own tabs draw. */
const GLOBE = ["M2 12a10 10 0 1 0 20 0 10 10 0 1 0-20 0", "M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20", "M2 12h20"];
const SOUND = [
  "M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z",
  "M16 9a5 5 0 0 1 0 6",
  "M19.364 18.364a9 9 0 0 0 0-12.728",
];
const SILENT = [
  "M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z",
  "M22 9l-6 6",
  "M16 9l6 6",
];

/** A tab's icon as the browser found it: one the package carries
 *  (`icons/…`), or a picture as a `data:` URL — nothing else is drawn. */
function iconOf(row) {
  const icon = typeof row.icon === "string" ? row.icon : "";
  if (/^icons\/[\w.-]+$/.test(icon) || /^data:image\/[\w.+-]+;base64,/.test(icon)) {
    const picture = document.createElement("img");
    picture.className = "favicon";
    picture.alt = "";
    picture.draggable = false;
    picture.src = icon;
    picture.addEventListener("error", () => picture.replaceWith(glyph("globe", 24, GLOBE)));
    return picture;
  }
  return glyph("globe", 24, GLOBE);
}

/** The rows drawn from `model`, as the component sends them, and the panel
 *  sized to them. What is not a row is left out. */
function draw(model) {
  const given = model && model.v === 1 && Array.isArray(model.rows) ? model.rows.slice(0, 24) : [];
  rows = given.filter((row) => row && (row.separator === true || (typeof row.id === "string" && typeof row.label === "string")));
  lit = -1;
  menu.removeAttribute("aria-activedescendant");
  menu.replaceChildren(
    ...rows.map((row, index) => {
      if (row.separator) {
        const line = document.createElement("div");
        line.className = "separator";
        line.setAttribute("role", "separator");
        return line;
      }
      const element = document.createElement("div");
      element.className = "row";
      element.id = `row-${index}`;
      element.dataset.index = String(index);
      const checkable = typeof row.checked === "boolean";
      element.setAttribute("role", checkable ? "menuitemcheckbox" : "menuitem");
      if (checkable) element.setAttribute("aria-checked", String(row.checked));
      if (row.disabled) element.setAttribute("aria-disabled", "true");
      if (row.checked) element.append(glyph("check", 10, CHECK));
      if (typeof row.url === "string") element.append(iconOf(row));
      const title = document.createElement("span");
      title.className = "title";
      title.textContent = row.label;
      element.append(title);
      if (row.sound === "playing" || row.sound === "muted") {
        const sound = glyph("sound", 24, row.sound === "muted" ? SILENT : SOUND);
        element.append(sound);
        element.setAttribute("aria-description", row.sound === "muted" ? "Muted" : "Playing");
      }
      return element;
    }),
  );
  size();
}

/** The panel asked to be the menu's size: as wide as its widest row and as
 *  tall as its rows. Asked while it is put away too, so the next opening is
 *  already that size (`keep-alive`). */
function size() {
  const box = menu.getBoundingClientRect();
  const width = Math.ceil(box.width);
  const height = Math.ceil(box.height);
  const wanted = `${width}x${height}`;
  if (wanted === asked || height === 0) return;
  asked = wanted;
  fetch("/__lumi__/size", { method: "POST", body: JSON.stringify({ width, height }) }).catch(() => {
    asked = "";
  });
}

// ---- The lit row -------------------------------------------------------------

function choosable(index) {
  const row = rows[index];
  return Boolean(row && !row.separator && !row.disabled);
}

function light(index) {
  if (index === lit) return;
  const before = menu.querySelector(".row.on");
  if (before) before.classList.remove("on");
  lit = choosable(index) ? index : -1;
  if (lit < 0) {
    menu.removeAttribute("aria-activedescendant");
    return;
  }
  const element = document.getElementById(`row-${lit}`);
  element.classList.add("on");
  menu.setAttribute("aria-activedescendant", element.id);
}

/** The next row that can be chosen, `by` 1 or -1 from the lit one, round
 *  the ends: from none, the first going down and the last going up. */
function step(by) {
  const count = rows.length;
  let index = lit < 0 ? (by > 0 ? -1 : count) : lit;
  for (let tries = 0; tries < count; tries += 1) {
    index = (index + by + count) % count;
    if (choosable(index)) return light(index);
  }
}

/** The first or the last row that can be chosen. */
function end(last) {
  lit = -1;
  const order = rows.map((_, index) => index);
  if (last) order.reverse();
  const index = order.find(choosable);
  if (index !== undefined) light(index);
}

/** A title as type-ahead compares it: no case, no accents — "huong"
 *  finds "Hương". */
function folded(text) {
  return text
    .normalize("NFD")
    .replace(/\p{M}/gu, "")
    .replace(/đ/g, "d")
    .replace(/Đ/g, "D")
    .toLowerCase();
}

function typeAhead(letter) {
  const now = performance.now();
  typed = now - typedAt > TYPED_FOR ? letter : typed + letter;
  typedAt = now;
  const wanted = folded(typed);
  const index = rows.findIndex((row, at) => choosable(at) && folded(row.label).startsWith(wanted));
  if (index >= 0) light(index);
}

// ---- Choosing ----------------------------------------------------------------

/** The row at `index` chosen: a blink, then the component runs it and puts
 *  the menu away (`choose`). */
function choose(index) {
  if (choosing || !choosable(index)) return;
  choosing = true;
  light(index);
  const element = document.getElementById(`row-${index}`);
  const id = rows[index].id;
  element.classList.remove("on");
  setTimeout(() => {
    element.classList.add("on");
    setTimeout(() => {
      call({ kind: "choose", row: id }).catch(() => {
        choosing = false;
      });
    }, BLINK);
  }, BLINK);
}

/** The menu put away with nothing chosen. */
function dismiss() {
  call({ kind: "dismiss" }).catch(() => {});
}

function rowAt(event) {
  const element = event.target instanceof Element ? event.target.closest(".row") : null;
  return element ? Number(element.dataset.index) : -1;
}

// The pointer lights the row under it — none over a separator, a row that
// cannot be chosen or the glass around them — and the light goes out as it
// leaves the menu.
menu.addEventListener("pointermove", (event) => {
  if (!choosing) light(rowAt(event));
});
document.documentElement.addEventListener("pointerleave", () => {
  if (!choosing) light(-1);
});

// Chosen where the button comes up, as macOS chooses: a press may slide from
// row to row first. The right button chooses too, as in a macOS menu.
menu.addEventListener("pointerup", (event) => {
  if (event.button !== 0 && event.button !== 2) return;
  const index = rowAt(event);
  if (choosable(index)) choose(index);
});
addEventListener("contextmenu", (event) => event.preventDefault());

document.addEventListener("keydown", (event) => {
  if (event.isComposing || event.keyCode === 229) return;
  if (choosing) {
    event.preventDefault();
    return;
  }
  if (event.metaKey || event.ctrlKey) return;
  switch (event.key) {
    case "ArrowDown":
      step(1);
      break;
    case "ArrowUp":
      step(-1);
      break;
    case "Home":
    case "PageUp":
      end(false);
      break;
    case "End":
    case "PageDown":
      end(true);
      break;
    case "Enter":
      if (lit >= 0) choose(lit);
      else dismiss();
      break;
    case " ":
      // A space inside letters being typed is one of them.
      if (typed && performance.now() - typedAt <= TYPED_FOR) typeAhead(" ");
      else if (lit >= 0) choose(lit);
      else dismiss();
      break;
    case "Escape":
      dismiss();
      break;
    default:
      if (event.key.length === 1 && !event.altKey) typeAhead(event.key);
      else return;
  }
  event.preventDefault();
});

// ---- Told by the component -------------------------------------------------------

addEventListener("lumi:message", (event) => {
  const said = event.detail;
  if (said && said.kind === "menu") draw(said.menu);
});

// Every opening starts with nothing lit and nothing typed, as a macOS menu
// opens; put away, the blink and the light are over.
addEventListener("lumi:hidden", () => {
  choosing = false;
  typed = "";
  light(-1);
});

addEventListener("lumi:shown", () => {
  choosing = false;
  typed = "";
  light(-1);
  menu.focus();
});

call({ kind: "menu" })
  .then(draw)
  .catch(() => draw(null));

// Floating Browser's Welcome window (welcome.html): seven steps and a
// finish. Each step's stage acts out what its words say, with a pointer of
// its own; the second step reads the shortcut Lumi armed at install and
// records another there, the way Gõ tiếng Việt's Welcome does. The
// component answers what a page cannot do itself (src/welcome.rs): why the
// window is up, the browser opened from the finish, and the window closed.
// An extension page may run no inline script (its CSP is
// `default-src 'self'`), so this is a file of its own.

"use strict";

const STEPS = document.querySelectorAll(".step").length;
const still = matchMedia("(prefers-reduced-motion: reduce)").matches;
const $ = (id) => document.getElementById(id);

// ---- The bridge -----------------------------------------------------------

// One request to the component (src/welcome.rs), answered as JSON; a
// refusal as an Error with its sentence.
async function call(request) {
  const answer = await fetch("/__lumi__/call", { method: "POST", body: JSON.stringify(request) });
  const body = await answer.text();
  if (!answer.ok) throw new Error(body || `Lumi answered ${answer.status}`);
  return body ? JSON.parse(body) : {};
}

// ---- The shortcut -----------------------------------------------------------

// An accelerator as Lumi writes one (`Ctrl+Alt+Super+KeyB`), one key cap
// each, in macOS's glyphs and order.
function capsOf(accelerator) {
  const parts = accelerator.split("+");
  const key = parts.pop() || "";
  const glyph = { Ctrl: "⌃", Control: "⌃", Alt: "⌥", Option: "⌥", Shift: "⇧", Super: "⌘", Cmd: "⌘", Command: "⌘" };
  const mods = new Set(parts.map((part) => glyph[part] || part));
  const name = /^Key([A-Z])$/.exec(key)?.[1] ?? /^Digit([0-9])$/.exec(key)?.[1] ?? key;
  return [...["⌃", "⌥", "⇧", "⌘"].filter((mod) => mods.has(mod)), name];
}

const glyphs = (accelerator) => capsOf(accelerator).join("");

// One `<kbd>` for each of `accelerator`'s key caps.
const kbdsOf = (accelerator) =>
  capsOf(accelerator).map((cap) => {
    const kbd = document.createElement("kbd");
    kbd.textContent = cap;
    return kbd;
  });

// The whole of `accelerator` in one `<kbd>`, as a row's words write a key
// (⌘L, ⌘Y): key caps one by one are for where a key is the subject.
function keyIn(accelerator) {
  const kbd = document.createElement("kbd");
  kbd.textContent = glyphs(accelerator);
  return kbd;
}

// The combination a press makes, as Lumi's recorder writes it, or null for a
// key no global shortcut can end on — a modifier still being held.
function acceleratorOf(event) {
  const key = /^(Key[A-Z]|Digit[0-9]|Space|F([1-9]|1[0-2]))$/.test(event.code) ? event.code : null;
  if (!key) return null;
  const mods = [event.ctrlKey && "Ctrl", event.altKey && "Alt", event.shiftKey && "Shift", event.metaKey && "Super"].filter(Boolean);
  return [...mods, key].join("+");
}

// Who holds a key, from Lumi's description of them: "“Search” in the Work
// profile and Lumi's own Show Lumi".
function holdersText(holders) {
  const names = holders.map((holder) =>
    holder.kind === "shortcut"
      ? holder.name
        ? `“${holder.name}” in the ${holder.profileName} profile`
        : `a shortcut in the ${holder.profileName} profile`
      : holder.kind === "app"
        ? `Lumi's own ${holder.label}`
        : `${holder.extensionName}'s ${holder.commandLabel}`,
  );
  return names.length <= 1 ? names[0] || "" : `${names.slice(0, -1).join(", ")} and ${names[names.length - 1]}`;
}

// One of the extension's own keys (a `[[shortcut]]` in the manifest) as a
// row of the shortcut step — `command`'s: `line` for what Lumi made of the
// key at install, or of the last press, and `recorder` for the key itself,
// which a click records again. `changed()` is told whenever the key Lumi
// holds may have changed; `recording()` as this row starts to record, so
// the other row stops — Lumi holds one recording at a time.
function keyRow({ command, line, recorder, changed, recording: started = () => {} }) {
  // `ess` in `GET /__lumi__/shortcuts`, the command's: `undefined` while it
  // is read, `null` when Lumi has none to tell.
  let own;
  // Lumi's Shortcuts switch, which every global key waits on.
  let shortcutsOn = true;
  let recording = false;
  let busy = false;
  // Why the last press or write did not land, or "".
  let said = "";
  // A key somebody holds, pressed here: offered to take, or not.
  let held = null;

  async function read() {
    try {
      const answer = await fetch("/__lumi__/shortcuts");
      if (!answer.ok) throw new Error();
      const all = await answer.json();
      shortcutsOn = all.on !== false;
      own = (all.ess || []).find((one) => one.command === command) || null;
    } catch {
      own = null;
    }
    draw();
    changed();
  }

  // Arm `key`, or clear it with null; `replace` takes it off whoever holds
  // it. A 409 is the key being somebody's: offered to take when Lumi allows
  // it.
  async function write(key, replace = false) {
    busy = true;
    said = "";
    draw();
    try {
      const answer = await fetch("/__lumi__/shortcuts", { method: "PUT", body: JSON.stringify({ command, key, replace }) });
      const body = await answer.text();
      if (answer.status === 409) {
        held = { key, holders: JSON.parse(body).holders || [] };
      } else if (!answer.ok) {
        said = body || `Lumi answered ${answer.status}`;
        held = null;
      } else {
        own = JSON.parse(body);
        held = null;
      }
    } catch (err) {
      said = err instanceof Error ? err.message : String(err);
    } finally {
      busy = false;
      draw();
      changed();
    }
  }

  // While recording, Lumi lets go of every global shortcut, so the
  // combination pressed — even one something holds, the command's own —
  // reaches this page rather than running. Lumi ends that itself when the
  // page loses the keyboard or after 30 seconds, and says so with
  // `lumi:shortcut-recording-ended`.
  function take(event) {
    event.preventDefault();
    event.stopPropagation();
    if (event.key === "Escape") {
      stop();
      return;
    }
    const got = acceleratorOf(event);
    if (!got) return;
    if (!/(^|\+)(Ctrl|Alt|Super)\+/.test(got)) {
      said = `${glyphs(got)}: add ⌘, ⌥ or ⌃, on its own it would take the key away from typing.`;
      draw();
      return;
    }
    stop();
    void write(got);
  }

  async function record() {
    started();
    said = "";
    held = null;
    recording = true;
    window.addEventListener("keydown", take, true);
    window.addEventListener("lumi:shortcut-recording-ended", stop);
    draw();
    const answer = await fetch("/__lumi__/shortcut-recording", { method: "POST" }).catch(() => null);
    if (answer && !answer.ok && answer.status !== 404 && recording) {
      said = (await answer.text()) || `Lumi answered ${answer.status}`;
      stop();
    }
  }

  function stop() {
    if (!recording) return;
    recording = false;
    window.removeEventListener("keydown", take, true);
    window.removeEventListener("lumi:shortcut-recording-ended", stop);
    void fetch("/__lumi__/shortcut-recording", { method: "DELETE" }).catch(() => {});
    draw();
  }

  function link(label, onclick) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "link";
    button.disabled = busy;
    button.textContent = label;
    button.addEventListener("click", onclick);
    return button;
  }

  function draw() {
    line.classList.remove("bad");
    if (own === undefined || own === null) {
      // A Lumi that tells an extension nothing of its key: the key is set
      // where every key is.
      line.textContent = own === undefined ? "Looking up the shortcut…" : "Give it a key on its Shortcuts tab in Lumi’s Settings.";
      recorder.replaceChildren();
      return;
    }
    const declared = glyphs(own.declared);
    if (recording) {
      line.textContent = "Press the new shortcut · Esc to cancel";
    } else if (held) {
      const key = glyphs(held.key);
      const holders = holdersText(held.holders);
      if (held.holders.length > 0 && held.holders.every((holder) => holder.kind !== "extension")) {
        line.replaceChildren(
          `${key} is used by ${holders}. Take it anyway? `,
          link("Keep Theirs", () => {
            held = null;
            draw();
          }),
          " · ",
          link("Take It", () => void write(held.key, true)),
        );
      } else {
        line.textContent = `${key} belongs to ${holders}. Pick another key.`;
        line.classList.add("bad");
      }
    } else if (said) {
      line.textContent = said;
      line.classList.add("bad");
    } else if (own.key) {
      line.textContent = !shortcutsOn
        ? "Shortcuts are switched off in Lumi, so this key does nothing yet."
        : own.key === own.declared
          ? "Ready in every profile. Click the key to change it."
          : `Instead of ${declared}. Click the key to change it.`;
      line.classList.toggle("bad", !shortcutsOn);
    } else if (own.state === "taken" && own.holder) {
      // Short enough for one line beside the recorder: the step holds two.
      line.textContent = `${declared} is taken by ${holdersText([own.holder])}.`;
      line.classList.add("bad");
    } else if (own.state === "invalid") {
      line.textContent = own.reason || `Lumi could not set up ${declared}.`;
      line.classList.add("bad");
    } else {
      line.textContent = "No key yet. Click Record to choose one.";
    }

    const parts = [];
    if (!recording && own.key !== own.declared && own.state !== "invalid") {
      parts.push(link(`Use ${declared}`, () => void write(own.declared)));
    }
    if (!recording && own.key) parts.push(link("Clear", () => void write(null)));
    const keys = document.createElement("button");
    keys.type = "button";
    keys.disabled = busy;
    keys.className = recording ? "keycaps recording" : own.key ? "keycaps" : "keycaps unset";
    keys.setAttribute(
      "aria-label",
      recording ? "Press the new shortcut, or Esc" : own.key ? `Shortcut ${glyphs(own.key)}, click to change` : "No shortcut, click to record one",
    );
    if (recording || !own.key) {
      const label = document.createElement("span");
      label.className = "listening";
      label.textContent = recording ? "Press keys…" : "Record";
      keys.append(label);
    } else {
      keys.append(...kbdsOf(own.key));
    }
    keys.addEventListener("click", () => (recording ? stop() : void record()));
    parts.push(keys);
    recorder.replaceChildren(...parts);
  }

  return {
    read,
    stop,
    // The key armed for the command, or null: none, or none told.
    get key() {
      return (own && own.key) || null;
    },
  };
}

// ---- Steps ------------------------------------------------------------------

// The two keys the shortcut step records: the one that shows the browser
// and puts it away, and Minimize's. Every other sentence that names a key
// reads it from these.
const keyChanged = () => {
  drawKeyWords();
  if (!$("finish").hidden) drawDone();
  else if (step === 1) playScene();
};
const shortcut = keyRow({
  command: "toggle",
  line: $("key-says"),
  recorder: $("recorder"),
  changed: keyChanged,
  recording: () => minimizeShortcut.stop(),
});
const minimizeShortcut = keyRow({
  command: "minimize",
  line: $("minimize-key-says"),
  recorder: $("minimize-recorder"),
  changed: keyChanged,
  recording: () => shortcut.stop(),
});

let step = 0;
let failed = "";

// The sentences that name the key, as it now is.
function drawKeyWords() {
  const minimizeKey = minimizeShortcut.key;
  const minimize = $("minimize-says");
  if (minimizeKey) {
    minimize.replaceChildren("The − beside ×, ", keyIn("Super+KeyM"), ", or ", keyIn(minimizeKey), " from any app, which also brings it back.");
  } else {
    minimize.replaceChildren("The − beside ×, or ", keyIn("Super+KeyM"), ". Drag the pill wherever you like.");
  }
  const key = shortcut.key;
  const close = $("close-says");
  const away = $("away-says");
  if (key) {
    close.replaceChildren("Closes every tab and takes the icon away, until ", keyIn(key), " brings it back.");
    away.replaceChildren(keyIn(key), ". Your tabs stay as they were; sound pauses until it is back. × closes them.");
  } else {
    close.textContent = "Closes every tab and takes the icon away, until you open the browser again.";
    away.textContent = "Its shortcut keeps your tabs as they were, sound paused until it is back. × closes them.";
  }
}

function draw() {
  $("back").hidden = step === 0;
  for (const section of document.querySelectorAll(".step")) {
    section.hidden = Number(section.dataset.step) !== step;
  }
  for (const scene of document.querySelectorAll(".scene")) {
    scene.hidden = Number(scene.dataset.scene) !== step;
  }
  $("dots").replaceChildren(
    ...Array.from({ length: STEPS }, (_, at) => {
      const dot = document.createElement("span");
      if (at === step) dot.className = "on";
      return dot;
    }),
  );
  for (const id of ["failed", "finish-failed"]) {
    $(id).textContent = failed;
    $(id).hidden = !failed;
  }
}

function go(to) {
  shortcut.stop();
  minimizeShortcut.stop();
  failed = "";
  step = Math.max(0, Math.min(STEPS - 1, to));
  $("finish").hidden = true;
  $("tour").hidden = false;
  draw();
  playScene();
  $("next").focus();
}

function act(work) {
  failed = "";
  draw();
  Promise.resolve()
    .then(work)
    .catch((err) => {
      failed = err instanceof Error ? err.message : String(err);
      draw();
    });
}

// ---- The stage --------------------------------------------------------------

const stage = $("stage");
const cursor = $("cursor");

// The run now playing, so a newer one (another step) ends it.
let playing = 0;
let timer = 0;

function stopPlaying() {
  playing++;
  clearTimeout(timer);
  cursor.classList.remove("on");
}

// Play `steps` — `[wait in ms, then do]` — in order, and from the start
// again after the last.
function script(steps) {
  const run = ++playing;
  clearTimeout(timer);
  let at = 0;
  const next = () => {
    if (run !== playing) return;
    if (at === steps.length) at = 0;
    const [wait, then] = steps[at++];
    timer = setTimeout(() => {
      if (run !== playing) return;
      then();
      next();
    }, wait);
  };
  next();
}

// Restart a CSS animation on `el` by taking its class away and putting it
// back.
function restart(el, className) {
  el.classList.remove(className);
  void el.offsetWidth;
  el.classList.add(className);
}

// The pointer's tip on the middle of `el`, or `dx`, `dy` from it.
function pointAt(el, dx = 0, dy = 0) {
  const s = stage.getBoundingClientRect();
  const r = el.getBoundingClientRect();
  const x = r.left - s.left + r.width / 2 + dx;
  const y = r.top - s.top + r.height / 2 + dy;
  cursor.style.transform = `translate(${Math.round(x)}px, ${Math.round(y)}px)`;
  cursor.classList.add("on");
}

// The pointer back off the stage, where each step's starts from.
function pointerHome() {
  cursor.classList.remove("on");
  cursor.style.transform = "";
}

const click = () => restart(cursor, "press");

// The video on the stage's tabs: the same lo-fi city in every `.video`,
// each layer an empty element welcome.css draws and moves. Built here
// rather than written out in welcome.html, where it would be four copies of
// some forty elements. Playing, so the player shows Pause, and its time
// runs on the clock, the seek bar with it.

/** How long the video is, and where it is when the window opens, in seconds. */
const VIDEO_LENGTH = 80;
const VIDEO_FROM = 18;

function layer(className, children = 0) {
  const el = document.createElement("span");
  el.className = className;
  for (let at = 0; at < children; at++) el.append(document.createElement("i"));
  return el;
}

// One of welcome.html's icons, as an `<svg>` of class `className`.
function glyph(className, href) {
  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute("class", className);
  const use = document.createElementNS("http://www.w3.org/2000/svg", "use");
  use.setAttribute("href", href);
  svg.append(use);
  return svg;
}

// A tab's close button at its end, after its speaker, as the browser draws
// it (browser.js): shown on the tab in front, which is every one the stage
// points at; the others show theirs only under the pointer, which the stage
// never puts there.
function withShut(tab) {
  const shut = document.createElement("span");
  shut.className = "shut";
  shut.append(glyph("i", "#i-x"));
  tab.append(shut);
  return tab;
}

function dressVideos() {
  for (const video of document.querySelectorAll(".fb-site.video")) {
    // Under whatever the page put there itself (the sound's bars).
    video.prepend(
      layer("sky"),
      layer("moon"),
      layer("cloud c1"),
      layer("cloud c2"),
      layer("city far", 16),
      layer("city near", 12),
      layer("shade"),
    );
    video.append(layer("pause"), layer("vtime"), layer("progress", 1));
  }
}

const minutes = (seconds) => `${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, "0")}`;
let videoAt = VIDEO_FROM;

function showVideoAt(jumped) {
  for (const video of document.querySelectorAll(".fb-site.video")) {
    video.classList.toggle("jump", jumped);
    video.style.setProperty("--played", `${(videoAt / VIDEO_LENGTH) * 100}%`);
    video.querySelector(".vtime").textContent = `${minutes(videoAt)} / ${minutes(VIDEO_LENGTH)}`;
  }
}

dressVideos();
for (const tab of document.querySelectorAll(".fb-tab")) withShut(tab);
showVideoAt(true);
if (!still) {
  setInterval(() => {
    const ended = videoAt >= VIDEO_LENGTH;
    videoAt = ended ? 0 : videoAt + 1;
    showVideoAt(ended);
  }, 1000);
}

// The menu bar's clock on every desk: the time now, as the menu bar shows
// it, with the Mac's own 12 or 24 hours — Gõ tiếng Việt's Welcome's clock.
// Kept right to the minute while the window is up, from each minute's turn.
const hourCycle = new Intl.DateTimeFormat([], { hour: "numeric" }).resolvedOptions().hourCycle;
let clockTimer = 0;

function tick() {
  const now = new Date();
  const time = now.toLocaleTimeString([], { hour: "numeric", minute: "2-digit", hourCycle });
  for (const clock of document.querySelectorAll(".clock")) clock.textContent = time;
  clearTimeout(clockTimer);
  clockTimer = setTimeout(tick, 60000 - (now.getTime() % 60000));
}

tick();

// 1. Desktops swiped through; the browser stays.
const SPACES = [
  ["Desktop 1", "Notes"],
  ["Desktop 2", "Numbers"],
  ["Full screen", ""],
];

function space(n) {
  $("everywhere").dataset.space = String(n);
  $("everywhere-label").textContent = SPACES[n][0];
  if (SPACES[n][1]) $("everywhere-app").textContent = SPACES[n][1];
}

function playEverywhere() {
  space(0);
  if (still) return;
  script([
    [1800, () => space(1)],
    [2300, () => space(2)],
    [2600, () => space(0)],
  ]);
}

// 2. The shortcut pressed: the browser comes and goes. With no key armed
// the caps say so, and nothing comes or goes.
function playShortcut() {
  const press = $("press");
  const fb = $("toggle-fb");
  const key = shortcut.key;
  press.replaceChildren(...(key ? kbdsOf(key) : ["No key yet"]));
  press.classList.toggle("none", !key);
  fb.classList.remove("away");
  if (still || !key) return;
  script([
    [1500, () => {
      restart(press, "down");
      fb.classList.add("away");
    }],
    [1400, () => {
      restart(press, "down");
      fb.classList.remove("away");
    }],
  ]);
}

// 3. Tabs to four, a shortcut dragged to the front, a search typed.
const TILES = ["google", "youtube", "facebook", "outlook", "wikipedia", "github"];

function newTab(on) {
  const tab = document.createElement("span");
  tab.className = on ? "fb-tab on born" : "fb-tab";
  const title = document.createElement("span");
  title.className = "t";
  title.textContent = "New Tab";
  tab.append(glyph("i fav", "#i-globe"), title);
  return withShut(tab);
}

function setTabs(count) {
  const tabs = $("tabs-tabs");
  for (const tab of tabs.children) tab.classList.remove("on");
  while (tabs.children.length > count) tabs.lastChild.remove();
  while (tabs.children.length < count) tabs.append(newTab(tabs.children.length === count - 1));
  if (!tabs.querySelector(".on")) tabs.lastChild.classList.add("on");
  tabs.classList.toggle("crowded", count >= 4);
  $("tabs-plus").classList.toggle("off", count >= 4);
}

function tile(name) {
  return $("tabs-tiles").querySelector(`[data-tile="${name}"]`);
}

function placeTiles(order) {
  order.forEach((name, slot) => tile(name).style.setProperty("--slot", String(slot)));
}

function typeInto(text) {
  $("tabs-typed").textContent = text;
  $("tabs-search").classList.toggle("typing", text.length > 0);
}

function resetTabs() {
  setTabs(1);
  placeTiles(TILES);
  for (const one of $("tabs-tiles").children) one.classList.remove("lift");
  $("tabs-search").classList.remove("focus");
  typeInto("");
  $("tabs-suggest").classList.remove("on");
  $("tabs-plus").classList.remove("lit");
}

function playTabs() {
  resetTabs();
  if (still) {
    setTabs(4);
    placeTiles(["wikipedia", ...TILES.filter((name) => name !== "wikipedia")]);
    return;
  }
  const plus = $("tabs-plus");
  const addTab = () => {
    click();
    setTabs($("tabs-tabs").children.length + 1);
  };
  const typing = [..."weather"].map((_, at, all) => [at ? 110 : 350, () => typeInto(all.slice(0, at + 1).join(""))]);
  script([
    [600, () => pointAt(plus)],
    [650, addTab],
    [350, () => pointAt(plus)],
    [550, addTab],
    [350, () => pointAt(plus)],
    [550, addTab],
    [900, () => pointAt(tile("wikipedia"), 0, -6)],
    [650, () => {
      click();
      tile("wikipedia").classList.add("lift");
    }],
    [250, () => {
      // Measured before the tiles move: where the first one stands now.
      pointAt(tile("google"), 0, -6);
      placeTiles(["wikipedia", ...TILES.filter((name) => name !== "wikipedia")]);
    }],
    [650, () => tile("wikipedia").classList.remove("lift")],
    [600, () => pointAt($("tabs-search"), -60, 0)],
    [600, () => {
      click();
      $("tabs-search").classList.add("focus");
    }],
    ...typing,
    [300, () => $("tabs-suggest").classList.add("on")],
    [2400, () => {
      pointerHome();
      resetTabs();
    }],
    [600, () => {}],
  ]);
}

// 4. One tab to its desktop layout, the other still on its phone layout.
function layout(tab, modes) {
  const site = $("layout-site");
  site.dataset.tab = String(tab);
  site.dataset.mode = modes[tab];
  $("layout-tab-0").classList.toggle("on", tab === 0);
  $("layout-tab-1").classList.toggle("on", tab === 1);
  $("layout-host").textContent = tab === 0 ? "lumikeys.app" : "www.google.com";
  $("layout-mode-use").setAttribute("href", modes[tab] === "phone" ? "#i-phone" : "#i-desktop");
}

function playLayouts() {
  const modes = ["phone", "phone"];
  layout(0, modes);
  if (still) return;
  script([
    [900, () => pointAt($("layout-mode"))],
    [650, () => {
      click();
      modes[0] = "desktop";
      layout(0, modes);
    }],
    [1700, () => pointAt($("layout-tab-1"))],
    [650, () => {
      click();
      layout(1, modes);
    }],
    [1700, () => pointAt($("layout-tab-0"))],
    [650, () => {
      click();
      layout(0, modes);
    }],
    [1500, () => pointAt($("layout-mode"))],
    [650, () => {
      click();
      modes[0] = "phone";
      layout(0, modes);
    }],
    [1500, () => pointerHome()],
  ]);
}

// 5. The speaker on the tab pressed, then Mute All from the menu bar.
function sound({ tab = false, all = false } = {}) {
  const hushed = tab || all;
  $("sound-speaker-use").setAttribute("href", hushed ? "#i-silent" : "#i-sound");
  $("sound-video").classList.toggle("hush", hushed);
  $("sound-menu-mark").setAttribute("href", hushed ? "#i-silent" : "#i-sound");
  $("sound-mute-tick").classList.toggle("off", !all);
}

function menu(open) {
  // Under the icon, as macOS opens a menu bar item's menu: from its left
  // edge, moved left only as far as the screen's edge needs. The clock
  // beside it is the time now, so where the icon stands is measured.
  const shown = $("sound-menu");
  if (open) {
    const left = $("sound-item").getBoundingClientRect().left - stage.getBoundingClientRect().left;
    shown.style.left = `${Math.round(Math.min(left, stage.clientWidth - shown.offsetWidth - 6))}px`;
  }
  shown.classList.toggle("on", open);
  $("sound-item").classList.toggle("lit", open);
  if (!open) $("sound-mute-all").classList.remove("pick");
}

function playSound() {
  sound();
  menu(false);
  if (still) return;
  const speaker = $("sound-speaker");
  const muteAll = (to) => [
    [1300, () => pointAt($("sound-item"))],
    [600, () => {
      click();
      menu(true);
    }],
    [500, () => pointAt($("sound-mute-all"), 20, 0)],
    [550, () => $("sound-mute-all").classList.add("pick")],
    [350, () => {
      click();
      sound({ all: to });
      menu(false);
    }],
  ];
  script([
    [800, () => pointAt(speaker)],
    [600, () => {
      click();
      speaker.classList.add("lit");
      sound({ tab: true });
    }],
    [1300, () => {
      click();
      sound();
    }],
    [300, () => speaker.classList.remove("lit")],
    ...muteAll(true),
    [1200, () => {}],
    ...muteAll(false),
    [1400, () => pointerHome()],
  ]);
}

// 6. Compact Mode on from the icon's menu, its bar pointed at and its title
// pressed; then off again.
function compact(on) {
  $("compact-fb").classList.toggle("compact", on);
  $("compact-row").querySelector(".switch").classList.toggle("on", on);
}

function compactMenu(open) {
  $("compact-menu").classList.toggle("on", open);
  $("compact-mark").classList.toggle("lit", open);
  $("compact-mark-2").classList.toggle("lit", open);
  if (!open) $("compact-row").classList.remove("pick");
}

function playCompact() {
  const bar = $("compact-fb").querySelector(".fb-title");
  const title = $("compact-title");
  compact(false);
  compactMenu(false);
  bar.classList.remove("hover");
  title.classList.remove("editing");
  if (still) {
    compact(true);
    return;
  }
  const flip = (to, mark) => [
    [900, () => pointAt($(mark))],
    [600, () => {
      click();
      compactMenu(true);
    }],
    [500, () => pointAt($("compact-row"), 30, 0)],
    [450, () => $("compact-row").classList.add("pick")],
    [300, () => {
      click();
      $("compact-row").querySelector(".switch").classList.toggle("on", to);
    }],
    [350, () => {
      compactMenu(false);
      compact(to);
    }],
  ];
  script([
    ...flip(true, "compact-mark"),
    [1000, () => pointAt(title, 0, 4)],
    [500, () => bar.classList.add("hover")],
    [900, () => {
      click();
      title.classList.add("editing");
    }],
    [1900, () => {
      title.classList.remove("editing");
      bar.classList.remove("hover");
    }],
    ...flip(false, "compact-mark-2"),
    [1500, () => pointerHome()],
  ]);
}

// 7. Minimize into the pill, and back from it.
function playMinimize() {
  const fb = $("mini-fb");
  const pill = $("mini-pill");
  fb.classList.remove("gone");
  pill.classList.remove("on", "lit");
  if (still) return;
  script([
    [900, () => pointAt($("mini-minimize"))],
    [650, () => {
      click();
      fb.classList.add("gone");
      pill.classList.add("on");
    }],
    [700, () => pointAt(pill, 18, 0)],
    [1700, () => pill.classList.add("lit")],
    [400, () => {
      click();
      pill.classList.remove("on", "lit");
      fb.classList.remove("gone");
    }],
    [1200, () => pointerHome()],
  ]);
}

const SCENES = [playEverywhere, playShortcut, playTabs, playLayouts, playSound, playCompact, playMinimize];

function playScene() {
  stopPlaying();
  pointerHome();
  SCENES[step]();
}

// ---- The finish ---------------------------------------------------------------

// Where each piece of confetti flies to from the middle of the mark, in px,
// and how far it turns. Fixed, so every finish bursts the same.
const CONFETTI = [
  [-150, -70, 200], [-120, -110, -140], [-80, -130, 260], [-40, -120, -90],
  [10, -140, 180], [55, -125, -220], [95, -115, 120], [135, -90, -160],
  [165, -50, 240], [-170, -20, -120], [-135, 25, 200], [150, 10, -200],
  [120, 50, 150], [-95, 60, -260], [80, 70, 90], [-30, 80, 210],
];
// The icon's teal and blue, then three that set them off.
const CONFETTI_COLOURS = ["#22c1c3", "#2563eb", "#f59e0b", "#ec4899", "#22c55e"];

// `accelerator`'s key caps kept on one line, so a sentence that wraps never
// leaves ⌃ at the end of one line and the rest of the key on the next.
function keysTogether(accelerator) {
  const keys = document.createElement("span");
  keys.className = "keys-together";
  keys.append(...kbdsOf(accelerator));
  return keys;
}

function drawDone() {
  const line = $("done-says");
  const key = shortcut.key;
  const minimizeKey = minimizeShortcut.key;
  if (key && minimizeKey) {
    line.replaceChildren("Press ", keysTogether(key), " in any app to open it and put it away, and ", keysTogether(minimizeKey), " to minimize it.");
  } else if (key) {
    line.replaceChildren("Press ", keysTogether(key), " in any app to open it, and again to put it away.");
  } else {
    line.textContent = "Give it a shortcut on its Shortcuts tab in Lumi’s Settings to open it from any app.";
  }
}

function finish() {
  stopPlaying();
  shortcut.stop();
  minimizeShortcut.stop();
  $("tour").hidden = true;
  $("finish").hidden = false;
  // The confetti made again, so it bursts every time the finish comes.
  const mark = $("finish-mark");
  for (const piece of mark.querySelectorAll("i")) piece.remove();
  if (!still) {
    CONFETTI.forEach(([x, y, turn], at) => {
      const piece = document.createElement("i");
      piece.style.setProperty("--x", `${x}px`);
      piece.style.setProperty("--y", `${y}px`);
      piece.style.setProperty("--turn", `${turn}deg`);
      piece.style.background = CONFETTI_COLOURS[at % CONFETTI_COLOURS.length];
      mark.prepend(piece);
    });
  }
  drawDone();
  // Read again, should it have been changed on the Shortcuts tab meanwhile.
  void shortcut.read();
  void minimizeShortcut.read();
  $("finish-try").focus();
}

// ---- Why it is up -------------------------------------------------------------

// The version an update replaced, said once on the first step; a fresh
// install, or the tour opened again from Lumi's About page, is a plain
// welcome.
function hello(told) {
  if (!told || !told.from) return;
  $("hello-title").textContent = "Floating Browser was updated";
  $("hello-says").textContent = told.version
    ? `From ${told.from} to ${told.version}. Your tabs, history and shortcuts are where they were — a minute to see what it does.`
    : `From ${told.from}. Your tabs, history and shortcuts are where they were — a minute to see what it does.`;
}

// ---- The controls -------------------------------------------------------------

$("back").addEventListener("click", () => go(step - 1));
$("next").addEventListener("click", () => (step === STEPS - 1 ? finish() : go(step + 1)));
$("finish-try").addEventListener("click", () => act(() => call({ kind: "open" })));
$("again").addEventListener("click", () => go(0));

// A preview outside Lumi is told its theme on the URL; inside Lumi a window
// follows the system.
const theme = new URLSearchParams(location.search).get("theme");
if (theme === "light" || theme === "dark") document.documentElement.dataset.theme = theme;

// Shown once the first step can be drawn as it will stand: the words of an
// update arrive with the component's answer, and drawn before it the window
// would flash the welcome of a fresh install first.
call({ kind: "welcome" })
  .then(hello)
  .catch(() => {})
  .finally(() => {
    $("tour").hidden = false;
    draw();
    playScene();
    $("next").focus();
  });
void shortcut.read();
void minimizeShortcut.read();

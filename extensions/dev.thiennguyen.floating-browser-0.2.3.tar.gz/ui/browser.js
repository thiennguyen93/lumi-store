// Floating Browser's page: tabs, an address bar that also searches, and one
// box (#site) where Lumi draws the tab in front's site (`POST /__lumi__/web`).
//
// Every tab is a site of its own in Lumi, under the tab's id as its name, so
// switching tabs hides one and shows another with no load (Lumi holds four a
// window — `MOST_TABS`). What Lumi tells of a site is its address and title
// (`lumi:web`), and that is all this page ever knows of it.
//
// Back and Forward are this page's own: Lumi has no history to walk, so each
// tab keeps the addresses it was told, and going back asks for the one
// before — a fresh load of it, not the page as it was left. A site that
// moves without loading a page (a YouTube video picked, most of Gmail) tells
// nothing, so its address here stays where its last load was.
//
// Compact Mode, switched under the extension's icon at the start of the
// strip, puts one bar (#title-bar) in place of the strip and the toolbar.
// The icon's menu is drawn over the site, so while it is open the site's
// whole box is sent to Lumi as covered.
//
// Built with textContent throughout: titles and addresses come from sites.

"use strict";

/** The most tabs at once: Lumi holds four sites a window. */
const MOST_TABS = 4;

/** Where a search goes. */
const SEARCH = "https://www.google.com/search?q=";

/** The start page's own shortcuts: shown until the person changes them, and
 *  what Restore Default Shortcuts brings back (The start page's shortcuts). */
const QUICK = [
  { label: "Google", url: "https://www.google.com/", mark: "G", color: "#4285f4" },
  { label: "YouTube", url: "https://m.youtube.com/", mark: "▶", color: "#ff0033" },
  { label: "Facebook", url: "https://www.facebook.com/", mark: "f", color: "#0866ff" },
  { label: "Outlook", url: "https://outlook.office.com/mail/", mark: "O", color: "#0078d4" },
  { label: "Wikipedia", url: "https://en.wikipedia.org/", mark: "W", color: "#636466" },
  { label: "GitHub", url: "https://github.com/", mark: "GH", color: "#24292f" },
];

/** Lucide's paths (ISC), drawn at 24 × 24. */
const ICONS = {
  back: '<path d="m15 18-6-6 6-6"/>',
  forward: '<path d="m9 18 6-6-6-6"/>',
  reload: '<path d="M21 12a9 9 0 1 1-9-9c2.52 0 4.93 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/>',
  close: '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
  sound: '<path d="M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z"/><path d="M16 9a5 5 0 0 1 0 6"/><path d="M19.364 18.364a9 9 0 0 0 0-12.728"/>',
  silent: '<path d="M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z"/><path d="M22 9l-6 6"/><path d="M16 9l6 6"/>',
  globe: '<circle cx="12" cy="12" r="10"/><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/><path d="M2 12h20"/>',
  search: '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
  clock: '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
  plus: '<path d="M5 12h14"/><path d="M12 5v14"/>',
  minus: '<path d="M5 12h14"/>',
  phone: '<rect width="14" height="20" x="5" y="2" rx="2" ry="2"/><path d="M12 18h.01"/>',
  desktop: '<rect width="20" height="14" x="2" y="3" rx="2"/><path d="M8 21h8"/><path d="M12 17v4"/>',
  lock: '<rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
  info: '<circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/>',
  external: '<path d="M15 3h6v6"/><path d="M10 14 21 3"/><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>',
  more: '<circle cx="12" cy="12" r="1"/><circle cx="12" cy="5" r="1"/><circle cx="12" cy="19" r="1"/>',
  pencil: '<path d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z"/><path d="m15 5 4 4"/>',
  trash: '<path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/>',
  left: '<path d="m12 19-7-7 7-7"/><path d="M19 12H5"/>',
  right: '<path d="M5 12h14"/><path d="m12 5 7 7-7 7"/>',
  // Lucide's settings, for Settings' row and tab.
  settings: '<path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/>',
  restore: '<path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/>',
};

function icon(name) {
  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute("viewBox", "0 0 24 24");
  svg.setAttribute("fill", "none");
  svg.setAttribute("stroke", "currentColor");
  svg.setAttribute("stroke-width", "2");
  svg.setAttribute("stroke-linecap", "round");
  svg.setAttribute("stroke-linejoin", "round");
  svg.setAttribute("aria-hidden", "true");
  // Constant markup from the table above, never from a site.
  svg.innerHTML = ICONS[name];
  return svg;
}

const $ = (id) => document.getElementById(id);
const site = $("site");
const address = $("address");

// ---- Lumi -----------------------------------------------------------------

/** One request to Lumi's web routes at a time: two in flight may reach its
 *  main thread in either order, and a tab switched away and back at once
 *  would be hidden after it was shown again. */
let queue = Promise.resolve();
function inTurn(request) {
  const turn = queue.then(request, request);
  queue = turn.catch(() => undefined);
  return turn;
}

/** The box in page pixels from the window's top-left. Offsets rather than
 *  `getBoundingClientRect`, so nothing mid-animation moves the site. */
function laidOut(box) {
  let x = 0;
  let y = 0;
  for (let at = box; at; at = at.offsetParent) {
    x += at.offsetLeft;
    y += at.offsetTop;
  }
  return { x, y, width: box.offsetWidth, height: box.offsetHeight };
}

/** The window's grips (`.edge`) that stand over the site's box, which runs
 *  to the window's edges: covered, so a press there is the page's and
 *  resizes the window rather than reaching the site. Four points wide, so
 *  most of a scroll bar by the edge is still the site's. */
function gripsOverSite() {
  const box = laidOut(site);
  return [...document.querySelectorAll(".edge")]
    .map(laidOut)
    .filter((grip) => grip.x < box.x + box.width && grip.x + grip.width > box.x && grip.y < box.y + box.height && grip.y + grip.height > box.y);
}

/** `tab`'s site shown in the box — or kept loaded out of sight, `hidden`.
 *  `null` when it is on its way, otherwise what Lumi said. While the icon's
 *  menu is open the whole box is covered: the menu is drawn over the site,
 *  and a press anywhere else on it has to reach this page to put the menu
 *  away, as a press beside a Mac menu does. So is it under the address
 *  bar's suggestions. */
function showSite(tab, hidden) {
  return inTurn(async () => {
    try {
      let covered = [];
      if (!hidden && (menuOpen || suggesting || extraFront || siteInfo || closeAsked)) covered = [laidOut(site)];
      else if (!hidden) covered = [...gripsOverSite(), ...(noticeUp ? [laidOut($("notice"))] : [])];
      // A link opened somewhere new is this page's to put in a tab
      // (`lumi:web`'s `open`, below), not the site's to load in place.
      const answer = await fetch("/__lumi__/web", {
        method: "POST",
        body: JSON.stringify({
          name: tab.id,
          url: tab.asked,
          rect: laidOut(site),
          covered,
          hidden,
          mobile: tab.mobile,
          muted: muted || tab.muted,
          newWindows: true,
          // What it plays told as `media`, for the pill's band, and its
          // seeking open to this page (Lumi 1.67.0).
          media: true,
        }),
      });
      if (answer.ok) return null;
      if (answer.status === 404) return "This needs a newer Lumi.";
      return (await answer.text()) || "Lumi could not show the page.";
    } catch {
      return "Lumi could not show the page.";
    }
  });
}

/** `tab`'s site let go of: Lumi blanks it. */
function dropSite(tab) {
  tab.asked = null;
  tab.media = null;
  return inTurn(async () => {
    try {
      await fetch("/__lumi__/web", { method: "DELETE", body: JSON.stringify({ name: tab.id }) });
    } catch {
      // Gone with the window anyway.
    }
  });
}

/** `tab`'s site loaded again where it stands. `null` when on its way. */
function reloadSite(tab) {
  return inTurn(async () => {
    try {
      const answer = await fetch("/__lumi__/web/reload", { method: "POST", body: JSON.stringify({ name: tab.id }) });
      return answer.ok ? null : (await answer.text()) || "nothing to reload";
    } catch {
      return "nothing to reload";
    }
  });
}

/** One of this extension's own requests (`run_ui`). */
async function call(request) {
  const answer = await fetch("/__lumi__/call", { method: "POST", body: JSON.stringify(request) });
  const text = await answer.text();
  if (!answer.ok) throw new Error(text);
  return text ? JSON.parse(text) : null;
}

// ---- Tabs -------------------------------------------------------------------

/**
 * A tab: `url` is where it is now as far as this page knows, `asked` the
 * address Lumi was last asked for under its id (`null` while Lumi holds no
 * site for it) — asking again for the same one only moves the site, so a
 * load of the page it already started on goes through `dropSite` first.
 * `expect` marks a load this page started: the address it lands on (after a
 * redirect) replaces `url` rather than being a step of its own.
 */
let tabs = [];
let activeId = null;
let made = 0;
let up = true;
/** Every tab's sound off — Mute All, in the icon's menu. Lumi is asked with
 *  it for each site at every ask (`showSite`), so a site loaded later is
 *  silent too, and an older Lumi ignores it. */
let muted = false;
/** What the pill was last told, so a redraw that changed nothing it shows
 *  sends nothing (Minimized, below). */
let bubbleTold = "";
/** A telling to the pill on its way: each is a run of the component, and
 *  Lumi runs up to four of an extension's at once, so two told a moment
 *  apart could reach the pill the wrong way round and leave it showing the
 *  older — a play button back to Play after the site said it plays. So one
 *  at a time, and once it has landed the state as it stands then. */
let bubbleSending = false;
/** What the menu bar item's menu was last handed of the tabs' icons
 *  (`tellMenuIcons`), so a redraw that changed none sends nothing. */
let menuIconsTold = "";
/** Compact Mode: one bar (#title-bar) in place of the strip and the
 *  toolbar. Kept with the tabs, so it outlives a restart, and switched from
 *  the icon's menu here or the menu bar's. */
let compact = false;
/** The icon's menu (#menu) is open. */
let menuOpen = false;
/** Compact Mode's title is the address field, being typed in. */
let editingTitle = false;
/** ⇧ held, as last seen: Compact Mode's Back is Forward for that long. */
let shiftHeld = false;

function newTab(fields = {}) {
  made += 1;
  return {
    id: `tab-${made}`,
    url: null,
    title: "",
    mobile: true,
    // The site its layout was last decided for (`phoneFor`): a step inside
    // the same site keeps the layout it has, a step onto another site
    // decides again (`landed`).
    layoutSite: "",
    // Its own sound off — its speaker pressed — beside Mute All's.
    muted: false,
    // Making sound now, as Lumi last told (`sound`), and since when: with
    // Prioritize Now Playing Tab on, the pill stands for the tab that began
    // to sound last (`soundingTab`).
    playing: false,
    soundingSince: 0,
    // What it plays, as Lumi last told (`media`): its length (null for a
    // live stream), where it was and how fast, its title and artist, and
    // when that was told, on the wall clock the pill shares. Never kept.
    media: null,
    back: [],
    forward: [],
    asked: null,
    expect: false,
    state: "start",
    reason: "",
    ...fields,
  };
}

const front = () => tabs.find((tab) => tab.id === activeId) || null;

/** Lumi asked to show the tab in front and to hide every other it holds.
 *  Coalesced: a live resize asks many times, and only the last box counts. */
let placing = false;
let placeAgain = false;
async function place() {
  if (placing) {
    placeAgain = true;
    return;
  }
  placing = true;
  try {
    do {
      placeAgain = false;
      if (!up) break;
      for (const tab of tabs) {
        if (tab.id !== activeId && tab.asked) await showSite(tab, true);
      }
      const tab = front();
      if (tab && tab.url) {
        // A tab opened behind, in front at last: loading, as far as this
        // page can tell, until Lumi says it is shown.
        if (tab.state === "behind") {
          tab.state = "loading";
          render();
        }
        if (!tab.asked) {
          tab.asked = tab.url;
          tab.expect = true;
          tab.state = "loading";
          render();
        }
        const said = await showSite(tab, false);
        if (said) {
          tab.asked = null;
          tab.state = "failed";
          tab.reason = said;
          render();
        }
      }
    } while (placeAgain);
  } finally {
    placing = false;
  }
}

/** Load `url` in `tab`. `walking` is Back or Forward, whose stacks the
 *  caller has already moved. */
async function go(tab, url, walking = false) {
  // Somewhere asked to go is somewhere to be seen: History's tab goes
  // behind the site's, still open.
  extraBehind();
  if (!walking && tab.url && tab.url !== url) {
    tab.back.push(tab.url);
    tab.forward = [];
  }
  tab.url = url;
  tab.mobile = phoneFor(url);
  tab.layoutSite = siteOf(url);
  tab.title = "";
  tab.state = "loading";
  tab.reason = "";
  if (tab.asked === url) await dropSite(tab);
  tab.asked = null;
  render();
  keep();
  if (tab.id === activeId) await place();
}

function select(id) {
  if (!tabs.some((tab) => tab.id === id)) return;
  activeId = id;
  extraBehind();
  render();
  keep();
  place();
}

/** A link the person opened somewhere new in `from`'s site — ⌘- or
 *  middle-clicked, or made to open a new window — in a tab of its own, as
 *  Chrome does: just after `from` and the tabs already opened from it, and
 *  behind the tab in front when `background` (⌘ or the middle button
 *  without ⇧), loaded there out of sight. With every tab taken, the notice
 *  says so and offers the two places left. */
function openLink(from, url, background) {
  if (typeof url !== "string" || !url.startsWith("https://") || url.length > LONGEST_REMEMBERED) return;
  if (tabs.length >= MOST_TABS) {
    notify(`${MOST_TABS} tabs are open. Close one to open the link in a new tab.`, [
      // The tab it came from, if it is still open.
      { label: "Open Here", run: () => go(tabs.includes(from) ? from : front(), url) },
      { label: "Open in Browser", run: () => call({ kind: "browser", url }).catch(() => {}) },
    ]);
    return;
  }
  let at = tabs.indexOf(from);
  while (at + 1 < tabs.length && tabs[at + 1].opener === from.id) at += 1;
  const tab = newTab({ opener: from.id });
  tabs.splice(at + 1, 0, tab);
  if (background) {
    tab.url = url;
    tab.mobile = phoneFor(url);
    tab.layoutSite = siteOf(url);
    // Asked for out of sight at once (`place`), and drawn as a tab not yet
    // looked at: Lumi says nothing of a site loaded hidden until it is shown.
    tab.asked = url;
    tab.expect = true;
    tab.state = "behind";
    render();
    keep();
    place();
    return;
  }
  select(tab.id);
  go(tab, url);
}

function openTab(url) {
  if (tabs.length >= MOST_TABS) return;
  const tab = newTab();
  tabs.push(tab);
  select(tab.id);
  if (url) go(tab, url);
  else focusAddress();
}

async function closeTab(id) {
  const at = tabs.findIndex((tab) => tab.id === id);
  if (at < 0) return;
  const [tab] = tabs.splice(at, 1);
  if (tab.asked) await dropSite(tab);
  if (tabs.length === 0) tabs.push(newTab());
  if (activeId === id) activeId = tabs[Math.min(at, tabs.length - 1)].id;
  render();
  keep();
  place();
}

/** ⌘W. History or Settings in front: that tab closes. Otherwise the tab in
 *  front closes, and the last one leaves a new tab, so the window stays.
 *  Pressed again on that new tab when it is all there is, nothing is left to
 *  close but the window, so it closes as × does — asking nothing, since ×
 *  asks only while a tab holds a page (`closeWindow`), and a tab loading one
 *  already holds its address. With History or Settings open behind it, that
 *  tab comes to the front instead: the new tab cannot go, and the window
 *  still holds something. */
function closeWithKey() {
  if (extraFront) {
    closeExtra();
    return;
  }
  const lone = tabs.length === 1 && !tabs[0].url;
  if (lone && extraOpen) {
    openExtra();
  } else if (lone) {
    closeWindow();
  } else if (activeId) {
    closeTab(activeId);
  }
}

/** One tab's sound off, or on again — its speaker pressed. Lumi is asked
 *  for the site with it at once; nothing loads again. */
function toggleTabMute(id) {
  const tab = tabs.find((each) => each.id === id);
  if (!tab) return;
  tab.muted = !tab.muted;
  render();
  keep();
  place();
}

/** Every tab closed, one new tab left — Close All Tabs and Close, in the
 *  icon's menu. */
async function closeAll() {
  const gone = tabs;
  tabs = [newTab()];
  activeId = tabs[0].id;
  for (const tab of gone) {
    if (tab.asked) await dropSite(tab);
  }
  render();
  keep();
  place();
}

function walk(by) {
  const tab = front();
  if (!tab) return;
  const [from, to] = by < 0 ? [tab.back, tab.forward] : [tab.forward, tab.back];
  if (from.length === 0) return;
  if (tab.url) to.push(tab.url);
  go(tab, from.pop(), true);
}

async function reload() {
  const tab = front();
  if (!tab || !tab.url) return;
  if (tab.asked && tab.state === "shown" && !(await reloadSite(tab))) {
    tab.state = "shown";
    render();
    return;
  }
  go(tab, tab.url, true);
}

/** Compact Mode on or off. The site's box changes size, which places the
 *  site again (the ResizeObserver below); nothing loads again. */
function setCompact(on) {
  compact = on;
  editingTitle = false;
  render();
  keep();
  if (menuOpen) placeMenu();
}

// ---- Phone or desktop ------------------------------------------------------

// A tab shows phone layouts (Lumi's iPhone agent, `"mobile"`), since the
// window is narrow — except on a site whose phone layout is made for a touch
// screen and fails a pointer, which opens on its desktop one. YouTube's phone
// player hides the pointer over a playing video, an advert's or the video's,
// and shows it, the controls and Tap to Unmute again only on a tap: measured
// 2026-10-31 in Chromium with Lumi's iPhone agent, forty moves over the
// player left its `ytp-autohide` and `cursor: none` as they were, where its
// desktop player let both go on the first move and hid them again after a
// rest. Its desktop layout fits the window's 400 points. YouTube sends each
// agent to its own site — m.youtube.com asked for with the desktop agent
// lands on www.youtube.com — so no address is changed here.
//
// The person's own choice wins, and it is the site's, not the tab's: the
// phone and desktop button, or Desktop Site, switches the site the tab is on,
// and every later visit to it — in any tab, after Lumi restarts — opens in
// the layout it was switched to. Kept by the extension, `{v, sites}`, each
// site's host to "phone" or "desktop" (`keep-layouts`); a site switched back
// to its own layout is forgotten, so it follows the rule above again.

/** The sites a tab opens on their desktop layout: each site and every name
 *  under it. */
const DESKTOP_FIRST = ["youtube.com"];

/** Hosts that are another site's own short name. */
const SAME_SITE = { "youtu.be": "youtube.com" };

/** The most sites whose layout is kept: the least lately switched go first. */
const MOST_LAYOUTS = 300;

/** Each site switched away from its own layout, to "phone" or "desktop", in
 *  the order switched, the latest last. */
const layouts = new Map();

/** The site `url` is on, as its layout is kept: its host, without the `www.`,
 *  `m.` or `mobile.` a site puts before its phone or desktop pages — which
 *  are one site — or "". */
function siteOf(url) {
  try {
    const host = new URL(url).hostname.toLowerCase().replace(/^(www|m|mobile)\./, "");
    return SAME_SITE[host] || host;
  } catch {
    return "";
  }
}

function desktopFirst(url) {
  const site = siteOf(url);
  return DESKTOP_FIRST.some((name) => site === name || site.endsWith(`.${name}`));
}

/** Whether `url` is asked for in the phone layout: as the person last
 *  switched its site, else as the site is best seen. */
function phoneFor(url) {
  const kept = layouts.get(siteOf(url));
  return kept ? kept === "phone" : !desktopFirst(url);
}

/** `url`'s site switched to the phone layout (`phone`) or the desktop one,
 *  and kept so. */
function rememberLayout(url, phone) {
  const site = siteOf(url);
  if (!site) return;
  layouts.delete(site);
  if (phone === desktopFirst(url)) layouts.set(site, phone ? "phone" : "desktop");
  while (layouts.size > MOST_LAYOUTS) layouts.delete(layouts.keys().next().value);
  call({ kind: "keep-layouts", layouts: { v: 1, sites: Object.fromEntries(layouts) } }).catch(() => {});
}

/** The layouts kept, read as any file is: only a host and a known word. */
function restoreLayouts(kept) {
  layouts.clear();
  if (!kept || kept.v !== 1 || !kept.sites || typeof kept.sites !== "object") return;
  for (const [site, layout] of Object.entries(kept.sites).slice(-MOST_LAYOUTS)) {
    if (site.length <= 253 && (layout === "phone" || layout === "desktop")) layouts.set(site, layout);
  }
}

/** The phone page or the desktop one, for the site the tab is on and every
 *  later visit to it: Lumi loads the site again either way, so it is asked
 *  for at the page the tab is on now. A tab with no site has nothing to
 *  remember, and its next site opens as that site is kept. */
async function toggleMobile() {
  const tab = front();
  if (!tab) return;
  tab.mobile = !tab.mobile;
  if (tab.url) rememberLayout(tab.url, tab.mobile);
  keep();
  if (tab.url) await go(tab, tab.url, true);
  else render();
}

// ---- The notice ------------------------------------------------------------

// A line at the foot of the window for what could not be done as asked — a
// link with no tab left for it — with what can be done instead. It goes by
// itself after `NOTICE_FOR`, held while the pointer is on it, and is part of
// what this page draws over the site while it is up (`showSite`).

/** How long the notice stays, in milliseconds. */
const NOTICE_FOR = 6000;

let noticeUp = false;
let noticeTimer = 0;

/** Say `text`, with a button for each of `actions` ({label, run}). */
function notify(text, actions = []) {
  const notice = $("notice");
  $("notice-text").textContent = text;
  const buttons = $("notice-actions");
  buttons.replaceChildren(
    ...actions.map(({ label, run }) => {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "notice-act";
      button.textContent = label;
      button.addEventListener("click", () => {
        hideNotice();
        run();
      });
      return button;
    }),
  );
  notice.hidden = false;
  noticeUp = true;
  holdNotice(false);
  place();
}

function hideNotice() {
  clearTimeout(noticeTimer);
  if (!noticeUp) return;
  noticeUp = false;
  $("notice").hidden = true;
  place();
}

/** The notice's clock stopped while the pointer is on it, and started again
 *  when it leaves. */
function holdNotice(held) {
  clearTimeout(noticeTimer);
  if (!held && noticeUp) noticeTimer = setTimeout(hideNotice, NOTICE_FOR);
}

$("notice").addEventListener("pointerenter", () => holdNotice(true));
$("notice").addEventListener("pointerleave", () => holdNotice(false));
$("notice-close").addEventListener("click", () => hideNotice());

// ---- What Lumi tells --------------------------------------------------------

addEventListener("lumi:web", (event) => {
  const news = event.detail;
  if (!news || news.v !== 1) return;
  const tab = tabs.find((each) => each.id === news.name);
  if (!tab) return;
  switch (news.kind) {
    case "loading":
      if (tab.state !== "shown" && tab.state !== "behind") tab.state = "loading";
      break;
    case "open":
      // A link the person opened somewhere new: a tab of its own.
      openLink(tab, news.url, news.background === true);
      return;
    case "shown":
    case "page":
      tab.state = "shown";
      landed(tab, news.url, news.title);
      break;
    case "failed":
      // A link inside the site failing leaves the site up: only a page that
      // never drew says so, and Lumi holds nothing for it any more.
      if (tab.state !== "shown") {
        tab.state = "failed";
        tab.reason = news.reason || "The page could not be shown.";
        tab.asked = null;
      }
      break;
    case "closed":
      // The window was put away and the site with it.
      tab.asked = null;
      tab.playing = false;
      tab.media = null;
      if (tab.url) tab.state = "loading";
      break;
    case "media":
      // What it plays, when that changed: the pill's band, title and
      // artist. Its clock moves on at its rate from now, on the pill. Where
      // it is may be unknown (`null`, Lumi 1.67.0), for media Lumi cannot
      // reach in the page: no band then, and it can still be paused.
      tab.media =
        typeof news.position === "number" || typeof news.playing === "boolean"
          ? {
              duration: typeof news.duration === "number" ? news.duration : null,
              position: typeof news.position === "number" ? news.position : null,
              rate: typeof news.rate === "number" ? news.rate : 0,
              // Whether it plays, apart from its clock's rate, which stays 0
              // for a moment after a play while the media starts. A Lumi
              // that does not say has the rate say.
              playing: typeof news.playing === "boolean" ? news.playing : news.rate > 0,
              title: typeof news.title === "string" ? news.title : "",
              artist: typeof news.artist === "string" ? news.artist : "",
              artwork: artworkOf(news, tab.media),
              at: Date.now(),
            }
          : null;
      break;
    case "sound":
      // Making sound, or not any more: the speaker on its tab and its row
      // in the icon's menu.
      if (tab.playing === (news.playing === true)) return;
      tab.playing = news.playing === true;
      if (tab.playing) tab.soundingSince = Date.now();
      keep();
      break;
  }
  render();
});

/** Where a site says it is now. A load this page started lands where it
 *  lands; anything else is the person following a link, a step to go back
 *  from. */
function landed(tab, url, title) {
  if (title) tab.title = title;
  if (url) {
    if (tab.expect) {
      tab.url = url;
      tab.expect = false;
    } else if (url !== tab.url) {
      if (tab.url) tab.back.push(tab.url);
      tab.forward = [];
      tab.url = url;
    }
  }
  // Arrived by a link or a redirect on another site, whose layout is the
  // other one — a YouTube link in Google's results: asked for again in it.
  // A step inside the same site keeps the layout it is in.
  if (tab.url && siteOf(tab.url) !== tab.layoutSite) {
    tab.layoutSite = siteOf(tab.url);
    if (phoneFor(tab.url) !== tab.mobile) {
      go(tab, tab.url, true);
      return;
    }
  }
  keep();
  if (tab.url) {
    // A visit when the tab is somewhere new; the title, when it comes later.
    remember(tab.url, tab.title, tab.url !== tab.remembered);
    tab.remembered = tab.url;
    findIcon(tab.url).then((found) => found && render());
  }
}

// ---- History ------------------------------------------------------------------

// The pages visited, which the address bar suggests from, kept by the
// extension in its own storage (`keep-history`) and nowhere else: each
// page's address, title, how often and when last. Only what Lumi tells of a
// site, its address and title, ever goes in.

/** The most pages kept: the least recently visited go first. */
const MOST_HISTORY = 1500;

/** An address longer than this is not kept: it is a session, not a page. */
const LONGEST_REMEMBERED = 2048;

/** `{v, entries: [{url, title, visits, last}]}`, `last` in ms. */
let history = { v: 1, entries: [] };

/** Well-known sites, suggested before the history has them: typing the
 *  start of their name should find them on a first day as on any other. */
const POPULAR = [
  ["google.com", "Google"],
  ["youtube.com", "YouTube"],
  ["mail.google.com", "Gmail"],
  ["facebook.com", "Facebook"],
  ["wikipedia.org", "Wikipedia"],
  ["github.com", "GitHub"],
  ["gitlab.com", "GitLab"],
  ["outlook.office.com", "Outlook"],
  ["teams.microsoft.com", "Microsoft Teams"],
  ["office.com", "Microsoft 365"],
  ["reddit.com", "Reddit"],
  ["x.com", "X"],
  ["instagram.com", "Instagram"],
  ["linkedin.com", "LinkedIn"],
  ["stackoverflow.com", "Stack Overflow"],
  ["chatgpt.com", "ChatGPT"],
  ["claude.ai", "Claude"],
  ["netflix.com", "Netflix"],
  ["amazon.com", "Amazon"],
  ["apple.com", "Apple"],
  ["maps.google.com", "Google Maps"],
  ["translate.google.com", "Google Translate"],
  ["vnexpress.net", "VnExpress"],
  ["tinhte.vn", "Tinh tế"],
  ["dantri.com.vn", "Dân trí"],
  ["tuoitre.vn", "Tuổi Trẻ"],
  ["thanhnien.vn", "Thanh Niên"],
  ["znews.vn", "ZNEWS"],
  ["vietnamnet.vn", "VietNamNet"],
  ["genk.vn", "GenK"],
  ["kenh14.vn", "Kênh 14"],
  ["cafef.vn", "CafeF"],
  ["24h.com.vn", "24h"],
  ["voz.vn", "VOZ"],
  ["shopee.vn", "Shopee"],
  ["tiki.vn", "Tiki"],
  ["lazada.vn", "Lazada"],
].map(([at, title]) => ({ url: `https://${at}/`, title, visits: 0, last: 0 }));

/** `url` visited — `counted` once per arrival — under `title`, if known. */
function remember(url, title, counted) {
  if (!url.startsWith("https://") || url.length > LONGEST_REMEMBERED) return;
  let entry = history.entries.find((each) => each.url === url);
  if (!entry) {
    if (!counted) return;
    entry = { url, title: "", visits: 0, last: 0 };
    history.entries.push(entry);
  }
  if (counted) {
    entry.visits += 1;
    entry.last = Date.now();
  }
  if (title) entry.title = title;
  if (history.entries.length > MOST_HISTORY) {
    history.entries.sort((a, b) => b.last - a.last);
    history.entries.length = MOST_HISTORY;
  }
  keepHistory();
}

/** One page taken out of the history (its × in the suggestions). */
function forget(url) {
  history.entries = history.entries.filter((each) => each.url !== url);
  keepHistory();
}

function clearHistory() {
  history.entries = [];
  keepHistory();
}

let historyTimer = 0;
/** The history handed to the extension to keep, a moment after a change. */
function keepHistory() {
  clearTimeout(historyTimer);
  historyTimer = setTimeout(() => {
    call({ kind: "keep-history", history }).catch(() => {});
  }, 1000);
}

/** Text as matched: lower case, and Vietnamese without its marks, so "tin
 *  tuc" finds "Tin tức". */
function folded(text) {
  return text.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/đ/g, "d");
}

/** What was typed, as matched against an address: scheme and `www.` gone. */
function asTyped(text) {
  return text.trim().toLowerCase().replace(/^https?:\/\//, "").replace(/^www\./, "");
}

/** The pages for `text`, best first: the history's and the well-known sites
 *  it does not have. A site whose name starts with what was typed first,
 *  then an address starting with it, then a page with every word at the
 *  start of a word of its title or address, then anywhere in them — each
 *  raised by how often and how lately it was visited. */
function ranked(text) {
  const typed = asTyped(text);
  if (!typed) return [];
  const words = folded(typed).split(/\s+/).filter(Boolean);
  const startsWord = (haystack, word) =>
    haystack.startsWith(word) || [" ", ".", "/", "-", "_"].some((before) => haystack.includes(before + word));
  const now = Date.now();
  const seen = new Set();
  const found = [];
  for (const entry of [...history.entries, ...POPULAR]) {
    let at;
    try {
      const parsed = new URL(entry.url);
      at = { host: parsed.hostname.replace(/^www\./, ""), plain: pretty(entry.url).toLowerCase() };
    } catch {
      continue;
    }
    if (seen.has(at.plain)) continue;
    seen.add(at.plain);
    const title = folded(entry.title || "");
    const plain = folded(at.plain);
    let match = 0;
    if (at.host.startsWith(typed)) match = 4;
    else if (at.plain.startsWith(typed)) match = 3;
    else if (words.every((word) => startsWord(title, word) || startsWord(plain, word))) match = 2;
    else if (words.every((word) => title.includes(word) || plain.includes(word))) match = 1;
    if (!match) continue;
    const days = entry.last ? (now - entry.last) / 86400000 : Infinity;
    const lately = days < 1 ? 4 : days < 7 ? 3 : days < 30 ? 2 : days < Infinity ? 1 : 0;
    found.push({ entry, at, match, score: match * 10 + Math.log2(1 + entry.visits) * 3 + lately });
  }
  return found.sort((a, b) => b.score - a.score);
}

/** What the field completes `text` to, as Chrome's omnibox does — the best
 *  page whose address starts with it: to its site while what was typed is
 *  part of the site's name, else to its address — or null. Never for a
 *  search, nor for text that starts with a scheme or `www.`, which a
 *  completion could not continue as typed. */
function completionOf(text) {
  if (!text || /\s/.test(text) || asTyped(text) !== text.toLowerCase()) return null;
  const typed = text.toLowerCase();
  const best = ranked(text).find((each) => each.match >= 3);
  if (!best) return null;
  const whole = best.at.host.startsWith(typed) ? best.at.host : best.at.plain;
  return whole.length > text.length ? text + whole.slice(text.length) : null;
}

// ---- Favicons ----------------------------------------------------------------

// Each tab shows its site's icon, as Chrome's do. This page never sees
// inside a site, and its CSP loads no picture but its own and `data:`, so the
// icon is fetched — the way Chrome finds one: the icons the page's `<head>`
// declares, else `/favicon.ico` — through `POST /__lumi__/download` with
// `"keep": false` (Lumi 1.44.0), which answers the bytes themselves and sends
// nothing but the address, and is drawn from a `data:` URL. Asked of the site
// itself, never of anybody's favicon service. The `<head>` is read with
// `DOMParser`, which runs nothing, and only its links' attributes are read.

// A few sites' icons are carried in the package (`ui/icons/`), so they show
// from the first moment — before any look, after Lumi restarts, in the
// history and the suggestions — and where a look finds nothing or the wrong
// thing: gitlab.com answered its icon's address with a bot check's page,
// Gmail, Drive, Calendar, Docs and Keep send a look, which carries nobody's
// sign-in, to Google's sign-in page, and Outlook and OneDrive to Microsoft's
// marketing pages (measured 2026-10-30). Each is the site's own: as its home
// page declared it that day, or for an app whose page shows only to somebody
// signed in, its maker's own icon for the product — Google's from gstatic's
// `images/branding/product`, Microsoft's from the Fluent brand icons on
// res.cdn.office.net that Word's, Excel's and PowerPoint's own pages
// declare. Outlook's calendar shows Outlook's: its page could not be seen
// signed out, so no icon of its own was. GitHub's page swaps its dark one in
// for a dark window, so this does too.

/** Each: the host, with a leading www or m left out; a path the address
 *  must begin with, where one is named; the icon, and its dark one; and
 *  whether every name under the host counts (Wikipedia's languages). The
 *  first that matches wins, so a path comes before its host. */
const CARRIED = [
  { host: "google.com", path: "/maps", icon: "maps.png" },
  { host: "google.com", icon: "google.png" },
  { host: "mail.google.com", icon: "gmail.png" },
  { host: "gmail.com", icon: "gmail.png" },
  { host: "drive.google.com", icon: "drive.png" },
  { host: "photos.google.com", icon: "photos.svg" },
  { host: "calendar.google.com", icon: "calendar.png" },
  { host: "docs.google.com", path: "/spreadsheets", icon: "sheets.png" },
  { host: "docs.google.com", path: "/presentation", icon: "slides.png" },
  { host: "docs.google.com", path: "/forms", icon: "forms.png" },
  { host: "docs.google.com", icon: "docs.png" },
  { host: "keep.google.com", icon: "keep.png" },
  { host: "meet.google.com", icon: "meet.png" },
  { host: "maps.google.com", icon: "maps.png" },
  { host: "translate.google.com", icon: "translate.png" },
  { host: "outlook.office.com", icon: "outlook.svg" },
  { host: "outlook.office365.com", icon: "outlook.svg" },
  { host: "outlook.live.com", icon: "outlook.svg" },
  { host: "outlook.cloud.microsoft", icon: "outlook.svg" },
  { host: "office.com", icon: "microsoft365.png" },
  { host: "microsoft365.com", icon: "microsoft365.png" },
  { host: "m365.cloud.microsoft", icon: "microsoft365.png" },
  { host: "teams.microsoft.com", icon: "teams.png" },
  { host: "teams.live.com", icon: "teams.png" },
  { host: "teams.cloud.microsoft", icon: "teams.png" },
  { host: "word.cloud.microsoft", icon: "word.svg" },
  { host: "excel.cloud.microsoft", icon: "excel.svg" },
  { host: "powerpoint.cloud.microsoft", icon: "powerpoint.svg" },
  { host: "onenote.com", icon: "onenote.svg" },
  { host: "onenote.cloud.microsoft", icon: "onenote.svg" },
  { host: "onedrive.live.com", icon: "onedrive.svg" },
  { host: "onedrive.com", icon: "onedrive.svg" },
  // A SharePoint link to a file says its kind in its path.
  { host: "sharepoint.com", path: "/:w:", icon: "word.svg", under: true },
  { host: "sharepoint.com", path: "/:x:", icon: "excel.svg", under: true },
  { host: "sharepoint.com", path: "/:p:", icon: "powerpoint.svg", under: true },
  { host: "sharepoint.com", path: "/:o:", icon: "onenote.svg", under: true },
  { host: "sharepoint.com", icon: "sharepoint.svg", under: true },
  { host: "youtube.com", icon: "youtube.png" },
  { host: "facebook.com", icon: "facebook.png" },
  { host: "wikipedia.org", icon: "wikipedia.ico", under: true },
  { host: "github.com", icon: "github.svg", dark: "github-dark.svg" },
  { host: "gitlab.com", icon: "gitlab.png" },
  { host: "about.gitlab.com", icon: "gitlab.png" },
];

const dark = matchMedia("(prefers-color-scheme: dark)");

/** The icon this package carries for `url`'s site, or "". */
function carriedIcon(url) {
  let name;
  let path;
  try {
    const address = new URL(url);
    name = address.hostname.replace(/^(www|m)\./, "");
    path = address.pathname;
  } catch {
    return "";
  }
  for (const each of CARRIED) {
    if (name !== each.host && !(each.under && name.endsWith(`.${each.host}`))) continue;
    if (each.path && path !== each.path && !path.startsWith(`${each.path}/`)) continue;
    return `icons/${each.dark && dark.matches ? each.dark : each.icon}`;
  }
  return "";
}

/** The track's cover, as Lumi drew it for `media` — a PNG, as data — or
 *  none. Lumi reads the cover after it has told the track, so a cover
 *  usually comes in a later `media` than the track's first, and a `media`
 *  that leaves it out for the same track (a seek, a pause) keeps the one
 *  already had: a cover that came and went with every pause would flicker
 *  on the pill. A new track without one has none. Anything but Lumi's own
 *  PNG, or one far past the 96-point picture's size, is none. Lumi draws
 *  it at most 192 × 96 pixels; uncompressed RGBA that is 72 KB, about
 *  98 KB as base64, so 160 KB holds any cover Lumi sends with room. */
const LONGEST_ARTWORK = 160 * 1024;
function artworkOf(news, before) {
  const art = news.artwork;
  if (typeof art === "string" && art.length <= LONGEST_ARTWORK && /^data:image\/png;base64,[A-Za-z0-9+/=]+$/.test(art)) return art;
  const same =
    before &&
    before.title === (typeof news.title === "string" ? news.title : "") &&
    before.artist === (typeof news.artist === "string" ? news.artist : "");
  return same && before.artwork ? before.artwork : "";
}

// The window turning dark or light swaps the icons that have a dark one.
dark.addEventListener("change", () => {
  render();
  drawQuick();
  if (extraOpen && extraKind === "history") drawHistory();
  if (suggesting) drawSuggest();
});

/** Each site's icon by origin, as a `data:` URL — "" where none was found. */
const icons = new Map();
/** Origins whose icon is being looked for, and the look. */
const looking = new Map();

/** One look at a time: each is a download, and a download counts with this
 *  extension's calls, of which Lumi runs four at once. */
let iconQueue = Promise.resolve();
function iconTurn(job) {
  const turn = iconQueue.then(job, job);
  iconQueue = turn.catch(() => undefined);
  return turn;
}

/** The icon carried or already found for `url`'s site, or "". */
function iconFor(url) {
  const carried = carriedIcon(url);
  if (carried) return carried;
  try {
    return icons.get(new URL(url).origin) || "";
  } catch {
    return "";
  }
}

/** The first `most` bytes at `url`, or the status Lumi refused with. */
async function download(url, most) {
  try {
    const answer = await fetch("/__lumi__/download", { method: "POST", body: JSON.stringify({ url, most, keep: false }) });
    if (!answer.ok) return { status: answer.status };
    return { bytes: new Uint8Array(await answer.arrayBuffer()) };
  } catch {
    return { status: 0 };
  }
}

/** What picture `bytes` are, from their first bytes, or null for none. */
function pictureType(bytes) {
  const starts = (...signature) => signature.every((byte, at) => bytes[at] === byte);
  if (starts(0x89, 0x50, 0x4e, 0x47)) return "image/png";
  if (starts(0x00, 0x00, 0x01, 0x00)) return "image/x-icon";
  if (starts(0x47, 0x49, 0x46, 0x38)) return "image/gif";
  if (starts(0xff, 0xd8, 0xff)) return "image/jpeg";
  if (starts(0x52, 0x49, 0x46, 0x46) && bytes[8] === 0x57 && bytes[9] === 0x45 && bytes[10] === 0x42 && bytes[11] === 0x50) return "image/webp";
  const text = new TextDecoder().decode(bytes.subarray(0, 512)).replace(/^﻿/, "").trimStart().toLowerCase();
  if (text.startsWith("<svg") || (text.startsWith("<?xml") && text.includes("<svg"))) return "image/svg+xml";
  return null;
}

function dataUrl(bytes, type) {
  let binary = "";
  for (let at = 0; at < bytes.length; at += 0x8000) {
    binary += String.fromCharCode(...bytes.subarray(at, at + 0x8000));
  }
  return `data:${type};base64,${btoa(binary)}`;
}

/** The icons `html`'s `<head>` declares, best first, as addresses against
 *  `base`: an SVG over a picture, 32 pt over 16 over the rest, a tab icon
 *  over an Apple touch icon. Only `https` and inline pictures. */
function declaredIcons(html, base) {
  const links = [...new DOMParser().parseFromString(html, "text/html").querySelectorAll("link[rel][href]")];
  const rank = (link) => {
    const rel = link.getAttribute("rel").toLowerCase();
    const sizes = (link.getAttribute("sizes") || "").toLowerCase();
    const svg = /svg/i.test(link.getAttribute("type") || "") || /\.svg(\?|#|$)/i.test(link.getAttribute("href"));
    const touch = rel.includes("apple-touch-icon") ? 10 : 0;
    const size = svg ? 0 : sizes.includes("32x32") ? 1 : sizes.includes("16x16") ? 2 : 3;
    return touch + size;
  };
  return links
    .filter((link) => /(^|\s)(icon|apple-touch-icon(-precomposed)?)(\s|$)/i.test(link.getAttribute("rel")))
    .sort((a, b) => rank(a) - rank(b))
    .map((link) => {
      try {
        return new URL(link.getAttribute("href"), base).href;
      } catch {
        return null;
      }
    })
    .filter((href) => href && (href.startsWith("https://") || /^data:image\//i.test(href)));
}

/** Look for `url`'s site's icon, once per site and never for one carried:
 *  what was found, or "". A look Lumi refused — the window put away, too
 *  much at once — is not kept, so the next page of that site looks again. */
function findIcon(url) {
  let origin;
  try {
    origin = new URL(url).origin;
  } catch {
    return Promise.resolve("");
  }
  if (icons.has(origin) || carriedIcon(url)) return Promise.resolve("");
  if (!looking.has(origin)) {
    const look = iconTurn(async () => {
      let refused = false;
      const page = await download(url, 256 * 1024);
      refused ||= page.status === 403 || page.status === 503;
      const declared = page.bytes ? declaredIcons(new TextDecoder().decode(page.bytes), url) : [];
      for (const address of [...declared.slice(0, 3), `${origin}/favicon.ico`]) {
        if (address.startsWith("data:")) return address;
        const picture = await download(address, 128 * 1024);
        refused ||= picture.status === 403 || picture.status === 503;
        const type = picture.bytes && picture.bytes.length > 0 ? pictureType(picture.bytes) : null;
        if (type) return dataUrl(picture.bytes, type);
      }
      return refused ? null : "";
    }).then((found) => {
      looking.delete(origin);
      if (found !== null) icons.set(origin, found);
      return found || "";
    });
    looking.set(origin, look);
  }
  return looking.get(origin);
}

/** A tab's mark, as the strip and the menu draw it: a spinner while it
 *  loads, its site's icon once found, the globe before. */
function tabMark(each) {
  if (Boolean(each.url) && each.state === "loading") {
    const spinner = document.createElement("span");
    spinner.className = "spinner";
    return spinner;
  }
  const found = each.url ? iconFor(each.url) : "";
  if (!found) return icon("globe");
  const picture = document.createElement("img");
  picture.className = "favicon";
  picture.alt = "";
  picture.draggable = false;
  picture.src = found;
  // A picture WebKit cannot draw is no icon: the globe again, for good.
  picture.addEventListener("error", () => {
    if (carriedIcon(each.url)) {
      picture.replaceWith(icon("globe"));
      return;
    }
    try {
      icons.set(new URL(each.url).origin, "");
    } catch {
      // No site, nothing kept.
    }
    render();
  });
  return picture;
}

// The icon's menu, through the extension (`src/lib.rs`): a tab chosen, the
// sound off or on again, every tab closed. The extension keeps the tabs the
// same way first, so a page loaded after hears nothing and reads them.
addEventListener("lumi:message", (event) => {
  const said = event.detail;
  if (!said) return;
  if (said.kind === "select" && Number.isInteger(said.index) && tabs[said.index]) {
    select(tabs[said.index].id);
  } else if (said.kind === "mute") {
    muted = said.muted === true;
    render();
    place();
  } else if (said.kind === "close-tabs") {
    closeAll();
  } else if (said.kind === "compact") {
    setCompact(said.compact === true);
  } else if (said.kind === "minimize") {
    // The Minimize shortcut, pressed from any app: as the − does.
    minimize();
  } else if (said.kind === "close-asked") {
    // Close in the pill's menu, where the × would ask first: the browser is
    // back from its pill (`close_from_pill`), and asks as the × does.
    closeWindow();
  } else if (said.kind === "seek" && typeof said.tab === "string" && Number.isFinite(said.position)) {
    // The pill's band pressed or dragged: what that tab plays sought there.
    // Lumi tells where it went as `media`, which reaches the pill again.
    const tab = tabs.find((each) => each.id === said.tab);
    if (tab && tab.asked) {
      fetch("/__lumi__/web/seek", {
        method: "POST",
        body: JSON.stringify({ name: tab.id, position: said.position, exact: said.exact !== false }),
      }).catch(() => {});
    }
  } else if (said.kind === "play" && typeof said.tab === "string" && typeof said.playing === "boolean") {
    // The pill's play button: what that tab plays paused or played on, as
    // the pill said. Lumi tells the change as `media`, which reaches the
    // pill again.
    const tab = tabs.find((each) => each.id === said.tab);
    if (tab && tab.asked) {
      fetch("/__lumi__/web/play", { method: "POST", body: JSON.stringify({ name: tab.id, playing: said.playing }) }).catch(() => {});
    }
  }
});

// Put away, the sites stay loaded (`keep-sites`) and the next showing only
// asks for them where they stand. A Lumi that lets them go says so site by
// site, as `closed` above, which is what marks a tab to be loaded again.
// The icon's menu and a title being typed in do not outlive it.
addEventListener("lumi:hidden", () => {
  up = false;
  menuOpen = false;
  editingTitle = false;
  suggesting = null;
  $("suggest").hidden = true;
  extraOpen = false;
  extraFront = false;
  $("history-view").hidden = true;
  $("settings-view").hidden = true;
  clearTimeout(noticeTimer);
  noticeUp = false;
  $("notice").hidden = true;
  render();
});

addEventListener("lumi:shown", () => {
  up = true;
  render();
  place();
});

// The keyboard back on a new tab goes to the start page's own search box,
// the one in the middle of what is on screen — not the toolbar's field, and
// not Compact Mode's title made into one. A press that landed in a field
// keeps it, and the History view, drawn over the start page, is left alone.
addEventListener("lumi:keyboard", (event) => {
  const tab = front();
  if (!(event.detail && event.detail.held && tab && !tab.url) || extraFront) return;
  const at = document.activeElement;
  if (at && at.matches("input, textarea")) return;
  startSearch.focus();
  startSearch.select();
});

new ResizeObserver(() => place()).observe(site);

// ---- Drawing ----------------------------------------------------------------

/** An address as Chrome's omnibox shows it while nobody is in it: without
 *  its scheme, a leading www or a trailing slash. */
function pretty(url) {
  return url.replace(/^https:\/\//, "").replace(/^www\./, "").replace(/\/$/, "");
}

/** The site a tab is on, as the loading screen names it: the host alone,
 *  since a whole address is too long to read at a glance. */
function host(url) {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return pretty(url);
  }
}

/** The address field, while nobody is typing in it: where the tab in front
 *  is, without its scheme. Left alone while somebody is. */
/** What the address bar says while empty: the page's own words, read once,
 *  and History's name while its tab is in front. */
const ADDRESS_HINT = address.placeholder;

/** The address History or Settings stands at, as Chrome's own pages have
 *  one (`chrome://settings`): shown in the address bar while it is in
 *  front, and typed into any address field to open it. */
function lumiAddress(kind) {
  return `lumi://${kind}`;
}

/** Which of History and Settings `typed` names (`lumi://history`,
 *  `lumi://settings`, any case, a slash after), or `null`. */
function lumiPageOf(typed) {
  const named = /^\s*lumi:\/\/([a-z]+)\/?\s*$/i.exec(typed);
  const kind = named && named[1].toLowerCase();
  return kind && Object.hasOwn(EXTRAS, kind) ? kind : null;
}

/** Open the page `field` names, if it names one of Lumi's: answers whether
 *  it did, so a submit goes no further. */
function openedLumiPage(field) {
  const kind = lumiPageOf(field.value);
  if (!kind) return false;
  field.blur();
  closeSuggest();
  if (kind === "history") openHistory();
  else openSettings();
  return true;
}

function showAddress() {
  const tab = front();
  if (document.activeElement !== address) address.value = extraFront ? lumiAddress(extraKind) : tab && tab.url ? pretty(tab.url) : "";
  address.placeholder = extraFront ? EXTRAS[extraKind].name : ADDRESS_HINT;
  drawMarks();
}

// A narrow tab leaves things out, as Chrome's does, rather than letting them
// run past its edge: four tabs in a narrow window are some seventy points
// each, and the one in front, its icon, speaker and close button at their
// sizes, put its close button over the next tab, where it read as that
// tab's. The title goes first; then the one in front keeps its close button,
// then its speaker, then its icon, and a tab behind keeps its icon, then its
// speaker, then its close button — Chrome's order. The sizes are the ones
// browser.css draws (`.tab`, `.mark.favicon`, `.sound`, `.shut`).

/** A tab's padding, the gap between its parts, its icon, a button on it,
 *  and the least of its title worth showing, in points. */
const TAB_PADDING = 18;
const TAB_GAP = 7;
const TAB_MARK = 16;
const TAB_BUTTON = 18;
const LEAST_TITLE = 16;

/** What a tab `width` points wide has room for: `{mark, label, sound, shut}`.
 *  Pure. */
function tabRoom(width, inFront, sounding) {
  const wanted = { mark: TAB_MARK, sound: sounding ? TAB_BUTTON : 0, shut: TAB_BUTTON };
  const order = inFront ? ["shut", "sound", "mark"] : ["mark", "sound", "shut"];
  let room = width - TAB_PADDING;
  const shown = new Set();
  for (const part of order) {
    if (!wanted[part]) continue;
    const need = wanted[part] + (shown.size ? TAB_GAP : 0);
    if (need > room) continue;
    shown.add(part);
    room -= need;
  }
  return { mark: shown.has("mark"), label: room - TAB_GAP >= LEAST_TITLE, sound: shown.has("sound"), shut: shown.has("shut") };
}

/** Each tab in the strip told what it has room for, as it stands now. */
function fitTabs() {
  for (const button of $("tabbar").querySelectorAll(".tab")) {
    const fits = tabRoom(button.offsetWidth, button.getAttribute("aria-selected") === "true", !button.querySelector(".sound").hidden);
    for (const [part, room] of Object.entries(fits)) button.classList.toggle(`no-${part}`, !room);
  }
}

// The strip narrows and widens with the window, and comes back from nothing
// when Compact Mode is turned off.
new ResizeObserver(() => fitTabs()).observe($("tabbar"));

/** The extra tab — History or Settings — as the strip draws a site's, with
 *  its own icon, no speaker, its own close button, and set apart from the
 *  sites' tabs by the hairline after it (browser.css). Never dragged. */
function extraTab() {
  const kind = EXTRAS[extraKind];
  const button = document.createElement("button");
  button.type = "button";
  button.className = "tab extra";
  button.setAttribute("role", "tab");
  button.setAttribute("aria-selected", String(extraFront));
  button.dataset.extra = extraKind;
  const divider = document.createElement("span");
  divider.className = "divider";
  // The clock, drawn as a tab's globe is when its site has no icon.
  const mark = icon(kind.icon);
  mark.classList.add("mark");
  const label = document.createElement("span");
  label.className = "label";
  label.textContent = kind.name;
  const sound = document.createElement("span");
  sound.className = "sound";
  sound.hidden = true;
  const shut = document.createElement("span");
  shut.className = "shut";
  shut.dataset.shut = extraKind;
  shut.dataset.tip = `Close ${kind.name} (⌘W)`;
  shut.setAttribute("aria-hidden", "true");
  shut.append(icon("close"));
  button.append(divider, mark, label, sound, shut);
  button.dataset.tip = `${kind.name} (${kind.keys})`;
  return button;
}

function render() {
  tellBubble();
  tellMenuIcons();
  const tab = front();

  // Chrome's strip: every tab, the one in front lifted into the toolbar —
  // left as it stands while a tab is being dragged along it, whose button
  // is the one under the pointer (Moving a tab, below).
  if (!(held && held.moving)) $("tabbar").replaceChildren(
    ...(extraOpen ? [extraTab()] : []),
    ...tabs.map((each) => {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "tab";
      button.setAttribute("role", "tab");
      button.setAttribute("aria-selected", String(each.id === activeId && !extraFront));
      button.dataset.id = each.id;
      const divider = document.createElement("span");
      divider.className = "divider";
      // The site's icon, or a spinner in its place while the tab loads, as
      // Chrome draws it.
      const mark = tabMark(each);
      mark.classList.add("mark");
      const label = document.createElement("span");
      label.className = "label";
      label.textContent = each.title || (each.url ? pretty(each.url) : "New Tab");
      // A speaker while it makes sound, or while its sound is off — what it
      // says and what a press on it does, beside the close button.
      const sound = document.createElement("span");
      sound.className = "sound";
      if (each.playing || each.muted) {
        const silent = each.muted || muted;
        sound.dataset.sound = each.id;
        sound.dataset.tip = each.muted ? "Unmute This Tab" : "Mute This Tab";
        sound.setAttribute("aria-label", sound.dataset.tip);
        sound.classList.toggle("silent", silent);
        sound.append(icon(silent ? "silent" : "sound"));
      } else {
        sound.hidden = true;
      }
      const shut = document.createElement("span");
      shut.className = "shut";
      shut.dataset.shut = each.id;
      shut.dataset.tip = "Close Tab (⌘W)";
      // Closing is ⌘W and the middle button for VoiceOver; the cross is
      // the pointer's, and left out of the tab's name.
      shut.setAttribute("aria-hidden", "true");
      shut.append(icon("close"));
      button.append(divider, mark, label, sound, shut);
      button.dataset.tip = each.title || each.url || "New Tab";
      return button;
    }),
  );
  fitTabs();
  $("new-tab").disabled = tabs.length >= MOST_TABS;
  $("new-tab").dataset.tip = tabs.length >= MOST_TABS ? `${MOST_TABS} tabs at most` : "New Tab (⌘T)";

  drawBarBack();

  // The toolbar's and Compact Mode's bar's alike.
  for (const button of document.querySelectorAll("[data-go]")) {
    const go = button.dataset.go;
    button.disabled = !tab || (go === "back" ? tab.back.length === 0 : go === "forward" ? tab.forward.length === 0 : !tab.url);
  }
  $("browser-open").disabled = !tab || !tab.url;

  const mobile = $("mobile");
  mobile.replaceChildren(icon(tab && tab.mobile ? "phone" : "desktop"));
  mobile.dataset.tip = tab && tab.mobile ? "Showing phone layouts — use desktop" : "Showing desktop layouts — use phone";
  mobile.setAttribute("aria-pressed", String(Boolean(tab && tab.mobile)));

  showAddress();

  const state = tab ? (tab.url ? tab.state : "start") : "start";
  site.dataset.state = state;
  // A shortcut's menu and sheet go with the start page they are on.
  if (state !== "start") {
    closeTileMenu(false);
    closeTileSheet(false);
  }
  $("wait-host").textContent = tab && tab.url ? host(tab.url) : "";
  $("wait").setAttribute("aria-label", tab && tab.url ? `Loading ${host(tab.url)}` : "");
  $("failed-why").textContent = tab ? tab.reason : "";
  for (const bar of document.querySelectorAll(".bar")) bar.classList.toggle("on", state === "loading");

  // Compact Mode's bar: the tab in front's title, and how many tabs on the
  // icon whose menu lists them.
  $("browser").classList.toggle("compact", compact);
  $("title-bar").classList.toggle("editing", compact && editingTitle);
  const name = extraFront ? EXTRAS[extraKind].name : tab ? tab.title || (tab.url ? pretty(tab.url) : "New Tab") : "New Tab";
  $("title").textContent = name;
  $("title").dataset.tip = tab && tab.title && tab.url ? `${tab.title} — ${pretty(tab.url)}` : name;
  const several = tabs.length > 1;
  $("tab-badge").hidden = !several;
  $("tab-badge").textContent = String(tabs.length);
  const said = several ? `Floating Browser · ${tabs.length} tabs` : "Floating Browser";
  $("bar-mark").dataset.tip = said;
  $("bar-mark").setAttribute("aria-label", said);

  drawMenu();
}

// ---- The icon's menu ----------------------------------------------------------

/** The icon's menu, as things stand: the tabs — a row each, as the strip
 *  draws them, and New Tab, in both modes, so switching Compact Mode from
 *  here leaves the menu as it was — then the switches for Compact Mode and
 *  Desktop Site, and History. */
function drawMenu() {
  const menu = $("menu");
  menu.hidden = !menuOpen;
  for (const button of document.querySelectorAll("[data-menu]")) button.setAttribute("aria-expanded", String(menuOpen));
  const row = $("compact-row");
  row.setAttribute("aria-checked", String(compact));
  row.querySelector(".switch").classList.toggle("on", compact);
  // Chrome's Desktop Site, for the tab in front: the toolbar's phone and
  // desktop button's own setting (`tab.mobile`, `toggleMobile`), so the two
  // are one switch drawn twice and each shows what the other set.
  const tab = front();
  const desktop = Boolean(tab && !tab.mobile);
  const desktopRow = $("desktop-row");
  desktopRow.setAttribute("aria-checked", String(desktop));
  desktopRow.querySelector(".switch").classList.toggle("on", desktop);
  if (!menuOpen) return;
  const rows = tabs.map((each) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "menu-row";
    button.setAttribute("role", "menuitemradio");
    button.setAttribute("aria-checked", String(each.id === activeId));
    button.classList.toggle("current", each.id === activeId);
    button.dataset.tab = each.id;
    const mark = tabMark(each);
    const label = document.createElement("span");
    label.className = "row-label";
    label.textContent = each.title || (each.url ? pretty(each.url) : "New Tab");
    const shut = document.createElement("span");
    shut.className = "row-shut";
    shut.dataset.shut = each.id;
    shut.dataset.tip = "Close Tab (⌘W)";
    shut.setAttribute("aria-hidden", "true");
    shut.append(icon("close"));
    button.append(mark, label, shut);
    return button;
  });
  const add = document.createElement("button");
  add.type = "button";
  add.className = "menu-row";
  add.id = "menu-new-tab";
  add.disabled = tabs.length >= MOST_TABS;
  const label = document.createElement("span");
  label.className = "row-label";
  label.textContent = tabs.length >= MOST_TABS ? `${MOST_TABS} tabs at most` : "New Tab";
  const keys = document.createElement("span");
  keys.className = "keys";
  keys.textContent = "⌘T";
  add.append(icon("plus"), label, keys);
  $("menu-tabs").replaceChildren(...rows, add);
}

/** Under whichever icon is on screen: switching Compact Mode moves it. */
function placeMenu() {
  const menu = $("menu");
  const anchor = [...document.querySelectorAll(".app-mark")].find((each) => each.offsetParent !== null);
  if (!anchor) return;
  const at = anchor.getBoundingClientRect();
  const left = Math.max(6, Math.min(at.left - 2, innerWidth - menu.offsetWidth - 6));
  menu.style.transform = `translate(${Math.round(left)}px, ${Math.round(at.bottom + 6)}px)`;
}

function openMenu() {
  closeSiteInfo();
  editingTitle = false;
  menuOpen = true;
  hideTip();
  render();
  placeMenu();
  // The whole site covered, so a press beside the menu puts it away.
  place();
}

function closeMenu() {
  if (!menuOpen) return;
  menuOpen = false;
  render();
  place();
}

$("compact-row").addEventListener("click", () => setCompact(!compact));

$("desktop-row").addEventListener("click", () => toggleMobile());

$("view-history").addEventListener("click", () => openHistory());

$("view-settings").addEventListener("click", () => openSettings());

// The × as a row: the menu goes, then the window closes as the × closes it.
$("menu-close").addEventListener("click", () => {
  closeMenu();
  closeWindow();
});

// ---- The history view -----------------------------------------------------------

// The pages visited, as Chrome's History lists them — by day, newest first,
// with a search through their titles and addresses — drawn by this page
// over the site's box rather than in a tab of its own, since a window holds
// four tabs and the history should not cost one. The box is covered whole
// while it is up (`showSite`), so the site under it keeps its place.

/** History's tab is open — always the first tab, before the sites', and
 *  the only one there is of its kind — and whether it is in front, its
 *  view drawn over the site's box. It holds no site, so it may be a fifth
 *  tab with four sites open. */
let extraOpen = false;
let extraFront = false;

/** Which the extra tab is. There is only ever one: opening the other turns
 *  this tab into it, in its place, rather than costing a second tab beside
 *  the sites'. */
let extraKind = "history";

/** What each extra tab is called, drawn with and opened by. */
const EXTRAS = {
  history: { name: "History", icon: "clock", keys: "⌘Y", view: "history-view" },
  settings: { name: "Settings", icon: "settings", keys: "⌘,", view: "settings-view" },
};

/** The extra tab open as `kind`, in front, its view shown and the other's
 *  hidden. Answers whether it was already open as that. */
function showExtra(kind) {
  closeMenu();
  closeSuggest();
  const was = extraOpen && extraKind === kind;
  if (extraKind !== kind && extraKind === "history") unaskClear();
  extraOpen = true;
  extraFront = true;
  extraKind = kind;
  for (const [each, extra] of Object.entries(EXTRAS)) $(extra.view).hidden = each !== kind;
  return was;
}

/** The extra tab brought to the front as whichever it is. */
function openExtra() {
  if (extraKind === "settings") openSettings();
  else openHistory();
}

/** The extra tab closed, whichever it is. */
function closeExtra() {
  closeHistory();
}

/** The most pages listed at once; a search finds the rest. */
const MOST_LISTED = 300;

/** History's tab opened — or, open already, brought to the front — its
 *  search emptied and the keyboard in it. */
function openHistory() {
  const was = showExtra("history");
  if (!was) $("history-search").value = "";
  drawHistory();
  render();
  place();
  $("history-search").focus();
}

/** History's tab closed, and the site that was in front shown again. */
function closeHistory() {
  if (!extraOpen) return;
  extraOpen = false;
  extraFront = false;
  $("history-view").hidden = true;
  $("settings-view").hidden = true;
  unaskClear();
  render();
  place();
}

/** History's tab put behind a site's, its view hidden and kept as it was. */
function extraBehind() {
  if (!extraFront) return;
  extraFront = false;
  $("history-view").hidden = true;
  $("settings-view").hidden = true;
  unaskClear();
}

// ---- Settings ----------------------------------------------------------------

// How the minimized pill shows a track's artwork: its shape — a record
// turning while it plays, a circle or a square — and whether the pill takes
// the cover's colour; and which tab it stands for (`bubbleState`). Kept by
// the component with the extension's own storage (`keep-look`), which hands
// it on to a pill that is up, so the pill follows a change at once; a site
// that gives no artwork is drawn as before whatever is chosen.

/** The pill's look as set: a spinning record, untinted, standing for the
 *  tab making sound, until set otherwise. */
const LOOK_SHAPES = ["record", "circle", "square"];
let look = { v: 1, shape: "record", tint: false, playingFirst: true };

/** A look read from storage or a request: only its known words. Prioritize
 *  Now Playing Tab is off only when said so, so a look kept before the
 *  switch existed goes on as the pill went then. */
function lookOf(said) {
  return {
    v: 1,
    shape: said && LOOK_SHAPES.includes(said.shape) ? said.shape : "record",
    tint: Boolean(said && said.tint === true),
    playingFirst: !(said && said.playingFirst === false),
  };
}

/** Settings' controls as the look stands, and the preview told. */
function drawSettings() {
  for (const button of document.querySelectorAll("[data-shape]")) {
    button.setAttribute("aria-checked", String(button.dataset.shape === look.shape));
  }
  $("tint-switch").setAttribute("aria-checked", String(look.tint));
  $("tint-switch").classList.toggle("on", look.tint);
  $("playing-first-switch").setAttribute("aria-checked", String(look.playingFirst));
  $("playing-first-switch").classList.toggle("on", look.playingFirst);
  for (const button of document.querySelectorAll("[data-appearance]")) {
    button.setAttribute("aria-checked", String(button.dataset.appearance === appearance));
  }
  $("ask-close-switch").setAttribute("aria-checked", String(asksBeforeClosing));
  $("ask-close-switch").classList.toggle("on", asksBeforeClosing);
  tellPreview();
}

/** The preview pill told the look, once its page is there to hear it (it
 *  says it is ready as it loads, below). */
function tellPreview() {
  const frame = $("settings-preview");
  if (frame.contentWindow) frame.contentWindow.postMessage({ look }, location.origin);
}

addEventListener("message", (event) => {
  if (event.origin !== location.origin || event.source !== $("settings-preview").contentWindow) return;
  const said = event.data;
  if (said && said.preview === "ready") tellPreview();
  // The preview as wide as its pill asks, as the pill's window is.
  if (said && said.preview === "size" && Number.isFinite(said.width)) {
    $("settings-preview").style.width = `${Math.max(120, Math.min(220, said.width))}px`;
  }
});

function setLook(change) {
  look = lookOf({ ...look, ...change });
  drawSettings();
  call({ kind: "keep-look", look }).catch(() => {});
  // Which tab the pill stands for may have moved with it.
  tellBubble();
}

/** Settings' tab opened — or brought to the front — in the extra tab's place. */
function openSettings() {
  showExtra("settings");
  drawSettings();
  render();
  place();
  const chosen = document.querySelector('[data-shape][aria-checked="true"]');
  if (chosen) chosen.focus();
}

for (const button of document.querySelectorAll("[data-shape]")) {
  button.addEventListener("click", () => setLook({ shape: button.dataset.shape }));
}

// The arrow keys move along the shapes, as a segmented control's do.
document.querySelector(".segmented").addEventListener("keydown", (event) => {
  const step = { ArrowLeft: -1, ArrowUp: -1, ArrowRight: 1, ArrowDown: 1 }[event.key];
  if (!step) return;
  event.preventDefault();
  const at = LOOK_SHAPES.indexOf(look.shape);
  const shape = LOOK_SHAPES[(at + step + LOOK_SHAPES.length) % LOOK_SHAPES.length];
  setLook({ shape });
  document.querySelector(`[data-shape="${shape}"]`).focus();
});

$("tint-switch").addEventListener("click", () => setLook({ tint: !look.tint }));
$("playing-first-switch").addEventListener("click", () => setLook({ playingFirst: !look.playingFirst }));

// Light, dark or macOS's, for every window but the Welcome tour, which has
// macOS's own title bar: put on each by Lumi (`keep-appearance`), which
// keeps it across a restart, so this page's own colours follow it through
// `prefers-color-scheme` like every other page's. Asked of the component
// only for these buttons — Lumi says nothing of it.

const APPEARANCES = ["light", "dark", "system"];
let appearance = "system";

function setAppearance(chosen) {
  appearance = chosen;
  drawSettings();
  call({ kind: "keep-appearance", appearance }).catch(() => {});
}

for (const button of document.querySelectorAll("[data-appearance]")) {
  button.addEventListener("click", () => setAppearance(button.dataset.appearance));
}

$("appearance-choice").addEventListener("keydown", (event) => {
  const step = { ArrowLeft: -1, ArrowUp: -1, ArrowRight: 1, ArrowDown: 1 }[event.key];
  if (!step) return;
  event.preventDefault();
  const at = APPEARANCES.indexOf(appearance);
  const chosen = APPEARANCES[(at + step + APPEARANCES.length) % APPEARANCES.length];
  setAppearance(chosen);
  document.querySelector(`[data-appearance="${chosen}"]`).focus();
});

/** The day `ms` is in, as a heading: Today, Yesterday, else its date. */
function dayOf(ms) {
  const day = new Date(ms);
  const today = new Date();
  const yesterday = new Date(today);
  yesterday.setDate(today.getDate() - 1);
  if (day.toDateString() === today.toDateString()) return "Today";
  if (day.toDateString() === yesterday.toDateString()) return "Yesterday";
  return day.toLocaleDateString(undefined, { weekday: "long", day: "numeric", month: "long", year: "numeric" });
}

function drawHistory() {
  const words = folded($("history-search").value.trim()).split(/\s+/).filter(Boolean);
  const pages = history.entries
    .filter((entry) => {
      const text = folded(`${entry.title} ${pretty(entry.url)}`);
      return words.every((word) => text.includes(word));
    })
    .sort((a, b) => b.last - a.last)
    .slice(0, MOST_LISTED);
  const list = $("history-list");
  if (pages.length === 0) {
    const none = document.createElement("p");
    none.className = "hv-empty";
    none.textContent = words.length ? "No pages match." : "Pages you visit are listed here.";
    list.replaceChildren(none);
    return;
  }
  const items = [];
  let day = "";
  for (const entry of pages) {
    const heading = dayOf(entry.last);
    if (heading !== day) {
      day = heading;
      const title = document.createElement("h3");
      title.className = "hv-day";
      title.textContent = heading;
      items.push(title);
    }
    const row = document.createElement("button");
    row.type = "button";
    row.className = "hv-row";
    row.dataset.url = entry.url;
    row.dataset.tip = entry.url;
    const time = document.createElement("time");
    time.textContent = new Date(entry.last).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    const found = iconFor(entry.url);
    let mark;
    if (found) {
      mark = document.createElement("img");
      mark.className = "favicon";
      mark.alt = "";
      mark.src = found;
    } else {
      mark = icon("globe");
    }
    const title = document.createElement("span");
    title.className = "hv-title";
    title.textContent = entry.title || pretty(entry.url);
    const where = document.createElement("span");
    where.className = "hv-host";
    where.textContent = host(entry.url);
    const out = document.createElement("span");
    out.className = "s-forget";
    out.dataset.forget = entry.url;
    out.dataset.tip = "Remove from History";
    out.append(icon("close"));
    row.append(time, mark, title, where, out);
    items.push(row);
  }
  list.replaceChildren(...items);
  // Every time as wide as the widest, so the titles start in one line
  // whatever the clock writes ("9:05 AM" beside "12:54 AM").
  list.style.removeProperty("--hv-time");
  const widest = Math.max(0, ...[...list.querySelectorAll(".hv-row time")].map((time) => time.offsetWidth));
  if (widest) list.style.setProperty("--hv-time", `${widest}px`);
}

$("history-search").addEventListener("input", () => drawHistory());

// A page pressed opens in the tab in front, as Chrome's History opens in
// its own; its × takes it out of the history.
$("history-list").addEventListener("click", (event) => {
  const out = event.target.closest("[data-forget]");
  if (out) {
    forget(out.dataset.forget);
    drawHistory();
    return;
  }
  const row = event.target.closest("[data-url]");
  if (!row) return;
  const tab = front();
  closeHistory();
  if (tab) go(tab, row.dataset.url);
});

// Clear Browsing History: the first press says what the second will do, for
// four seconds; the second clears every page the history holds.
let clearAsked = 0;
function unaskClear() {
  clearTimeout(clearAsked);
  clearAsked = 0;
  $("history-clear").classList.remove("danger");
  $("history-clear").textContent = "Clear Browsing History";
}
// Done closes History or Settings where no tab is drawn to close it.
for (const done of document.querySelectorAll(".hv-done")) done.addEventListener("click", () => closeExtra());

$("history-clear").addEventListener("click", () => {
  if (!clearAsked) {
    $("history-clear").classList.add("danger");
    $("history-clear").textContent = "Click Again to Clear All History";
    clearAsked = setTimeout(unaskClear, 4000);
    return;
  }
  clearHistory();
  unaskClear();
  drawHistory();
});

$("menu-tabs").addEventListener("click", (event) => {
  const shut = event.target.closest("[data-shut]");
  if (shut) {
    closeTab(shut.dataset.shut);
    return;
  }
  if (event.target.closest("#menu-new-tab")) {
    closeMenu();
    openTab();
    return;
  }
  const row = event.target.closest("[data-tab]");
  if (!row) return;
  closeMenu();
  select(row.dataset.tab);
});

for (const button of document.querySelectorAll("[data-menu]")) {
  button.addEventListener("click", () => (menuOpen ? closeMenu() : openMenu()));
}

// A press anywhere but the menu and the buttons that open it puts it away:
// on the page's own bars, and on the site, which is covered while it is open.
document.addEventListener(
  "pointerdown",
  (event) => {
    if (menuOpen && !event.target.closest("#menu, [data-menu]")) closeMenu();
  },
  true,
);

// And so does the keyboard going to another application.
addEventListener("blur", () => closeMenu());

// ---- The start page's shortcuts ---------------------------------------------

// The tiles under the start page's search, the person's own as Chrome's
// shortcuts are: held and dragged to another place, edited or removed from
// the ⋮ on each (or a right-click), and added from the Add Shortcut tile —
// an address typed, or a page picked from the history. Until any of that,
// nothing is kept and the start page draws the ones it carries (`QUICK`);
// once something is, the whole list is kept by the extension
// (`keep-tiles`), and Restore Default Shortcuts forgets it. Everything
// except a drag is in the ⋮'s menu too, Move Left and Move Right included,
// so the keyboard and VoiceOver reach all of it.

/** The most shortcuts, as Chrome's ten: the Add Shortcut tile goes at ten. */
const MOST_TILES = 10;

/** The longest name a shortcut keeps. */
const LONGEST_TILE_NAME = 60;

/** The most pages of the history the sheet offers to pick from. */
const MOST_PICKS = 8;

/** The person's shortcuts, `[{label, url}]`, or null while the start page's
 *  own are shown. */
let ownTiles = null;

/** The shortcuts shown now. */
const tiles = () => ownTiles || QUICK;

/** `list` as the start page carries its own: the same names at the same
 *  addresses, in the same order. */
function carriedTiles(list) {
  return list.length === QUICK.length && list.every((each, at) => each.label === QUICK[at].label && each.url === QUICK[at].url);
}

/** One request at a time: a remove and its Undo pressed at once must reach
 *  the extension in that order. */
let tileKeeping = Promise.resolve();

/** `list` the start page's shortcuts, drawn and kept — or the start page's
 *  own again, forgotten, for `null` or a list that is the same. */
function setTiles(list) {
  ownTiles = list && !carriedTiles(list) ? list.map(({ label, url }) => ({ label, url })) : null;
  drawQuick();
  const kept = ownTiles ? { v: 1, tiles: ownTiles } : null;
  tileKeeping = tileKeeping.then(() => call({ kind: "keep-tiles", tiles: kept })).catch(() => {});
}

/** The shortcuts kept, read as any file is: only well-formed ones, at most
 *  `MOST_TILES`. Anything else is the start page's own. */
function restoreTiles(kept) {
  if (!kept || kept.v !== 1 || !Array.isArray(kept.tiles)) return;
  ownTiles = kept.tiles
    .filter((each) => each && typeof each.url === "string" && each.url.startsWith("https://") && each.url.length <= LONGEST_REMEMBERED)
    .slice(0, MOST_TILES)
    .map((each) => ({
      url: each.url,
      label: (typeof each.label === "string" ? each.label.trim().slice(0, LONGEST_TILE_NAME) : "") || host(each.url),
    }));
}

/** The shortcut at `at` taken off the start page, with a notice that offers
 *  it back, as Chrome's does. */
function removeTile(at) {
  const before = ownTiles;
  const list = tiles().filter((_, each) => each !== at);
  setTiles(list);
  notify("Shortcut removed.", [
    { label: "Undo", run: () => setTiles(before) },
    ...(ownTiles ? [{ label: "Restore Default Shortcuts", run: () => restoreDefaultTiles() }] : []),
  ]);
}

/** The start page's own shortcuts back, with a notice that can undo it. */
function restoreDefaultTiles() {
  const before = ownTiles;
  if (!before) return;
  setTiles(null);
  notify("Default shortcuts restored.", [{ label: "Undo", run: () => setTiles(before) }]);
}

/** The shortcut at `from` put at `to`, the ones between moving up one. */
function moveTile(from, to) {
  const list = [...tiles()];
  if (to < 0 || to >= list.length || from === to) return;
  const [moved] = list.splice(from, 1);
  list.splice(to, 0, moved);
  setTiles(list);
}

/** A name's first letter, for a site with no icon to show. */
function letterOf(label) {
  const [first] = label.trim();
  return first ? first.toLocaleUpperCase() : "?";
}

/** The disc on a tile: the site's icon where the package carries one or one
 *  was found (Favicons); else, or if it cannot be drawn, the letter the
 *  start page's own shortcuts carry on their colour, or a name's first
 *  letter on a plain disc, as Chrome draws a site with no icon. A site whose
 *  icon has not been looked for is looked for, and the tiles drawn again. */
function tileMark(each) {
  const mark = document.createElement("span");
  const own = QUICK.find((carried) => carried.url === each.url);
  const lettered = () => {
    mark.style.removeProperty("background");
    if (own) {
      mark.className = "mark";
      mark.style.background = own.color;
      mark.replaceChildren(own.mark);
    } else {
      mark.className = "mark site letter";
      mark.replaceChildren(letterOf(each.label));
    }
  };
  const found = iconFor(each.url);
  if (!found) {
    lettered();
    findIcon(each.url).then((look) => look && drawQuick());
    return mark;
  }
  mark.className = "mark site";
  const picture = document.createElement("img");
  picture.alt = "";
  picture.draggable = false;
  picture.src = found;
  picture.addEventListener("error", lettered, { once: true });
  mark.append(picture);
  return mark;
}

/** The tiles drawn again: left as they stand while one is being dragged —
 *  its element is the one under the pointer — and drawn when it is let go. */
let quickStale = false;
function drawQuick() {
  if (tileHeld && tileHeld.moving) {
    quickStale = true;
    return;
  }
  quickStale = false;
  const list = tiles();
  const items = list.map((each, at) => {
    const tile = document.createElement("div");
    tile.className = "tile";
    tile.setAttribute("role", "listitem");
    tile.dataset.at = String(at);
    const open = document.createElement("button");
    open.type = "button";
    open.className = "tile-open";
    open.dataset.tip = pretty(each.url);
    const label = document.createElement("span");
    label.className = "tile-label";
    label.textContent = each.label;
    open.append(tileMark(each), label);
    const more = document.createElement("button");
    more.type = "button";
    more.className = "tile-more";
    more.dataset.tip = "More actions";
    more.setAttribute("aria-label", `More actions for ${each.label}`);
    more.setAttribute("aria-haspopup", "menu");
    more.setAttribute("aria-expanded", String(Boolean(tileMenu && tileMenu.at === at)));
    more.append(icon("more"));
    tile.append(open, more);
    return tile;
  });
  if (list.length < MOST_TILES) {
    const tile = document.createElement("div");
    tile.className = "tile add";
    tile.setAttribute("role", "listitem");
    const open = document.createElement("button");
    open.type = "button";
    open.className = "tile-open";
    open.setAttribute("aria-haspopup", "dialog");
    const mark = document.createElement("span");
    mark.className = "mark site";
    mark.append(icon("plus"));
    const label = document.createElement("span");
    label.className = "tile-label";
    label.textContent = "Add Shortcut";
    open.append(mark, label);
    tile.append(open);
    items.push(tile);
  }
  $("quick").replaceChildren(...items);
}

/** The tile at `at`'s element, or the Add Shortcut tile's for `null`. */
function tileAt(at) {
  return $("quick").querySelector(at === null ? ".tile.add" : `.tile[data-at="${at}"]`);
}

// A tile pressed opens its site in the tab in front; its ⋮ opens its menu;
// the Add Shortcut tile opens the sheet. A press that ended a drag is none
// of them.
let tileDragged = false;

$("quick").addEventListener("click", (event) => {
  if (tileDragged) return;
  const tile = event.target.closest(".tile");
  if (!tile) return;
  if (tile.classList.contains("add")) {
    openTileSheet(null);
    return;
  }
  const at = Number(tile.dataset.at);
  const more = event.target.closest(".tile-more");
  if (more) {
    if (tileMenu && tileMenu.at === at) closeTileMenu(true);
    else openTileMenu(at, more.getBoundingClientRect(), event.detail === 0);
    return;
  }
  const each = tiles()[at];
  const tab = front();
  if (each && tab) go(tab, each.url);
});

// A right-click on a tile opens the same menu, at the pointer.
$("quick").addEventListener("contextmenu", (event) => {
  const tile = event.target.closest(".tile:not(.add)");
  if (!tile) return;
  event.preventDefault();
  const at = { left: event.clientX, right: event.clientX, top: event.clientY, bottom: event.clientY };
  openTileMenu(Number(tile.dataset.at), at, event.button !== 2);
});

// ---- Moving a shortcut ------------------------------------------------------

// A tile held and moved goes with the pointer, as Chrome's shortcuts do,
// and takes the place of the tile its middle comes over; the tiles between
// slide along into the places left. The strip's tabs' rules (Moving a tab):
// the element moved, not drawn again; every place read from layout
// (`offsetLeft`, `offsetTop`), never from what is drawn, since a tile still
// sliding is drawn where it was; and reaching an edge is passing it, so a
// tile held against the grid's end takes the last place. The grid holds the
// pointer once the tile moves, so a release anywhere ends it.

/** The tile held: its element, the pointer, where the press was in the
 *  grid, and — once it moves — how far into the tile it was taken hold of
 *  and how far it is drawn from its place. */
let tileHeld = null;

const reduceMotion = matchMedia("(prefers-reduced-motion: reduce)");

/** The pointer at `event` in the grid's own coordinates. */
function inQuick(event) {
  const box = $("quick").getBoundingClientRect();
  return { x: event.clientX - box.left, y: event.clientY - box.top };
}

$("quick").addEventListener("pointerdown", (event) => {
  if (event.button !== 0 || event.target.closest(".tile-more")) return;
  const tile = event.target.closest(".tile:not(.add)");
  if (!tile) return;
  tileHeld = { tile, pointer: event.pointerId, from: inQuick(event), moving: false };
});

$("quick").addEventListener("pointermove", (event) => {
  if (!tileHeld || event.pointerId !== tileHeld.pointer) return;
  const at = inQuick(event);
  if (!tileHeld.moving) {
    if (Math.hypot(at.x - tileHeld.from.x, at.y - tileHeld.from.y) < DRAG_AFTER) return;
    closeTileMenu(false);
    tileHeld.moving = true;
    tileHeld.grip = { x: tileHeld.from.x - tileHeld.tile.offsetLeft, y: tileHeld.from.y - tileHeld.tile.offsetTop };
    tileHeld.tile.classList.add("moving");
    $("quick").setPointerCapture(event.pointerId);
    hideTip();
  }
  followTile(at);
});

/** The held tile under the pointer at `at`, kept inside the grid, in the
 *  place of the tile its middle is over. */
function followTile(at) {
  const grid = $("quick");
  const tile = tileHeld.tile;
  const want = {
    x: Math.min(Math.max(at.x - tileHeld.grip.x, 0), grid.offsetWidth - tile.offsetWidth),
    y: Math.min(Math.max(at.y - tileHeld.grip.y, 0), grid.offsetHeight - tile.offsetHeight),
  };
  const middle = { x: want.x + tile.offsetWidth / 2, y: want.y + tile.offsetHeight / 2 };
  const others = [...grid.children].filter((other) => other !== tile && !other.classList.contains("add"));
  const over = others.find(
    (other) =>
      middle.x >= other.offsetLeft &&
      middle.x <= other.offsetLeft + other.offsetWidth &&
      middle.y >= other.offsetTop &&
      middle.y <= other.offsetTop + other.offsetHeight,
  );
  if (over) {
    const was = new Map(others.map((other) => [other, { x: other.offsetLeft, y: other.offsetTop }]));
    const order = [...grid.children];
    if (order.indexOf(over) > order.indexOf(tile)) grid.insertBefore(tile, over.nextElementSibling);
    else grid.insertBefore(tile, over);
    for (const [other, from] of was) {
      const dx = from.x - other.offsetLeft;
      const dy = from.y - other.offsetTop;
      if ((dx || dy) && !reduceMotion.matches) {
        other.animate([{ transform: `translate(${dx}px, ${dy}px)` }, { transform: "none" }], { duration: 150, easing: "ease-out" });
      }
    }
  }
  tileHeld.shift = { x: want.x - tile.offsetLeft, y: want.y - tile.offsetTop };
  tile.style.transform = `translate(${tileHeld.shift.x}px, ${tileHeld.shift.y}px)`;
}

function letGoTile(event) {
  if (!tileHeld || event.pointerId !== tileHeld.pointer) return;
  const was = tileHeld;
  tileHeld = null;
  if (!was.moving) return;
  // The click this release makes is no press on a tile.
  tileDragged = true;
  setTimeout(() => (tileDragged = false), 0);
  const list = tiles();
  const order = [...$("quick").children].filter((each) => !each.classList.contains("add")).map((each) => list[Number(each.dataset.at)]);
  const tile = was.tile;
  tile.style.transform = "";
  const settle = () => {
    tile.classList.remove("moving");
    // Kept, and drawn again: the tiles' places are their new order's.
    if (order.some((each, at) => each !== list[at])) setTiles(order);
    else if (quickStale) drawQuick();
  };
  if (reduceMotion.matches) {
    settle();
    return;
  }
  const { x, y } = was.shift || { x: 0, y: 0 };
  tile.animate([{ transform: `translate(${x}px, ${y}px)` }, { transform: "none" }], { duration: 150, easing: "ease-out" }).onfinish = settle;
}

$("quick").addEventListener("pointerup", letGoTile);
$("quick").addEventListener("pointercancel", letGoTile);

// ---- A shortcut's menu ------------------------------------------------------

/** The menu up for the tile at `at`, or null. */
let tileMenu = null;

for (const [id, name] of [
  ["tile-edit", "pencil"],
  ["tile-remove", "trash"],
  ["tile-left", "left"],
  ["tile-right", "right"],
  ["tile-restore", "restore"],
]) {
  $(id).querySelector(".row-ico").append(icon(name));
}

/** The menu for the tile at `at`, under `box` (its ⋮, or the pointer's
 *  point for a right-click) from its leading edge, as a Mac menu drops —
 *  held inside the window, and over it where the window's foot leaves no
 *  room. `keyed`: opened by the keyboard, so its first row takes it. */
function openTileMenu(at, box, keyed) {
  closeMenu();
  closeSiteInfo();
  hideTip();
  tileMenu = { at };
  const menu = $("tile-menu");
  const count = tiles().length;
  $("tile-left").disabled = at === 0;
  $("tile-right").disabled = at === count - 1;
  $("tile-restore").hidden = !ownTiles;
  $("tile-restore-sep").hidden = !ownTiles;
  menu.hidden = false;
  const left = Math.max(6, Math.min(box.left, innerWidth - menu.offsetWidth - 6));
  let top = box.bottom + 4;
  if (top + menu.offsetHeight > innerHeight - 6) top = Math.max(6, box.top - menu.offsetHeight - 4);
  menu.style.transform = `translate(${Math.round(left)}px, ${Math.round(top)}px)`;
  for (const more of $("quick").querySelectorAll(".tile-more")) more.setAttribute("aria-expanded", String(more.closest(".tile").dataset.at === String(at)));
  if (keyed) menu.querySelector(".menu-row:not(:disabled)").focus();
}

/** The menu put away — `refocus`, the keyboard back on the tile's ⋮. */
function closeTileMenu(refocus) {
  if (!tileMenu) return;
  const { at } = tileMenu;
  tileMenu = null;
  $("tile-menu").hidden = true;
  for (const more of $("quick").querySelectorAll(".tile-more")) more.setAttribute("aria-expanded", "false");
  const tile = tileAt(at);
  if (refocus && tile) tile.querySelector(".tile-more").focus();
}

/** Run `act` with the menu's tile, the menu put away first. */
function fromTileMenu(act) {
  return () => {
    if (!tileMenu) return;
    const { at } = tileMenu;
    closeTileMenu(false);
    act(at);
  };
}

$("tile-edit").addEventListener("click", fromTileMenu((at) => openTileSheet(at)));
$("tile-remove").addEventListener(
  "click",
  fromTileMenu((at) => {
    removeTile(at);
    // The keyboard on the tile that came into its place, else the one before.
    const next = tileAt(Math.min(at, tiles().length - 1)) || tileAt(null);
    if (next) next.querySelector(".tile-open").focus();
  }),
);
for (const [id, by] of [
  ["tile-left", -1],
  ["tile-right", 1],
]) {
  $(id).addEventListener(
    "click",
    fromTileMenu((at) => {
      moveTile(at, at + by);
      const moved = tileAt(at + by);
      if (moved) moved.querySelector(".tile-more").focus();
    }),
  );
}
$("tile-restore").addEventListener("click", fromTileMenu(() => restoreDefaultTiles()));

// The arrows walk the menu's rows (Escape, below, puts it away).
$("tile-menu").addEventListener("keydown", (event) => {
  if (event.key !== "ArrowDown" && event.key !== "ArrowUp") return;
  event.preventDefault();
  const rows = [...$("tile-menu").querySelectorAll(".menu-row")].filter((row) => !row.disabled && !row.hidden);
  const at = rows.indexOf(document.activeElement);
  const next = event.key === "ArrowDown" ? (at + 1) % rows.length : (at - 1 + rows.length) % rows.length;
  rows[next].focus();
});

// A press anywhere but the menu and the ⋮ it is up for puts it away — that
// ⋮'s own click does, as a second press on a menu's button does — and so
// do Escape, the keyboard back on that ⋮, the keyboard going to another
// application and the window being put away.
document.addEventListener(
  "pointerdown",
  (event) => {
    if (tileMenu && !event.target.closest("#tile-menu, .tile-more[aria-expanded='true']")) closeTileMenu(false);
  },
  true,
);
document.addEventListener(
  "keydown",
  (event) => {
    if (!tileMenu || event.isComposing || event.key !== "Escape") return;
    event.preventDefault();
    event.stopImmediatePropagation();
    closeTileMenu(true);
  },
  true,
);
addEventListener("blur", () => closeTileMenu(false));
addEventListener("lumi:hidden", () => closeTileMenu(false));

// ---- Adding or editing a shortcut ---------------------------------------------

// Chrome's Add shortcut and Edit shortcut, as a sheet over the window: a name
// and an address, and the pages of the history to pick one from — the ones
// visited most and most lately, or, once something is typed in the address,
// the ones that match it. Checked on Save and not before (Lumi's rule): Save
// is never greyed, and a press with an address that cannot be a shortcut
// says why under the field and puts the keyboard there; from then on the
// sentence follows what is typed.

/** The sheet up: the tile it edits (`null` adding one), whether Save was
 *  pressed, and what the history's list is narrowed by. */
let tileSheet = null;

/** What the person typed as a shortcut's address, as one: `{url}`, or
 *  `{error}` saying why it cannot be. Lumi shows https alone, so plain http
 *  is asked for over https, as the address bar does; a bare host is an
 *  https one. */
function tileAddress(text) {
  const typed = text.trim();
  if (!typed) return { error: "Type the page's address." };
  const notWeb = { error: "Type a web address, such as example.com." };
  let asked = typed;
  if (/^http:\/\//i.test(asked)) asked = `https://${asked.slice(7)}`;
  else if (!/^https:\/\//i.test(asked)) {
    // Another scheme (mailto:, file:) is no web page; a host and a port is.
    if (/^[a-z][a-z0-9+.-]*:(?!\d)/i.test(asked)) return notWeb;
    asked = `https://${asked}`;
  }
  let url;
  try {
    url = new URL(asked);
  } catch {
    return notWeb;
  }
  if (/\s/.test(typed) || !url.hostname.includes(".") || url.hostname.endsWith(".")) return notWeb;
  if (url.href.length > LONGEST_REMEMBERED) return { error: "This address is too long to keep." };
  const taken = tiles().findIndex((each) => each.url === url.href);
  if (taken >= 0 && taken !== tileSheet.at) return { error: "This page is already a shortcut." };
  return { url: url.href };
}

/** The sheet up, for the tile at `at`, or to add one for `null`. */
function openTileSheet(at) {
  closeTileMenu(false);
  closeSuggest();
  closeSiteInfo();
  hideTip();
  const each = at === null ? null : tiles()[at];
  tileSheet = { at, attempted: false, narrowed: "", offers: false };
  $("tile-sheet-title").textContent = each ? "Edit Shortcut" : "Add Shortcut";
  $("tile-name").value = each ? each.label : "";
  $("tile-url").value = each ? each.url : "";
  sayTileError("");
  tileSheet.offers = picks().length > 0;
  const list = $("tile-picks");
  list.style.removeProperty("height");
  drawPicks();
  $("tile-sheet").hidden = false;
  // The list as tall as it opened, whatever narrows it: a sheet that shrank
  // as the address was typed moved Save up from under the pointer on its
  // way to it, and the press landed beside the sheet.
  if (tileSheet.offers) list.style.height = `${list.offsetHeight}px`;
  // The rest of the window out of reach while it is up, for VoiceOver and
  // the keyboard as for the pointer, which the scrim stops.
  for (const id of ["strip", "toolbar", "title-bar", "start-mark", "start-form", "quick"]) $(id).inert = true;
  $("tile-name").focus();
  $("tile-name").select();
}

/** The sheet put away — `refocus`, the keyboard back on the tile it came
 *  from. */
function closeTileSheet(refocus) {
  if (!tileSheet) return;
  const { at } = tileSheet;
  tileSheet = null;
  $("tile-sheet").hidden = true;
  for (const id of ["strip", "toolbar", "title-bar", "start-mark", "start-form", "quick"]) $(id).inert = false;
  if (!refocus) return;
  const tile = tileAt(at !== null && at < tiles().length ? at : null) || tileAt(null);
  if (tile) tile.querySelector(".tile-open").focus();
}

/** Why the address cannot be a shortcut, under it — or nothing. */
function sayTileError(error) {
  const field = $("tile-url");
  const said = $("tile-url-error");
  said.textContent = error;
  said.hidden = !error;
  field.setAttribute("aria-invalid", String(Boolean(error)));
}

/** The history's pages to pick from: the ones that match what was typed in
 *  the address, else the ones visited most and most lately — never one that
 *  is a shortcut already. */
function picks() {
  const taken = new Set(tiles().map((each) => each.url));
  const words = folded(tileSheet.narrowed.trim()).split(/\s+/).filter(Boolean);
  const now = Date.now();
  const worth = (entry) => {
    const days = (now - entry.last) / 86400000;
    return Math.log2(1 + entry.visits) * 3 + (days < 1 ? 4 : days < 7 ? 3 : days < 30 ? 2 : 1);
  };
  const seen = new Set();
  return history.entries
    .filter((entry) => {
      const plain = pretty(entry.url);
      if (taken.has(entry.url) || seen.has(plain)) return false;
      seen.add(plain);
      const text = folded(`${entry.title} ${plain}`);
      return words.every((word) => text.includes(word));
    })
    .sort((a, b) => worth(b) - worth(a))
    .slice(0, MOST_PICKS);
}

/** The list of the history's pages, the one the fields hold marked — or a
 *  line saying none matches. Not drawn at all when the history had none to
 *  offer as the sheet opened. */
function drawPicks() {
  const pages = picks();
  const chosen = $("tile-url").value.trim();
  $("tile-picks-part").hidden = !tileSheet.offers;
  if (pages.length === 0) {
    const none = document.createElement("p");
    none.className = "tile-picks-none";
    none.textContent = "No pages in your history match.";
    $("tile-picks").replaceChildren(none);
    return;
  }
  $("tile-picks").replaceChildren(
    ...pages.map((entry) => {
      const row = document.createElement("button");
      row.type = "button";
      row.className = "suggestion";
      row.setAttribute("role", "option");
      row.setAttribute("aria-selected", String(entry.url === chosen));
      row.dataset.url = entry.url;
      const found = iconFor(entry.url);
      let mark;
      if (found) {
        mark = document.createElement("img");
        mark.className = "favicon";
        mark.alt = "";
        mark.src = found;
      } else {
        mark = icon("globe");
      }
      const title = document.createElement("span");
      title.className = "s-title";
      title.textContent = entry.title || pretty(entry.url);
      const detail = document.createElement("span");
      detail.className = "s-detail";
      detail.textContent = host(entry.url);
      row.append(mark, title, detail);
      return row;
    }),
  );
}

/** A page's title as a shortcut's name: what comes before the site's own
 *  name, which most titles add after a dash or a bar — "Q4 notes - Google
 *  Docs", "AppKit | Apple Developer" — since a tile has room for a word or
 *  two. The site's host where it has no title. */
function tileNameOf(entry) {
  const [first] = (entry.title || "").split(/\s+[-|–—·•]\s+/);
  return (first.trim() || host(entry.url)).slice(0, LONGEST_TILE_NAME);
}

// A page picked fills both fields: its title, and its address.
$("tile-picks").addEventListener("click", (event) => {
  const row = event.target.closest("[data-url]");
  if (!row || !tileSheet) return;
  const entry = history.entries.find((each) => each.url === row.dataset.url);
  if (!entry) return;
  $("tile-name").value = tileNameOf(entry);
  $("tile-url").value = entry.url;
  for (const each of $("tile-picks").children) each.setAttribute("aria-selected", String(each === row));
  if (tileSheet.attempted) sayTileError(tileAddress(entry.url).error || "");
});

// The arrows walk the list.
$("tile-picks").addEventListener("keydown", (event) => {
  if (event.key !== "ArrowDown" && event.key !== "ArrowUp") return;
  event.preventDefault();
  const rows = [...$("tile-picks").children];
  const at = rows.indexOf(document.activeElement);
  const next = rows[event.key === "ArrowDown" ? Math.min(at + 1, rows.length - 1) : Math.max(at - 1, 0)];
  if (next) next.focus();
});

// What is typed in the address narrows the list; once Save has been pressed,
// the sentence under it follows too.
$("tile-url").addEventListener("input", () => {
  tileSheet.narrowed = $("tile-url").value;
  drawPicks();
  if (tileSheet.attempted) sayTileError(tileAddress($("tile-url").value).error || "");
});

$("tile-form").addEventListener("submit", (event) => {
  event.preventDefault();
  if (!tileSheet) return;
  tileSheet.attempted = true;
  const { url, error } = tileAddress($("tile-url").value);
  sayTileError(error || "");
  if (error) {
    $("tile-url").focus();
    $("tile-url").select();
    return;
  }
  const label = $("tile-name").value.trim().slice(0, LONGEST_TILE_NAME) || host(url);
  const list = [...tiles()];
  const { at } = tileSheet;
  if (at === null) list.push({ label, url });
  else list[at] = { label, url };
  closeTileSheet(false);
  setTiles(list);
  const tile = tileAt(at === null ? list.length - 1 : at);
  if (tile) tile.querySelector(".tile-open").focus();
});

// A press on the scrim beside the sheet does nothing, as beside a Mac sheet:
// a press that missed Save must not throw away what was typed.
$("tile-cancel").addEventListener("click", () => closeTileSheet(true));
// Escape is Cancel, ahead of everything else that hears it; and the
// browser's own keys (⌘T, ⌘Y, ⌃⇥ — Presses, below) wait while the sheet is
// up, which holds the keyboard. Only kept from this page's listeners: what a
// key does in a field (⌘A, ⌘V) is still done.
document.addEventListener(
  "keydown",
  (event) => {
    if (!tileSheet || event.isComposing) return;
    if (event.key === "Escape") {
      event.preventDefault();
      event.stopImmediatePropagation();
      closeTileSheet(true);
    } else if (event.metaKey || event.ctrlKey) {
      event.stopPropagation();
    }
  },
  true,
);

// ---- The address bar --------------------------------------------------------

/** What the person typed, as an address: one already, a bare host, or else
 *  a search. Plain http is asked for over https — Lumi shows nothing else. */
function addressFor(text) {
  const typed = text.trim();
  if (!typed) return null;
  if (/^https:\/\//i.test(typed)) return typed;
  if (/^http:\/\//i.test(typed)) return `https://${typed.slice(7)}`;
  if (!/\s/.test(typed) && /^[^\s/?#]+\.[a-z]{2,}(:\d+)?([/?#].*)?$/i.test(typed)) return `https://${typed}`;
  return SEARCH + encodeURIComponent(typed);
}

/** The address field to type in: the toolbar's, or in Compact Mode the
 *  title made into one. */
function focusAddress() {
  if (compact) {
    editTitle();
    return;
  }
  address.focus();
  address.select();
}

// ---- Compact Mode's title ---------------------------------------------------

const titleAddress = $("title-address");

/** The title made into the address field, the whole address in it and
 *  selected, as the toolbar's is on focus. */
function editTitle() {
  closeMenu();
  editingTitle = true;
  render();
  const tab = front();
  titleAddress.value = tab && tab.url ? tab.url : "";
  drawMarks();
  titleAddress.focus();
  titleAddress.select();
}

/** Back to the title, leaving what was typed. */
function stopEditingTitle() {
  if (!editingTitle) return;
  editingTitle = false;
  render();
}

// The title is the bar's widest part, so it drags the window as the bar
// does — and a press that never moves is a click, which types an address.
// The drag is asked for only once the pointer has moved (`DRAG_AFTER`, the
// tabs' own threshold): asked on the press, as the bar's empty parts ask, no
// click could come. Lumi only needs the button still down, and macOS takes
// the window from where the pointer is then.
let titleHeld = null;

$("title").addEventListener("pointerdown", (event) => {
  if (event.button !== 0) return;
  titleHeld = { pointer: event.pointerId, x: event.clientX, y: event.clientY, dragged: false };
  $("title").setPointerCapture(event.pointerId);
});

$("title").addEventListener("pointermove", (event) => {
  if (!titleHeld || titleHeld.dragged || event.pointerId !== titleHeld.pointer) return;
  if (Math.hypot(event.clientX - titleHeld.x, event.clientY - titleHeld.y) < DRAG_AFTER) return;
  titleHeld.dragged = true;
  hideTip();
  fetch("/__lumi__/drag", { method: "POST" }).catch(() => {});
});

$("title").addEventListener("pointercancel", () => {
  titleHeld = null;
});

// A click with no press behind it is the keyboard's (Space or Return), and
// edits too; one that ends a drag does not.
$("title").addEventListener("click", () => {
  const was = titleHeld;
  titleHeld = null;
  if (was && was.dragged) return;
  editTitle();
});

// Leaving the field folds it back into the title, and so does the page losing
// the keyboard with the field still the document's focused element (below).
titleAddress.addEventListener("blur", () => {
  setTimeout(() => {
    if (document.activeElement !== titleAddress || !document.hasFocus()) stopEditingTitle();
  }, 0);
});

// A press on the site gives the site the keyboard, and WebKit tells this page
// it lost focus while leaving whichever address field was being typed in as
// the document's focused element: `activeElement` still answers that field,
// so it went on looking edited — the whole address shown, selected — while
// the person browsed the site under it, and a press back on the page focused
// it again. So the field is let go of outright, as a blur of its own.
addEventListener("blur", () => {
  const field = document.activeElement;
  if (field === address || field === titleAddress) field.blur();
});

/** Escape in an address field, as in Chrome's omnibox: what was typed goes,
 *  the page's own address comes back, selected, and the list with it — and
 *  the field keeps the keyboard, so typing on replaces the address. Only a
 *  press on the site (or anywhere else) puts the field down. A suggestion
 *  chosen by an arrow is the step before this one (Suggestions, below). */
function revertAddress(field, event) {
  if (event.isComposing || event.keyCode === 229 || event.key !== "Escape") return;
  event.preventDefault();
  // Nothing behind the field hears it: not the History view's Escape.
  event.stopPropagation();
  const tab = front();
  field.value = tab && tab.url ? tab.url : "";
  closeSuggest();
  drawMarks();
  field.select();
}

titleAddress.addEventListener("keydown", (event) => revertAddress(titleAddress, event));

$("title-form").addEventListener("submit", (event) => {
  event.preventDefault();
  if (openedLumiPage(titleAddress)) {
    stopEditingTitle();
    return;
  }
  const url = addressFor(titleAddress.value);
  const tab = front();
  if (!url || !tab) return;
  titleAddress.blur();
  stopEditingTitle();
  go(tab, url);
});

address.addEventListener("focus", () => {
  const tab = front();
  address.value = extraFront ? lumiAddress(extraKind) : tab && tab.url ? tab.url : "";
  drawMarks();
  address.select();
});

// Only the field: leaving it by pressing a tab used to draw the whole tab
// strip again between the press and its release, and a release on a new
// button is no click — the tab took a second press.
address.addEventListener("blur", () => showAddress());

$("address-form").addEventListener("submit", (event) => {
  event.preventDefault();
  if (openedLumiPage(address)) return;
  const url = addressFor(address.value);
  const tab = front();
  if (!url || !tab) return;
  address.blur();
  go(tab, url);
});

address.addEventListener("keydown", (event) => revertAddress(address, event));

// ---- The start page's search ------------------------------------------------

// Chrome's new tab page has a search box beside the omnibox. This one is a
// third address field: the suggestions drop from it as from the others
// (Suggestions, below), Escape empties it — a new tab's address is nothing —
// and Enter goes where the toolbar's would, in the tab in front.

const startSearch = $("start-search");

$("start-form").addEventListener("submit", (event) => {
  event.preventDefault();
  if (openedLumiPage(startSearch)) return;
  const url = addressFor(startSearch.value);
  const tab = front();
  if (!url || !tab) return;
  startSearch.blur();
  startSearch.value = "";
  go(tab, url);
});

startSearch.addEventListener("keydown", (event) => revertAddress(startSearch, event));

// ---- Suggestions ---------------------------------------------------------------

// While somebody types in an address field — the toolbar's, or Compact
// Mode's title — a list drops from it, as from Chrome's omnibox: first what
// Enter does with what was typed, then the pages of the history and the
// well-known sites that match (`ranked`), and the field completes the best
// of them inline, the part added selected, so typing on replaces it. Nothing
// typed leaves the Mac: the suggestions are the history's alone, never a
// search engine's.

/** The most pages listed under what was typed. */
const MOST_SUGGESTED = 5;

/** The list up, or null: the field, what was typed, the rows and the one
 *  chosen (0, what was typed, unless an arrow moved it). */
let suggesting = null;

/** What `field` holds now, as the list's first row: where Enter goes. */
function typedRow(value) {
  const target = addressFor(value);
  if (!target) return null;
  const search = target.startsWith(SEARCH);
  return { url: target, title: search ? value.trim() : pretty(target), detail: search ? "Google Search" : "", search, history: false };
}

/** The list for `field`, typed `typed` and showing `value` (with any inline
 *  completion). */
function suggestFor(field, typed, value) {
  const first = typedRow(value);
  if (!first) {
    closeSuggest();
    return;
  }
  const rows = [first];
  for (const { entry, at } of ranked(typed)) {
    if (rows.length > MOST_SUGGESTED) break;
    if (at.plain === pretty(first.url).toLowerCase()) continue;
    const kept = history.entries.includes(entry);
    rows.push({ url: entry.url, title: entry.title || at.plain, detail: at.plain, search: false, history: kept });
  }
  const opening = !suggesting;
  suggesting = { field, typed, value, rows, chosen: 0 };
  drawSuggest();
  // The site covered whole while the list is up (`showSite`).
  if (opening) place();
}

function closeSuggest() {
  if (!suggesting) return;
  suggesting = null;
  $("suggest").hidden = true;
  place();
}

function drawSuggest() {
  const list = $("suggest");
  if (!suggesting) {
    list.hidden = true;
    return;
  }
  list.replaceChildren(
    ...suggesting.rows.map((row, at) => {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "suggestion";
      button.setAttribute("role", "option");
      button.setAttribute("aria-selected", String(at === suggesting.chosen));
      button.dataset.at = String(at);
      const found = row.search ? "" : iconFor(row.url);
      let mark;
      if (found) {
        mark = document.createElement("img");
        mark.className = "favicon";
        mark.alt = "";
        mark.src = found;
      } else {
        mark = icon(row.search ? "search" : "globe");
      }
      const title = document.createElement("span");
      title.className = "s-title";
      title.textContent = row.title;
      const detail = document.createElement("span");
      detail.className = "s-detail";
      detail.textContent = row.detail && row.detail !== row.title ? row.detail : "";
      button.append(mark, title, detail);
      if (row.history) {
        const out = document.createElement("span");
        out.className = "s-forget";
        out.dataset.forget = row.url;
        out.dataset.tip = "Remove from History";
        out.append(icon("close"));
        button.append(out);
      }
      return button;
    }),
  );
  list.hidden = false;
  placeSuggest();
}

/** Under the field's own box, at least as wide as a page's address needs,
 *  inside the window. */
function placeSuggest() {
  if (!suggesting) return;
  const list = $("suggest");
  const box = suggesting.field.closest("form").getBoundingClientRect();
  const width = Math.min(Math.max(box.width, 300), innerWidth - 12);
  const left = Math.max(6, Math.min(box.left, innerWidth - width - 6));
  list.style.width = `${Math.round(width)}px`;
  list.style.transform = `translate(${Math.round(left)}px, ${Math.round(box.bottom + 6)}px)`;
}

/** Choose row `at`: the field shows where it goes. */
function choose(at) {
  if (!suggesting) return;
  suggesting.chosen = at;
  const { field, typed, value } = suggesting;
  field.value = at === 0 ? value : pretty(suggesting.rows[at].url);
  // Back on what was typed, its inline completion is selected again, as it
  // was: typing on still replaces it.
  const completed = at === 0 && value.length > typed.length && value.toLowerCase().startsWith(typed.toLowerCase());
  field.setSelectionRange(completed ? typed.length : field.value.length, field.value.length);
  drawSuggest();
  drawMarks();
}

/** Go where row `at` goes, by the field's own form — as Enter would. */
function goTo(at) {
  if (!suggesting) return;
  const { field, rows } = suggesting;
  if (at > 0) field.value = rows[at].url;
  field.closest("form").requestSubmit();
}

for (const field of [address, titleAddress, startSearch]) {
  // Every edit lists again; one that typed (not one that deleted, nor a
  // letter still being composed by an input method) completes inline too.
  field.addEventListener("input", (event) => {
    const typed = field.value;
    if (!typed.trim()) {
      closeSuggest();
      return;
    }
    const typing = !event.isComposing && typeof event.inputType === "string" && event.inputType.startsWith("insert");
    const completion = typing && field.selectionEnd === typed.length ? completionOf(typed) : null;
    if (completion) {
      field.value = completion;
      field.setSelectionRange(typed.length, completion.length);
    }
    suggestFor(field, typed, field.value);
  });

  field.addEventListener("compositionend", () => {
    if (field.value.trim()) suggestFor(field, field.value, field.value);
  });

  // Ahead of the field's own Escape, which brings the page's address back:
  // with a suggestion chosen by an arrow, Escape first goes back to what was
  // typed, the list still up — Chrome's order.
  field.addEventListener(
    "keydown",
    (event) => {
      if (!suggesting || suggesting.field !== field || event.isComposing || event.keyCode === 229) return;
      const count = suggesting.rows.length;
      if (event.key === "ArrowDown" || event.key === "ArrowUp") {
        event.preventDefault();
        event.stopImmediatePropagation();
        choose((suggesting.chosen + (event.key === "ArrowDown" ? 1 : count - 1)) % count);
      } else if (event.key === "Escape" && suggesting.chosen > 0) {
        event.preventDefault();
        event.stopImmediatePropagation();
        choose(0);
      } else if (event.key === "Enter" && suggesting.chosen > 0) {
        // The page's whole address, not the shorter one the field shows.
        field.value = suggesting.rows[suggesting.chosen].url;
      }
    },
    true,
  );

  field.addEventListener("blur", () => closeSuggest());
}

// A press on a row keeps the field's focus, and its release goes there; the
// × takes the page out of the history and lists again.
$("suggest").addEventListener("pointerdown", (event) => event.preventDefault());
$("suggest").addEventListener("click", (event) => {
  if (!suggesting) return;
  const out = event.target.closest("[data-forget]");
  if (out) {
    forget(out.dataset.forget);
    suggestFor(suggesting.field, suggesting.typed, suggesting.field.value);
    return;
  }
  const row = event.target.closest("[data-at]");
  if (row) goTo(Number(row.dataset.at));
});
addEventListener("resize", () => placeSuggest());

// ---- The site's mark --------------------------------------------------------

// The icon at an address field's start, as Chrome's omnibox draws it. A lock
// while the field holds the address of the page in front: every site here is
// on https — Lumi keeps it there — and WebKit refuses a certificate it cannot
// trust, so a page that loaded is one whose connection was checked. Pressed,
// it says so (#site-info). While somebody types, a magnifier for a search or
// a globe for an address, where the field's Enter would go; and an
// information mark for a page that did not load, whatever stopped it.

/** Each address field and its mark. */
const MARKED = [
  ["address", "site-mark"],
  ["title-address", "title-site-mark"],
];

/** What `field`'s mark shows now: "lock", "info", "search" or "globe". */
function markOf(field) {
  const tab = front();
  const value = field.value.trim();
  if (tab && tab.url && (value === tab.url || value === pretty(tab.url))) {
    if (tab.state === "failed") return "info";
    return tab.url.startsWith("https://") ? "lock" : "globe";
  }
  const url = addressFor(value);
  return !url || url.startsWith(SEARCH) ? "search" : "globe";
}

/** The page the site information is up for, `{tab, url}`, or null. */
let siteInfo = null;

/** Each field's mark drawn again for what the field holds now — and the site
 *  information put away once the page it told of is no longer in front. */
function drawMarks() {
  for (const [fieldId, markId] of MARKED) {
    const mark = $(markId);
    const kind = markOf($(fieldId));
    if (mark.dataset.kind === kind) continue;
    mark.dataset.kind = kind;
    mark.replaceChildren(icon(kind));
    // Only the lock is pressed; the others say what Enter would do.
    mark.disabled = kind !== "lock";
    if (kind === "lock") {
      mark.dataset.tip = "View site information";
      mark.setAttribute("aria-label", "View site information");
    } else {
      delete mark.dataset.tip;
      mark.setAttribute("aria-label", kind === "info" ? "The page did not load" : kind === "search" ? "Search" : "Address");
    }
  }
  const tab = front();
  if (siteInfo && !(tab && tab.id === siteInfo.tab && tab.url === siteInfo.url && tab.state !== "failed")) closeSiteInfo();
}

function openSiteInfo(mark) {
  const tab = front();
  if (!tab || !tab.url) return;
  closeMenu();
  closeSuggest();
  hideTip();
  siteInfo = { tab: tab.id, url: tab.url };
  const panel = $("site-info");
  $("site-info-host").textContent = host(tab.url);
  panel.hidden = false;
  const at = mark.getBoundingClientRect();
  const left = Math.max(6, Math.min(at.left - 4, innerWidth - panel.offsetWidth - 6));
  panel.style.transform = `translate(${Math.round(left)}px, ${Math.round(at.bottom + 8)}px)`;
  for (const each of document.querySelectorAll("[data-site-info]")) each.setAttribute("aria-expanded", String(each === mark));
  // The whole site covered, so a press beside it puts it away.
  place();
}

function closeSiteInfo() {
  if (!siteInfo) return;
  siteInfo = null;
  $("site-info").hidden = true;
  for (const each of document.querySelectorAll("[data-site-info]")) each.setAttribute("aria-expanded", "false");
  place();
}

for (const [fieldId, markId] of MARKED) {
  const mark = $(markId);
  mark.setAttribute("aria-haspopup", "dialog");
  mark.setAttribute("aria-expanded", "false");
  // A press on the mark leaves the keyboard in the field, so Compact Mode's
  // title stays the field it was made into.
  mark.addEventListener("mousedown", (event) => event.preventDefault());
  mark.addEventListener("click", () => (siteInfo ? closeSiteInfo() : openSiteInfo(mark)));
  // After the suggestions' own listener, which may complete what was typed.
  $(fieldId).addEventListener("input", () => drawMarks());
}

// A press anywhere but the panel and the marks puts it away, the site
// included, which is covered while it is up; so do Escape — ahead of the
// field's own, which would bring the address back — and the keyboard going
// to another application.
document.addEventListener(
  "pointerdown",
  (event) => {
    if (siteInfo && !event.target.closest("#site-info, [data-site-info]")) closeSiteInfo();
  },
  true,
);
document.addEventListener(
  "keydown",
  (event) => {
    if (!siteInfo || event.isComposing || event.key !== "Escape") return;
    event.preventDefault();
    event.stopImmediatePropagation();
    closeSiteInfo();
  },
  true,
);
addEventListener("blur", () => closeSiteInfo());
addEventListener("lumi:hidden", () => closeSiteInfo());

// ---- Presses ----------------------------------------------------------------

// A tab is chosen on the press, as Chrome's is, so nothing between the press
// and the release — focus leaving the address field or the site, a load
// redrawing the strip — can cost it a second press. Closing waits for the
// release, on the close button or with the middle button, and is matched
// by the tab's id rather than by the element: the strip may have been drawn
// again in between, and a release over the new button is the same tab.
let closing = null;

/** The tab whose speaker is held down, muted or heard again on its release
 *  — by id, as closing is. A press there never chooses the tab. */
let silencing = null;

$("tabbar").addEventListener("pointerdown", (event) => {
  const tab = event.target.closest(".tab");
  if (!tab) return;
  // History's tab: in front on a press, closed by its cross or the middle
  // button, and never dragged.
  if (tab.dataset.extra) {
    if (event.button === 0 && event.target.closest("[data-shut]")) closing = "extra";
    else if (event.button === 1) {
      event.preventDefault();
      closing = "extra";
    } else if (event.button === 0) {
      closing = null;
      openExtra();
    }
    return;
  }
  const speaker = event.target.closest("[data-sound]");
  if (event.button === 0 && speaker) {
    silencing = speaker.dataset.sound;
    closing = null;
    return;
  }
  const shut = event.target.closest("[data-shut]");
  if (event.button === 0 && shut) {
    closing = shut.dataset.shut;
  } else if (event.button === 1) {
    event.preventDefault();
    closing = tab.dataset.id;
  } else if (event.button === 0) {
    closing = null;
    select(tab.dataset.id);
  }
  if (event.button === 0) held = { id: tab.dataset.id, pointer: event.pointerId, from: event.clientX, moving: false };
});

$("tabbar").addEventListener("pointerup", (event) => {
  const speaker = event.target.closest("[data-sound]");
  if (silencing && speaker && speaker.dataset.sound === silencing) toggleTabMute(silencing);
  silencing = null;
  const was = closing;
  closing = null;
  const tab = event.target.closest(".tab");
  if (!was || !tab) return;
  const shut = event.target.closest("[data-shut]");
  if (was === "extra") {
    if (tab.dataset.extra && (event.button === 0 ? shut : true)) closeExtra();
    return;
  }
  if (event.button === 0 ? shut && shut.dataset.shut === was : tab.dataset.id === was) closeTab(was);
});

// ---- Moving a tab ---------------------------------------------------------

// A tab held and moved along the strip goes with the pointer, as Chrome's
// does, and takes a neighbour's place once its middle passes the
// neighbour's; the neighbour slides into the place it left. The buttons are
// moved, not drawn again — the one being dragged has to stay the one under
// the pointer — and the tabs' order follows the buttons'. Kept when the
// tab is let go. The strip holds the pointer from the moment the tab
// moves, so a release anywhere, over the site included, ends it.

/** How far the pointer moves with a tab held before the tab moves with it:
 *  a press that wobbles is a press. */
const DRAG_AFTER = 4;

/** The tab held: its id, the pointer holding it, where the press was, and
 *  — once it moves — its button, how far into it the pointer took hold,
 *  and how far it is shifted from its place. */
let held = null;

$("tabbar").addEventListener("pointermove", (event) => {
  if (!held || event.pointerId !== held.pointer) return;
  if (!held.moving) {
    if (Math.abs(event.clientX - held.from) < DRAG_AFTER) return;
    const button = $("tabbar").querySelector(`.tab[data-id="${CSS.escape(held.id)}"]`);
    if (!button) {
      held = null;
      return;
    }
    // A press on the close button that moves is a drag, not a close.
    closing = null;
    held.moving = true;
    held.button = button;
    held.grip = held.from - button.offsetLeft;
    button.classList.add("moving");
    $("tabbar").setPointerCapture(event.pointerId);
    hideTip();
  }
  follow(event.clientX);
});

/** The held tab under the pointer at `x`, kept inside the strip, past any
 *  neighbour whose middle it has crossed. Every place is read from layout
 *  (`offsetLeft`), never from what is drawn: a neighbour still sliding into
 *  the place it was given is drawn where it was, and read that way it was
 *  passed again on the way back, and two tabs changed places that the
 *  pointer never took the held one past. */
function follow(x) {
  const bar = $("tabbar");
  const button = held.button;
  const width = button.offsetWidth;
  const want = Math.min(Math.max(x - held.grip, bar.offsetLeft), bar.offsetLeft + bar.offsetWidth - width);
  const middle = want + width / 2;
  const middleOf = (other) => other.offsetLeft + other.offsetWidth / 2;
  // At most one step past each tab: the strip holds four.
  for (let step = 0; step < MOST_TABS; step += 1) {
    const next = button.nextElementSibling;
    // History's tab stays first: a site's tab never goes before it.
    const before = button.previousElementSibling && !button.previousElementSibling.dataset.extra ? button.previousElementSibling : null;
    let passed = null;
    // Reaching a middle is passing it: held against the strip's end, the
    // tab stands exactly over the last one there and must take its place.
    if (next && middle >= middleOf(next)) passed = next;
    else if (before && middle <= middleOf(before)) passed = before;
    if (!passed) break;
    const was = passed.offsetLeft;
    if (passed === next) bar.insertBefore(next, button);
    else bar.insertBefore(button, before);
    passed.animate([{ transform: `translateX(${was - passed.offsetLeft}px)` }, { transform: "none" }], {
      duration: 150,
      easing: "ease-out",
    });
  }
  held.shift = want - button.offsetLeft;
  button.style.transform = `translateX(${held.shift}px)`;
}

function letGo(event) {
  if (!held || event.pointerId !== held.pointer) return;
  const was = held;
  held = null;
  if (!was.moving) return;
  const order = [...$("tabbar").children].map((button) => button.dataset.id);
  tabs = order.map((id) => tabs.find((tab) => tab.id === id)).filter(Boolean);
  keep();
  // Into its place, then drawn again with whatever changed meanwhile.
  const button = was.button;
  button.style.transform = "";
  const settled = button.animate([{ transform: `translateX(${was.shift || 0}px)` }, { transform: "none" }], {
    duration: 150,
    easing: "ease-out",
  });
  settled.onfinish = () => {
    button.classList.remove("moving");
    render();
  };
}

$("tabbar").addEventListener("pointerup", letGo);
$("tabbar").addEventListener("pointercancel", letGo);

// The keyboard's press (Space or Return on a focused tab) is a click with no
// pointer behind it; a pointer's was taken on its press above.
$("tabbar").addEventListener("click", (event) => {
  if (event.detail !== 0) return;
  const tab = event.target.closest(".tab");
  if (tab && tab.dataset.extra) openExtra();
  else if (tab) select(tab.dataset.id);
});

$("new-tab").addEventListener("click", () => openTab());
// Back, Forward and Reload: the toolbar's, and Compact Mode's bar's — whose
// Back goes forward when ⇧ is held at the press, whatever it was showing.
for (const button of document.querySelectorAll("[data-go]")) {
  button.addEventListener("click", (event) => {
    const go = button === $("bar-back") ? (event.shiftKey ? "forward" : "back") : button.dataset.go;
    if (go === "back") walk(-1);
    else if (go === "forward") walk(1);
    else reload();
  });
}

/** Compact Mode's bar has no room for Forward, so its Back is Forward while
 *  ⇧ is held: its arrow, its words and whether it can be pressed. Only this
 *  button is drawn again when ⇧ changes, not the whole page. */
function drawBarBack() {
  const tab = front();
  const button = $("bar-back");
  const go = shiftHeld ? "forward" : "back";
  if (button.dataset.go !== go || !button.firstChild) {
    button.dataset.go = go;
    button.replaceChildren(icon(go));
    button.dataset.tip = go === "forward" ? "Forward (⌘])" : "Back (⌘[)";
    button.setAttribute("aria-label", go === "forward" ? "Forward" : "Back");
    if (tipFor === button && tip.classList.contains("on")) showTip(button);
  }
  button.disabled = !tab || (go === "forward" ? tab.forward : tab.back).length === 0;
}

// Where ⇧ is seen: its own key while this page holds the keyboard; the
// pointer moving or pressing on the bar, which says it either way; and,
// while a site or another application holds the keyboard and the pointer
// rests here, `lumi:modifiers` (Lumi 1.65.0), told when ⇧ is pressed or let
// go on its own — so Back turns as ⇧ goes down, with no nudge. An older Lumi
// tells nothing, and Back turns once the pointer moves.
function seeShift(held) {
  if (held === shiftHeld) return;
  shiftHeld = held;
  drawBarBack();
}

for (const kind of ["pointermove", "pointerdown"]) {
  $("title-bar").addEventListener(kind, (event) => seeShift(event.shiftKey));
}
$("title-bar").addEventListener("pointerleave", () => seeShift(false));
addEventListener("lumi:modifiers", (event) => {
  if (event.detail && event.detail.v === 1) seeShift(event.detail.shiftKey === true);
});
for (const kind of ["keydown", "keyup"]) {
  document.addEventListener(kind, (event) => {
    if (event.key === "Shift") seeShift(event.shiftKey);
  });
}
addEventListener("blur", () => seeShift(false));
$("mobile").addEventListener("click", () => toggleMobile());
$("retry").addEventListener("click", () => {
  const tab = front();
  if (tab && tab.url) go(tab, tab.url, true);
});
$("browser-open").addEventListener("click", () => {
  const tab = front();
  if (tab && tab.url) call({ kind: "browser", url: tab.url }).catch(() => {});
});
// ---- Closing ----------------------------------------------------------------

// × closes the window as a Mac app's does, its tabs with it: the next opening
// is one new tab. Putting it away with the tabs kept is the shortcut's, and
// out of the way with them playing on is Minimize's. The component clears
// the tabs it keeps and tells this page `close-tabs`, as Quit in the menu
// bar does, so the sites go too — after the window, never in front of
// somebody. Asked first while a tab holds a page, since nothing brings
// those back, unless Don't ask again was ticked; Settings' Ask Before
// Closing is the way back from that.

/** Whether × asks first: kept by the component, read as the page loads. */
let asksBeforeClosing = true;

/** The close sheet is up. */
let closeAsked = false;

function closeWindow() {
  if (!asksBeforeClosing || !tabs.some((tab) => tab.url)) {
    closeNow();
    return;
  }
  closeMenu();
  closeSuggest();
  closeSiteInfo();
  hideTip();
  closeAsked = true;
  const count = tabs.length;
  $("close-text").textContent = count > 1 ? `Your ${count} tabs will close.` : "Your tab will close.";
  $("close-again").checked = false;
  $("close-sheet").hidden = false;
  // The rest of the window out of reach, for VoiceOver and the keyboard as
  // for the pointer, which the scrim stops; and the site covered whole.
  $("browser").inert = true;
  place();
  $("close-confirm").focus();
}

/** The sheet put away, the window left as it was. */
function closeCloseSheet() {
  if (!closeAsked) return;
  closeAsked = false;
  $("close-sheet").hidden = true;
  $("browser").inert = false;
  place();
}

function closeNow() {
  closeCloseSheet();
  call({ kind: "close" }).catch(() => {});
}

function setAsksBeforeClosing(asks) {
  asksBeforeClosing = asks;
  drawSettings();
  call({ kind: "keep-asks-before-closing", asks }).catch(() => {});
}

for (const id of ["close", "bar-close"]) {
  $(id).addEventListener("click", () => closeWindow());
}
$("close-cancel").addEventListener("click", () => closeCloseSheet());
$("close-confirm").addEventListener("click", () => {
  if ($("close-again").checked) setAsksBeforeClosing(false);
  closeNow();
});
$("ask-close-switch").addEventListener("click", () => setAsksBeforeClosing(!asksBeforeClosing));

// An alert's keys, ahead of every other: Escape is Cancel, Return is Close
// wherever the keyboard is in the card, and no shortcut reaches the window
// under it — ⌘W would close a tab the sheet is asking about.
document.addEventListener(
  "keydown",
  (event) => {
    if (!closeAsked || event.isComposing) return;
    if (event.key === "Escape") {
      event.preventDefault();
      closeCloseSheet();
    } else if (event.key === "Enter") {
      event.preventDefault();
      $("close-confirm").click();
    } else if (event.metaKey || event.ctrlKey) {
      event.preventDefault();
    } else {
      return;
    }
    event.stopImmediatePropagation();
  },
  true,
);
addEventListener("lumi:hidden", () => closeCloseSheet());

// ---- Minimized --------------------------------------------------------------

// Minimize takes the browser out of the way to a pill in the screen's corner
// (bubble.html) — not put away: the component takes the window off screen
// with `hide-window`, which leaves this page running and every site playing,
// where Close holds them paused. The pill shows the site in front (or the
// one making sound, as Settings says), whether it plays, and how many tabs
// there are; this
// page tells the component whenever that changes, since it is the one that
// hears the sites — minimized or not. The pill can be up beside the browser
// (Lumi's About page opens either), and one told only while this page had
// minimized itself showed the site it was minimized on for as long as it
// stood there. The component keeps what it is told, which the pill reads as
// it opens, and hands it on to a pill that is up.

/** The tab the pill stands for while sound plays, with Prioritize Now
 *  Playing Tab on: the one in front if it is sounding, since that is the one
 *  being looked at; otherwise the one that began to sound last, as macOS's
 *  Now Playing does — music left playing in one tab while another is read. */
function soundingTab() {
  const looked = front();
  if (looked && looked.playing) return looked;
  return tabs.filter((each) => each.playing).reduce((latest, each) => (!latest || each.soundingSince > latest.soundingSince ? each : latest), null);
}

/** What the pill shows: with Prioritize Now Playing Tab on, where every Mac
 *  starts, the tab making sound (`soundingTab`), else the one in front; with
 *  it off, the tab in front always — the one being looked at when the
 *  browser was minimized, and the one it comes back on — since a pill naming
 *  music in a tab nobody had in front read to some as the wrong page. A tab
 *  playing behind it plays on either way, its speaker on its tab and its
 *  row. */
function bubbleState() {
  const shown = (look.playingFirst && soundingTab()) || front();
  const url = shown && shown.url ? shown.url : "";
  return {
    v: 1,
    title: shown ? shown.title || (url ? pretty(url) : "") : "",
    icon: url ? iconFor(url) : "",
    playing: Boolean(shown && shown.playing),
    muted: Boolean(shown && shown.playing && (shown.muted || muted)),
    // `tabMark`'s rule, so the pill shows a ring where the tab does.
    loading: Boolean(url) && shown.state === "loading",
    tabs: tabs.length,
    // What that tab plays, for the pill's band and its two lines, and the
    // tab it is in, which a seek on the pill names.
    tab: shown ? shown.id : "",
    media: shown && shown.media ? { ...shown.media } : null,
  };
}

function tellBubble() {
  if (bubbleSending) return;
  const bubble = bubbleState();
  const told = JSON.stringify(bubble);
  if (told === bubbleTold) return;
  bubbleTold = told;
  bubbleSending = true;
  call({ kind: "bubble-update", bubble }).then(
    () => {
      bubbleSending = false;
      tellBubble();
    },
    () => {
      // Told again at the next redraw, not at once: a component refusing
      // every telling would otherwise be asked without end.
      bubbleSending = false;
      bubbleTold = "";
    },
  );
}

function minimize() {
  hideTip();
  // The button stays under a pointer that is no longer over the window:
  // unlit until one moves over the page again (browser.css).
  document.documentElement.classList.add("hover-stale");
  // What the pill shows goes with the ask, kept before anything is hidden.
  const bubble = bubbleState();
  call({ kind: "minimize", bubble })
    .then(() => {
      bubbleTold = JSON.stringify(bubble);
    })
    .catch(() => {});
}

for (const button of document.querySelectorAll("[data-minimize]")) {
  button.addEventListener("click", minimize);
}

addEventListener("pointermove", () => document.documentElement.classList.remove("hover-stale"), { passive: true });

// The bar and the strip move the window, wherever no control is.
document.addEventListener("pointerdown", (event) => {
  if (event.button !== 0) return;
  if (event.target.closest("button, input, form, .edge")) return;
  if (!event.target.closest("[data-drag]")) return;
  event.preventDefault();
  fetch("/__lumi__/drag", { method: "POST" }).catch(() => {});
});

for (const grip of document.querySelectorAll(".edge")) {
  grip.addEventListener("pointerdown", (event) => {
    if (event.button !== 0) return;
    event.preventDefault();
    fetch("/__lumi__/resize", { method: "POST", body: JSON.stringify({ edge: grip.dataset.edge }) }).catch(() => {});
  });
}

// The keys a browser has — while this page holds the keyboard. Once a site
// has it, its keys are the site's, and these never reach here.
document.addEventListener("keydown", (event) => {
  if (event.isComposing) return;
  if (event.key === "Escape" && menuOpen) {
    event.preventDefault();
    closeMenu();
    return;
  }
  // Escape in the history's search empties it first, as a search field's does.
  if (event.key === "Escape" && extraFront && !(event.target === $("history-search") && $("history-search").value)) {
    event.preventDefault();
    closeExtra();
    return;
  }
  const command = event.metaKey && !event.ctrlKey && !event.altKey;
  if (command && !event.shiftKey) {
    const handled = {
      l: focusAddress,
      t: () => openTab(),
      w: closeWithKey,
      // A Mac window's Minimize.
      m: minimize,
      r: reload,
      "[": () => walk(-1),
      "]": () => walk(1),
      // Chrome's History, on and off.
      y: () => (extraFront && extraKind === "history" ? closeHistory() : openHistory()),
      // A Mac app's Settings…, on and off as History is.
      ",": () => (extraFront && extraKind === "settings" ? closeExtra() : openSettings()),
    }[event.key.toLowerCase()];
    if (handled) {
      event.preventDefault();
      handled();
      return;
    }
    const number = Number(event.key);
    if (number >= 1 && number <= tabs.length) {
      event.preventDefault();
      select(tabs[number - 1].id);
    }
    return;
  }
  if (event.ctrlKey && event.key === "Tab" && tabs.length > 1) {
    event.preventDefault();
    const at = tabs.findIndex((tab) => tab.id === activeId);
    const next = (at + (event.shiftKey ? -1 : 1) + tabs.length) % tabs.length;
    select(tabs[next].id);
  }
});

// ---- Tooltips ---------------------------------------------------------------

// Drawn by this page (#tip), not by Lumi: a small label under whatever the
// pointer rests on, as a Mac app's tooltip comes up — after a moment's rest,
// and at once while moving along a row of them (the tabs, the toolbar) with
// one just shown. A `title` shows nothing in Lumi. It is held inside the
// window, which is all the page can draw in, and never takes the pointer, so
// the site under it still has every press.

/** How long the pointer rests before a tooltip comes up. */
const TIP_WAIT = 600;
/** How soon one comes up while another was up a moment ago. */
const TIP_AGAIN = 60;
/** How long after one goes the next is still quick. */
const TIP_WARM = 400;
/** The gap between a tooltip and what it names, and the window's edges. */
const TIP_GAP = 6;

const tip = $("tip");
let tipFor = null;
let tipTimer = 0;
let tipGoneAt = -Infinity;

function hideTip() {
  clearTimeout(tipTimer);
  tipFor = null;
  if (tip.classList.contains("on")) tipGoneAt = performance.now();
  tip.classList.remove("on");
}

function showTip(target) {
  // Redrawn under the pointer since (a tab's title arriving): nothing to
  // stand under any more.
  if (!target.isConnected || !target.dataset.tip) return;
  tip.textContent = target.dataset.tip;
  const box = target.getBoundingClientRect();
  const own = tip.getBoundingClientRect();
  const x = Math.max(TIP_GAP, Math.min(box.left + box.width / 2 - own.width / 2, innerWidth - own.width - TIP_GAP));
  // Under it, or over it where the window's foot leaves no room.
  let y = box.bottom + TIP_GAP;
  if (y + own.height > innerHeight - TIP_GAP) y = box.top - own.height - TIP_GAP;
  tip.style.transform = `translate(${Math.round(x)}px, ${Math.round(y)}px)`;
  tip.classList.add("on");
}

document.addEventListener("pointerover", (event) => {
  const target = event.target.closest("[data-tip]");
  if (target === tipFor) return;
  const warm = tip.classList.contains("on") || performance.now() - tipGoneAt < TIP_WARM;
  hideTip();
  if (!target) return;
  tipFor = target;
  tipTimer = setTimeout(() => showTip(target), warm ? TIP_AGAIN : TIP_WAIT);
});
// A press, the pointer leaving the page — onto the site or out of the
// window — or the window going: no label stays behind.
document.addEventListener("pointerdown", hideTip, true);
document.addEventListener("pointerout", (event) => {
  if (!event.relatedTarget) hideTip();
});
document.documentElement.addEventListener("pointerleave", hideTip);
addEventListener("blur", hideTip);
addEventListener("lumi:hidden", hideTip);

// ---- Kept between launches --------------------------------------------------

/** The tabs handed to the extension to keep, a moment after the last change. */
let keepTimer = 0;
function keep() {
  clearTimeout(keepTimer);
  keepTimer = setTimeout(() => {
    const kept = tabs.map((tab) => ({ url: tab.url, title: tab.title, mobile: tab.mobile, muted: tab.muted, playing: tab.playing }));
    const active = Math.max(0, tabs.findIndex((tab) => tab.id === activeId));
    call({ kind: "keep-tabs", tabs: { v: 1, tabs: kept, active, muted, compact } }).catch(() => {});
  }, 400);
}

/** Each tab's icon handed to the extension, by address, for the menu its
 *  item opens (ui/menu.html): that page shows no site and so finds no icon
 *  of its own. Only the icons known — the extension keeps the last one it
 *  had for a tab whose icon this page has not found again yet, after a
 *  restart. */
function tellMenuIcons() {
  const known = {};
  for (const each of tabs) {
    const found = each.url ? iconFor(each.url) : "";
    if (found) known[each.url] = found;
  }
  const told = JSON.stringify(known);
  if (told === menuIconsTold) return;
  menuIconsTold = told;
  call({ kind: "keep-icons", icons: known }).catch(() => {
    menuIconsTold = "";
  });
}

async function start() {
  for (const [id, name] of [
    ["new-tab", "plus"],
    ["close", "close"],
    ["back", "back"],
    ["forward", "forward"],
    ["reload", "reload"],
    ["browser-open", "external"],
  ]) {
    $(id).append(icon(name));
  }
  for (const button of document.querySelectorAll("#bar-nav [data-go]")) button.append(icon(button.dataset.go));
  $("view-history").querySelector(".row-ico").append(icon("clock"));
  $("view-settings").querySelector(".row-ico").append(icon("settings"));
  $("menu-close").querySelector(".row-ico").append(icon("close"));
  $("start-form").querySelector(".start-ico").append(icon("search"));
  $("site-info").querySelector(".si-ico").append(icon("lock"));
  $("notice-close").append(icon("close"));
  $("bar-close").append(icon("close"));
  for (const button of document.querySelectorAll("[data-minimize]")) button.append(icon("minus"));
  // The shortcuts asked for beside the tabs, and drawn before the start page
  // first shows, so it never shows the carried ones a moment first.
  const keptTiles = call({ kind: "tiles" }).catch(() => null);
  // And each site's layout, before the tabs ask for their sites.
  const keptLayouts = call({ kind: "layouts" }).catch(() => null);
  let kept = null;
  try {
    kept = await call({ kind: "tabs" });
  } catch {
    // A first opening, or storage that could not be read: one blank tab.
  }
  restoreTiles(await keptTiles);
  restoreLayouts(await keptLayouts);
  drawQuick();
  const restored = kept && kept.v === 1 && Array.isArray(kept.tabs) ? kept.tabs.slice(0, MOST_TABS) : [];
  tabs = restored.map((each) => {
    const url = typeof each.url === "string" && each.url.startsWith("https://") ? each.url : null;
    return newTab({
      url,
      title: typeof each.title === "string" ? each.title : "",
      // Its site's layout as kept now, which a switch made in another tab
      // since may have changed.
      mobile: url ? phoneFor(url) : each.mobile !== false,
      layoutSite: url ? siteOf(url) : "",
      muted: each.muted === true,
      state: "loading",
    });
  });
  if (tabs.length === 0) tabs.push(newTab());
  muted = Boolean(kept && kept.muted === true);
  compact = Boolean(kept && kept.compact === true);
  const at = Number.isInteger(kept && kept.active) ? kept.active : 0;
  activeId = tabs[Math.min(Math.max(at, 0), tabs.length - 1)].id;
  render();
  place();
  // The pill's look, as kept: a spinning record, untinted, otherwise.
  try {
    look = lookOf(await call({ kind: "look" }));
    // Told with the default look while it was asked for.
    tellBubble();
  } catch {
    // None kept yet: the default.
  }
  try {
    asksBeforeClosing = (await call({ kind: "asks-before-closing" })) !== false;
  } catch {
    // A component from before the question: ask.
  }
  try {
    const kept = await call({ kind: "appearance" });
    if (APPEARANCES.includes(kept)) appearance = kept;
  } catch {
    // A component from before the question: macOS's.
  }
  drawSettings();
  // The history, read as any file is: only well-formed pages of it.
  try {
    const kept = await call({ kind: "history" });
    if (kept && kept.v === 1 && Array.isArray(kept.entries)) {
      const pages = kept.entries.filter(
        (each) =>
          each &&
          typeof each.url === "string" &&
          each.url.startsWith("https://") &&
          each.url.length <= LONGEST_REMEMBERED &&
          Number.isFinite(each.visits) &&
          Number.isFinite(each.last),
      );
      history = {
        v: 1,
        entries: pages
          .slice(0, MOST_HISTORY)
          .map((each) => ({ url: each.url, title: typeof each.title === "string" ? each.title : "", visits: each.visits, last: each.last })),
      };
    }
  } catch {
    // None kept yet, or unreadable: the history starts empty.
  }
}

start();

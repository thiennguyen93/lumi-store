// The tip over the pill: as tall as its words, asked of Lumi as it lays out
// (`POST /__lumi__/size`, the panel's size — Lumi adds the arrow's band and
// places it again beside the pill), and put away by Got It. Every other way
// it goes — a press on the pill, the browser back — is the component's.
"use strict";

const tip = document.getElementById("tip");

/** The panel's width, the manifest's. */
const WIDTH = 252;

function fit() {
  const height = Math.ceil(tip.getBoundingClientRect().height);
  if (height > 0) {
    fetch("/__lumi__/size", { method: "POST", body: JSON.stringify({ width: WIDTH, height }) }).catch(() => {});
  }
}

// An accelerator as Lumi writes one (`Ctrl+Alt+Super+KeyB`), in macOS's
// glyphs and order — welcome.js's `glyphs`.
function glyphs(accelerator) {
  const parts = accelerator.split("+");
  const key = parts.pop() || "";
  const glyph = { Ctrl: "⌃", Control: "⌃", Alt: "⌥", Option: "⌥", Shift: "⇧", Super: "⌘", Cmd: "⌘", Command: "⌘" };
  const mods = new Set(parts.map((part) => glyph[part] || part));
  const name = /^Key([A-Z])$/.exec(key)?.[1] ?? /^Digit([0-9])$/.exec(key)?.[1] ?? key;
  return [...["⌃", "⌥", "⇧", "⌘"].filter((mod) => mods.has(mod)), name].join("");
}

// Minimize's key, the one that switches between the pill and the browser,
// as Lumi holds it now — the person may have recorded another, or Lumi may
// have left it unset at install. No key, or Lumi's Shortcuts switch off, and
// the line stays out.
async function drawKey() {
  try {
    const answer = await fetch("/__lumi__/shortcuts");
    if (!answer.ok) return;
    const all = await answer.json();
    const key = all.on !== false && (all.ess || []).find((one) => one.command === "minimize")?.key;
    if (!key) return;
    document.getElementById("minimize-key").textContent = glyphs(key);
    document.getElementById("switches").hidden = false;
  } catch {
    // Lumi did not answer: the tip says what the pill is without the key.
  }
}

document.getElementById("got-it").addEventListener("click", () => {
  fetch("/__lumi__/call", { method: "POST", body: JSON.stringify({ kind: "got-it" }) }).catch(() => {});
});

new ResizeObserver(fit).observe(tip);
drawKey();

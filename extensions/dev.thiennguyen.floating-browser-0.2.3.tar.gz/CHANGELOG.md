# Changelog

## 0.2.3

- Prioritize Now Playing Tab, in Settings: on, as before, the minimized pill shows the tab playing audio or video; off, it always shows the tab you were looking at, while the other plays on.

## 0.2.2

- Floating Browser's page in the Extension Store says what it does: what you get, how your browsing stays private, and how to start.

## 0.2.1

- A short demo video on Floating Browser's page in the Extension Store and on lumikeys.app — the browser over your work, Compact Mode, the pill playing on in the corner — to watch before you install.

## 0.2.0

- ⌘W on the last tab leaves a new tab, so the browser stays open; ⌘W again on that new tab closes the browser, as × does, without asking.
- What plays on the pill: the track's title over its artist, a band along the pill's foot that fills as it plays — press or drag it to go to another place — and on a hover the time played and a button to pause it or play it on. Paused, a play triangle stands where the bars dance (Lumi 1.67.0).
- Artwork in the pill: where a site gives what it plays a cover, the minimized pill shows it in place of the site's icon, the site's icon a small badge on its corner (Lumi 1.67.0).
- Settings (⌘,), in the icon's menu, opens as a tab of its own, as History does — one such tab at a time. It sets the cover's shape on the pill — Spinning Record, which turns while the track plays, Circle or Square — and Tint with Artwork Colour, which washes the pill and its band in the cover's colour, with a preview of the pill as set. The pill follows a change at once, and the choice is kept on this Mac.
- Appearance, in Settings: Light, Dark or System, as in Lumi's own Settings. The browser, its pill, its menus and the tip change at once and stay that way after Lumi restarts; the Welcome tour follows macOS.
- History and Settings stand at an address of their own, as Chrome's pages do: the address bar shows `lumi://history` or `lumi://settings` while one is in front, and typing either in any tab opens it.
- In Compact Mode, History and Settings have a Done button, since no tab is drawn to close them.
- The menu bar icon's last row says Quit, which is what it does: every tab closed and the icon taken away until the shortcut brings it back.
- × closes the browser and its tabs, as closing a window does, and it opens on a new tab next time. It asks first while a tab holds a page; tick Don't ask again to stop it, and Ask Before Closing in Settings to have it ask again. The shortcut still puts it away with your tabs kept.
- YouTube opens on its desktop layout, whose player shows the pointer and its controls as you move the mouse; its phone layout hid both over a playing video until you clicked.
- A site you switch between its phone and desktop layouts stays as you switched it: it opens that way every time, in any tab, after Lumi restarts too.
- Close in the pill's menu is the browser's ×: while a tab holds a page the browser comes back from the pill and asks first, as the × does.
- The shortcuts swap places: ⌃⌥⌘H opens Floating Browser and puts it away, and ⌃⌥⌘B minimizes it to its pill and brings it back. The tip over the pill names the key Minimize has, and leaves it out when it has none.

## 0.1.0

- A small browser that floats over every app, at the top-right corner of the screen, opened and put away by ⌃⌥⌘B — minimized to its pill too, the pill with it — and opened again the way you put it away, as the browser or as its pill.
- It goes with you to every desktop, and stays over apps in full screen (Lumi 1.65.0).
- Up to four tabs along the top, the one in front holding the address bar, as in Chrome. Drag a tab along the strip to put it somewhere else.
- An address bar that also searches, with Back, Forward and Reload. A lock at its start, as in Chrome, says the page's connection is secure; press it to read so.
- The address bar suggests as you type, from your history and well-known sites, and completes the address in place, as in Chrome.
- Your browsing history, kept on this Mac: History (⌘Y), in the icon's menu, lists the pages you visited by day, to search, open again or remove one by one, or clear.
- ⌘-click or middle-click a link to open it in a new tab behind this one — with ⇧, in front — and a link that opens a new window opens in a new tab. With four tabs open it offers this tab or your browser instead (Lumi 1.65.0).
- A new tab opens on a search box under Lumi's mark, as in Chrome, with the address bar's suggestions and shortcuts to Google, YouTube, Facebook, Outlook, Wikipedia and GitHub; you type straight into it.
- The start page's shortcuts are yours, as in Chrome: drag one to move it, use its ⋮ (or right-click it) to edit or remove it, Add Shortcut for up to ten, and Restore Default Shortcuts for the first six. They stay after Lumi restarts.
- Phone or desktop layouts, per tab: phone by default, since the window is narrow. Switch with the toolbar's button or Desktop Site in the icon's menu.
- Open in your browser, for anything more.
- An icon of its own in the menu bar: your tabs, Compact Mode, Mute All, Close All Tabs, and Close, which puts it away until you call it again.
- Its menu shows each tab with its site's icon and a speaker while it makes sound, and works as any Mac menu, keys included. Right-click the icon for the Mac's own menu.
- The icon at the left of the tab strip lists your tabs, with Compact Mode, Desktop Site and History.
- Compact Mode, from that icon or the menu bar: one slim bar instead of the tabs and the toolbar, with the page's title and Close. Click the title to type an address; point at the bar for Back and Reload, ⇧ making Back go forward.
- Each tab shows its site's own icon, as in Chrome, fetched from the site itself; those of Google's and Microsoft's apps, YouTube, Facebook, Wikipedia, GitHub and GitLab come with the browser, so they show at once, signed in or not.
- A speaker on a tab making sound, as in Chrome: press it to mute that tab. The menu bar menu marks it too (Lumi 1.65.0).
- Drag it by its tab strip or toolbar, resize it by its edges; it opens where you left it. Pages run to its edges, as in Chrome.
- Minimize (− beside Close, or ⌘M) moves it to a small pill in the corner of the screen, with the page's title, how many tabs are open and a ring while a page loads; whatever plays in it plays on, bars dancing on the pill to say so (a muted speaker when it is silenced). Click the pill to bring the browser back, drag it to another corner, or click the icon at its left for your tabs or Close. The first time after the Welcome tour, a tip over the pill points at it.
- Its tabs stay as they were while it is put away, and show at once when it comes back; anything playing in them pauses until then (Lumi 1.65.0).
- Your tabs are still there after Lumi restarts. Sites remember you between openings, kept apart from your other browsers.
- ⌃⌥⌘H minimizes it from any app, and brings it back from the pill; with the browser away, it opens it.
- A Welcome tour when it is installed or updated, a step for each thing it does, where its shortcut can be recorded again. Its About page in Lumi opens it again.

import{C as e,S as t,T as n,d as r,h as i,n as a,p as o,r as s,t as c,u as l,y as u}from"./jsx-runtime-Z8r-og1n.js";import{n as d}from"./Tooltip-DaSXxCyy.js";import{t as f}from"./audio-lines-D6zgGk4y.js";import{t as p}from"./captions-UQXDLEcM.js";import{T as m}from"./modelMenu-CZWn3Use.js";import{f as h,n as g,r as _,u as v,w as y}from"./main-BhfUp0cp.js";import{a as ee}from"./Settings-aOMi6sMz.js";import{a as b,i as x,r as te}from"./floating-CzNnrcX9.js";import{t as S}from"./settings-DfLdXKpZ.js";import{t as C}from"./icon-DgvpdGw3.js";var w={name:`arrow-up-right`,size:24,node:[[`path`,{d:`M7 7h10v10`,key:`1tivn9`}],[`path`,{d:`M7 17 17 7`,key:`1vkiza`}]]};w.node;var T=t(w),E={name:`hard-drive`,size:24,node:[[`path`,{d:`M10 16h.01`,key:`1bzywj`}],[`path`,{d:`M2.212 11.577a2 2 0 0 0-.212.896V18a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-5.527a2 2 0 0 0-.212-.896L18.55 5.11A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z`,key:`18tbho`}],[`path`,{d:`M21.946 12.013H2.054`,key:`zqlbp7`}],[`path`,{d:`M6 16h.01`,key:`1pmjb7`}]]};E.node;var D=t(E),O={name:`users`,size:24,node:[[`path`,{d:`M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2`,key:`1yyitq`}],[`path`,{d:`M16 3.128a4 4 0 0 1 0 7.744`,key:`16gr8j`}],[`path`,{d:`M22 21v-2a4 4 0 0 0-3-3.87`,key:`kshegd`}],[`circle`,{cx:`9`,cy:`7`,r:`4`,key:`nufk8`}]]};O.node;var k=t(O),A=n(),j=e(),M=`# Meeting Notes — live captions for meetings, with speaker identification,
# translation on request, and every meeting kept as a transcript.
#
# Lumi hears the call and the microphone, tells the voices apart and
# transcribes them; everything about the captions, the meetings and their
# window is this extension's. The design is the 0.1 plan; the windows and
# menus follow the approved mock.

[extension]
id = "dev.thiennguyen.meeting"
name = "Meeting Notes"
version = "0.12.0"
description = "Live captions for your meetings, with speaker identification and translation on request."
author = "Thien Nguyen"
summary = "Live captions for your meetings, in the language they are spoken, with speaker identification: voices you saved a profile for by name, everyone else as Speaker 1, 2, 3. Translate any caption with a click, or turn on Live Translation. Every meeting is saved on this Mac as a transcript to read, copy or export. Transcription, speaker identification and translation run on this Mac unless you choose an online model, and Lumi asks before anything leaves it."
homepage = "https://lumikeys.app/extensions/dev.thiennguyen.meeting/"
# The store page's pictures, 1280 × 800, published beside the package —
# Lumi's installer ignores the key. Taken from the dev mock's store pages
# (\`?store=call\` and \`?store=window\`, web/src/dev/store.tsx) with
# lumi-store's preview server, from the spec and scenes beside them
# (shots/promo.json, shots/scenes/), which stay here with the source.
screenshots = ["shots/1-captions.png", "shots/2-translate.png", "shots/3-transcript.png", "shots/4-private.png"]
# 1.64.0: \`transcribe\` with a call's two streams, speaker identification
# and voice profiles (\`voices\`), and \`audio-levels\`. 1.65.0: the menu bar
# item's animated icon while transcribing (\`menu-bar-item.set-animated\`),
# which the component imports, so a 1.64.0 Lumi would refuse to load it;
# and \`recordings.keep\`, each part's audio kept as a file of this
# extension's own (\`keep-audio\`). A debug Lumi measures floors as the next
# minor release, so a dev build of 1.64.0 takes it.
# 1.89.0: the \`launcher\` capability and \`[launcher]\` below — the app in
# Applications — which an older Lumi refuses. What set the floor before it
# is said above.
# 1.90.0: \`models\` — each task's models listed, downloaded from Settings'
# pop-ups in Lumi's panel, and Meeting Notes' own choice kept by Lumi — which
# the component imports, so an older Lumi would refuse to load it.
# 1.91.0: \`ui.set-floating\` — Live Captions let down behind the Meeting Notes
# or Settings window the person is working in — another import.
# 1.92.0: \`ai.limits\` — what a call to the chosen model takes, so a meeting
# is read whole when it fits and in parts only past that — which the summary
# imports. Lumi 1.91.0 shipped without it and refuses the component.
# 1.93.0: \`transcribe.complete-with\` — a meeting's kept audio heard again
# (Listen Again), its progress told to the window and a call's two sides
# heard apart — another import.
# 1.95.0: \`transcribe.start-live\` and \`models.live-text\` — Words While
# Speaking, the grey words written by a second, lighter model while Speech
# Recognition writes each line — another import.
min-lumi-version = "1.95.0"
# speech + microphone + system-audio: a call's two sides, Me and the others.
# voices: speakers named where a saved voice profile speaks
# (\`speakers: named\`), and saving a profile the person names.
# audio-levels: the panel's input level bars — loudness only, no bands.
# ai: the AI model as the Translation Engine beside Apple Translation.
# clipboard: Copy Transcript in the Meeting Notes window.
# menu, menu-bar-item: the item in the menu bar, its panel and its menu.
# preload: the item's panel and the captions loaded ahead, so the first click
# and the first meeting show them at once.
# keep-audio: each part's audio kept, with Keep Audio on, to listen back to.
# microphone-use: which apps have a microphone open, so a call starting is
# noticed (\`src/detect.rs\`) — never what they hear.
# microphone-sites: which site a browser using the microphone shows, by host,
# so Google Meet or Teams in a browser is noticed too.
# offer: "Microsoft Teams is using your microphone — Take Notes", a line and a
# button Lumi draws; the press starts the notes. Never a start by itself.
# calendar (Lumi 1.94.0): the event a meeting is, to name it and know who was
# invited (\`src/calendar.rs\`) — read with Meeting Notes' own Calendars grant,
# asked from Settings' switch or the header's Link Calendar Event….
# reminders (Lumi 1.94.0): a summary's action items added to Reminders, and
# whether those are done (\`src/reminders.rs\`), with its own Reminders grant.
# timers: woken as a meeting in a room starts, to offer Take Notes for it.
capabilities = ["speech", "microphone", "system-audio", "voices", "audio-levels", "ai", "clipboard", "menu", "menu-bar-item", "preload", "keep-audio", "microphone-use", "microphone-sites", "offer", "launcher", "calendar", "reminders", "timers"]
# How long a meeting is recorded before it stops by itself: two hours, where
# Lumi starts an extension that says nothing at half an hour. The person
# moves it on Meeting Notes' Permissions sheet, and theirs then holds.
longest-recording-minutes = 120
# The item's menu opens the window first; a right-click opens it directly.
# Lumi's own Settings… row is left out: the settings are in the window.
menu-bar-item-right-click = "open"
menu-bar-item-settings = false
# The window the settings live in (Lumi 1.93.0): the app menu's Settings…
# (⌘,), drawn under "Meeting Notes" while the Meeting Notes window is in
# front, opens it, as the window's Settings button does. Lumi's menu takes
# ⌘, before the page hears it, so this is the only way the key reaches
# them; without it Settings… opened Meeting Notes' page in Lumi, whose
# Settings tab is hidden below.
settings-window = "settings"
# The captions panel's ⋯ menu put away — a row chosen, Escape, a press
# anywhere else — told to the captions panel, which is solid while it is up.
# And which apps use a microphone, the whole set as it changes: a meeting
# starting or ending (\`src/detect.rs\`). The calendars changing (the next
# meeting in a room may be another), Reminders changing (an action item done
# there), and the in-person timer (Lumi 1.94.0).
events = ["window-closed", "microphone-use", "calendar-changed", "reminders-changed", "timer"]

# Meeting Notes in Applications (Lumi 1.89.0): opening it from Spotlight, the
# Dock or Launchpad switches Meeting Notes on if it was off, then opens its
# main window, where a meeting is started.
[launcher]
opens = "window"
window = "main"

[[command]]
name = "open"
label = "Open Meeting Notes"
icon = "icons/notebook-text.svg"

# The item's menu rows of the same names, from a key (the [[shortcut]]s
# below). Each does what its row does — Start goes on in a paused meeting, as
# the menu's Resume; Stop ends a paused one — and does nothing where the menu
# has no such row (\`live::start_command\`).
[[command]]
name = "start"
label = "Start Transcription"
icon = "icons/audio-lines.svg"

[[command]]
name = "pause"
label = "Pause Transcription"
icon = "icons/pause.svg"

[[command]]
name = "stop"
label = "Stop Transcription"
icon = "icons/square.svg"

[[command]]
name = "start-stop"
label = "Start or Stop Transcription"
icon = "icons/audio-lines.svg"

[[command]]
name = "toggle-captions"
label = "Show or Hide Live Captions"
icon = "icons/captions.svg"

# Take notes of the meeting found — the offer's button and the menu's row
# (\`src/detect.rs\`) — or resume the meeting an offer names. Start only: a
# stale press never stops anything.
[[command]]
name = "take-notes"
label = "Take Notes"
icon = "icons/audio-lines.svg"

# Stop the meeting an offer names — "The call ended", "Nothing heard for 10
# minutes" — and only if it is the one being heard.
[[command]]
name = "stop-and-save"
label = "Stop and Save"
icon = "icons/square.svg"

# Summarize the meeting a call-ended card names — the card's Summarize, for
# meetings of 3 minutes or more — or, from a shortcut, the newest meeting
# that has ended: the window opens on it and writes its summary there
# (\`src/summary.rs\`).
[[command]]
name = "summarize"
label = "Summarize Last Meeting"
icon = "icons/sparkles.svg"

# The caption just said, translated under it on the panel. No key of its
# own; a row in Lumi's Shortcuts pane can run it.
[[command]]
name = "translate-last"
label = "Translate Last Caption"
icon = "icons/languages.svg"

# Extension-scoped, armed at install, in every profile. Recorded and changed
# in the window's Settings, the one place they are set
# (\`POST /__lumi__/shortcut-recording\`, \`PUT /__lumi__/shortcuts\`), so
# Lumi's Shortcuts tab is hidden below.
[[shortcut]]
command = "open"
key = "ctrl+alt+cmd+m"

[[shortcut]]
command = "toggle-captions"
key = "ctrl+alt+cmd+c"

# Start, Pause and Stop on ⌃⌥⌘ and the digits, in the menu's order: ⌃⌥⌘S
# and ⌃⌥⌘P are Sticky's and Floating Browser's keys, and macOS's own ⌃⌥⌘
# keys (8, comma, period — Accessibility's, shipped off) are none of these.
# A key somebody holds at install is not armed; Settings says who has it.
[[shortcut]]
command = "start"
key = "ctrl+alt+cmd+1"

[[shortcut]]
command = "pause"
key = "ctrl+alt+cmd+2"

[[shortcut]]
command = "stop"
key = "ctrl+alt+cmd+3"

# The live captions. Floats over every app (focus = false: never takes the
# keyboard, up until put away), kept while hidden so the transcription goes
# on, where the person left it. HUD glass, which blurs what is behind it as
# the HIG pass's mock does, in the panel's own Appearance (the page tells
# Lumi, \`look\`); the page paints its tint over it at the opacity the person
# chose.
[[window]]
name = "captions"
title = "Live Captions"
path = "captions.html"
kind = "panel"
position = "bottom-right"
focus = false
material = "hud"
width = 720
height = 156
min-width = 360
min-height = 72
keep-alive = true
# Loaded ahead, as the item's panel is: the captions show at once when the
# first meeting after Lumi starts begins, rather than a beat later (the
# owner, 2026-11-19). The page is the kept page it always was, hidden till
# shown; its first \`state\` (\`loaded\`) now runs at launch, so a meeting cut
# off when Lumi stopped is saved then, not at the next meeting.
preload = true
remember-frame = true
# On every desktop, over every app in full screen. A panel otherwise stays
# on the desktop it was shown on, and an app put in full screen is a
# desktop of its own: the captions were left behind on the desktop the
# meeting was started from while the person watched the call in full
# screen. Lumi 1.65.0; an older Lumi ignores the key.
all-desktops = true
# With Click Through Captions on, the captions' text lets every click, scroll
# and hover through to what is under it — the call, a shared slide — while
# the bar, its buttons, the strip and the edges take them (\`click-through\`,
# Lumi 1.78.0; the page names what takes, \`web/src/captions/clickThrough.ts\`).
click-through = true

# ⋯'s menu on the live captions: a panel of its own, so it opens whole over
# every app however few lines the captions show, and the captions can still
# be dragged up to the menu bar — a band around them (\`overhang\`) kept them
# that far from it. At the pointer, which is on ⋯ as it opens; Lumi keeps
# it inside the screen. It takes the keyboard, as a menu does: Escape or a
# press anywhere else puts it away, and the arrows walk its rows. A Mac
# menu's glass; kept and loaded ahead so it opens at once, fitted by its
# page. No button for it anywhere: only ⋯ knows where it goes.
[[window]]
name = "captions-menu"
title = "Live Captions Menu"
path = "captions-menu.html"
kind = "panel"
position = "cursor"
material = "popover"
width = 240
height = 180
keep-alive = true
preload = true
listed = false

# Settings' model pop-ups' menu — Speech Recognition, Speakers Model, Text
# Model: every model Lumi knows for the task, as long as its list. A panel
# of its own hanging from the pop-up pressed, as a pop-up's menu does: the
# page names the button's box (\`/__lumi__/anchor-box\`, Lumi 1.72.0) and Lumi
# stands the panel under it, its right edge on the button's — over it when
# the display has no room below. Being a panel, it opens whole over
# everything as tall as the screen allows, rather than inside the Settings
# window, which had to grow for it or have it scroll. It takes the keyboard
# as a menu does: Escape or a press anywhere else puts it away. Kept and
# loaded ahead, so it opens at once; it reads which task it was opened for
# (\`model-menu-asked\`) and the task's models each time it is shown, and fits
# itself to them.
[[window]]
name = "model-menu"
title = "Models"
path = "model-menu.html"
kind = "panel"
position = "window"
# Beside Settings, or the Meeting Notes window, whichever asked (Lumi
# 1.93.0): the Refine sheet picks Listen Again's speech model in it too.
anchor = { window = ["settings", "main"], at = "end", side = "below" }
material = "popover"
width = 320
height = 240
keep-alive = true
preload = true
listed = false

# A submenu of the model menu — a provider's models, what can't run here —
# beside the row it came from, as a Mac submenu opens: Lumi stands it to the
# menu's right, or left where the display has no room, its first row level
# with that row (the menu names the row's box, \`/__lumi__/anchor-box\`). It
# never takes the keyboard, so the menu stays up and keeps it; the menu walks
# the submenu's rows with the arrows by telling it (\`/__lumi__/post\`), and a
# row clicked is a press. It goes when the menu goes. The menu tells it the
# rows to draw, so it opens at once without reading the models itself.
[[window]]
name = "model-submenu"
title = "Models"
path = "model-submenu.html"
kind = "panel"
position = "window"
anchor = { window = "model-menu", at = "start", side = "trailing", follow = true }
focus = false
material = "popover"
width = 240
height = 120
keep-alive = true
preload = true
listed = false

# What a click on the menu bar item opens, under it (option C of the mock):
# Start or Stop Transcription, three switches, the last meetings, and the
# window. Lumi's popover glass with an arrow at the item, Gõ tiếng Việt's
# arrangement; kept loaded and loaded ahead so the first click opens it at
# once, and fitted by its page to what it shows. With it, the item's menu
# answers VoiceOver; a right-click still opens the window.
[[window]]
name = "popover"
title = "Meeting Notes"
path = "popover.html"
kind = "panel"
position = "menu-bar-item"
anchor = { at = "center" }
material = "popover"
arrow = true
keep-alive = true
preload = true
width = 320
height = 300

# The extension's own window: the meetings. Opened from the item's panel, a
# right-click on the item, the shortcut and the captions panel. Kept and
# loaded ahead (Lumi 1.65.0), as an app's window is: closing it hides it, and
# it opens at once, as it was — loaded when Lumi starts, under the same
# switch as the item's panel.
[[window]]
name = "main"
# The name its title bar shows too (\`.mw-title\`), so the Window menu and
# Mission Control say what the window does (the owner, 2026-11-21).
title = "Lumi Meeting Notes"
path = "index.html"
titlebar = "unified"
width = 960
height = 640
min-width = 720
min-height = 460
remember-frame = true
keep-alive = true
preload = true

# Settings, as a Mac app's are: a window of its own with a pane per toolbar
# button — General, Transcription, Captions, Translation, Speakers, Storage,
# and About, which has no app menu to live in since the menu bar's About is
# Lumi's. It was a view of the main window; Apple's guidelines keep settings
# out of an app's main window. The page fits the window's height to each
# pane, so it is not resizable; and close is all a settings window needs:
# minimise and zoom are greyed (the owner's choice, 2026-11-18, over
# \`window-buttons = "close"\`, which takes them off the title bar — a greyed
# pair keeps the row every Mac window has). It opens
# where it was left, and is kept while it is closed so the pane and the
# place in it stay. On install it opens on Transcription, whose On This Mac
# is what a first meeting needs.
[[window]]
name = "settings"
title = "Meeting Notes Settings"
path = "settings.html"
titlebar = "unified"
# The title's row: the window's name centred on it, the traffic lights on it
# too, as a Mac app's settings window has them; the page draws the panes'
# buttons under it.
titlebar-height = 32
width = 680
height = 560
resizable = false
maximizable = false
minimizable = false
remember-frame = true
keep-alive = true

# The Welcome tour (the owner's mock, 2026-11-20): what a first meeting
# needs — the microphone and system audio, the speech model, the calendar,
# the person's name and keys — each asked or downloaded from a press in it,
# then a finish. Opened by a fresh install (\`installed\`, src/lib.rs), never
# by an update, and again from Settings › About › Welcome Tour… and Lumi's
# About page. Laid out for this size and no other, as Clipboard Manager's,
# Screenshot's, Selection Bar's and Gõ tiếng Việt's tours are: a stage on
# top, the words under it, a footer. The page draws the title on the
# traffic lights' row, as Settings does, so a download going on behind the
# tour has a place at its right end. Not kept: each opening reads where
# things stand afresh, from the first step.
[[window]]
name = "welcome"
title = "Welcome to Meeting Notes"
path = "welcome.html"
titlebar = "unified"
titlebar-height = 32
width = 680
height = 600
resizable = false
maximizable = false

# Lumi's page for the extension shows its Changelog and About: settings
# and shortcuts live in the Settings window. The [[settings]] below still
# hold the values — Lumi keeps and checks them, every page hears
# \`lumi:settings\` — only their tab is hidden.
#
# The Changelog is Lumi's own tab, drawn from the CHANGELOG.md the package
# carries, as Metronome's is — no \`[tabs.changelog]\` at all. It was hidden
# while the Settings window's About › What's New was the one place to read
# it; that page stays, and the tab is where somebody looking at the
# extension in Lumi's Settings expects the history, beside every other
# extension's.
[tabs.settings]
hidden = true

[tabs.shortcuts]
hidden = true

# Every value is the Mac's, not a profile's: the person's languages and the
# captions' look do not change with a Lumi profile. Values arrive as text,
# the way Lumi's own form saves them; the window draws them all.

# The Meeting Notes window's look, apart from the captions panel's (\`look\`).
# The item's panel keeps macOS's: its glass is drawn by macOS.
[[settings]]
name = "appearance"
label = "Appearance"
kind = "segmented"
default = "system"
scope = "mac"

[[settings.options]]
value = "dark"
label = "Dark"

[[settings.options]]
value = "light"
label = "Light"

[[settings.options]]
value = "system"
label = "Match macOS"

[[settings]]
name = "hear"
label = "Audio Source"
kind = "select"
default = "call-everything"
scope = "mac"

[[settings.options]]
value = "call-everything"
label = "System audio and microphone"

[[settings.options]]
value = "call-app"
label = "One app and microphone"

[[settings.options]]
value = "microphone"
label = "Microphone only"

# A language id ("en"); the window draws it as a picker.
[[settings]]
name = "language"
label = "Spoken Language"
kind = "text"
default = "en"
scope = "mac"

# A second language spoken in the meetings, a language id, or empty for
# none: Lumi hears each line in whichever of the two it was said in. The
# window draws it as a picker beside Spoken Language.
[[settings]]
name = "secondLanguage"
label = "Second Language"
kind = "text"
default = ""
scope = "mac"

# Before Lumi 1.90.0 kept Meeting Notes' own model per task (\`models.choose\`),
# its id was this setting's: an update hands it to Lumi once and clears it
# (\`src/catalog.rs\`). Kept declared so that value can still be read; nothing
# writes it since.
[[settings]]
name = "speechModel"
label = "Speech Model"
kind = "text"
default = ""
scope = "mac"

# Words While Speaking: the model that writes the grey words while someone
# talks — an id from Lumi's \`models.live-text\`, Apple Speech as
# \`apple-speech:apple-speech\` — or empty for Same as Speech Recognition,
# whose model writes both. The window draws it as a pop-up under Speech
# Recognition; Meeting Notes keeps it, since no task of Lumi's names these
# models (\`src/catalog.rs\`). Read as a meeting begins: a meeting gone on in
# keeps what it began with.
[[settings]]
name = "wordsWhileSpeaking"
label = "Words While Speaking"
kind = "text"
default = ""
scope = "mac"

# One term a line, sent to the speech model as hints.
[[settings]]
name = "jargon"
label = "Custom Vocabulary"
kind = "textarea"
default = ""
scope = "mac"

[[settings]]
name = "speakers"
label = "Identify Speakers"
kind = "bool"
default = "true"
scope = "mac"

[[settings]]
name = "lines"
label = "Visible Lines"
kind = "segmented"
default = "3"
scope = "mac"

[[settings.options]]
value = "2"
label = "2"

[[settings.options]]
value = "3"
label = "3"

[[settings.options]]
value = "4"
label = "4"

[[settings]]
name = "size"
label = "Text Size"
kind = "segmented"
default = "regular"
scope = "mac"

[[settings.options]]
value = "small"
label = "Small"

[[settings.options]]
value = "regular"
label = "Regular"

[[settings.options]]
value = "large"
label = "Large"

[[settings]]
name = "look"
label = "Appearance"
kind = "segmented"
default = "dark"
scope = "mac"

[[settings.options]]
value = "dark"
label = "Dark"

[[settings.options]]
value = "light"
label = "Light"

[[settings.options]]
value = "system"
label = "Match macOS"

[[settings]]
name = "opacity"
label = "Background Opacity"
kind = "slider"
default = "75"
min = 25
max = 100
step = 5
scope = "mac"

[[settings]]
name = "labels"
label = "Speaker Labels"
kind = "bool"
default = "true"
scope = "mac"

[[settings]]
name = "showMe"
label = "Show My Captions"
kind = "bool"
default = "true"
scope = "mac"

[[settings]]
name = "clickThrough"
label = "Click Through Captions"
kind = "bool"
default = "false"
scope = "mac"

[[settings]]
name = "autoTranslate"
label = "Live Translation"
kind = "bool"
default = "false"
scope = "mac"

# With Live Translation on: each finished sentence of a line translated while
# it is still being said, before the speaker pauses. Off, only each line is,
# once it lands.
[[settings]]
name = "translateWhileSpeaking"
label = "Translate While Speaking"
kind = "bool"
default = "true"
scope = "mac"

[[settings]]
name = "translateWith"
label = "Translation Engine"
kind = "select"
default = "mac"
scope = "mac"

[[settings.options]]
value = "mac"
label = "Apple Translation"

[[settings.options]]
value = "ai"
label = "AI Model"

# A language id ("vi"); the window draws it as a picker of the languages
# Apple Translation lists.
[[settings]]
name = "translateInto"
label = "Target Language"
kind = "text"
default = "vi"
scope = "mac"

# As \`speechModel\`, for the text model: handed to Lumi once, then cleared.
[[settings]]
name = "aiModel"
label = "AI Model"
kind = "text"
default = ""
scope = "mac"

[[settings]]
name = "goOn"
label = "Auto-Resume at Recording Limit"
kind = "bool"
default = "true"
scope = "mac"

# Every start — the window's Start or Resume, the item's panel's, the
# menu's, a key's, an offer's Take Notes — closes the Meeting Notes window
# (put away, its page kept) and brings Live Captions up over every app (the
# owner, 2026-11-20; \`popover::show_for_start\`). Off, the window is left as
# it is: a start elsewhere brings the captions up, and a start pressed in the
# window keeps them out of its way until the person leaves it.
[[settings]]
name = "closeOnStart"
label = "Close Window When Transcription Starts"
kind = "bool"
default = "true"
scope = "mac"

# Your Name (Settings › Speakers): what names Me in place of "Me" — in the
# transcript, the captions, the summary and what its AI reads, a copy and a
# file — in every meeting, those before it too (\`meeting::my_name\`). Empty
# is "Me".
[[settings]]
name = "myName"
label = "Your Name"
kind = "text"
default = ""
scope = "mac"

# Each part's audio, kept as Lumi's file of this extension's own and played
# in the window. Only new meetings follow it: audio already kept stays until
# it is deleted.
[[settings]]
name = "keepAudio"
label = "Keep Audio"
kind = "bool"
default = "true"
scope = "mac"

# Where Save Audio… writes a meeting's audio once the person chose a folder
# in Settings; with none chosen it asks with Lumi's Save panel each time.
[[folder]]
name = "audio"
label = "Save meeting audio to"

# Summaries (\`src/summary.rs\`), drawn in Settings › Summaries. The Default
# Template, by id: a built-in's, or one of the person's own.
[[settings]]
name = "summaryTemplate"
label = "Default Template"
kind = "text"
default = "general"
scope = "mac"

# Where a new summary's Language pop-up starts: \`same\` for the meeting's own,
# or a language id.
[[settings]]
name = "summaryLanguage"
label = "Summary Language"
kind = "text"
default = "same"
scope = "mac"

# A meeting of 3 minutes or more is summarized with the Default Template as
# the window opens on it at its end (it was Lumi's card at a call's end
# offering Summarize, \`offerSummary\`, until 0.8.2).
[[settings]]
name = "autoSummary"
label = "Automatically Summarize When a Meeting Ends"
kind = "bool"
default = "true"
scope = "mac"

# Refine Transcript (\`src/refine.rs\`), drawn in Settings › Transcription ›
# After a Meeting. What cleans a meeting's transcript up by itself as it
# ends, for meetings of 3 minutes or more: Light at once, with no AI; Full
# then the text model below, once the window shows the meeting. The words
# as heard are always kept.
[[settings]]
name = "refineClean"
label = "Clean Up Transcript"
kind = "select"
default = "light"
scope = "mac"

[[settings.options]]
value = "off"
label = "Off"

[[settings.options]]
value = "light"
label = "Light — No AI"

[[settings.options]]
value = "full"
label = "Full — With AI"

# The text model Full uses by itself, by id: on this Mac or online (the
# owner, 2026-11-20). Empty for Meeting Notes' Text Model.
[[settings]]
name = "refineModel"
label = "Clean Up Model"
kind = "text"
default = ""
scope = "mac"

# Listen Again as a meeting ends: its kept audio heard again by a stronger
# speech model, after the summary (\`src/listen.rs\`). Off by default (the
# owner's R2): it uses this Mac for minutes.
[[settings]]
name = "refineListen"
label = "Listen Again"
kind = "bool"
default = "false"
scope = "mac"

# The speech model Listen Again hears with, by id. Empty for Lumi's own
# choice for Meeting Notes.
[[settings]]
name = "refineSpeech"
label = "Speech Model for Listen Again"
kind = "text"
default = ""
scope = "mac"

# The person's own templates, as JSON, written by Settings › Summaries'
# editor through the component, which holds them to the editor's rules.
[[settings]]
name = "summaryTemplates"
label = "Templates"
kind = "textarea"
default = "[]"
scope = "mac"

# Meeting detection (\`src/detect.rs\`). Offer to take notes when a call app or
# a meeting site starts using the microphone — never start by itself.
[[settings]]
name = "askStart"
label = "When a Meeting Starts"
kind = "select"
default = "ask"
scope = "mac"

[[settings.options]]
value = "ask"
label = "Offer to take notes"

[[settings.options]]
value = "never"
label = "Do nothing"

# When the call app of a recording started for it lets go of the microphone
# for 20 seconds. A recording started by hand with no call app is never ended.
[[settings]]
name = "atEnd"
label = "When a Meeting Ends"
kind = "select"
default = "stop"
scope = "mac"

[[settings.options]]
value = "stop"
label = "Stop and save"

[[settings.options]]
value = "ask"
label = "Ask first"

[[settings.options]]
value = "nothing"
label = "Keep recording"

# Bundle ids of call apps not offered for, one per line. Slack by default: it
# holds the microphone at times with no huddle.
[[settings]]
name = "quietApps"
label = "Don't Offer For"
kind = "text"
default = "com.tinyspeck.slackmacgap"
scope = "mac"

# The hosts that make a browser using the microphone a meeting, one per line,
# \`*.\` for any subdomain.
# Name Meetings After Calendar Events (Settings › General › Calendar): a
# meeting takes the name of the event it overlaps, and keeps who was invited
# (\`src/calendar.rs\`). Off until the person turns it on, which asks for the
# calendars (D2).
[[settings]]
name = "calendarNames"
label = "Name Meetings After Calendar Events"
kind = "bool"
default = "false"
scope = "mac"

# The calendars left out of naming meetings and in-person offers, by id, one
# per line — "auto" for the first rule: every calendar but Birthdays and
# subscriptions such as holidays (\`calendar::kept\`).
[[settings]]
name = "calendarsOff"
label = "Calendars Left Out"
kind = "text"
default = "auto"
scope = "mac"

# In-Person Meetings (Settings › General › Offer For): offer Take Notes as an
# event with people and a place starts and no call app is heard (D6, on).
[[settings]]
name = "offerInPerson"
label = "Offer for In-Person Meetings"
kind = "bool"
default = "true"
scope = "mac"

# The Reminders list the last action items went to; empty for the person's
# default list.
[[settings]]
name = "remindersList"
label = "Reminders List"
kind = "text"
default = ""
scope = "mac"

[[settings]]
name = "meetingSites"
label = "Meeting Sites"
kind = "text"
default = "meet.google.com\\nteams.microsoft.com\\nteams.live.com\\nteams.cloud.microsoft\\nzoom.us\\n*.zoom.us\\n*.webex.com\\nwhereby.com"
scope = "mac"
`,N=`# Changelog

## [Unreleased]

## [0.12.0] - 2026-11-21

### Added

- **Words While Speaking**, in Settings › Transcription: choose the model that writes the grey words while someone talks — Apple Speech, or Nemotron 3.5 Streaming, which hears both of a meeting's languages. Speech Recognition still writes each line when they pause, so the words come steadily and the graphics chip is mostly free for the call, though they're less accurate until the pause. Same as Speech Recognition, as before, is the default; a model not on this Mac downloads when you pick it, and a change applies from the next meeting. Needs Lumi 1.95.
- **Translate While Speaking**, in Settings › Translation: with Live Translation on, each sentence is translated before the speaker pauses, as before. Turn it off to translate only each finished line.

### Changed

- **Chat shows a line's actions as you point at it**: Play, Translate, Copy and More beside the bubble, as Paragraphs and Lines show them. The View popover's help is one line.
- **Click a line to play it**, and again to pause it, under the pointing hand; ⌘-click or ⇧-click selects lines. A click used to select and a double-click to play. A line with no audio still selects on a click.
- **Play is Pause while its line plays**, in every layout, and Play again goes on where it stopped. The bars that show a turn playing stand at the speaker's outer edge in Chat, and in place of the speaker's initial in Paragraphs and Lines, so nothing moves when a line starts or stops, and Name… coming and going under the pointer leaves no gap beside them.
- **Your own turns in Chat read "0:32 Me"**, your name at the bubble's edge as other speakers' names are at theirs.
- **Chat's bubbles stop at a comfortable line length** on a wide window — about 65 characters, at every text size.
- **Unlink a meeting's event by pressing it again** in the event menu, where it is ticked; None is gone.
- **In Live Captions, a speaker not known yet is three blinking dots**, as the main window shows words still being heard, where a still "…" stood.

### Fixed

- **A turn says which sentences are not translated yet.** In Chat and Paragraphs, a sentence with no translation shows Translate where its translation would be, a press away; half a turn's translation read as all of it.
- **A finished meeting opens at its start**, not on its last lines. A meeting being transcribed still follows what is said.
- **The bar for several selected lines no longer hides the last ones.**
- In Chat, words fade under the speaker's name as they scroll past it, rather than being cut at its edge.
- **The event menu fits what it holds.** With no event near the meeting it is its heading and Open in Calendar, no wider than they are.
- **With translations beside the words, each language's name stands over its column**, in Lines and Paragraphs. On a wide window the original language's name stood well left of its words.

## [0.11.0] - 2026-11-21

### Added

- **Merge speakers and assign lines.** When one person was heard as two, right-click a line and choose Merge “Speaker 3” Into, or press Merge… beside the speaker in the inspector. When a line went to the wrong person, Assign To moves it — or every selected line — to anyone in the meeting, to you, or to a New Speaker. Both have Undo, and both wait until the meeting ends.

### Fixed

- **Name… opens its card whole**, in the transcript over the turns below it — upward near the transcript's foot — and in the inspector, with no scrollbar of its own. In Lines, a turn's header now holds at the top as you scroll, and its text follows View's size.
- **Listen Again keeps My Voice.** On a call heard again, someone beside you at your microphone was folded into your lines as Me; now, as in Live Captions, only your voice is Me and anyone else there stays their own speaker. In a room, your lines are Me too.

## [0.10.0] - 2026-11-21

### Added

- **A Welcome tour on a fresh install.** The microphone and system audio, your language and its speech model (downloading in the background), your calendar, your name, Keep Audio and summaries, and the keys that start a meeting. Again from Settings › About › Welcome Tour….
- **Pin and folders.** Right-click a meeting to Pin it or Move To a folder, or drag it there. New Folder (⇧⌘N) is named in place, folders keep the order you drag them, and Delete Folder keeps its meetings, with Undo. Sort By date, title or length. The meeting being transcribed stays at the top, in Now.
- **Export… (⇧⌘E) makes a PDF, HTML, Markdown or plain text file** from one sheet: a template — Standard, Minutes or Columns — and the paper; the summary, any version of it, or Summarize… or Regenerate… there; the transcript refined or as heard, its translations (Translate… if there are none yet) and timestamps. Customization names you another way in that file, or leaves out the AI models' names. The preview is the file: PDF and HTML zoom, Markdown and plain text copy — Markdown's Formatted view as rich text. An HTML file has its own Light, Dark and System. Every file ends with "Made with Lumi Meeting Notes". Saved, the message names the file and its folder, with Show in Finder.
- **Your Name in place of "Me"** in every meeting, earlier ones too: Settings › Speakers › Your Name.
- **Quick Translate.** In a meeting with nothing translated, the translate button translates it at once into your Settings' language with your translator, a ring round it showing how far.
- **Meetings named after their calendar events** (Settings › General › Calendar). The event button beside the date links another event or opens it in Calendar; the inspector shows who was invited. Reads your calendar, never changes it.
- **Offers for meetings in a room** as a calendar event with a place starts (Settings › General › Offer For › In-Person Meetings); a call still heard 5 minutes after its event ends offers Stop and Save.
- **Add to Reminders** from the Action Items heading: the items you tick, with a date. Done in Reminders shows done here.

### Changed

- **The sidebar slides** out and in (⌘B), its button beside New Folder.
- **The window shows its name**, Lumi Meeting Notes, at the middle of its title bar.

### Fixed

- **Settings › Storage** gives the transcripts' size without the audio, always shows the Audio section, and Delete All Audio works with hundreds of meetings.
- **Messages** stay at the middle of the window's foot.
- **The Summary tab** shows a spinner, not No Summary Yet, while the summary is read.

Needs Lumi 1.94.0.

## [0.9.0] - 2026-11-20

### Added

- **Refine and Translate.** In the Transcript tab, Refine and Translate… cleans up a meeting that has ended. Light takes out ums and words said twice, on this Mac, with no AI. Full also fixes punctuation, grammar and your Custom Vocabulary terms with the text model you choose, and leaves out any change that would alter what was said. Translate All translates every line not yet translated, or all of them again once every line is. The sheet says how long it takes and which AI calls go where before you start; Stop keeps what's done.
- **Original, Changes and Refined.** See the refined words, what refining changed — taken out struck through, put in underlined — or the words as heard. Revert to Original puts lines, or the whole meeting, back as heard. ⌘Z undoes the last refine or revert, and ⇧⌘Z redoes it. Copy and Export take the version shown.
- **Listen Again.** Hears a meeting's kept audio again with a stronger speech model on this Mac, for truer words and speakers: on a call your lines stay Me, and someone the live transcript mixed up is told apart. The words heard live stay as Original, and the summary's times follow the new lines.
- **Meetings clean themselves up as they end.** Settings › Transcription › After a Meeting: Light by default, for meetings of 3 minutes or more; Full and Listen Again can follow, with the models you choose.
- **Volume in the player.** A speaker button mutes playback; hover over it for a volume slider.
- **⌘B shows or hides the sidebar.**
- **A Changelog tab** beside About on Meeting Notes' page in Lumi's Settings.

### Changed

- **Start Transcription shows Live Captions and closes the Meeting Notes window**, wherever you press it, so you follow the meeting over the call; open Meeting Notes again to read along. To keep the window, set Settings › General › When Transcription Starts to Keep Window Open.
- **Show Translations beside View.** A translate button shows or hides translations, and turns Live Translation on or off while a meeting is heard.
- **Summary choices wait for Regenerate.** A new template, model or language no longer rewrites the summary at once.
- **Icons in the meeting menus**, as macOS menus have them.

### Fixed

- **Settings… opens Meeting Notes Settings.** With the Meeting Notes window in front, Meeting Notes › Settings… and ⌘, open its Settings window and leave the window where it is.
- **The View and date popovers open over the transcript**, no longer under a speaker's name held at the top.

## [0.8.2] - 2026-11-20

### Added

- **Escape closes Settings.** A menu or a sheet open in it, a shortcut being recorded, or a field you're typing in takes Escape first; press it again to close the window.

### Changed

- **A summary writes itself in as the model writes it.** While the transcript is read, the Summary tab shows what's happening where "No Summary Yet" stood, with Stop, and a long meeting's progress fills the ring round its mark. When the model starts writing, the mark moves up to a line that stays at the top as you scroll, and the overview and each item appear as they're written. Regenerate keeps the summary you have, dimmed, until the new one starts.
- **Live Translation keeps up with a long turn.** Each sentence is translated as soon as it's said, while the speaker goes on, instead of once they pause; the rest of the caption follows when it ends. A sentence heard differently a moment later is translated again. With macOS translating (Settings › Translation Engine), the words still being said are translated too, dimmed, and replaced as more is said, then by the caption's own translation when it ends; the AI is never asked for these.
- **Live Captions are ready from the moment Lumi starts**, as the menu bar item's panel is, so the first meeting shows them at once. Lumi's Preload switch for Meeting Notes covers them too.
- **Live Captions step out of the way while you're in the Meeting Notes window watching the meeting being heard**, since the window already shows its words, and come back over every app as soon as you switch to another app or close the window (closing needs Lumi 1.93.0). Start or Resume pressed in the window starts the meeting from there, without the captions flashing up first. Captions you hid yourself stay hidden, and they stay put while Live Translation is by the AI.
- **A meeting is summarized by itself as it ends.** Settings › Summaries' Automatically Summarize When a Meeting Ends, on unless you turn it off, writes the summary with the Default Template as the Meeting Notes window opens on a meeting of 3 minutes or more, in place of Offer to Summarize; Lumi's card at a call's end offers Resume. Set as Default under Templates picks the template.
- **Templates says which are built in**: they're listed under BUILT-IN, yours under YOUR TEMPLATES. A built-in opens with View…, and − says why it can't delete one.
- **The menu bar item's panel has no Live Captions or Live Translation switch any more.** Show Live Captions appears there while you record and the captions are out of sight, and the Meeting Notes window's translate button turns Live Translation on and off while it shows the meeting being heard.
- **A meeting that ends opens in the Meeting Notes window**, and Live Captions go away, instead of staying up to say it was saved: stopped, ended after a pause, or stopped by itself when the call ended.

### Fixed

- **The menu bar item no longer goes on showing a recording after it stopped**: now and then its wave kept moving beside a clock standing at the meeting's last second, with nothing being heard.

## [0.8.1] - 2026-11-19

### Changed

- **A long Chat bubble's speaker stays in sight across the column**, on a band in the window's own background at the top of the transcript, with the words passing under it, instead of floating over them.

### Fixed

- **The inspector's speakers no longer look switched off.** They were drawn at a faint strength, as were Save Voice Profile and a summary template's fields; they're at full strength now, their checkboxes drawn as a Mac's, and a speaker you uncheck is dimmed so the ones shown stand out.
- **Nothing shows above what stays at the transcript's top**: a sliver of words used to peek over a held turn's header or a bubble's speaker.

## [0.8.0] - 2026-11-19

### Added

- **Choose how the transcript reads.** View, beside the tabs, lays it out as Chat (bubbles, yours on the right, as Messages draws them), Paragraphs or Lines, with translations below the words or side by side, four text sizes (⌘+ ⌘−), and Timestamps, Follow Along While Playing and Speaker Colors.
- **Select lines and act on them.** Click, ⇧- or ⌘-click, or ↑ ↓; ⌘C copies, ⌘A selects all, Return plays. Several selected get a bar with Play, Copy and Translate; right-click for Copy with Names and Times, Select Whole Turn, Name and Hide. Name… beside an unnamed speaker names them right there.
- **Follow along while it plays**: the line heard is lit and kept in sight; scroll away and Back to Now Playing returns to it.
- **See who spoke where on the player's scrubber**: point at it and the turn under the pointer lights up, with a tooltip naming the speaker, the time a click plays from, and when the turn starts and ends. ⇧-click plays the turn from its start.
- **Appearance in the toolbar**: a click goes System, Light, Dark; right-click to pick one. The same setting as Settings › General.
- **Every speech model that heard a meeting**, with when it took over, in Details, under the title and in exports.
- **Search finds what was said** in every meeting's transcript, translations and summary. The sidebar shows the meetings that hold your words, their matches and two of their lines: click one to open the meeting there. Without accents a word finds every accent ("hop" finds họp, hộp and hợp); quotes keep a phrase in order.
- **Move from match to match** with ‹ › beside the search, Return or ⌘G (⇧⌘G back), the summary's matches included; each tab says how many it holds. ⌘F goes to the search.
- **Click Through Captions**, in Settings › Live Captions: the captions' text lets clicks, scrolls and hovers through to what's under it; the bar and the panel's edges still take them.
- **Keys for Start, Pause and Stop Transcription**: ⌃⌥⌘1, ⌃⌥⌘2 and ⌃⌥⌘3 in every app, as the menu bar item's rows. Change or clear them in Settings › General › Shortcuts.

### Changed

- **Transcript and Summary are two tabs** under the meeting's title, ⌘1 and ⌘2; the title heads the page over the date and who spoke. Point at a summary's time to read its lines; click it to see them in the transcript, and Back to Summary (⌘[) to return. The player stays under both tabs, and a meeting opens on the tab you left. ⌥⌘S is gone with the pane.
- **The transcript opens as Chat**, headed by when it was heard, the model and the language, with quiets of 15 s or more said between turns. A long bubble keeps its speaker's name in sight as you scroll through it.
- **A meeting where nothing was said says so**, in place of the tabs.

### Fixed

- **Stop on a paused meeting shows it saved** in the window open beside it.
- **The toolbar's buttons work while the search is open**, and the empty field stays open, so the toolbar doesn't move under your pointer; click elsewhere or press Escape to close it.
- **Share is off when there's nothing to share**, as Show Translations is.
- **A meeting is named by the first speech model that heard it**, not the one a change left it on.
- **A narrow transcript stays readable**: translations go under the words, and Lines lets its buttons go.

## [0.7.0] - 2026-11-19

### Added

- **Summarize a meeting.** A Summary pane under the transcript writes an overview, the action items and the sections of a template — General, 1:1, Stand-up, Interview, Customer Call or one of your own — each item with the time it was said: click the time to see those lines in the transcript. Template, model and language are right above it; choosing another writes a new version, and the one before stays a click away with your edits. Edit any item in place, tick action items, choose who owns them; Copy Summary and Copy Action Items paste as Markdown. The summary is written by the text model you set up in Lumi, on this Mac or online — Lumi asks before anything leaves it — and the meeting takes the summary's title while it still has the one Meeting Notes gave it. Drag the pane taller or shorter, make it larger, or fold it away with ⌥⌘S. Needs Lumi 1.92.0.
- **Long meetings are read in parts** when the model you chose can't read them whole, then put together, with a bar of how far it got, the time left and Stop. A stretch that couldn't be read is said at the top of the summary.
- **No text model yet?** Summarize offers one to download, in Lumi's own panel, and goes on once it's ready.
- **Settings › Summaries**: the Text Model, the template and language a summary starts with, and your own templates — a name, instructions, and the sections you want in your order.
- **Summarize from the card when a call ends.** For notes of 3 minutes or more, Lumi's card offers Summarize instead of Resume, and the window opens on the meeting writing it. Turn it off in Settings › Summaries.
- **Exports include the summary.** Export as Markdown or Plain Text puts the summary ahead of the transcript, each item with the time of what it came from; Share › Copy Summary copies it.

### Changed

- **The player is a bar at the foot of the transcript**, in the same place whatever the window shows, with no Close; Space plays and pauses.
- **Scroll to Top and Scroll to Bottom** appear as you scroll a long transcript or summary; Home, End, ⌘↑ and ⌘↓ go there too.
- **Alerts' buttons are drawn as macOS's**, one line each.
- **Live Captions step back while you work in Meeting Notes.** With the Meeting Notes or Settings window in use, the captions no longer cover it: they go behind it, and float over every app again as soon as you go back to another app, or when you click them. Needs Lumi 1.91.0.

### Fixed

- **Menus are drawn in macOS's appearance.** The model pop-ups' menus in Settings, their submenus and Live Captions' ⋯ menu follow macOS's light or dark, as a Mac menu does; they used to follow Lumi's Appearance where you had set it apart from macOS.
- **Live Captions stay in sight over an app in full screen.** They now follow you onto every desktop and over every app in full screen; they used to stay behind on the desktop the meeting was started from, so a call watched in full screen showed no captions.

## [0.6.0] - 2026-11-18

### Added

- **Escape hides Live Captions** once you have clicked the panel, as its Hide button does; with its ⋯ menu open, Escape closes the menu first.
- **Choose and download models in Settings.** Speech Recognition, Speakers Model and Text Model are pop-ups that offer every model Lumi knows: ready on this Mac or online — Lumi Models, Apple Speech, apps such as Ollama and LM Studio, services you have a key for, Claude Code — the ones Lumi can download, with their sizes, and the ones that can't run here, saying why. A provider's models, and the ones that can't run here, open in a submenu beside the menu, as a Mac menu's do. Lumi asks before anything is downloaded; it comes down with a bar, with Cancel where the download can be stopped (macOS's own language downloads can't be), and Meeting Notes uses it once it's ready. Transcription's On This Mac shows the speech model, the speakers model and the translation together. Your choice is kept by Lumi, which shows it under Settings › AI › Extensions & Privacy, where Use My Default puts it back. Needs Lumi 1.90.0.

### Changed

- **Settings shows its name on the title bar's top row**, Meeting Notes Settings, beside the window's buttons, with the panes' buttons under it, as a Mac app's settings window does; it stays the same whichever pane is open.

## [0.5.0] - 2026-11-18

### Added

- **Record Your Voice in English or Vietnamese.** Switch the text to read between English and Tiếng Việt; it starts in your Spoken Language, and Meeting Notes listens in the language you read.

### Changed

- **The Meeting Notes window keeps up with Live Captions.** A meeting being recorded shows in the window as Live Captions shows it, the line being said included, the moment it changes — speaker names and translations too — instead of up to half a minute behind. Needs Lumi 1.90.0; with an older Lumi the window catches up as before.
- **Open Meeting Notes in Live Captions' ⋯ menu opens the meeting being recorded** — or the one paused — rather than whichever meeting the window showed last.

### Fixed

- **Notes stop when the call ends, however you started them.** Notes started with Start Transcription, the menu or a shortcut during a Teams, Zoom, Google Meet or other call now stop and save when that call ends, as notes started from the "Take Notes" offer always did; they used to go on after the call. And notes started after one call has ended are no longer stopped because of it.
- **Record Your Voice is seen whole.** The Speakers pane keeps Settings tall enough for it, so it no longer runs off the bottom of the window; and should its text ever be longer than the window, the text scrolls between the title and the buttons, so Record, Stop and Save stay in reach.

## [0.4.0] - 2026-11-18

### Changed

- **Live Captions move smoothly.** New words glide the captions up instead of jumping them a line at a time; a line heard again shorter no longer pulls everything back down, and only the words a correction changed fade in — words it drops from the end fade out, and words it moves fade back in where they now stand rather than sliding — so you keep your place while reading. Latest glides back down too. With Reduce Motion on, the captions move as before.
- **Live Captions keep their size for a notice.** A notice — a language pack to download, Lumi's recording limit — floats over the top of the captions instead of making the panel taller, so the newest line stays in sight and the panel stays where you put it.

### Fixed

- **A speaker's name held at the top of Live Captions stays put** while their long turn is still being heard; it used to drop and slide back each time the line changed.

## [0.3.0] - 2026-11-18

### Added

- **Meeting Notes in Applications**: open it from Spotlight, the Dock or Launchpad, and its window opens, ready to start a meeting. Opened while Meeting Notes is switched off, it switches it on first.
- Needs Lumi 1.89.0.

## [0.2.0] - 2026-11-18

### Changed

- **A new look, after Apple's design guidelines.** The window keeps your meetings on a floating sidebar, the open meeting's commands as toolbar buttons, and its details, speakers and translation in an inspector; the player floats over the transcript, with skip, speed and Mute Me.
- **Start Transcription is at the foot of the sidebar.** While a meeting is recorded it becomes the recording time with Pause and Stop — click the time to go back to the meeting from any other.
- **Settings has a window of its own**, with panes for General, Transcription, Captions, Translation, Speakers, Storage and About.
- **Live Captions stay out of the way.** While you read, the panel shows the captions, the recording time and Lumi's mark — nothing else. Point at it and the controls come in: click the red time to stop. The panel keeps its size, is frosted glass in its own appearance and turns solid under the pointer.
- **Translate a caption** from the button it shows when you point at it.

### Added

- **Copy one line**, with who said it, from its hover buttons or its menu.
- **Open the meeting being recorded** by clicking its card in the menu bar panel.
- **Full screen**: the sidebar's button and the recorder move into the corner the window buttons leave.

### Fixed

- Meeting Notes no longer asks Lumi for too much at once every time a meeting being recorded is saved.

## [0.1.0] - 2026-10-25

### Added

- **Live captions for your meetings**, in a panel that floats above your call: what is said, as it is said, with **speaker identification** — saved voice profiles by name, everyone else as Speaker 1, 2, 3 — and your own lines as Me.
- **Meetings in two languages**: set a Second Language in Settings, and each line is written in whichever of the two it was said in. Translation translates each line from its own language and leaves the lines already in the language you translate into.
- **Translation on request**: click a caption to translate it, or turn on **Live Translation**, with Apple Translation on this Mac or the AI model you set up in Lumi.
- **Every meeting saved as a transcript** in the Meeting Notes window, to read, copy or export as Markdown or plain text.
- **Read what one speaker said**: click a speaker above a transcript to show only their lines, click others to add theirs, and Reset shows everyone again. The chevron beside a speaker names it, right there.
- **Voice profiles**: name a speaker during or just after a meeting and save the profile, and Meeting Notes identifies them in every meeting after.
- **My Voice**: record your own voice in Settings, with the steps and a text to read, so in a call your lines are Me and anyone else heard by your microphone is shown as another speaker.
- **Listen back to a meeting**: with Keep Audio on, each meeting's audio is kept with its transcript. Click a line's time to hear it from there, the line being heard lit, at 1×, 1.5× or 2×, and in a call **Mute Myself** plays it without your microphone; Save Audio… writes it as an .m4a, into a folder you choose in Settings or wherever you pick. Delete All Audio in Settings removes it and keeps the transcripts.
- **Long meetings**: a recording runs up to two hours by default; set **Longest Recording** in Settings, up to eight hours, and **Auto-Resume at Recording Limit** goes on in the same meeting once it is reached.
- Hints as you point at a button, a speaker or a caption, and why a button is off — in the captions panel too.
- **Notices a meeting starting**: when Microsoft Teams, Zoom, FaceTime or another call app — or Google Meet, Teams or Zoom in a browser — starts using your microphone, a **Take Notes** button comes up at the top right of your screen. Meeting Notes never starts by itself. When the call ends, the notes stop and are saved, with **Resume** if it was too soon — or it asks first, or keeps recording, as you choose in Settings, where each call app has a switch (Slack is off, since it holds the microphone outside huddles too) and the meeting sites are a list you can edit.
- Opens from its own menu bar item, or with ⌃⌥⌘M.
- Needs Lumi 1.65.0.
`;function P(e,t){let n=e.split(/^\[extension\]\s*$/m)[1]?.split(/^\[/m)[0]??``;for(let e of n.split(`
`)){let n=e.match(/^([A-Za-z0-9_-]+)\s*=\s*"([^"]*)"\s*$/);if(n?.[1]===t)return n[2]??``}return``}var F={Added:`New Features`,Changed:`Improvements`,Fixed:`Bug Fixes`,Removed:`Removed`,Deprecated:`Deprecated`,Security:`Security`};function I(e){return e.split(/^## /m).slice(1).map(e=>{let[t=``,...n]=e.split(`
`),[,r=``,i=``]=t.match(/^\[([^\]]+)\]\s*-\s*(\S+)/)??[],a=[];for(let e of n)e.startsWith(`### `)?a.push({kind:e.slice(4).trim(),changes:[]}):e.startsWith(`- `)&&(a.length===0&&a.push({kind:``,changes:[]}),a[a.length-1].changes.push(e.slice(2).trim()));return{version:r,date:i,parts:a.filter(e=>e.changes.length>0)}}).filter(e=>e.version!==``&&e.parts.length>0)}function L(e){return e.split(/(\*\*[^*]+\*\*)/).filter(e=>e!==``).map(e=>e.startsWith(`**`)&&e.endsWith(`**`)&&e.length>4?{text:e.slice(2,-2),bold:!0}:{text:e,bold:!1})}function R(e){let t=new Date(`${e}T12:00:00`);return/^\d{4}-\d{2}-\d{2}$/.test(e)&&!Number.isNaN(t.getTime())?t.toLocaleDateString(`en-GB`,{day:`numeric`,month:`long`,year:`numeric`}):e}function ne(e){return e.replace(/^https?:\/\//,``).replace(/[/?#].*$/,``)}var z=c(),B=[[`info`,`Information`],[`new`,`What’s New`]],V=e=>P(M,e),H=I(N);function U(e){return(0,z.jsxs)(`div`,{className:`srow`,children:[(0,z.jsxs)(`span`,{className:`lab`,children:[e.label,e.help&&(0,z.jsx)(`span`,{className:`help`,children:e.help})]}),e.children]})}function W(e){return(0,z.jsx)(`div`,{className:`notes`,children:e.release.parts.map(e=>(0,z.jsxs)(`section`,{className:`notes-part`,children:[e.kind&&(0,z.jsx)(`h3`,{className:`notes-kind`,children:F[e.kind]??e.kind}),(0,z.jsx)(`ul`,{className:`notes-list`,children:e.changes.map((e,t)=>(0,z.jsx)(`li`,{children:L(e).map((e,t)=>e.bold?(0,z.jsx)(`strong`,{children:e.text},t):e.text)},t))})]},e.kind))})}function G(e){let[t,n]=(0,A.useState)(!1),{version:r,date:i}=e.release,a=`release-notes-${r}`;return(0,z.jsxs)(`div`,{className:t?`srow history open`:`srow history`,children:[(0,z.jsxs)(`button`,{type:`button`,className:`history-head`,"aria-expanded":t,"aria-controls":a,onClick:()=>n(!t),children:[(0,z.jsx)(m,{size:12,className:`disclose`,"aria-hidden":`true`}),(0,z.jsxs)(`span`,{className:`lab`,children:[`Version `,r]}),(0,z.jsx)(`span`,{className:`val`,children:R(i)})]}),t&&(0,z.jsx)(`div`,{id:a,className:`history-notes`,children:(0,z.jsx)(W,{release:e.release})})]})}function K(){let[e,...t]=H;return e?(0,z.jsxs)(z.Fragment,{children:[(0,z.jsxs)(`div`,{className:`release-head`,children:[(0,z.jsxs)(`h2`,{className:`release-version`,children:[`Version `,e.version]}),(0,z.jsx)(`span`,{className:`release-date`,children:R(e.date)})]}),(0,z.jsx)(`div`,{className:`group notes-card`,children:(0,z.jsx)(W,{release:e})}),t.length>0&&(0,z.jsxs)(z.Fragment,{children:[(0,z.jsx)(`h2`,{className:`sec`,children:`Version History`}),(0,z.jsx)(`div`,{className:`group`,children:t.map(e=>(0,z.jsx)(G,{release:e},e.version))})]})]}):null}function q(e){let[t,n]=(0,A.useState)(`info`),r=V(`version`),i=V(`author`),a=H[0]?.date.slice(0,4),o=async t=>{let n=await s({m:t});n.ok||e.onError(n.error)};return(0,z.jsx)(z.Fragment,{children:(0,z.jsx)(`div`,{className:`settings`,children:(0,z.jsxs)(`div`,{className:`settings-body`,children:[(0,z.jsxs)(`div`,{className:`about-hero`,children:[(0,z.jsx)(`img`,{className:`about-icon`,src:C,alt:``}),(0,z.jsx)(`h1`,{className:`about-name`,children:V(`name`)}),(0,z.jsxs)(`div`,{className:`about-version`,children:[`Version `,r]}),(0,z.jsx)(`p`,{className:`about-blurb`,children:V(`description`)})]}),(0,z.jsx)(`div`,{className:`about-tabs`,children:(0,z.jsx)(`span`,{className:`seg`,role:`tablist`,"aria-label":`About ${V(`name`)}`,children:B.map(([e,r])=>(0,z.jsx)(`button`,{type:`button`,role:`tab`,"aria-selected":t===e,className:t===e?`on`:``,onClick:()=>n(e),children:r},e))})}),t===`info`?(0,z.jsxs)(z.Fragment,{children:[(0,z.jsxs)(`div`,{className:`group`,children:[(0,z.jsx)(U,{label:`Version`,children:(0,z.jsx)(`span`,{className:`val`,children:r})}),(0,z.jsx)(U,{label:`Developer`,children:(0,z.jsx)(`span`,{className:`val`,children:i})}),(0,z.jsx)(U,{label:`Requires`,children:(0,z.jsxs)(`span`,{className:`val`,children:[`Lumi `,V(`min-lumi-version`),` or later`]})}),(0,z.jsx)(U,{label:`Website`,children:(0,z.jsxs)(`button`,{type:`button`,className:`val link`,onClick:()=>void o(`open-website`),children:[ne(V(`homepage`)),(0,z.jsx)(T,{size:12,"aria-hidden":`true`})]})}),(0,z.jsx)(U,{label:`Permissions`,help:`What Meeting Notes may reach, kept by Lumi.`,children:(0,z.jsx)(`button`,{type:`button`,className:`push`,onClick:()=>void o(`open-permissions`),children:`Open in Lumi…`})}),(0,z.jsx)(U,{label:`Welcome Tour`,help:`Hearing the call, the speech model, your calendar, your name and keys.`,children:(0,z.jsx)(`button`,{type:`button`,className:`push`,onClick:()=>void o(`open-welcome`),children:`Welcome Tour…`})})]}),a&&(0,z.jsxs)(`div`,{className:`about-copy`,children:[`© `,a,` `,i]})]}):(0,z.jsx)(K,{})]})})})}function J(e,t,n){return e.key!==`Escape`||e.isComposing||e.defaultPrevented||e.metaKey||e.ctrlKey||e.altKey||e.shiftKey||t?null:n?`leave-field`:`close`}var Y=`.scrim, .menu, [role="menu"], [role="dialog"], .naming, .keycap.rec`,X=`input:not([type="checkbox"]):not([type="radio"]):not([type="range"]):not([type="button"]), textarea, select, [contenteditable="true"]`,re=680,ie=300,ae=760,oe={speakers:465,summaries:520},se=10,ce=16,le=`Meeting Notes Settings`,ue=2600,Z=`settingsPane`,Q={general:{label:`General`,icon:(0,z.jsx)(S,{size:20,strokeWidth:1.6,"aria-hidden":`true`})},transcription:{label:`Transcription`,icon:(0,z.jsx)(f,{size:20,strokeWidth:1.6,"aria-hidden":`true`})},captions:{label:`Captions`,icon:(0,z.jsx)(p,{size:20,strokeWidth:1.6,"aria-hidden":`true`})},translation:{label:`Translation`,icon:(0,z.jsx)(d,{size:20,strokeWidth:1.6,"aria-hidden":`true`})},summaries:{label:`Summaries`,icon:(0,z.jsx)(y,{size:20,strokeWidth:1.6,"aria-hidden":`true`})},speakers:{label:`Speakers`,icon:(0,z.jsx)(k,{size:20,strokeWidth:1.6,"aria-hidden":`true`})},storage:{label:`Storage`,icon:(0,z.jsx)(D,{size:20,strokeWidth:1.6,"aria-hidden":`true`})},about:{label:`About`,icon:(0,z.jsx)(b,{size:20,strokeWidth:1.6,"aria-hidden":`true`})}};function $(e){return typeof e==`string`&&a.includes(e)}function de(){try{let e=localStorage.getItem(Z);return $(e)?e:`general`}catch{return`general`}}function fe(){let[e,t]=(0,A.useState)(de),[n,c]=(0,A.useState)({}),[d,f]=(0,A.useState)(null),[p,m]=(0,A.useState)(0),[h,y]=(0,A.useState)(()=>Date.now()),[b,S]=(0,A.useState)(null),[C,w]=(0,A.useState)(``),T=(0,A.useRef)(0),E=(0,A.useRef)(null),D=(0,A.useRef)(null),O=x(),k=n.appearance;(0,A.useEffect)(()=>{k!==void 0&&v(k)},[k]),(0,A.useEffect)(()=>{let e=e=>{let t=e.target instanceof Element?e.target:null,n=!!t?.closest(X),r=J(e,!!document.querySelector(Y),n);r===`leave-field`?t.blur():r===`close`&&(e.preventDefault(),s({m:`close-settings`}))};return window.addEventListener(`keydown`,e),()=>window.removeEventListener(`keydown`,e)},[]);let j=(0,A.useCallback)(e=>{t(e),S(null);try{localStorage.setItem(Z,e)}catch{}},[]),M=(0,A.useCallback)(e=>{window.clearTimeout(T.current),w(e),T.current=window.setTimeout(()=>w(``),ue)},[]),N=(0,A.useCallback)(async()=>{let e=await s({m:`voices`});e.ok&&f(e.value)},[]),P=(0,A.useCallback)(async()=>{let e=await s({m:`list`});e.ok&&m(e.value.index.items.length)},[]),F=(0,A.useCallback)(e=>{let t=e?.pane;$(t)&&j(t)},[j]);(0,A.useEffect)(()=>{l().then(c),N(),P(),s({m:`settings-asked`}).then(e=>e.ok&&F(e.value));let e=[o(c),r(`lumi:voices`,()=>void N()),r(`lumi:message`,e=>F(e)),te(),r(`lumi:shown`,()=>{N(),P()})],t=window.setInterval(()=>y(Date.now()),3e4);return()=>{e.forEach(e=>e()),window.clearInterval(t)}},[N,P,F]),(0,A.useLayoutEffect)(()=>{let t=E.current;if(!t)return;let n=0,r=()=>{let r=Math.ceil(D.current?.getBoundingClientRect().height??g()),i=oe[e],a=i?r+se+i+ce:0,o=Math.min(ae,Math.max(ie,a,Math.ceil(t.scrollHeight)+r));o!==n&&(n=o,u(re,o))};r();let i=new ResizeObserver(r);return i.observe(t),()=>i.disconnect()},[e]);let I=(e,t)=>(c(n=>({...n,[e]:t})),i({[e]:t})),L=async(e,t)=>{let n=await s({m:`rename-voice`,voice:e,name:t});return n.ok?(N(),null):n.error},R=async e=>{let t=await s({m:`forget-voice`,voice:e});t.ok?M(`Voice profile deleted. Past meetings keep their speaker names.`):S({text:t.error}),N()};return(0,z.jsxs)(`div`,{className:`sw`,style:{"--bar":`${g()}px`},children:[(0,z.jsxs)(`header`,{ref:D,className:`sw-bar`,..._,children:[(0,z.jsx)(`h1`,{className:`sw-title`,children:le}),(0,z.jsx)(`nav`,{className:`sw-tabs`,role:`tablist`,"aria-label":`Settings`,children:a.map(t=>(0,z.jsxs)(`button`,{type:`button`,role:`tab`,"aria-selected":e===t,className:e===t?`sw-tab on`:`sw-tab`,onClick:()=>j(t),children:[Q[t].icon,(0,z.jsx)(`span`,{children:Q[t].label})]},t))})]}),(0,z.jsxs)(`main`,{className:`sw-pane`,role:`tabpanel`,"aria-label":Q[e].label,children:[(0,z.jsx)(`div`,{ref:E,className:`sw-measure`,children:e===`about`?(0,z.jsx)(q,{onError:e=>S({text:e})}):(0,z.jsx)(ee,{pane:e,values:n,voices:d,look:O,now:h,meetings:p,onSet:I,onRenameVoice:L,onForgetVoice:e=>void R(e),onReady:()=>void P(),onError:e=>S({text:e})})}),b&&(0,z.jsxs)(`div`,{className:`banner notice`,role:`alert`,children:[b.text,(0,z.jsx)(`button`,{type:`button`,className:`btn plain small`,onClick:()=>S(null),children:`OK`})]}),C&&(0,z.jsx)(`div`,{className:`toast`,role:`status`,children:C})]})]})}async function pe(){h();let e=document.getElementById(`root`);e&&(0,j.createRoot)(e).render((0,z.jsx)(A.StrictMode,{children:(0,z.jsx)(fe,{})}))}pe();
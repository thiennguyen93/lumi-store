# Changelog

## [Unreleased]

## [0.12.0] - 2026-11-21

### Added

- **Words While Speaking**, in Settings › Transcription: choose the model that writes the grey words while someone talks — Apple Speech, or Nemotron 3.5 Streaming, which hears both of a meeting's languages. Speech Recognition still writes each line when they pause, so the words come steadily and the graphics chip is mostly free for the call, though they're less accurate until the pause. Same as Speech Recognition, as before, is the default; a model not on this Mac downloads when you pick it, and a change applies from the next meeting. Needs Lumi 1.95.
- **Translate While Speaking**, in Settings › Translation: with Live Translation on, each sentence is translated before the speaker pauses, as before. Turn it off to translate only each finished line.

### Changed

- **Chat shows a line's actions as you point at it**: Play, Translate, Copy and More beside the bubble, as Paragraphs and Lines show them. The View popover's help is one line.
- **Click a line to play it**, and again to pause it, under the pointing hand; ⌘-click or ⇧-click selects lines. A click used to select and a double-click to play. A line with no audio still selects on a click.
- **Play is Pause while its line plays**, in every layout, and Play again goes on where it stopped. The bars that show a turn playing stand at the speaker's outer edge in Chat, and in place of the speaker's initial in Paragraphs and Lines, so nothing moves when a line starts or stops, and Name… coming and going under the pointer leaves no gap beside them.
- **Your own turns in Chat read "0:32 Me"**, your name at the bubble's edge as other speakers' names are at theirs.
- **Chat's bubbles stop at a comfortable line length** on a wide window — about 65 characters, at every text size.
- **Unlink a meeting's event by pressing it again** in the event menu, where it is ticked; None is gone.
- **In Live Captions, a speaker not known yet is three blinking dots**, as the main window shows words still being heard, where a still "…" stood.

### Fixed

- **A turn says which sentences are not translated yet.** In Chat and Paragraphs, a sentence with no translation shows Translate where its translation would be, a press away; half a turn's translation read as all of it.
- **A finished meeting opens at its start**, not on its last lines. A meeting being transcribed still follows what is said.
- **The bar for several selected lines no longer hides the last ones.**
- In Chat, words fade under the speaker's name as they scroll past it, rather than being cut at its edge.
- **The event menu fits what it holds.** With no event near the meeting it is its heading and Open in Calendar, no wider than they are.
- **With translations beside the words, each language's name stands over its column**, in Lines and Paragraphs. On a wide window the original language's name stood well left of its words.

## [0.11.0] - 2026-11-21

### Added

- **Merge speakers and assign lines.** When one person was heard as two, right-click a line and choose Merge “Speaker 3” Into, or press Merge… beside the speaker in the inspector. When a line went to the wrong person, Assign To moves it — or every selected line — to anyone in the meeting, to you, or to a New Speaker. Both have Undo, and both wait until the meeting ends.

### Fixed

- **Name… opens its card whole**, in the transcript over the turns below it — upward near the transcript's foot — and in the inspector, with no scrollbar of its own. In Lines, a turn's header now holds at the top as you scroll, and its text follows View's size.
- **Listen Again keeps My Voice.** On a call heard again, someone beside you at your microphone was folded into your lines as Me; now, as in Live Captions, only your voice is Me and anyone else there stays their own speaker. In a room, your lines are Me too.

## [0.10.0] - 2026-11-21

### Added

- **A Welcome tour on a fresh install.** The microphone and system audio, your language and its speech model (downloading in the background), your calendar, your name, Keep Audio and summaries, and the keys that start a meeting. Again from Settings › About › Welcome Tour….
- **Pin and folders.** Right-click a meeting to Pin it or Move To a folder, or drag it there. New Folder (⇧⌘N) is named in place, folders keep the order you drag them, and Delete Folder keeps its meetings, with Undo. Sort By date, title or length. The meeting being transcribed stays at the top, in Now.
- **Export… (⇧⌘E) makes a PDF, HTML, Markdown or plain text file** from one sheet: a template — Standard, Minutes or Columns — and the paper; the summary, any version of it, or Summarize… or Regenerate… there; the transcript refined or as heard, its translations (Translate… if there are none yet) and timestamps. Customization names you another way in that file, or leaves out the AI models' names. The preview is the file: PDF and HTML zoom, Markdown and plain text copy — Markdown's Formatted view as rich text. An HTML file has its own Light, Dark and System. Every file ends with "Made with Lumi Meeting Notes". Saved, the message names the file and its folder, with Show in Finder.
- **Your Name in place of "Me"** in every meeting, earlier ones too: Settings › Speakers › Your Name.
- **Quick Translate.** In a meeting with nothing translated, the translate button translates it at once into your Settings' language with your translator, a ring round it showing how far.
- **Meetings named after their calendar events** (Settings › General › Calendar). The event button beside the date links another event or opens it in Calendar; the inspector shows who was invited. Reads your calendar, never changes it.
- **Offers for meetings in a room** as a calendar event with a place starts (Settings › General › Offer For › In-Person Meetings); a call still heard 5 minutes after its event ends offers Stop and Save.
- **Add to Reminders** from the Action Items heading: the items you tick, with a date. Done in Reminders shows done here.

### Changed

- **The sidebar slides** out and in (⌘B), its button beside New Folder.
- **The window shows its name**, Lumi Meeting Notes, at the middle of its title bar.

### Fixed

- **Settings › Storage** gives the transcripts' size without the audio, always shows the Audio section, and Delete All Audio works with hundreds of meetings.
- **Messages** stay at the middle of the window's foot.
- **The Summary tab** shows a spinner, not No Summary Yet, while the summary is read.

Needs Lumi 1.94.0.

## [0.9.0] - 2026-11-20

### Added

- **Refine and Translate.** In the Transcript tab, Refine and Translate… cleans up a meeting that has ended. Light takes out ums and words said twice, on this Mac, with no AI. Full also fixes punctuation, grammar and your Custom Vocabulary terms with the text model you choose, and leaves out any change that would alter what was said. Translate All translates every line not yet translated, or all of them again once every line is. The sheet says how long it takes and which AI calls go where before you start; Stop keeps what's done.
- **Original, Changes and Refined.** See the refined words, what refining changed — taken out struck through, put in underlined — or the words as heard. Revert to Original puts lines, or the whole meeting, back as heard. ⌘Z undoes the last refine or revert, and ⇧⌘Z redoes it. Copy and Export take the version shown.
- **Listen Again.** Hears a meeting's kept audio again with a stronger speech model on this Mac, for truer words and speakers: on a call your lines stay Me, and someone the live transcript mixed up is told apart. The words heard live stay as Original, and the summary's times follow the new lines.
- **Meetings clean themselves up as they end.** Settings › Transcription › After a Meeting: Light by default, for meetings of 3 minutes or more; Full and Listen Again can follow, with the models you choose.
- **Volume in the player.** A speaker button mutes playback; hover over it for a volume slider.
- **⌘B shows or hides the sidebar.**
- **A Changelog tab** beside About on Meeting Notes' page in Lumi's Settings.

### Changed

- **Start Transcription shows Live Captions and closes the Meeting Notes window**, wherever you press it, so you follow the meeting over the call; open Meeting Notes again to read along. To keep the window, set Settings › General › When Transcription Starts to Keep Window Open.
- **Show Translations beside View.** A translate button shows or hides translations, and turns Live Translation on or off while a meeting is heard.
- **Summary choices wait for Regenerate.** A new template, model or language no longer rewrites the summary at once.
- **Icons in the meeting menus**, as macOS menus have them.

### Fixed

- **Settings… opens Meeting Notes Settings.** With the Meeting Notes window in front, Meeting Notes › Settings… and ⌘, open its Settings window and leave the window where it is.
- **The View and date popovers open over the transcript**, no longer under a speaker's name held at the top.

## [0.8.2] - 2026-11-20

### Added

- **Escape closes Settings.** A menu or a sheet open in it, a shortcut being recorded, or a field you're typing in takes Escape first; press it again to close the window.

### Changed

- **A summary writes itself in as the model writes it.** While the transcript is read, the Summary tab shows what's happening where "No Summary Yet" stood, with Stop, and a long meeting's progress fills the ring round its mark. When the model starts writing, the mark moves up to a line that stays at the top as you scroll, and the overview and each item appear as they're written. Regenerate keeps the summary you have, dimmed, until the new one starts.
- **Live Translation keeps up with a long turn.** Each sentence is translated as soon as it's said, while the speaker goes on, instead of once they pause; the rest of the caption follows when it ends. A sentence heard differently a moment later is translated again. With macOS translating (Settings › Translation Engine), the words still being said are translated too, dimmed, and replaced as more is said, then by the caption's own translation when it ends; the AI is never asked for these.
- **Live Captions are ready from the moment Lumi starts**, as the menu bar item's panel is, so the first meeting shows them at once. Lumi's Preload switch for Meeting Notes covers them too.
- **Live Captions step out of the way while you're in the Meeting Notes window watching the meeting being heard**, since the window already shows its words, and come back over every app as soon as you switch to another app or close the window (closing needs Lumi 1.93.0). Start or Resume pressed in the window starts the meeting from there, without the captions flashing up first. Captions you hid yourself stay hidden, and they stay put while Live Translation is by the AI.
- **A meeting is summarized by itself as it ends.** Settings › Summaries' Automatically Summarize When a Meeting Ends, on unless you turn it off, writes the summary with the Default Template as the Meeting Notes window opens on a meeting of 3 minutes or more, in place of Offer to Summarize; Lumi's card at a call's end offers Resume. Set as Default under Templates picks the template.
- **Templates says which are built in**: they're listed under BUILT-IN, yours under YOUR TEMPLATES. A built-in opens with View…, and − says why it can't delete one.
- **The menu bar item's panel has no Live Captions or Live Translation switch any more.** Show Live Captions appears there while you record and the captions are out of sight, and the Meeting Notes window's translate button turns Live Translation on and off while it shows the meeting being heard.
- **A meeting that ends opens in the Meeting Notes window**, and Live Captions go away, instead of staying up to say it was saved: stopped, ended after a pause, or stopped by itself when the call ended.

### Fixed

- **The menu bar item no longer goes on showing a recording after it stopped**: now and then its wave kept moving beside a clock standing at the meeting's last second, with nothing being heard.

## [0.8.1] - 2026-11-19

### Changed

- **A long Chat bubble's speaker stays in sight across the column**, on a band in the window's own background at the top of the transcript, with the words passing under it, instead of floating over them.

### Fixed

- **The inspector's speakers no longer look switched off.** They were drawn at a faint strength, as were Save Voice Profile and a summary template's fields; they're at full strength now, their checkboxes drawn as a Mac's, and a speaker you uncheck is dimmed so the ones shown stand out.
- **Nothing shows above what stays at the transcript's top**: a sliver of words used to peek over a held turn's header or a bubble's speaker.

## [0.8.0] - 2026-11-19

### Added

- **Choose how the transcript reads.** View, beside the tabs, lays it out as Chat (bubbles, yours on the right, as Messages draws them), Paragraphs or Lines, with translations below the words or side by side, four text sizes (⌘+ ⌘−), and Timestamps, Follow Along While Playing and Speaker Colors.
- **Select lines and act on them.** Click, ⇧- or ⌘-click, or ↑ ↓; ⌘C copies, ⌘A selects all, Return plays. Several selected get a bar with Play, Copy and Translate; right-click for Copy with Names and Times, Select Whole Turn, Name and Hide. Name… beside an unnamed speaker names them right there.
- **Follow along while it plays**: the line heard is lit and kept in sight; scroll away and Back to Now Playing returns to it.
- **See who spoke where on the player's scrubber**: point at it and the turn under the pointer lights up, with a tooltip naming the speaker, the time a click plays from, and when the turn starts and ends. ⇧-click plays the turn from its start.
- **Appearance in the toolbar**: a click goes System, Light, Dark; right-click to pick one. The same setting as Settings › General.
- **Every speech model that heard a meeting**, with when it took over, in Details, under the title and in exports.
- **Search finds what was said** in every meeting's transcript, translations and summary. The sidebar shows the meetings that hold your words, their matches and two of their lines: click one to open the meeting there. Without accents a word finds every accent ("hop" finds họp, hộp and hợp); quotes keep a phrase in order.
- **Move from match to match** with ‹ › beside the search, Return or ⌘G (⇧⌘G back), the summary's matches included; each tab says how many it holds. ⌘F goes to the search.
- **Click Through Captions**, in Settings › Live Captions: the captions' text lets clicks, scrolls and hovers through to what's under it; the bar and the panel's edges still take them.
- **Keys for Start, Pause and Stop Transcription**: ⌃⌥⌘1, ⌃⌥⌘2 and ⌃⌥⌘3 in every app, as the menu bar item's rows. Change or clear them in Settings › General › Shortcuts.

### Changed

- **Transcript and Summary are two tabs** under the meeting's title, ⌘1 and ⌘2; the title heads the page over the date and who spoke. Point at a summary's time to read its lines; click it to see them in the transcript, and Back to Summary (⌘[) to return. The player stays under both tabs, and a meeting opens on the tab you left. ⌥⌘S is gone with the pane.
- **The transcript opens as Chat**, headed by when it was heard, the model and the language, with quiets of 15 s or more said between turns. A long bubble keeps its speaker's name in sight as you scroll through it.
- **A meeting where nothing was said says so**, in place of the tabs.

### Fixed

- **Stop on a paused meeting shows it saved** in the window open beside it.
- **The toolbar's buttons work while the search is open**, and the empty field stays open, so the toolbar doesn't move under your pointer; click elsewhere or press Escape to close it.
- **Share is off when there's nothing to share**, as Show Translations is.
- **A meeting is named by the first speech model that heard it**, not the one a change left it on.
- **A narrow transcript stays readable**: translations go under the words, and Lines lets its buttons go.

## [0.7.0] - 2026-11-19

### Added

- **Summarize a meeting.** A Summary pane under the transcript writes an overview, the action items and the sections of a template — General, 1:1, Stand-up, Interview, Customer Call or one of your own — each item with the time it was said: click the time to see those lines in the transcript. Template, model and language are right above it; choosing another writes a new version, and the one before stays a click away with your edits. Edit any item in place, tick action items, choose who owns them; Copy Summary and Copy Action Items paste as Markdown. The summary is written by the text model you set up in Lumi, on this Mac or online — Lumi asks before anything leaves it — and the meeting takes the summary's title while it still has the one Meeting Notes gave it. Drag the pane taller or shorter, make it larger, or fold it away with ⌥⌘S. Needs Lumi 1.92.0.
- **Long meetings are read in parts** when the model you chose can't read them whole, then put together, with a bar of how far it got, the time left and Stop. A stretch that couldn't be read is said at the top of the summary.
- **No text model yet?** Summarize offers one to download, in Lumi's own panel, and goes on once it's ready.
- **Settings › Summaries**: the Text Model, the template and language a summary starts with, and your own templates — a name, instructions, and the sections you want in your order.
- **Summarize from the card when a call ends.** For notes of 3 minutes or more, Lumi's card offers Summarize instead of Resume, and the window opens on the meeting writing it. Turn it off in Settings › Summaries.
- **Exports include the summary.** Export as Markdown or Plain Text puts the summary ahead of the transcript, each item with the time of what it came from; Share › Copy Summary copies it.

### Changed

- **The player is a bar at the foot of the transcript**, in the same place whatever the window shows, with no Close; Space plays and pauses.
- **Scroll to Top and Scroll to Bottom** appear as you scroll a long transcript or summary; Home, End, ⌘↑ and ⌘↓ go there too.
- **Alerts' buttons are drawn as macOS's**, one line each.
- **Live Captions step back while you work in Meeting Notes.** With the Meeting Notes or Settings window in use, the captions no longer cover it: they go behind it, and float over every app again as soon as you go back to another app, or when you click them. Needs Lumi 1.91.0.

### Fixed

- **Menus are drawn in macOS's appearance.** The model pop-ups' menus in Settings, their submenus and Live Captions' ⋯ menu follow macOS's light or dark, as a Mac menu does; they used to follow Lumi's Appearance where you had set it apart from macOS.
- **Live Captions stay in sight over an app in full screen.** They now follow you onto every desktop and over every app in full screen; they used to stay behind on the desktop the meeting was started from, so a call watched in full screen showed no captions.

## [0.6.0] - 2026-11-18

### Added

- **Escape hides Live Captions** once you have clicked the panel, as its Hide button does; with its ⋯ menu open, Escape closes the menu first.
- **Choose and download models in Settings.** Speech Recognition, Speakers Model and Text Model are pop-ups that offer every model Lumi knows: ready on this Mac or online — Lumi Models, Apple Speech, apps such as Ollama and LM Studio, services you have a key for, Claude Code — the ones Lumi can download, with their sizes, and the ones that can't run here, saying why. A provider's models, and the ones that can't run here, open in a submenu beside the menu, as a Mac menu's do. Lumi asks before anything is downloaded; it comes down with a bar, with Cancel where the download can be stopped (macOS's own language downloads can't be), and Meeting Notes uses it once it's ready. Transcription's On This Mac shows the speech model, the speakers model and the translation together. Your choice is kept by Lumi, which shows it under Settings › AI › Extensions & Privacy, where Use My Default puts it back. Needs Lumi 1.90.0.

### Changed

- **Settings shows its name on the title bar's top row**, Meeting Notes Settings, beside the window's buttons, with the panes' buttons under it, as a Mac app's settings window does; it stays the same whichever pane is open.

## [0.5.0] - 2026-11-18

### Added

- **Record Your Voice in English or Vietnamese.** Switch the text to read between English and Tiếng Việt; it starts in your Spoken Language, and Meeting Notes listens in the language you read.

### Changed

- **The Meeting Notes window keeps up with Live Captions.** A meeting being recorded shows in the window as Live Captions shows it, the line being said included, the moment it changes — speaker names and translations too — instead of up to half a minute behind. Needs Lumi 1.90.0; with an older Lumi the window catches up as before.
- **Open Meeting Notes in Live Captions' ⋯ menu opens the meeting being recorded** — or the one paused — rather than whichever meeting the window showed last.

### Fixed

- **Notes stop when the call ends, however you started them.** Notes started with Start Transcription, the menu or a shortcut during a Teams, Zoom, Google Meet or other call now stop and save when that call ends, as notes started from the "Take Notes" offer always did; they used to go on after the call. And notes started after one call has ended are no longer stopped because of it.
- **Record Your Voice is seen whole.** The Speakers pane keeps Settings tall enough for it, so it no longer runs off the bottom of the window; and should its text ever be longer than the window, the text scrolls between the title and the buttons, so Record, Stop and Save stay in reach.

## [0.4.0] - 2026-11-18

### Changed

- **Live Captions move smoothly.** New words glide the captions up instead of jumping them a line at a time; a line heard again shorter no longer pulls everything back down, and only the words a correction changed fade in — words it drops from the end fade out, and words it moves fade back in where they now stand rather than sliding — so you keep your place while reading. Latest glides back down too. With Reduce Motion on, the captions move as before.
- **Live Captions keep their size for a notice.** A notice — a language pack to download, Lumi's recording limit — floats over the top of the captions instead of making the panel taller, so the newest line stays in sight and the panel stays where you put it.

### Fixed

- **A speaker's name held at the top of Live Captions stays put** while their long turn is still being heard; it used to drop and slide back each time the line changed.

## [0.3.0] - 2026-11-18

### Added

- **Meeting Notes in Applications**: open it from Spotlight, the Dock or Launchpad, and its window opens, ready to start a meeting. Opened while Meeting Notes is switched off, it switches it on first.
- Needs Lumi 1.89.0.

## [0.2.0] - 2026-11-18

### Changed

- **A new look, after Apple's design guidelines.** The window keeps your meetings on a floating sidebar, the open meeting's commands as toolbar buttons, and its details, speakers and translation in an inspector; the player floats over the transcript, with skip, speed and Mute Me.
- **Start Transcription is at the foot of the sidebar.** While a meeting is recorded it becomes the recording time with Pause and Stop — click the time to go back to the meeting from any other.
- **Settings has a window of its own**, with panes for General, Transcription, Captions, Translation, Speakers, Storage and About.
- **Live Captions stay out of the way.** While you read, the panel shows the captions, the recording time and Lumi's mark — nothing else. Point at it and the controls come in: click the red time to stop. The panel keeps its size, is frosted glass in its own appearance and turns solid under the pointer.
- **Translate a caption** from the button it shows when you point at it.

### Added

- **Copy one line**, with who said it, from its hover buttons or its menu.
- **Open the meeting being recorded** by clicking its card in the menu bar panel.
- **Full screen**: the sidebar's button and the recorder move into the corner the window buttons leave.

### Fixed

- Meeting Notes no longer asks Lumi for too much at once every time a meeting being recorded is saved.

## [0.1.0] - 2026-10-25

### Added

- **Live captions for your meetings**, in a panel that floats above your call: what is said, as it is said, with **speaker identification** — saved voice profiles by name, everyone else as Speaker 1, 2, 3 — and your own lines as Me.
- **Meetings in two languages**: set a Second Language in Settings, and each line is written in whichever of the two it was said in. Translation translates each line from its own language and leaves the lines already in the language you translate into.
- **Translation on request**: click a caption to translate it, or turn on **Live Translation**, with Apple Translation on this Mac or the AI model you set up in Lumi.
- **Every meeting saved as a transcript** in the Meeting Notes window, to read, copy or export as Markdown or plain text.
- **Read what one speaker said**: click a speaker above a transcript to show only their lines, click others to add theirs, and Reset shows everyone again. The chevron beside a speaker names it, right there.
- **Voice profiles**: name a speaker during or just after a meeting and save the profile, and Meeting Notes identifies them in every meeting after.
- **My Voice**: record your own voice in Settings, with the steps and a text to read, so in a call your lines are Me and anyone else heard by your microphone is shown as another speaker.
- **Listen back to a meeting**: with Keep Audio on, each meeting's audio is kept with its transcript. Click a line's time to hear it from there, the line being heard lit, at 1×, 1.5× or 2×, and in a call **Mute Myself** plays it without your microphone; Save Audio… writes it as an .m4a, into a folder you choose in Settings or wherever you pick. Delete All Audio in Settings removes it and keeps the transcripts.
- **Long meetings**: a recording runs up to two hours by default; set **Longest Recording** in Settings, up to eight hours, and **Auto-Resume at Recording Limit** goes on in the same meeting once it is reached.
- Hints as you point at a button, a speaker or a caption, and why a button is off — in the captions panel too.
- **Notices a meeting starting**: when Microsoft Teams, Zoom, FaceTime or another call app — or Google Meet, Teams or Zoom in a browser — starts using your microphone, a **Take Notes** button comes up at the top right of your screen. Meeting Notes never starts by itself. When the call ends, the notes stop and are saved, with **Resume** if it was too soon — or it asks first, or keeps recording, as you choose in Settings, where each call app has a switch (Slack is off, since it holds the microphone outside huddles too) and the meeting sites are a list you can edit.
- Opens from its own menu bar item, or with ⌃⌥⌘M.
- Needs Lumi 1.65.0.

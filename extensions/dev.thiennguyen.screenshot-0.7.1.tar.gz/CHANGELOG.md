# Changelog

## [0.7.1] - 2026-10-08

### Added

- A short demo video on Screenshot's page in the Extension Store and on lumikeys.app — capturing, marking up and copying text — to watch before you install.

## [0.7.0] - 2026-10-06

### Added

- Double-click a preview card's title to enlarge it, and again to put it back — what Space does.

## [0.6.9] - 2026-10-05

### Added

- Hide the editor while capturing, on by default (Settings › Editor): while you drag out an area or point at a window, the editor and the previews step out of the way, and come back where they were, with your marks, once you have chosen. It covers Screenshot's own captures, Recognize Text and Lumi's Copy Text from Screen.
- Lumi's Copy Text from Screen reads past the editor: the editor is never in the picture it reads, a whole-screen read included.
- An editor in full screen stays where it is and is captured as it is, since nothing is behind it.
- Select text (E): the picture's own text, read on the Mac. Drag across it a letter at a time, double-click a word, triple-click a line, ⌘A for all; ⌘C copies it. Copy All, Pixelate what is chosen, or every email address and phone number at once — in the status bar or on a right-click.

### Changed

- Capture on the editor's empty page keeps the window, rather than closing and opening it again.
- Settings: Preview is now Preview cards, and is never greyed out — it sets the cards Recognize Text and Recent Captures show as well.
- Welcome: the first scene starts on a bright desktop, shows a shortcut pressed, and only then dims for the capture. Two new steps show the editor: marking a capture up, and pixelating every email address and phone number in it with Select text.
- An editor in full screen starts its toolbar at the window's left edge, where the traffic lights no longer are.
- Needs Lumi 1.36.0, for stepping the editor aside and keeping it out of Lumi's own captures.

## [0.6.8] - 2026-10-04

### Added

- Marker (M): a highlighter drawn by hand — wide, see-through ink that leaves the words under it dark, in any colour, with Shift for a straight stroke along a line of text. A stroke drawn nearly straight lands straight, and level when it was nearly level; a wave drawn on purpose stays. Round or chisel tip, from Colour and stroke or ⌘↩.
- Open File and Open From Clipboard: a picture from a file picked in Lumi's Open panel, or whatever picture is on the clipboard, straight into the editor — from the menu bar menu, any Lumi shortcut bound to them, ⌘O and ⇧⌘V in the editor, and the editor's empty page (⌘V there too).
- Paste a picture onto the one being edited with ⌘V, or drop picture files onto it: each lands at its own size — smaller only when it would not fit — selected, to move, resize (it keeps its shape), delete or undo like any mark, and turns with the picture when that is rotated or flipped.
- Several pictures open in the editor at once, as tabs along the bottom: a capture, a file, a paste or a preview's Edit opens its own tab and never takes the place of one being marked up. Each keeps its marks, crop and undo; a dot shows the ones not yet copied or saved. ⌘1–⌘9 and ⌘⇧[ ⌘⇧] move between them, ⌘W or a tab's ✕ closes one; with marks not yet copied or saved it asks first: Save (Return) saves and then closes, Don't Save (⌘⌫) closes, Cancel (Esc) keeps it. Up to six: past that the oldest finished tab closes, and with none finished the new picture goes to the preview stack.
- Rotate and flip the picture, from the toolbar's Rotate and flip menu, or ⌘L and ⌘R as in Preview. Marks and the crop turn with it, as one step of undo; text and step numbers stay upright.
- Filled rectangles and ellipses: a Fill row in Colour and stroke, in a colour of its own — a solid box edged in another, or a block over something to hide.
- Pick colour (I): a loupe shows the pixels and hex under the pointer. Click or Tab copies it, a drag an area's average, ⇧Tab the darkest pixel nearby (text). ⌥ draws in it.
- Callout (K): a speech bubble with a tail. Drag from what it points at to where the bubble goes, then type; ⇧↩ for a new line. Drag the tail's tip to repoint it, a corner to resize it.
- Marks can cross the picture's edge: the canvas grows and shrinks to hold them, clear in a PNG. Off in Settings.

### Changed

- Highlight is now Highlight area, and Pixelate has an icon that shows what it does.
- A narrow editor window gives up tools before anything else: the ones without room move behind a ⋯ button — which wears the tool in use when it is one of them — then Save and Copy lose their words and the drag-out button goes. Undo, Redo, Save and Copy always stay. The status bar drops its hint, then the scale, the same way. The window stops narrowing at 480 × 360 points.
- The stroke slider reaches more than twice as thick as before.
- Needs Lumi 1.36.0, for reading a file and the clipboard's picture, and for a Save through the Save panel to say whether it was saved.
- A Save through the Save panel waits for the answer: a cancelled panel no longer counts as saved, in the editor or on a preview, and Save All on the preview stack goes on to the next picture once one is saved.
- The background's padding is a slider, from a thin border to a wide one, in place of three fixed sizes.
- Esc no longer closes the editor: it backs out one step a press — a stroke being drawn, then the selected mark, then the crop, then the tool in hand, back to Select. ⌘W closes a tab — the window with its last — and the red button closes the window. With pictures not yet copied or saved, the red button asks about each first, the way ⌘W asks about one.
- A press on the tool already in hand puts it down, as in Preview: back to Select, or from Crop to the tool before it. A tool's key only picks it.

### Fixed

- The note after a Copy shows the picture's thumbnail beside its size; Lumi's page policy refused the way it was loaded, and it showed an empty frame.
- Crops are as sharp as the capture.

## [0.6.7] - 2026-10-04

### Added

- Open Screenshot Editor, from the menu bar menu, its own key (⌘⇧8) or any Lumi shortcut bound to it: the editor on the last picture it had, or — before the first capture — a page that takes one straight into it.
- New tools in the editor: Line (L), Ellipse (O), Pen (P) for drawing by hand, and Spotlight (S), which dims everything outside the boxes drawn — several at once, overlaps left lit.
- The stroke is a slider, from a hairline to thick, rather than three sizes; dragged with a mark selected it restyles the mark, as one step of undo.
- Text can sit on a pill of its colour instead of being outlined: Colour and stroke → Text.
- A background for the picture: six gradients and flat colours, three paddings, the picture rounded and shadowed on it — in the editor, the copy, the file and the drag alike.
- Drag the edited picture straight into another app from the toolbar, as a PNG named the way Save would name it.
- The crop keeps its handles while the crop tool is out: drag a corner or a side, move it whole, see its size and thirds. Free, 1:1, 4:3, 16:9 and Original shapes; Return or Esc goes back to the tool before, and the editor then shows the picture as cropped — the crop tool brings the rest back to adjust it.
- Pinch or ⌘-scroll zooms about the pointer, and Space-drag pans.
- A mark is edited where it is: Colour and stroke change the selected mark, double-click a text — or click it with the text tool — to rewrite it, ⌘D duplicates, the arrow keys nudge (⇧ for ten), and Shift keeps an arrow or line to 45°, a box square and a move straight.

### Changed

- Deleting a numbered step renumbers the ones after it.
- Esc over marks not yet copied or saved asks for a second Esc before the editor closes.

## [0.6.5] - 2026-10-04

### Added

- A Welcome tour when Screenshot is installed or updated: allow Screen Recording (the tour waits for it), check each capture's key — and take one back from whatever holds it — choose what a capture leads to, and meet Recognize Text. Reopen it from Screenshot's About page in Lumi.

## [0.6.3] - 2026-10-04

### Added

- ↑ and ↓ walk the preview stack the way it stands on screen: they choose the card the keys act on — Space then enlarges it — and, while a card is enlarged, switch to the next one, the frame changing size and the pictures crossing as it does.
- A picture on a preview card sits on a backdrop — one of ten, picked at random for each capture and kept for it — inset with a corner and a shadow, rather than between grey bands where its shape is not the card's. Settings → Preview → Backdrop turns it off.
- An enlarged capture has a Recognize Text switch: the first press reads the picture, with the sweep a Recognize Text capture has, and boxes its lines on it — chosen in orange, copied with a double-click or ⌘C, and all at once with Copy, which copies the text while the lines show; after that it switches between the lines and the picture as taken. The text is kept with the card, and nothing goes on the clipboard until asked.

### Changed

- A window's card says it is a window first, then whose: "Window · Safari · 14:32" rather than "Safari · 14:32", which stood where "Area" stands and read as another way of capturing.
- A picture dragged out of a preview card is named the way the file-name setting names a saved one, such as "Safari Screenshot 2026-10-04 at 14.32.05.png", rather than "Image …".
- A card's time always has two digits for the hour, "01:59" rather than "1:59", which beside a picture read like an aspect ratio.

### Fixed

- A picture dragged out of a preview card drops into apps built on a browser engine — Claude, Slack, a browser's upload field — and not only into Finder. Needs Lumi 1.34.

## [0.6.2] - 2026-10-04

### Added

- Swipe a preview card away with two fingers on the trackpad, towards the edge the cards stand against — as a flick does with the pointer.
- `{app}` and `{title}` in the file name: the app a window belongs to and the window's title, such as "Safari - Start Page 2026-10-04 at 14.32.05.png". An area or the whole screen is nobody's window, and not every window has a title, so a token with nothing to say is left out, with the space or dash beside it.
- Drag a picture into another app by the icon at the left of its card's title.
- Enlarge a capture's card to look at it — its magnifier, or Space — as a Recognize Text card already could. The picture grows to the size it had on screen, made smaller only to fit; Space, Esc or the button puts it back. A card further up the stack slides down to the corner before it grows, and back to its own place after.

### Changed

- A window's card is titled with the app it belongs to, such as "Safari · 14:32", rather than "Window".

## [0.6.1] - 2026-10-04

### Added

- A Save button on a Recognize Text card, and ⌘S, to keep the picture the text was read from. Recognize Text never copies or saves the picture by itself — the text is what it is for.

### Changed

- Every preview card has a title of its own — what was captured and when, such as "Area · 14:32" — with Keep and Close beside it, so nothing is drawn over the picture or the first line of text any more.
- On a Recognize Text card, double-click a line to copy it, as on the enlarged picture; a single click says so instead of copying.
- Copy and Save on a preview card keep their own icon once done and gain a small green check, so it is clear which one happened.

### Fixed

- The ring marking the card your keys act on shows only while the preview has the keyboard, not whenever the pointer passes over it.

## [0.6.0] - 2026-10-03

### Added

- A Settings page of its own. Choose what a capture leads to — open the editor, copy, save, or any of them together — and one of them always stays on.
- Copy and Save can happen straight after a capture, with or without the editor.
- A preview instead of the editor: each capture lands as a card in a corner of the screen while you keep typing — Copy, Save, Edit, drag it into another app, or flick it away. Several captures pile up in the corner and fan out under the pointer, with Copy all, Save all and Close all for the whole pile. Each card closes by itself after a few seconds (or never), saving first if you like — pin one to keep it. Closed a card too soon? ⌘⇧0 shows the last few again, and hides them; bind Recent captures to a key of your own to show, hide or toggle them.
- Save pictures as PNG or JPEG, at full resolution or at screen size.
- Save straight into your Pictures folder, or one you choose, without the Save panel each time. ⌥⌘S in the editor still asks where.
- Name saved files the way you like, with the date and time filled in.
- Choose whether a window is captured with its shadow.
- Every capture, and the Settings page, from Lumi's menu bar menu.
- A shortcut for every capture: ⌘⇧2 an area, ⌥⌘⇧2 a window you pick, ⌘⇧1 the whole screen, ⌥⌘⇧1 the window in front.
- Recognize Text, on ⌘⇧9 and in the menu bar menu: drag over any text on screen and it goes straight to the clipboard, Vietnamese included. A card in the corner shows the lines it read — click one to copy just that line — and its magnifier (or Space) opens the picture large enough to read, every line boxed. There, choose lines the way you choose files — click, ⌘- or ⇧-click, drag across them, ⌘A — and ⌘C copies exactly those; double-click a line to copy it alone. An area with no text leaves the clipboard as it was.

### Changed

- Copy says only what it copied — the picture's size and how big the file is — without the timings it used to show beside them.
- Needs Lumi 1.34.0 or later.

### Fixed

- Copying many times in one editor no longer leaves each copied picture held in memory until the editor closes.

## [0.5.0] - 2026-10-01

### Added

- A window is captured with its shadow too: the shadow button in the editor shows it or leaves it out, at any point, without losing a mark.

### Fixed

- A window's rounded corners are transparent in the editor, as they are in the picture, rather than looking white: the editor's own shadow follows the picture's shape instead of a rectangle round it.

## [0.4.0] - 2026-10-01

### Added

- Capture a window by pointing at it: the window under the pointer lights up, and a click takes it.

### Changed

- Capturing the window in front, with no picking, is now "Capture the front window".

## [0.3.0] - 2026-10-01

### Added

- Capture an area you drag, the window in front, or the whole screen, and edit it straight away.
- ⌘⇧2 captures an area.
- Copy puts the edited picture on the clipboard; Save offers it as a file.

## [0.2.0] - 2026-09-30

### Added

- The editor: crop, arrows, boxes, highlights, pixelation, text and numbered steps, with undo, zoom, and copy or save of the result.
- The editor's toolbar is its title bar.

## [0.1.0] - 2026-09-30

### Added

- The extension's frame: a command that opens the editor window.

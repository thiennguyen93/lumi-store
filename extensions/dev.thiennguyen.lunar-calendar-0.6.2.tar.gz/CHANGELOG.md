# Changelog

## [0.6.2] - 2026-11-04
### Sửa
- Liên kết trang web trong trang Giới thiệu của Âm Lịch Việt Nam trong Lumi mở trang của tiện ích trên lumikeys.app. Trước đây nó mở một trang không còn tồn tại.

## [0.6.1] - 2026-11-04
### Thay đổi
- Ô Tên khi thêm một ngày gợi ý "Sinh nhật con gái" thay cho "Giỗ bà nội"; ngày ví dụ trong cửa sổ Chào mừng cũng đổi từ ngày giỗ sang một ngày sinh nhật.

## [0.6.0] - 2026-10-22
### Thêm
- Ngày âm hôm nay hiện ngay trên menu bar, cạnh biểu tượng Lumi, kèm hình trăng: `12/9`, sang ngày mới thì tự đổi. Bấm vào để mở các dòng của Âm Lịch; trỏ chuột vào để xem cả thứ, ngày dương và năm Can Chi. Ẩn được trong bảng Quyền của tiện ích trong Lumi.

## [0.5.1] - 2026-10-22
### Thay đổi
- Hình minh hoạ trong cửa sổ Chào mừng dùng ngày thật hôm nay: tờ lịch, dòng menu bar, số ngày đến Tết, và ngày dương sắp tới của các ngày giỗ ví dụ.

## [0.5.0] - 2026-10-21
### Thay đổi
- Cửa sổ Chào mừng làm lại thành một chuyến đi qua năm bước, có hình minh hoạ chuyển động: phím mở lịch (đổi được ngay tại đó), chọn kiểu lịch, lướt lịch bằng trackpad và phím, Ngày của tôi. Cuối cùng là nút Mở lịch.

## [0.4.1] - 2026-10-21
### Sửa
- Theo trăng: tháng đang xem không còn ghi tên hai lần (tiêu đề và dòng ranh giới); tên tháng chỉ hiện ở tháng kế bên dưới.

## [0.4.0] - 2026-10-21
### Thay đổi
- Cuộn chuột hoặc vuốt trackpad thì lịch trượt theo tay, có quán tính như cuộn trang, thay vì nhảy từng trang: Tờ lịch và Lịch treo tường cuộn dọc qua các tuần, Theo trăng cuộn dọc qua các tháng âm, Canh giờ trượt ngang qua các tuần. Dừng tay thì lịch nằm gọn một hàng tuần (hay một tháng âm, một tuần).
- Tiêu đề đổi theo tháng đang xem; ngày của tháng khác làm mờ, ngày mùng 1 ghi kèm tháng.
- Nút ‹ ›, ⌥← ⌥→ và Hôm nay cuộn mượt tới nơi.

## [0.3.0] - 2026-10-21
### Mới
- Cuộn chuột hoặc vuốt trackpad trên lịch để lật trang: Tờ lịch, Lịch treo tường và Theo trăng cuộn dọc để đổi tháng, Canh giờ vuốt ngang để đổi tuần. Mỗi nấc chuột, mỗi lần vuốt là một trang.

## [0.2.0] - 2026-10-21
### Thay đổi
- Qua 0 giờ, dòng ngày âm và số ngày đến Tết trên menu bar tự đổi sang ngày mới, lịch đang mở cũng vậy. Trước đây phải mở lịch hoặc Copy thì mới đổi.
- Hôm nay tính theo múi giờ của máy Mac. Đổi múi giờ (đi nước ngoài chẳng hạn) thì menu bar và lệnh Copy đổi theo ngay, không cần mở lịch.
- Cần Lumi 1.59.0 trở lên.

## [0.1.1] - 2026-10-21
### Thay đổi
- Lời giới thiệu trên store, trong cửa sổ Chào mừng và ảnh store viết lại cho tự nhiên, nói thẳng lịch làm được gì.

## [0.1.0] - 2026-10-21
### Mới
- Lịch âm Việt Nam trong một panel ở góc trên bên phải: bấm ⌃⌥⌘L, chọn trong danh sách lệnh, hoặc mở từ menu bar.
- Bốn bố cục để chọn: Tờ lịch (mặc định), Lịch treo tường, Canh giờ và Theo trăng.
- Tab Cài đặt ngay trên lịch (⌘4), cùng các cài đặt như trong Settings của Lumi.
- Ngày âm trên từng ngày của tháng, đánh dấu Mùng 1, Rằm và các ngày lễ; chọn một ngày để xem Can Chi, giờ hoàng đạo và tiết khí.
- Đổi ngày dương sang âm và ngược lại, kể cả tháng nhuận.
- Ngày của tôi: ngày giỗ, sinh nhật âm lịch, tự tính ra ngày dương mỗi năm.
- Giao diện: kính tối, kính sáng hoặc theo macOS, và độ trong của nền từ kính đến đặc (mặc định là đặc, để chữ dễ đọc).
- Ngày âm hôm nay và số ngày đến Tết trong menu bar của Lumi, kèm lệnh Copy ngày âm hôm nay.

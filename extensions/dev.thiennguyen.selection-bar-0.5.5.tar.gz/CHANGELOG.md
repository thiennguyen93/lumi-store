# Changelog

## [0.5.5] - 2026-10-20

### Fixed

- **Search's results and the dictionaries on the web show again with a solid background.** With **Background transparency** moved toward Solid, the Search card and the Oxford and Cambridge tabs stayed dark where the site should be; the site now shows in its box, and the background is solid everywhere else.

## [0.5.4] - 2026-10-20

### Added

- **Glass or solid.** Settings › Look has **Background transparency**, a slider from **Glass** to **Solid**: the further toward Solid, the less the colours of the window under the bar show through it, so it reads the same over anything. The preview and the Look tiles follow it as you drag.

## [0.5.1] - 2026-10-19

### Added

- **Search shows its results in the bar.** Press Search and the bar grows into a card with the search site's results for what you selected — scroll them, follow a link, Reload, or press Browser to carry on in your browser — without leaving the app you're in. Search's gear in Settings has **Show results**: **In the bar**, or **In your browser** as before.

### Fixed

- **Define's tabs keep their whole names.** With more dictionaries than fit across the card, the tabs scroll sideways — swipe, or turn the mouse wheel over them — rather than each being cut short to a few letters. An end with more tabs past it fades out, and the tab you're on stays in view.

### Changed

- Needs Lumi 1.58.0.

## [0.5.0] - 2026-10-19

### Changed

- Needs Lumi 1.57.0, and Selection Bar now asks to reach the web. This version sends nothing anywhere it did not before.

## [0.4.1] - 2026-10-19

### Changed

- **Define's card keeps one height** whichever dictionary's tab you choose — the tallest tab's, up to its usual limit, a tab with more scrolling inside. Above the text, a card that grew and shrank with each tab moved its tabs out from under the pointer, and the next tab took a move of the mouse to reach.

## [0.4.0] - 2026-10-19

### Added

- **Define.** Select a word or a phrase and press Define to look it up in the dictionaries you turned on in the Dictionary app, in their order — a tab for each that has it. The card shows the word and its syllables, how it is said (US and UK where the dictionary gives both), and its senses under each part of speech, with examples and usage labels; a thesaurus shows synonyms and opposites, and a bilingual dictionary — Vietnamese – English, say — its translations, examples translated too.
- **Speak** says the word aloud with your Mac's own voices.
- **Copy** copies the entry, and **Dictionary** opens the Dictionary app at the word, with every dictionary's whole entry.
- Define shows for a word or a phrase of up to four words on one line, when at least one dictionary is turned on. Its gear in Settings lists the dictionaries it looks in, and opens the Dictionary app, where its Settings turn on others.
- Looked up on this Mac: nothing you select leaves it for Define, and nothing is kept.

### Changed

- Needs Lumi 1.55.0.

## [0.3.27] - 2026-10-19

### Fixed

- **Count** under ⋯ shows the words, characters and lines when you press it, as Count's button on the bar does. Pressed there — when the bar had no room for it, on either bar — it seemed to do nothing.

## [0.3.26] - 2026-10-18

### Added

- **AI answers drawn as they are meant to read.** What a model writes when it answers Ask…, explains or summarizes — headings, **bold** and *italic*, lists inside lists, `code` and code blocks, quotes, tables, links — is shown formatted on the card, as it comes, rather than with its asterisks and hashes. Code and a table wider than the card scroll sideways on their own. A link opens in your browser, web and mail addresses only. Copy keeps the formatting for apps that take it — Mail, Notes, a document — and gives the Markdown itself to anything that takes plain text. A fix, a rewrite or a translation is still shown exactly as it will be written over your text, and a reply as it will be sent.

## [0.3.25] - 2026-10-18

### Added

- A short demo video on Selection Bar's page in the Extension Store and on lumikeys.app — fixing, rewriting, explaining and translating the text you select, in the apps you use — to watch before you install.

## [0.3.24] - 2026-10-17

### Added

- **A Welcome tour**, opened when Selection Bar is installed or updated, and again from Lumi's About page. A small pretend Mac acts out each step above the words: Fix Spelling & Grammar marking and correcting a mail's mistakes one by one, Rewrite in a style — then the same answer asked again with another of your models, and more thinking, for that card alone — Explain, Reply… offering the ways to answer a message, Translate on this Mac, the second bar ⌥ holds, and the keys: the shortcut, 1–9, ↩. The bar in it wears your Look, Dark, Light or Match macOS. The models it names are yours, from Lumi's AI settings — or "Your model" where you have none — and its last step says whether one is set up for the AI actions, and where to set one up if not. The shortcut step says whether ⌃⌥⌘Space was free to take, and if something else holds it, offers to take it, to pick another key, or to leave it for later.

## [0.3.23] - 2026-10-17

### Added

- **Reply…** — for a message someone sent you. The AI reads it first and offers the ways you are likeliest to answer it, a few words each — "3 pm works for me", "Suggest 4 pm instead", "Ask what the review covers" — and a field to say your own. Pick one and it writes the reply along it, in the message's language and your voice, to copy and send. Back goes to the ways again, and ↻ on them asks for others. Its sheet has two sets of instructions: which ways to offer, and how to write the reply. However you word the first, the bar asks for the ways one a line, so they can always be listed; should none come back, the field is still there. The ways come in your Mac's language; the way you pick goes to the model with the message, as text to work on, never as instructions.
- **Text you can't edit**, under an AI action's Shows for: a message, a page — where Reply… shows, and where an action of your own can too.

### Fixed

- The Settings tab no longer says every AI action needs a model when Lumi has one. Lumi lets the tab ask the bar anything only while Settings is in front, and a tab loaded behind another app — Lumi reopening Settings as it starts, or a new version arriving — was refused, and showed what it could not read as none: no model, no translator, an empty sample bar. It now reads them again as Settings comes to the front, waits longer while the bar is busy starting, and until it knows, says nothing either way.

## [0.3.22] - 2026-10-17

### Added

- **Each bar its own settings for an action.** An action's gear on the While holding ⌥ tab opens its sheet for that bar: Use the main bar's settings, on at first, shows the main bar's settings dimmed — what the bar asks with, changed from the Main tab. Turned off, the bar has its own — instructions, model, thinking, when it shows and what its answer is for, Translate's translator and languages, Search's site — starting as a copy of the main bar's, so Fix Spelling & Grammar can ask a quick model on one bar and a careful one on the other. Turned back on, its own are kept for the next time it is turned off. Each sheet says at its top which bar it saves for, and the While holding ⌥ tab marks an action with settings of its own there. An action of your own keeps one name and icon on both bars.
- **Ask… chooses its model before the first question.** Under the question's field, the model it goes to and how hard it thinks — Ask…'s own — open Ask With: pick another model or thinking, Done, and the question asks with it, and the chat after it too.

### Fixed

- The model at the foot of an AI card is as tall as the card's buttons, and its corner follows the panel's: under Ask…'s first question, alone in its footer, it had shrunk to its text, its lit background against the panel's edge.

## [0.3.21] - 2026-10-17

### Fixed

- In Ask…'s chat, Return in the follow-up field sends the question again: the bar's own keys had taken it while the bar held the keyboard.
- The follow-up field shows its caret only while what you type goes into it. In an app that answers Accessibility nothing while the bar has the keyboard — Chromium and Electron apps, Visual Studio Code — reading the selection for the question lent the keyboard back to the app, and the field kept a caret that typing never reached: the bar went instead. With Lumi 1.55.0 the keyboard comes back to the bar once the question is asked, so typing goes on into the field; with an older Lumi, a press on the field gives it back.

## [0.3.20] - 2026-10-17

### Added

- **Ask… is a chat.** Once it has answered, a field under the answer takes the next question, and the model is asked it with the chat so far — your earlier questions with its instructions, its earlier answers after the selected text, as text to work on, never as instructions — so "which part?" or "make it friendlier" follow on. The card keeps every question and answer in turn, the newest last, as a messages app draws them — yours on the right in the accent colour, the model's on the left — each answer with a Copy of its own beside it — shown as you point at the answer, and on the latest until you point at another — that leaves the chat up — in place of the footer's Copy, which took the last answer and put the bar away — and ↻ asks the last one again with the same chat. The latest eight questions go with each, and of a long answer its first 3,000 characters. Like a translation, the chat goes when the bar does.

## [0.3.19] - 2026-10-17

### Changed

- In an AI action's sheet, an answer that is new text to copy no longer shows Write it over at once, Show what changed and How changes are marked, dimmed: they are gone until the answer replaces what you selected again, each keeping its choice. How changes are marked goes the same way while Show what changed is off. The sheet is shorter for it.

## [0.3.18] - 2026-10-17

### Added

- **Ask again with another model.** On an AI action's card, once it has answered, the model named at the bottom opens Ask Again With: pick another of the models you turned on in Lumi, and how hard it thinks — Off, Low, Medium or High, for a model that can — then Ask Again. The choice holds for that card, ↻ asking with it too, and the action keeps its own as its sheet has it. Translate's card does the same when the AI translates, as Translate Again With, and a language changed on the card keeps the model chosen.

## [0.3.17] - 2026-10-17

### Removed

- The Settings tab's AI section. It only said how many models Lumi has and which is the default: each AI action's sheet says which model runs it and whether it runs on this Mac, and with no model in Lumi, the AI actions' rows say they need one.

## [0.3.16] - 2026-10-17

### Changed

- Selection Bar's page in Lumi opens on Settings rather than About. Once you pick another tab, Lumi reopens it on yours until it quits.
- Show what changed and How changes are marked moved from the Settings tab's AI section into each AI action's sheet, under The answer, where they apply: only an answer that replaces what you selected is marked. Show what changed is each action's own now — on for Fix Spelling & Grammar and off for Rewrite, say. How changes are marked is still one choice for every action, chosen from a menu with a sample under it, from any of their sheets. Turned off before, Show what changed starts off for every action.

## [0.3.15] - 2026-10-17

### Fixed

- An AI action added with + in Settings could be missing from the list once its sheet closed, and a change made in an AI action's sheet could be lost: the action and the lists were saved apart, at the same moment, and Lumi kept only one of the two. They are now one save, as are Translate's choices and − taking an action off. An action lost that way has to be added again.

## [0.3.14] - 2026-10-17

### Fixed

- In Settings, switching the Actions list between Main and While holding ⌥ no longer moves the page up and down in a narrow window. How many actions go under ⋯ is now a small count on the preview's ⋯ itself, instead of words beside the samples that could wrap that row onto a second line, and the two tabs' notes keep the height of the longer.

## [0.3.13] - 2026-10-17

### Added

- **A second bar while ⌥ is held.** Under Actions in Settings, a new tab, While holding ⌥, chooses a second set of actions in an order of their own. Hold ⌥ while the bar is up and it shows them instead, ⌥ after Lumi's name at its start; let go and it shows the main ones again. Select text with ⌥ held and it comes up as the second bar at once. Each action shows only when it fits, and past eight the rest go under ⋯, on either bar; one with nothing for the selection shows only ⋯. An action can be on both bars, its gear's choices the same on each. Everything starts off, so ⌥ changes nothing until you turn some on. A menu opened from either bar stays that bar's until you go back. Needs Lumi 1.54.0 for ⌥ to be heard with the pointer resting; an older Lumi swaps as the pointer comes onto the bar with ⌥ held.
- Settings' Show the bar says that holding ⌘ as you select with the mouse keeps it away.

## [0.3.12] - 2026-10-16

### Fixed

- In Translate's sheet, with the AI translating, the two languages' Download… was dimmed and could not be pressed. It can now: the languages are macOS's, for every app, and the bar's too whenever the AI cannot be asked and macOS translates instead.

## [0.3.11] - 2026-10-16

### Changed

- Translate's choices — who translates, the two languages, and the AI's model, instructions and thinking — and Search's site moved from their own places on the Settings tab into a sheet of their own, opened by the gear on the action's row, as an AI action's is. The row says what is chosen: "For words · macOS", "For a short text · Google".

## [0.3.10] - 2026-10-16

### Fixed

- In Settings, a click on an action's name or the line under it turned the action on or off. A click anywhere on its row now only picks the row; the switch alone turns the action on or off.

## [0.3.9] - 2026-10-16

### Changed

- Scrolling a page with the arrow keys, Page Up and Down, Home, End or Space no longer puts the bar away: it follows the text as it does for the trackpad. In a text field those keys move the caret or type, and the bar goes as before. Needs Lumi 1.53.0.

## [0.3.8] - 2026-10-16

### Changed

- The bar opened with ⌃⌥⌘Space follows the text through a scroll too, as the one that comes up when you select does, instead of staying where it was. It keeps the keyboard throughout. In Chrome, Slack and other apps built on Chrome, which say nothing is selected while the bar holds the keyboard, it steps away while you scroll and comes back only if the app says again where the text is. Needs Lumi 1.53.0.

## [0.3.7] - 2026-10-16

### Changed

- Scrolling no longer puts the bar away. In apps that say at once where the text is — TextEdit, Notes, Safari and most of macOS — it moves with the text you selected, to the text's other side when there is no room. Where an app cannot say in time — Chrome, Slack and other apps built on Chrome — or the text scrolls out of sight, the bar steps away while you scroll and comes back beside the text when you stop, with whatever it was showing, such as a translation or an AI answer; if the text is out of sight by then, the bar goes. Needs Lumi 1.53.0; an older Lumi puts the bar away on a scroll, as before.

## [0.3.6] - 2026-10-16

### Added

- With the bar showing icons only, a button's name shows beside it the moment you point at it, or move onto it with the arrow keys: drawn as macOS draws a tooltip, above the bar or below it, away from the text you selected. Moving along the bar changes it at once; pressing a button or leaving the bar takes it away. Needs Lumi 1.53.0; an older Lumi shows no name.

## [0.3.5] - 2026-10-16

### Added

- **Translate with AI.** Under Translate in Settings, choose who translates: macOS, on this Mac and offline, or the AI you set up in Lumi, which is better at tone and idioms. The translation is written onto the card as the model writes it, with Stop, Copy and Replace, and the footer says which model translated and whether it ran on this Mac. Choose its model, and change its instructions and how hard it thinks with Edit…
- With the AI translating, a few words macOS cannot place are no longer asked about: the model tells their language, and the card says Detect Language. Choose the source on the card to tell the model instead.
- On a Mac before macOS 26, Translate now works with the AI. With no model turned on in Lumi, macOS translates whatever is chosen; Settings says which one runs, and why.

## [0.3.4] - 2026-10-16

### Fixed

- Translate in Slack, and in other apps built on Chromium, no longer says nothing is selected. Pressing it took the keyboard from the app, which then answered as if nothing were selected; Translate's card never needed the keyboard, and no longer takes it.

## [0.3.3] - 2026-10-16

### Changed

- An AI action's sheet is shorter: its title and its buttons stay put, and only the settings between them scroll, so Done and Cancel are always in sight. What a setting's name does not say is behind a (?) beside it, shown when you point at it; settings whose names say it all have none.

### Fixed

- Scrolling an AI action's sheet no longer shows the Settings page through it, in strips beside and above the settings, and the sheet no longer sits a little to the left of its frame.
- A (?) tip on a setting that waits on another, such as Write it over at once, is no longer see-through.

## [0.3.2] - 2026-10-16

### Added

- **How changes are marked**, under AI in Settings: GitHub's red and green backgrounds (the default), GitLab's, VS Code's — a background and a line through what went — or Track Changes, as Word and Google Docs mark a suggestion. Each is shown on the bar's own glass, as the card will show it.

### Changed

- What an AI answer took away is no longer greyed and struck through, which was hard to read: it is marked as the chosen convention marks it.

## [0.3.1] - 2026-10-16

### Added

- A **Changes** toggle at the top of an AI answer that replaces your text: the changes marked, or the answer as it reads. It starts as Show what changed in Settings has it, and changes only that card.

## [0.3.0] - 2026-10-16

### Added

- AI actions, on the AI you set up in Lumi: **Fix Spelling & Grammar**, **Rewrite** with a menu of styles, **Summarize**, **Explain** and **Ask…**. Each is a button on the bar like the rest, and shows only when it fits: Fix and Rewrite for text you can edit, Summarize for a longer text. Ask… is there to switch on.
- Actions of your own: + under the Actions list adds one, with a name, an icon and instructions of your own, such as composing a reply to a message you received.
- The answer comes onto a card beside the text as it is written. One that replaces what you selected — a fix, a rewrite — marks what it changed and offers Replace; new text — a reply, an explanation — offers Copy and is never written over what you selected. Stop, ask again, and see which model answered and whether the text left your Mac.
- Every AI action's instructions are yours to change, with its default one press away: the gear on its row in Settings opens them, with when it shows, what its answer is for, the language it answers in, the model it asks and how hard it thinks. Rewrite's styles are each a name and instructions of their own.
- Write it over at once: a fix or a rewrite written straight over the text, with no card first.
- Settings' AI section says whether Lumi has a model for the bar to ask, and whether answers mark what they changed.

### Changed

- Needs Lumi 1.52.0.
- Selected text leaves your Mac when you press an AI action on a model that runs online, and Lumi asks you first, unless you told it not to.

## [0.2.8] - 2026-10-16

### Fixed

- A section of Settings that stacks what it holds — the Look tiles, the apps the bar stays out of — is as tall as what it shows, never taller. A grid that fills its lines could be measured as if one item wide, and leave a tall empty space under it.

## [0.2.7] - 2026-10-14

### Fixed

- Back from macOS's download prompt, the bar stays exactly where it was. It came back a little lower, placed again from scratch.
- An answer that comes back after you have selected something else is dropped. Selecting text in another app while macOS's download prompt was up brought the card for the old text back beside the new selection; a press's tick could also put away a bar just shown for a new selection.

## [0.2.6] - 2026-10-14

### Fixed

- Back from macOS's download prompt, Translate's card no longer comes back a little too big for the bar, its right and bottom edges cut off — Try again among them. The bar measured the card while it was still rising into place, a touch smaller than it is.

## [0.2.5] - 2026-10-14

### Changed

- The buttons at the bar's edges take the bar's corner radius from Lumi, so they keep following its corners if Lumi ever rounds them differently.

## [0.2.4] - 2026-10-14

### Fixed

- A button lit at the edge of the bar — the way back in a menu, More, the last item, and on Translate's card its way back, Copy or Replace and the last language in a list — now rounds its outer corners along the bar's own. They drew a tighter curve inside the bar's corner.

## [0.2.3] - 2026-10-14

### Changed

- **Not in…** under ⋯ on the bar is now **Don't pop up in…**, and so is its section in Settings: selecting text in that app no longer brings up the bar, and the shortcut still does.

## [0.2.2] - 2026-10-14

### Fixed

- When Translate's card comes up, nothing on it is lit until you move the pointer. The language to translate into, where Translate had been, came up lit as if the pointer were over it. The same goes for a language list opening in the card, and for going back.

## [0.2.1] - 2026-10-14

### Fixed

- Going back from Translate's card to the buttons, the bar shrinks back to its own size and returns to its place beside the text. It used to stay as tall as the card, with the buttons at its top.

## [0.2.0] - 2026-10-14

### Added

- **Translate** on the bar: press it to read what you selected in your own language. The bar opens into a card with the translation, made on this Mac by the translator built into macOS. Nothing you select leaves your Mac.
- Text in your own language goes into your next one: on a Mac set to English in Vietnam, English goes into Vietnamese and everything else into English. Choose both in Settings → Translate.
- The card names both languages. Press either to choose another, from a list that shows which are on this Mac and which need downloading.
- **Copy** puts the translation on the clipboard. **Replace** writes it over what you selected, where the text can be edited.
- A word or two can be in several languages, so when the language isn't clear the card asks which it is.
- When a language isn't on your Mac yet, **Download…** opens macOS's own prompt, and the card shows the translation once it's there. Settings → Translate does the same for your two languages.
- Lines of a paragraph that was wrapped at a fixed width, as in text copied from a PDF, are translated as one sentence.
- Needs Lumi 1.51.0 and macOS 26. On an older Mac the bar offers no Translate.

## [0.1.20] - 2026-10-14

### Added

- Select text with the mouse in any app — drag across it, double-click a word or triple-click a line — and a small bar of actions shows up beside it. It never takes the keyboard from the app, and goes away when you click, type or scroll somewhere else.
- Nothing on the bar is lit when it comes up — not the button the pointer was last over, nor the first button when the shortcut opens it. The arrow keys light the button they move to.
- Escape backs out of the menus a level at a time — a group opened from More back to More, then to the bar — and then puts the bar away, also when the bar came up for the mouse: opening a menu gives it the keyboard.
- A menu with more items than fit, such as Case, keeps to a width and scrolls sideways: swipe on the trackpad or turn the mouse wheel. The way back stays put, and the ends fade where items are hidden. The first few times one opens, its items slide a little to the left and back, to show they scroll.
- The bar starts with Lumi's mark and name, so you can tell where it comes from. Menus opened in it keep their room for their items.
- After a double-click the bar waits a fifth of a second, in case a third click makes it a triple-click, so selecting a line by triple-clicking shows it once, not twice. With a slower double-click speed in macOS, it waits longer. In Settings it can also show at once, or a moment after every selection.
- Select text with the keyboard too — ⇧ and the arrow keys, ⇧⌥ by words, ⌘A — and the bar shows up once you stop and let go. Typing over what you selected never brings it up. Turn it off in Settings. Or keep it to ⇧ with the arrow keys and ⌘A, so a command that leaves text selected — ⌘F filling its field, ⌘L an address bar — does not bring it up.
- **Copy** and **Search** for any text. **Open link** for a web address, **New email** for an email address, the answer to a sum such as `1280 * 0.15 + 42`, and **Format JSON** for JSON.
- **Case**, **Lines** and **Encode**, each opening in the bar with Lumi's own changes: UPPERCASE, Title Case, snake_case, Sort lines, Remove duplicate lines, Base64, URL encode and more. The change is written over what you selected and stays selected, with the bar beside it, so you can make another.
- **Count** shows the words, characters and lines in what you selected. It is off at first; turn it on in Settings.
- Press **⌃⌥⌘Space** for the same bar from the keyboard, in any app: numbers or arrow keys choose, Return presses, Escape closes. Each button shows its number while you use the keys — not when you open a menu with the mouse.
- In Settings: show the bar when you select text or only with the shortcut; its look — Dark, Light or Match macOS — and its size; whether it shows on the pointer's side of the text, above it or below it; icons or icons and names; the search engine; and which actions show, each with its own switch, in the order you drag them to. A preview at the top shows the bar as you set it, for a few words, a link, an email address, a sum, JSON or several lines. Press the shortcut's keys there to record another.
- Copy shows a tick before the bar goes, and a change still being made shows a spinner on its button.
- **Settings…** is under ⋯ on the bar.
- **Not in…** under ⋯ on the bar keeps it from showing by itself in that app. The shortcut still works there.
- Needs Lumi 1.50.0.

# Changelog

## [0.1.17] - 2026-11-18

### Added

- **Menu bar icon** (Biểu tượng trên menu bar) on the Settings tab: the V or E as a plain letter, with a border round it, or in a filled box as before. Each choice shows the letter the menu bar shows now.

### Changed

- The V or E in the menu bar is a plain letter unless you choose the box on the Settings tab.

## [0.1.16] - 2026-11-18

### Added

- **Lumi Gõ tiếng Việt in Applications**: open it from Spotlight, the Dock or Launchpad to switch Vietnamese typing back on when it is off. No window opens; the V in the menu bar shows it is on.
- Needs Lumi 1.89.0.

## [0.1.15] - 2026-11-04

### Fixed

- The lumikeys.app link at the end of Lumi Gõ tiếng Việt's page in the Extension Store opens the extensions on lumikeys.app. It opened a page that no longer exists.

## [0.1.14] - 2026-11-03

### Added

- **Play a sound when switching** (Âm báo khi chuyển) on the Settings tab: a marimba's two notes, rising as typing becomes Vietnamese and falling as it becomes English, when you switch it yourself — the shortcut, a right-click on the V or E, the popover or the menu. Off until you turn it on.

### Changed

- The V or E in the menu bar, and the popover's tiles, change the moment you switch — before anything else the switch sees to.
- Needs Lumi 1.74.0.

## [0.1.13] - 2026-10-31

### Added

- **Capitalize sentences**, as in Gõ Nhanh: the first letter after a full stop, **!** or **?** and a Space, or after a new line, is typed as a capital — “ok. ban” becomes “ok. Ban”. Off until you switch it on, on the Settings tab, in the menu or in the popover. Needs Lumi 1.68.0.

## [0.1.12] - 2026-10-22

### Changed

- The line that describes it in the Extension Store and in Lumi reads: *Vietnamese typing for your Mac, with Telex or VNI and no input method to install.*

## [0.1.11] - 2026-10-22

### Added

- The Welcome has a step for switching Vietnamese typing on and off. It shows the key Lumi set at install, **fn ⇧** unless something else already held it, and says who does when it is taken. Record another key right there, take one back from a shortcut that holds it, or go back to fn ⇧, as on the Settings tab. Right-clicking the V in the menu bar switches too.

### Changed

- **Getting started** on the About tab names the shortcut among what the tour shows.

## [0.1.10] - 2026-10-22

### Added

- A short demo video on Lumi Gõ tiếng Việt's page in the Extension Store and on lumikeys.app — typing in your apps, the V in the menu bar, fn ⇧ and Keep English — to watch before you install.

## [0.1.9] - 2026-10-22

### Removed

- The **Source code** row on the About tab.

## [0.1.8] - 2026-10-22

### Added

- **Getting started** on the About tab, under what the extension does with your keys: it opens the welcome tour again, to choose the language and the typing method and see where your keys go.

## [0.1.7] - 2026-10-22

### Fixed

- The About tab's help tags show. Rest the pointer on **Works offline**, **No typing history** or **Open source** for what each means, or on the developer's mail, website and GitHub buttons for where each goes; tab to a button and its tag shows at once. They never showed before.

## [0.1.6] - 2026-10-22

### Changed

- On a work's page in the Acknowledgements sheet, the button back to the list reads **Back**.

## [0.1.5] - 2026-10-22

### Fixed

- In the Licence and Acknowledgements sheets the grey box stays where it is and only the text inside it scrolls, as a text view does on the Mac, instead of the whole box moving.

## [0.1.4] - 2026-10-22

### Changed

- The About tab is laid out as macOS lists its settings. It opens on what the extension does with the keys you type: **Works offline**, **No typing history** and **Open source**, each explained when you rest the pointer on it. Then the developer, with his mail, website and GitHub as buttons on his row, the extension's website, its source, its licence and its acknowledgements, a row each; and **Powered by the Gõ Nhanh engine** on a row of its own.
- The licence reads as paragraphs, wrapped to the sheet, instead of text broken mid-sentence.
- **Acknowledgements** replaces the third-party notices: a list of the work the engine is built on, each with a page of its own for its notice, a link to the project and its licence.
- Both sheets are as tall as what they show.

## [0.1.3] - 2026-10-22

### Added

- A Welcome window when it is first installed, in Vietnamese or English: choose the display language and the typing method, and see where the keys you type go.
- **Switch Vietnamese typing on or off** has a key of its own, **fn ⇧** — fn and ⇧ pressed together and let go — set at install when nothing else holds it. Change it on the Settings tab, under **Shortcut**, where a keyboard without fn takes any other key.
- The Settings tab reads in Vietnamese or English: choose with **Display language** at its top. Vietnamese is the default.
- **Popover appearance** on the Settings tab: the popover in Lumi's own look, or light or dark on its own.
- The row in Lumi's menu bar menu follows the display language: **Gõ tiếng Việt**, or **Vietnamese typing** in English.
- An About tab of its own, in English: what the extension can reach, who made it and how to get in touch, its page in the store, its source, the engine it types with — powered by the Gõ Nhanh engine, by Kha Phan, with a link to its repository — and its licence and third-party notices, each read in a sheet.
- The Settings, About and Changelog tab names follow the display language: **Cài đặt**, **Giới thiệu** and **Nhật ký thay đổi** in Vietnamese.
- A V or an E in the menu bar, beside Lumi's icon, says at a glance whether Vietnamese typing is on. Click it for a popover of tiles: the switch — with the app it is remembered for — Telex or VNI, the switches from the Settings tab — modern tone marks, Escape, English words, remembering each app, which shows the icons of the other apps typing is left the same way in — the extension's settings, and **Quit**, which switches the extension off in Lumi until you switch it on again under Extensions. Right-click it to switch Vietnamese typing on or off at once, as fn ⇧ does. Hide it from the extension's Permissions sheet in Lumi.
- The popover is loaded as Lumi starts, so even the first click shows it at once. Turn that off with **Preload** on the extension's Permissions sheet in Lumi.

### Changed

- The switch leaves Lumi's menu bar menu: the V or E holds it now. Put it back from the extension's Permissions sheet in Lumi.
- The Settings tab is laid out as rows, each with its control on the right: the typing method is a Telex/VNI switch, and placing tone marks the modern way (hoà, thuý) is a switch of its own.
- A new icon: a V over a keyboard.
- The extension's page in Settings opens on its Settings tab.
- Its tabs come in the order Settings, About, Changelog: the Changelog last, after About.

## [0.1.0] - 2026-10-21

### Added

- Type Vietnamese in every app with Telex or VNI, switched on and off from Lumi's menu bar or a shortcut you choose for **Switch Vietnamese typing on or off**.
- The switch is remembered for each app, unless you turn that off in Settings.
- Escape gives back the keys as you typed them, and English words can be kept as typed — both in Settings.

const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./katex-IHsOaJ5Q.css","./highlight-C7gy0f0K.js","./keys-D0zNrMEI.js"])))=>i.map(i=>d[i]);
import{$ as e,A as t,B as n,C as r,D as i,Dt as a,Et as o,F as s,G as c,H as l,J as u,K as d,L as f,M as p,N as m,O as h,P as g,Q as _,R as v,T as y,Tt as b,U as ee,V as te,X as ne,Y as re,Z as x,_ as S,_t as ie,b as C,bt as ae,ct as oe,dt as w,et as se,ft as ce,g as le,gt as ue,h as de,ht as T,i as fe,it as E,j as D,k as pe,lt as me,m as he,mt as O,n as ge,nt as _e,ot as k,q as ve,r as ye,rt as be,st as xe,t as Se,tt as A,vt as Ce,w as we,wt as j,xt as Te,z as Ee}from"./keys-D0zNrMEI.js";import{_ as M,a as De,b as Oe,d as N,f as ke,g as Ae,h as je,i as P,l as F,m as Me,n as Ne,o as Pe,p as Fe,r as Ie,s as Le,t as Re,u as ze,v as Be,y as Ve}from"./search-CGtgA5H1.js";var I=a(),He=b(),Ue=`# Changelog

## [0.90.0] - 2026-11-04

### Added

- The preview of a text or rich text item says how long it is: its characters, words and paragraphs, counted over the whole text, however much of it the preview shows. Characters include spaces and line breaks, and a paragraph is every line with something on it, as Pages and Word count them. Hidden items in privacy mode show no counts until you show them.

## [0.89.2] - 2026-11-04

### Fixed

- The lumikeys.app link at the end of Clipboard Manager's page in the Extension Store opens the extensions on lumikeys.app. It opened a page that no longer exists.

## [0.89.1] - 2026-10-21

### Changed

- New pictures on Clipboard Manager's page in the Extension Store and on lumikeys.app: the history, searching the text in a screenshot, privacy mode and the ⌘K actions. Nothing in the extension itself has changed.

## [0.89.0] - 2026-10-21

### Added

- **Glass or solid.** Settings → Appearance has **Background transparency**, a slider from **Glass** to **Solid**: the further toward Solid, the less the colours of the window under the panel show through it, so the history reads the same over anything. It works with every panel glass and theme, and the glass tiles above it follow the slider as you drag.

## [0.88.0] - 2026-10-15

### Changed

- The panel now opens on your newest copy, not on your first pinned item, so ↩ pastes what you copied last however many items you have pinned. Your pinned items are still at the top: press ↑ to reach them, or their own ⌘-letter. Clearing the search or switching between All, Text, Links and the rest also goes back to your newest copy. While you search, the first match is still selected, pinned or not.

## [0.87.1] - 2026-10-11

### Fixed

- Scrolling the history fast with a trackpad no longer leaves part of the list empty for a moment. The rows ahead of the scroll now show as they come into view, at any speed.

## [0.87.0] - 2026-10-09

### Added

- Settings → Shortcuts has a new option, "Press shortcut again to hide". Turn it on and the Show clipboard history shortcut also closes the panel when it is already open, even when the panel is pinned behind another app. It is off by default, so the shortcut only opens the panel, as before.

## [0.86.0] - 2026-10-09

### Changed

- The Show clipboard history shortcut is set on the Settings tab now. Click the key and press a new one; Clear removes it, and a button puts the default ⇧⌘C back. It is the same key as before and works in every profile. Clipboard Manager's separate Shortcuts tab in Lumi is gone.
- While you record a new key, Lumi's other shortcuts stay quiet. Pressing ⇧⌘C, or a combination something else already uses, records it instead of opening the panel or running that shortcut. This needs a newer Lumi; on an older one, recording works as before.
- If the key you pick belongs to one of your shortcuts in Lumi, the row says which one and offers to take it over.

## [0.85.3] - 2026-10-09

### Changed

- Loading the panel when Lumi starts is on when you first install Clipboard Manager. An update leaves it as you set it.

## [0.85.2] - 2026-10-09

### Changed

- Loading the panel ahead is now a permission Clipboard Manager asks for, listed with the others before you install or update: it keeps its panel loaded out of sight from when Lumi starts.

## [0.85.1] - 2026-10-09

### Changed

- The switch on Clipboard Manager's Permissions sheet in Lumi that matches **Load the panel when Lumi starts** is now called **Preload**.

## [0.85.0] - 2026-10-09

### Added

- **Menu bar & startup** in Settings: **Show in Lumi's menu bar menu** and **Load the panel when Lumi starts**. They are the same switches as **Menu bar** and **Preload** on Clipboard Manager's Permissions sheet in Lumi, so you can turn them on or off in either place.
- Needs Lumi 1.45.0 or later.

## [0.84.0] - 2026-10-09

### Changed

- Loading the panel ahead is now yours to allow. Clipboard Manager asks Lumi to load it as Lumi starts, and you decide with **Preload** on Clipboard Manager's Permissions sheet in Lumi. With it off, the panel loads the first time you open it and opens at once every time after that.

## [0.83.0] - 2026-10-09

### Changed

- The first **⇧⌘C** after Lumi starts is as quick as every one after it. On Lumi 1.45.0 or later, Lumi loads the panel ahead, out of sight, as it starts, and once Clipboard Manager is installed, updated or switched on, so your history is already drawn the first time you open it.

## [0.82.0] - 2026-10-09

### Changed

- **⇧⌘C** opens the panel with your history already in it, instead of an empty sheet of glass that fills in a moment later. On Lumi 1.45.0 or later the panel keeps its page while it is put away, so it is shown again at once, with what you copied meanwhile on top. Each opening still starts fresh: the search is empty, the first item is selected, and privacy mode covers what you showed. On an older Lumi the panel opens as before, a little sooner.
- A long history scrolls and moves under the arrow keys more smoothly.
- While **Lock history** is on, the panel is not given your history at all until you unlock it.

## [0.81.0] - 2026-10-05

### Added

- Lock your history at once from the panel with **⇧⌘L**, the same as **Lock history now** in **⌘K**: every preview is covered, and the panel asks "Is it you?" before it shows your history again. The key works while **Lock history** is on, and **⌘K** shows it beside the action.
- Choose your own key for it in Settings, under **Lock again after panel closes**, the way you choose Pin's. A key another of the panel's shortcuts already uses is refused, with what that shortcut does.

## [0.80.5] - 2026-10-05

### Fixed

- In the Welcome tour, the buttons on the privacy mode step and the Touch ID step sit at the same height, just above Back and Continue, so they no longer jump when you go from one step to the other.

## [0.80.4] - 2026-10-05

### Fixed

- In the Welcome tour, **Turn on privacy mode**, **Lock my history** and **Ask before showing** no longer jump when pressed. Each now says it is done in its own place, at the same size, instead of turning into a smaller line that moved the button next to it.
- **Ask before showing** stays in the Touch ID step once your history is locked, dimmed as it is in Settings, instead of disappearing.

## [0.80.3] - 2026-10-05

### Changed

- The eye in the panel's title bar is gone. It only showed that privacy mode was on, but looked like a button beside the pin. The covered previews already show it.

## [0.80.2] - 2026-10-05

### Changed

- In Settings, a setting that only works while another is on is now dimmed as a whole row: its name, its description and its control. The "Works while…" and "Lock history already asks…" lines are gone, since the setting it waits on is right above it. Its value is kept as before.
- **Look in**, under **Match snippets**, stays in view and is dimmed while Match snippets is off, instead of disappearing.
- **Theme** is dimmed the same way while **Dark glass** is chosen.
- Where "Is it you?" cannot be asked, the Settings tab, the Welcome tour and the locked panel now say it needs a password on this Mac, without naming an old Lumi version.

## [0.80.1] - 2026-10-05

### Changed

- In Settings, **Confirm it's you before showing** is greyed out while **Lock history** is on, and says "Lock history already asks before anything is shown". A locked history already asks "Is it you?" before you see anything, and that answer covers showing items too, so the setting did nothing alongside it. Its value is kept, and it works again once Lock history is off. It now sits under **Lock again after panel closes**.
- With **Lock history** on, turning privacy mode off no longer asks "Is it you?": the panel itself still asks before it shows anything.
- The Welcome tour's Touch ID step no longer offers **Ask before showing** once your history is locked.

## [0.80.0] - 2026-10-05

### Changed

- With **Confirm it's you before showing** on, turning privacy mode off asks "Is it you?" first, from Settings, from Lumi's menu bar or with the **Toggle privacy mode** key. Someone at your Mac can no longer switch it off to see your previews. If you cancel, privacy mode stays on. Turning it on never asks.

## [0.79.0] - 2026-10-05

### Changed

- **Cover again after panel closes** (was **Cover again after**) now counts from when the panel closes. Reopen the panel within that time and what you showed is still shown. While the panel is open, nothing is covered again by itself, and a pinned panel stays as it is when you switch to another app. The choices are **Immediately** (the new default), 30 seconds, 1 minute and 5 minutes.
- **Lock again after panel closes** (was **Lock again**) now counts from when the panel closes, not from when you unlocked. While the panel is open, it stays unlocked. The choices are **Immediately**, 1 minute, 5 minutes and 15 minutes.
- **Lock again after panel closes** is greyed out while **Lock history** is off.
- Needs Lumi 1.37.0 or later, which tells the extension when the panel closes.

## [0.78.1] - 2026-10-05

### Changed

- In Settings, the settings that only act on covered previews (**Show or hide content**, **Show or hide all**, **Cover again after** and **Confirm it's you before showing**) are greyed out while privacy mode is off, and say "Works while privacy mode is on". They keep their values, and become available again when privacy mode is turned on.

## [0.78.0] - 2026-10-05

### Changed

- Privacy mode can no longer be turned on or off from the panel. The eye in the panel's title bar now only shows that privacy mode is on, and **⌘K** no longer offers **Turn on privacy mode** or **Turn off privacy mode**. Turn it on or off in the extension's Settings tab, from Lumi's menu bar, or with the **Toggle privacy mode** key. Showing covered content in the panel works as before.

## [0.77.2] - 2026-10-05

### Fixed

- **Copy all** in the Math section has its copy icon and lines up with the cards under it, instead of running into the preview's right edge.

## [0.77.1] - 2026-10-05

### Fixed

- Rich text copied while 0.76.0 was installed now shows its **Math** section too. Those items had been marked as having no math, and copying the same text again did not look again. They are worked out the first time you preview them, and their row shows the answer from then on.

## [0.77.0] - 2026-10-05

### Added

- Rich text copies get the **Math** section too. The math is read from the copy's text and marked where it is written in the formatted preview, even when it runs across bold, italic or coloured words. The row in the list shows its answer, as for plain text.

## [0.76.0] - 2026-10-05

### Added

- Math in copied plain text is worked out in the preview. Under the text, a **Math** section shows each sum with its result (\`1 + 2 + 5 + 10 = 18\`), each equation in one unknown of degree one or two solved (\`x² − 5x + 6 = 0\` gives \`x = 2\` and \`x = 3\`, with exact roots like \`2 ± √3\` and complex ones), each written equality checked as true or false, and each \`15% of 200\` taken. Every result is typeset, and a click copies it; **Copy all** copies every answer. Where each one is written is marked in the text, and the row in the list shows its answer (\`= 18\`), or how many there are.
- Dates, times, phone numbers, version numbers, ranges like \`1-2\` and sizes like \`1920x1080\` are left alone.

## [0.75.3] - 2026-10-05

### Fixed

- A pinned panel no longer locks your history again when you switch to another app. With **Lock again** set to **When the panel closes**, a pinned panel in the background has not closed, so it stays unlocked until you close it. Lock it by hand with **Lock history now** in **⌘K**, or pick one of the timed **Lock again** choices. Privacy mode still covers previews when you switch away, and with history unlocked, showing one again doesn't ask "Is it you?".

## [0.75.2] - 2026-10-05

### Fixed

- With **Lock history** on, the panel no longer flashes the open history's search box, filters and paste keys before it shows it is locked. Until the panel knows whether your history is locked, it shows an empty frame where nothing can be typed or pasted, then the lock card or the history.

## [0.75.1] - 2026-10-05

### Fixed

- **Lock history** no longer locks again right after you confirm it's you, and an item shown after "Is it you?" no longer covers itself again a moment later. After the dialog answers, Lumi briefly loses the keyboard and takes it straight back, and the panel was treating that as you leaving. Now only the keyboard staying away counts as leaving (a pinned panel still locks and covers itself when you switch apps), and answering the dialog never counts.

## [0.75.0] - 2026-10-05

### Added

- The Welcome tour has a Touch ID step: the panel opens locked, macOS asks "Is it you?", and the history opens behind it. Buttons there lock your history or ask before showing, straight away; on a Lumi older than 1.36 the step says what it needs instead.

## [0.74.0] - 2026-10-05

### Added

- The Welcome tour has a step on privacy mode: the panel covers a budget, shows it with your key, shows a colour that is never covered, shows everything at once and covers it all again. A button there turns privacy mode on, and the keys it names are the ones you set.

## [0.73.0] - 2026-10-05

### Added

- **Confirm it's you before showing.** In privacy mode, the first item you show asks macOS's "Is it you?" — Touch ID, your Apple Watch or your password. After that, showing more items, or all of them, does not ask again until they are covered again.
- **Lock history.** The panel opens locked: no list, no preview and nothing to paste until you confirm it's you. It asks as soon as the panel opens; **Cancel** leaves an **Unlock** button. Choose under **Lock again** whether it locks every time the panel closes or a while after you unlock, and lock it at once with **Lock history now** in **⌘K**.
- Turning either of them off in Settings asks "Is it you?" first, so someone at your Mac cannot switch them off.
- Both need Lumi 1.36. On an older Lumi the switches say so, and nothing else changes.

## [0.72.1] - 2026-10-05

### Changed

- Privacy mode leaves colours uncovered. A colour's row already shows its whole value and its swatch, so covering its preview kept nothing private and only cost a press. Everything else is covered as before.

## [0.72.0] - 2026-10-05

### Added

- Show every item at once in privacy mode with **⌥⇧⌘H**, instead of showing them one by one: they stay shown until the panel covers them again, and the same key covers them all. **⇧⌘H** still covers or shows the selected item on its own. Also in the **⌘K** menu, as **Show all content** and **Hide all content**.
- Choose your own key for it under **Privacy** in Settings, next to the key for one item. A key another of the panel's shortcuts holds is refused with what it does.

## [0.71.1] - 2026-10-05

### Changed

- The key that shows or hides an item is set under **Privacy** in Settings, next to **Privacy mode**, instead of under **Shortcuts**.

### Fixed

- **Reset** no longer shows beside a shortcut that is already its default.

## [0.71.0] - 2026-10-05

### Added

- Choose your own key for showing and hiding an item in privacy mode in Settings, the way you choose Pin's. It is ⇧⌘H until you change it, and a key the panel already uses — Pin's among them — is refused with what it does.

### Fixed

- A Pin key held with ⇧, such as ⇧⌘K, no longer opens the actions menu or does what the key without ⇧ does: the keys you set are answered first.

## [0.70.1] - 2026-10-05

### Fixed

- The ninth pinned item could be given the letter K, but **⌘K** always opens the actions menu, so that item could never be pasted with its key. Pins skip K now, and an item already pinned to K moves to the first free letter when the panel opens.

## [0.70.0] - 2026-10-05

### Added

- Privacy mode. While it is on, the preview of every item is covered until you show it, so whatever you copied is not on screen just because the selection landed on it. Click the cover or press **⌘⇧H** to show an item; it stays shown while you move around the list, and **⌘⇧H** covers it again. Everything is covered again when the panel closes, when a pinned panel loses the keyboard to another app, and after a minute with nothing done in the panel (**Cover again after** in Settings).
- Turn privacy mode on or off with the eye in the panel's title bar, from **⌘K**, from **Turn On Privacy Mode** in Lumi's menu bar menu, in Settings, or with a key of your own for the new **Toggle privacy mode** command — so it can be turned on before the panel is ever opened.
- A covered item can still be pasted, dragged out, copied, pinned and deleted. The list itself is unchanged: titles, thumbnails and search matches still show.

## [0.69.1] - 2026-10-04

### Fixed

- "Clipboard Manager is already doing 4 things at once" no longer turns up when you move through the list quickly, or while the panel is reading the text in your images. The preview, and the words on a picture, are now asked for one at a time and only for the row you stopped on; reading images steps aside whenever you do something. A request Lumi turns away because the extension is full is asked again for a moment before it is given up on.

## [0.69.0] - 2026-10-03

### Added

- Select text right on a copied image in the preview: press on a word and drag across the words you want, or double-click a line. **⌘C** or **Copy** copies just those words; **⎋** lets them go. A press between words still drags the image out.

### Fixed

- Images whose text was never read are read now, when the panel opens or when **Search text in images** is turned on, so every image can be found by its words. This covers images copied while that setting was off, while Lumi was quitting, or in a quick run of copies.

## [0.68.0] - 2026-10-03

### Added

- Icons beside every row of Clipboard Manager's menu in Lumi's menu bar.

### Changed

- **Pause Recording** in the menu bar reads **Resume Recording** while paused, in place of a tick.
- Needs Lumi 1.34.0.

## [0.67.0] - 2026-10-02

### Added

- Clipboard Manager in Lumi's menu bar menu: **Show Clipboard History**, **Pause Recording**, **Delete All Unpinned…** and **Settings…**.
- **Pause Recording** stops keeping what you copy until you untick it. Nothing copied while paused is recorded.
- **Delete All Unpinned…** opens the panel and deletes there, so ⌘Z still brings everything back.

### Fixed

- The preview's width and split, and what a PDF fits, are kept between openings of the panel. They were never saved before.

### Changed

- Needs Lumi 1.33.0, and declares \`menu\`, the capability its menu bar rows need. The menu shows nothing you copied.

## [0.66.1] - 2026-10-02

### Changed

- With the panel pinned and you working in another app, Show clipboard history gives it the keyboard back the moment you press it, before the selected item blinks: Clipboard Manager now asks Lumi where the panel stands instead of finding out from the panel. Needs Lumi 1.31.0.

## [0.66.0] - 2026-10-02

### Added

- Two more commands, Hide clipboard history and Toggle clipboard history, for keys of your own in Lumi's Settings. The shortcut the extension comes with stays on Show clipboard history.

### Changed

- Show clipboard history only ever brings the panel up. Pressed while the panel is already up, pinned or not, it no longer puts it away: the panel takes the keyboard back if you were working in another app, and the selected item blinks so you know you can search or move through the list. Escape, Hide or Toggle put it away.

## [0.65.1] - 2026-10-02

### Fixed

- A long copy's scroll bar no longer covers its last letters. Every scroll bar in the preview — the copy, what it expands to, the text read in an image, the list of links — now sits in one line along the right edge.

## [0.65.0] - 2026-10-02

### Added

- Drag the line across the preview up or down to give more room to either side: the picture or the text read in it, or a copy or what it expands to. The line stays where you leave it for both kinds, so it holds still as you move through the list. Double-click the line to put it back where it was.

## [0.64.0] - 2026-10-02

### Added

- With the panel pinned and you working in another app, the shortcut gives the panel the keyboard back where it stands, and the selected item now blinks to say so, so you know you can search or move through the list right away. With the ⌘K menu up, its chosen action blinks instead. Press the shortcut again to put the panel away.

## [0.63.26] - 2026-10-02

### Added

- Copy one of your snippet triggers, such as \`;addr\`, and the preview shows what it expands to: its web addresses read as plain text and turn into links under the pointer, a button copies it, and clicking its heading folds it away. A snippet that comes out the same every time is remembered with the copy. One that changes, such as a date, is expanded again each time the panel shows it.
- Settings has a new Snippets section. Match snippets switches it on or off. Look in picks the profile you're using (the default), every profile, or Selected Profiles. Once Selected Profiles is chosen, its submenu lists every profile with a search field on top, to find them by name and tick them however many you have. An open panel, pinned or not, follows at once when you switch, rename or remove a profile, change these settings or edit a snippet in Lumi, and a snippet that can change is expanded again each time you come back to it. Needs Lumi 1.31.0.

## [0.62.1] - 2026-10-01

### Fixed

- The ⌘K actions menu's search field fits inside the menu instead of running past its right edge.

## [0.62.0] - 2026-10-01

### Added

- The ⌘K actions menu highlights the letters you typed in each action it found, the way the history search does.

## [0.61.0] - 2026-10-01

### Added

- The ⌘K actions menu takes shorthand: string together the starts of an action's words, as in "delall" for "Delete all…" or "sif" for "Show in Finder". The closest match comes first, right above the search field.

## [0.60.8] - 2026-10-01

### Fixed

- Searching the ⌘K actions menu matches the start of a word: "de" finds the Delete actions, no longer "Show in Finder" for the "de" inside "Finder".

## [0.60.7] - 2026-10-01

### Changed

- The ⌘K actions menu reads from the bottom up: Paste sits right above the search field, the delete actions furthest from it. The arrow keys move the way they point.

## [0.60.6] - 2026-10-01

### Changed

- The ⌘K actions menu has its search field at the bottom, next to the ⌘K that opens it. The field stays in place while you type and the list narrows above it.

## [0.60.5] - 2026-10-01

### Fixed

- The ⌘K actions menu shows all its actions instead of cutting the last one in half. When the panel is too short for them all, the list scrolls, fades at the edge that has more, and the arrow keys keep the chosen action in view.

## [0.60.4] - 2026-10-01

### Changed

- The panel opens faster with a long history: it reads the history once, and brings items kept by older versions up to date only once.

## [0.60.3] - 2026-10-01

### Fixed

- What you copy while the panel is open, pinned or not, shows up in it straight away.

## [0.60.2] - 2026-10-01

### Changed

- A copy's links are found once, when it is copied, instead of each time its preview is shown.

## [0.60.1] - 2026-10-01

### Added

- Links in rich text can be clicked in the preview. Plain text stays plain, to select and copy; its links are listed under it.

## [0.59.0] - 2026-10-01

### Added

- Text and rich text show the links they contain under their preview, each opened in the browser with a click.

### Fixed

- Links in rich text copied from TextEdit or Pages no longer drop out of the preview.

## [0.58.3] - 2026-09-30

### Changed

- The extension's homepage is now its page on lumikeys.app.

## [0.58.2] - 2026-09-30

### Changed

- About's Docs opens this extension's page on lumikeys.app, and Store page opens the extensions list there.

## [0.58.1] - 2026-09-30

### Changed

- About's buttons stay at the bottom of the panel while the changelog scrolls above them.

## [0.58.0] - 2026-09-30

### Added

- About in the ⌘K menu: the extension's version, what's new, the full changelog, and links to the docs, the store page and the Welcome tour, right in the panel.

## [0.57.0] - 2026-09-30

### Added

- Colours written as \`rgb()\`, \`rgba()\`, \`hsl()\` or \`hsla()\` are recognised as colours.
- A copied colour's preview lists it in the other formats (hex, \`rgb()\`, \`hsl()\`) to copy from.

## [0.54.11] - 2026-09-30

### Changed

- Long lists fade at the edge while there is more to scroll.

### Fixed

- The text-recognition panel no longer collapses when it has little to show.

## [0.54.6] - 2026-09-30

### Added

- Each panel remembers how you like PDFs fitted.

## [0.54.2] - 2026-09-30

### Fixed

- ⌘Y expands the preview, so an item pinned to Y moves to another letter.

## [0.53.3] - 2026-09-30

### Added

- A zoomed view for PDF previews.

## [0.52.4] - 2026-09-30

### Changed

- Simpler wording in the Welcome tour.

## [0.52.3] - 2026-09-30

### Added

- ⌘⇧P pins the panel, so it stays open while you paste one item after another.

### Changed

- Pinning an item is ⌘P by default (it was ⌥P).

## [0.51.6] - 2026-09-30

### Changed

- File icons are easier to tell apart in light and dark mode.

## [0.51.5] - 2026-09-30

### Added

- Images in the preview can be dragged into other apps.

## [0.51.4] - 2026-09-30

### Added

- Choosing an app in Settings suggests matches as you type its name or bundle id.

## [0.51.2] - 2026-09-30

### Fixed

- Search no longer loses letter case the first time it reads the history.

## [0.51.1] - 2026-09-30

### Fixed

- Search keeps text cased as it was copied.

## [0.51.0] - 2026-09-30

### Added

- A sixth step in the Welcome tour, on privacy.

## [0.50.0] - 2026-09-30

### Changed

- Searching the text recognised in images is separate from searching what you copied.

## [0.49.1] - 2026-09-30

### Changed

- The Welcome tour has five steps.

### Fixed

- Keyboard focus in the Welcome tour.

## [0.46.15] - 2026-09-30

### Changed

- The Welcome window's example copies lumikeys.app.

## [0.46.14] - 2026-09-30

### Added

- Screenshots for the Extension Store.

## [0.46.13] - 2026-09-29

### Added

- Links in the preview can be clicked.

## [0.46.11] - 2026-09-29

### Changed

- Renamed to Clipboard Manager.
- Better search.

## [0.46.8] - 2026-09-29

### Changed

- The Welcome window is redesigned around a live preview of the panel.

## [0.46.0] - 2026-09-29

### Added

- A Welcome tour.

## [0.45.6] - 2026-09-29

### Changed

- An empty history shows an icon and a clearer layout.

## [0.45.2] - 2026-09-29

### Fixed

- Escape closes an open menu before it closes the panel.

## [0.45.1] - 2026-09-29

### Added

- A Copy path action for files.

## [0.43.0] - 2026-09-29

### Added

- Items can be dragged out of the history into other apps.

## [0.42.0] - 2026-09-29

### Added

- Copies of several files show a list of them in the preview, with highlighting.

## [0.39.0] - 2026-09-29

### Added

- JSON is previewed as a tree, and text files are previewed.

## [0.37.0] - 2026-09-29

### Added

- Previews for copied image files, with their size in pixels and on disk.

## [0.36.0] - 2026-09-29

### Added

- Previews for PDFs.

## [0.30.0] - 2026-09-29

### Added

- Copied files show an icon for their type, their path and their extension.

## [0.28.0] - 2026-09-29

### Added

- The preview shows a copied file's size.
- Each item shows the icon of the app it was copied from, with the name on hover.

## [0.26.2] - 2026-09-29

### Added

- Save image as… in the actions menu for images. Needs Lumi 1.26.0.

### Fixed

- Rich text previews no longer go blank or flash as plain text.

## [0.25.2] - 2026-09-29

### Fixed

- Text recognised in images is left out of search when reading images is off.

## [0.23.0] - 2026-09-29

### Added

- The text recognised in a copied image is shown in its preview.

## [0.22.1] - 2026-09-29

### Added

- The key used for pinning can be changed.

## [0.21.0] - 2026-09-29

### Changed

- Deleting an item takes ⌘⌥⌫, so it is not done by accident.

## [0.19.0] - 2026-09-29

### Added

- A Settings page, and a choice of how long history is kept.

## [0.15.1] - 2026-09-29

### Added

- Rich text is previewed with its formatting.

## [0.13.1] - 2026-09-29

### Changed

- The About page is now the Dashboard tab.

## [0.12.0] - 2026-09-29

### Added

- A choice of glass material for the panel.

## [0.10.0] - 2026-09-29

### Added

- A menu entry and a shortcut for Settings.

## [0.9.3] - 2026-09-29

### Added

- Text in copied images is recognised, so they can be found by what they say.
- Clear all.
- Actions for links and files.

## [0.8.0] - 2026-09-29

### Added

- Undo for deleted items, which also restores their pins.

## [0.5.2] - 2026-09-29

### Added

- First release: a history of what you copy — text, links, images and files — with a panel to search it and paste an item back.
`,L=`# Clipboard Manager's manifest.
#
# Listed in extensions.toml, and held back by \`min-lumi-version\` alone: the
# \`clipboard-history\` and \`input\` capabilities, \`events\` and the panel \`kind\`
# all arrive with lumi:ext 0.3 in Lumi 1.25.0, and an older Lumi shows this
# as needing an update rather than installing it. 1.26.0 since Save image
# as…: \`storage.blob-save\` is a new import, and a component that imports it
# does not load on a Lumi without it at all. 1.29.0 since the panel's pin, for
# the same reason: \`ui.set-pinned\`. 1.31.0 since snippets — and Show and
# Toggle ask \`ui.window-state\`, which arrives there too. 1.33.0 for the
# menu bar rows (\`menu\`), and 1.34.0 since they wear icons:
# \`menu.set-rows\`. 1.37.0 for the \`window-closed\` event and, the same way as
# Save image as…, for \`owner.authenticate\`: turning privacy mode off asks
# "Is it you?" from the menu bar row and the command, which have no page.
# 1.45.0 for the Settings tab's switches over the menu bar rows and loading
# the panel ahead (\`menu.set-shown\`, \`ui.set-preload-enabled\`): the same
# switches as on the Permissions sheet, which an older Lumi does not let an
# extension move — and a component that calls them does not load there.
[extension]
id = "dev.thiennguyen.clipboard"
name = "Clipboard Manager"
version = "0.90.0"
description = "Keep what you copy — text, links, images and files — and paste it back from a panel."
author = "Thien Nguyen"
summary = "Remembers what you copy on this Mac and brings it back with one shortcut: search, pick, and it is pasted into the app you were typing in. Text, rich text, links, colours, files and images, with pins for what you keep reaching for. Anything a password manager marks as secret is never recorded — Lumi drops it before this extension hears of it — and the history is stored encrypted with a key Lumi keeps in your Keychain. Nothing leaves your Mac: the extension has no network access."
homepage = "https://lumikeys.app/extensions/dev.thiennguyen.clipboard/"
min-lumi-version = "1.45.0"
# \`clipboard-history\`: hears each copy (the review sheet says so).
# \`clipboard\`: puts a chosen item back on the pasteboard.
# \`input\` + \`accessibility\`: pastes it into the app in front — the same
# two a Lumi flow needs to type by pasting.
# \`snippets\`: a copy that is one of your snippet triggers shows what it
# expands to — Lumi matches and expands it, as typing would. 1.31.0 for it.
# \`preload\`: the panel loaded ahead, out of sight, as Lumi starts (Lumi 1.45),
# so the first ⌘⇧C opens as quickly as every one after it — the switch over
# it is on the Settings tab and the Permissions sheet alike.
capabilities = ["clipboard", "clipboard-history", "input", "accessibility", "snippets", "menu", "preload"]
# Where that switch starts on a fresh install: on, so the first ⌘⇧C after
# installing is already quick. Said outright though on is Lumi's default
# too. An update leaves the switch where it was left.
preload-default = true
# \`clipboard-ocr\`: the text Lumi reads in a copied image, a moment after the
# copy, so a screenshot can be found by what it says. Switched by the \`ocr\`
# setting below.
# \`window-closed\`: the panel put away (Lumi 1.37), which "Cover again after
# panel closes" and "Lock again after panel closes" count from.
# \`menu-shown\`, \`preload-enabled\`: the menu bar rows' switch and the
# loading-ahead switch moved on the Permissions sheet (Lumi 1.44, 1.45), so
# an open Settings tab's own switches follow.
events = ["clipboard", "clipboard-ocr", "window-closed", "menu-shown", "preload-enabled"]
# Pictures for this extension's page in Lumi's Extension Store. The store
# publishes them beside the package; Lumi's installer ignores the key.
screenshots = ["shots/1-history.png", "shots/2-search.png", "shots/3-private.png", "shots/4-keys.png"]
# The Settings tab is drawn by web/settings.html rather than from the
# [[settings]] below — which still decide what it can save.
settings-page = "settings.html"

# Lumi's Shortcuts tab for this extension, hidden: Show's own key — the
# \`[[shortcut]]\` below — is recorded and changed on the Settings tab, in the
# Shortcuts section, the one place it is set. It is the same key, kept by
# Lumi in every profile; Hide, Toggle and Privacy get keys in Lumi's
# Shortcuts pane, as the person's own rows.
[tabs.shortcuts]
hidden = true

# The panel's three commands. Show only ever brings it up — pressed while
# it is up, the panel takes the keyboard back and its selection blinks; only
# Escape, Hide or Toggle put it away — unless the person turns on "Press
# shortcut again to hide" (\`showToggles\`), which makes Show a Toggle. \`open\`, not \`show\`: the name the
# shortcut below and the keys people gave it already point at.
[[command]]
name = "open"
label = "Show clipboard history"
icon = "clipboard-list"

[[command]]
name = "hide"
label = "Hide clipboard history"
icon = "eye-off"

# Up: put away, pinned or not. Not up: shown, as Show does.
[[command]]
name = "toggle"
label = "Toggle clipboard history"
icon = "toggle-right"

# Privacy mode on or off without opening the panel — which would show the
# newest copy — for a key of the person's own in Lumi's Settings, like Hide
# and Toggle. The menu bar row does the same.
[[command]]
name = "privacy"
label = "Toggle privacy mode"
icon = "shield"

# Show's key — Hide, Toggle and Privacy come with none, for the person to
# give them in Lumi's Settings. Maccy's key, as the extension's own: Lumi arms it at
# install when nothing holds it, in every profile, and it goes with the
# extension. When something
# does hold it Lumi arms nothing and says who — the Welcome window's second
# step reads that and asks. Replaces the \`suggested-key\` this command had,
# which was a row proposed to the person rather than a key of its own.
[[shortcut]]
command = "open"
key = "cmd+shift+c"

# The eight-step tour \`on_lifecycle\` opens when the extension is installed
# or updated: what it keeps, how it is kept private, its shortcut (armed,
# or not — and then what to do), the keys inside the panel, the preview,
# privacy mode, Touch ID, and dragging out. An ordinary declared window: the
# declaration is the grant, and the review sheet lists it.
[[window]]
name = "welcome"
title = "Welcome to Clipboard Manager"
path = "welcome.html"
width = 560
height = 460
resizable = false
maximizable = false

# The panel: borderless, floats over whatever is in front without taking
# it out of front, and takes the keyboard so the search field can be typed
# in (Vietnamese input methods included). Closes as soon as it loses the
# keyboard.
[[window]]
name = "history"
title = "Clipboard Manager"
path = "panel.html"
kind = "panel"
position = "cursor"
# macOS's popover glass behind the page — the blur Spotlight uses, light or
# dark with the system. The page leaves its background clear for it.
material = "popover"
width = 620
height = 430
# The page stays loaded while the panel is put away, so ⌘⇧C shows the
# history on the panel's first frame instead of a sheet of glass that fills
# in a beat later (Lumi 1.45). The page starts itself over on \`lumi:hidden\`
# and reads the opening list on \`lumi:shown\` (web/src/visibility.ts). An
# older Lumi ignores the key and loads the page at every opening, as before.
keep-alive = true
# And loaded ahead, as Lumi starts, so the first ⌘⇧C is as quick. One
# switch over it, kept by Lumi: "Load the panel when Lumi starts" on the
# Settings tab and Preload on the Permissions sheet are the same
# switch. Off, the page loads at the first opening and is kept from then on.
preload = true

# The first tab of the extension's page in Lumi: live counts from the
# history, asked of \`run-ui\` as the \`:page:dashboard\` window and pushed to
# it with \`ui.post\` after each copy, pin or delete.
[[page]]
name = "dashboard"
label = "Dashboard"
path = "dashboard.html"

# How long an unpinned row is kept after it was last copied. Pins stay.
[[settings]]
name = "keep"
label = "Keep history for"
kind = "select"
default = "3mo"

[[settings.options]]
value = "5m"
label = "5 minutes"

[[settings.options]]
value = "1h"
label = "1 hour"

[[settings.options]]
value = "1d"
label = "1 day"

[[settings.options]]
value = "1w"
label = "1 week"

[[settings.options]]
value = "1mo"
label = "1 month"

[[settings.options]]
value = "3mo"
label = "3 months"

[[settings]]
name = "pasteOnSelect"
label = "Paste the item you pick"
kind = "bool"
default = "true"

# A drag out of the panel leaves it up by default, so several items can be
# dragged out one after another.
[[settings]]
name = "closeAfterDrag"
label = "Close the panel after dragging an item out"
kind = "bool"
default = "false"

# Show's key — and any row of the person's that runs Show — as a toggle:
# pressed while the panel is up, it puts it away. Off, Show only ever
# brings the panel up.
[[settings]]
name = "showToggles"
label = "Press shortcut again to hide"
kind = "bool"
default = "false"

# Lumi reads for this extension only while this is on: a second or two of
# CPU per image copied.
[[settings]]
name = "ocr"
label = "Search text in images"
kind = "bool"
default = "true"

# Privacy mode itself is a switch the extension keeps (menu bar, command,
# Settings tab), not a setting. This is how long what the panel showed while
# it is on stays shown after the panel closes — an opening within it shows
# it again — counted from Lumi's \`window-closed\`. "Immediately" keeps the
# name \`never\` from when this meant a while with nothing done.
[[settings]]
name = "privacyIdle"
label = "Cover again after panel closes"
kind = "select"
default = "never"

[[settings.options]]
value = "never"
label = "Immediately"

[[settings.options]]
value = "30s"
label = "After 30 seconds"

[[settings.options]]
value = "1m"
label = "After 1 minute"

[[settings.options]]
value = "5m"
label = "After 5 minutes"

# The panel's own Pin key, while the panel is up — not a global shortcut.
# Spelled "cmd+p", "ctrl+shift+1"; the Settings tab records it. ⌘P because
# no row is ever given ⌘P (\`history::PIN_LETTERS\`), and ⌘⇧P pins the panel.
[[settings]]
name = "pinKey"
label = "Pin shortcut"
kind = "text"
default = "cmd+p"

# macOS's "Is it you?" dialog — Touch ID, a Watch or the login password —
# before the first preview shown in an opening (\`POST /__lumi__/authenticate\`,
# Lumi 1.36). A page route, not an import: an older Lumi still loads this, and
# the Settings tab offers the switch only where the dialog can be shown.
[[settings]]
name = "privacyConfirm"
label = "Confirm it's you before showing"
kind = "bool"
default = "false"

# The whole history behind that dialog: the panel opens locked — no list, no
# preview, no paste — until the owner confirms.
[[settings]]
name = "lockHistory"
label = "Lock history"
kind = "bool"
default = "false"

# How long an unlocked history stays unlocked after the panel closes —
# counted from Lumi's \`window-closed\`, kept as \`lock.until\` in storage — so
# openings within it open unlocked. While the panel is up it stays unlocked.
[[settings]]
name = "lockAfter"
label = "Lock again after panel closes"
kind = "select"
default = "close"

[[settings.options]]
value = "close"
label = "Immediately"

[[settings.options]]
value = "1m"
label = "After 1 minute"

[[settings.options]]
value = "5m"
label = "After 5 minutes"

[[settings.options]]
value = "15m"
label = "After 15 minutes"

# Privacy mode's show or hide of the selected item, while the panel is up —
# the panel's own key, as Pin's is, recorded on the Settings tab and checked
# by the page against Pin's and the panel's other keys. ⌘⇧H beside ⌘⇧P.
[[settings]]
name = "revealKey"
label = "Show or hide shortcut"
kind = "text"
default = "cmd+shift+h"

# The same for every item at once, until the panel covers them again: so
# the person need not show items one by one. ⌥ added, macOS's "all" key —
# not ⌥⌘H, which macOS gives Hide Others.
[[settings]]
name = "revealAllKey"
label = "Show or hide all shortcut"
kind = "text"
default = "alt+shift+cmd+h"

# "Lock history now" in a key, while the panel is up and Lock history is on —
# the panel's own key, as Pin's is, not a shortcut of Lumi's: locked at once,
# every preview covered, and the next opening asks "Is it you?". ⌘⇧L, since
# ⌘L may be a pinned row's letter (\`history::PIN_LETTERS\`).
[[settings]]
name = "lockKey"
label = "Lock history now shortcut"
kind = "text"
default = "cmd+shift+l"

# How the panel's search reads a query — Maccy's four modes.
[[settings]]
name = "search"
label = "Search"
kind = "segmented"
default = "mixed"

[[settings.options]]
value = "exact"
label = "Exact"

[[settings.options]]
value = "fuzzy"
label = "Fuzzy"

[[settings.options]]
value = "regexp"
label = "Regex"

[[settings.options]]
value = "mixed"
label = "Mixed"

[[settings]]
name = "sort"
label = "Order"
kind = "segmented"
default = "last"

[[settings.options]]
value = "last"
label = "Last copied"

[[settings.options]]
value = "first"
label = "First copied"

[[settings.options]]
value = "used"
label = "Most used"

# The panel's glass — macOS's own materials. The manifest's \`material\`
# above is only the default; the panel is opened on this one.
[[settings]]
name = "appearance"
label = "Appearance"
kind = "segmented"
default = "popover"

[[settings.options]]
value = "popover"
label = "Glass"

[[settings.options]]
value = "hud"
label = "Dark glass"

[[settings.options]]
value = "sidebar"
label = "Frosted"

# Light or dark for the panel; "system" follows macOS. Dark glass is dark
# whatever this says.
[[settings]]
name = "theme"
label = "Theme"
kind = "segmented"
default = "system"

[[settings.options]]
value = "dark"
label = "Dark"

[[settings.options]]
value = "light"
label = "Light"

[[settings.options]]
value = "system"
label = "System"

# How much of what is under the panel shows through it: 0 is the glass as
# it is, 100 is solid, the glass's own colour painted over it by the page —
# for a panel that reads the same over any window. Selection Bar's slider.
[[settings]]
name = "solid"
label = "Background transparency"
kind = "slider"
min = 0
max = 100
step = 5
default = "0"

# One bundle id per line, e.g. com.apple.keychainaccess. Copies made while
# one of these is in front are not kept.
[[settings]]
name = "ignoreApps"
label = "Never keep copies from"
kind = "textarea"
default = ""

# One regular expression per line; a copy whose text matches is not kept.
[[settings]]
name = "ignorePatterns"
label = "Never keep text matching"
kind = "textarea"
default = ""

# Whether a copy that is one of your snippet triggers shows what it
# expands to, in the preview's "Expands to".
[[settings]]
name = "matchSnippets"
label = "Match snippets"
kind = "bool"
default = "true"

# Whose snippets it looks in, while that is on: the live profile's, every
# profile's, or the ones ticked under Selected Profiles (\`snippetProfiles\`).
[[settings]]
name = "snippetsIn"
label = "Look in"
kind = "segmented"
default = "current"

[[settings.options]]
value = "current"
label = "Current Profile"

[[settings.options]]
value = "all"
label = "All Profiles"

[[settings.options]]
value = "selected"
label = "Selected Profiles"

# The profiles Selected Profiles looks in: their ids, joined by commas.
# Ticked in the Look in menu on the Settings tab, found by name.
[[settings]]
name = "snippetProfiles"
label = "Profiles to match"
kind = "text"
default = ""
`,We=/^## \[([^\]]+)\](?:\s*-\s*(\S+))?/;function R(e){let t=[];for(let n of e.split(/\r?\n/)){let e=We.exec(n);if(e){t.push({version:e[1],date:e[2]??``,groups:[]});continue}let r=t.at(-1);if(r){if(n.startsWith(`### `))r.groups.push({title:n.slice(4).trim(),notes:[]});else if(/^[-*] /.test(n))r.groups.length||r.groups.push({title:``,notes:[]}),r.groups.at(-1).notes.push(n.slice(2).trim());else if(/^\s+\S/.test(n)){let e=r.groups.at(-1)?.notes;e?.length&&(e[e.length-1]+=` ${n.trim()}`)}}}return t}function Ge(e){return e.split("`")}function Ke(e){let t=t=>RegExp(`^${t}\\s*=\\s*"([^"]*)"`,`m`).exec(e)?.[1]??``;return{id:t(`id`),name:t(`name`),version:t(`version`),author:t(`author`),description:t(`description`)}}var z=me(),qe=Ke(L),B=R(Ue);function Je({onLink:e}){let[t,n]=(0,I.useState)(!1),r=t?B:B.slice(0,1);return(0,z.jsxs)(`section`,{className:`about`,"aria-label":`About ${qe.name}`,children:[(0,z.jsxs)(`div`,{className:`about-body`,children:[(0,z.jsxs)(`header`,{className:`about-head`,children:[(0,z.jsx)(D,{}),(0,z.jsxs)(`div`,{className:`about-title`,children:[(0,z.jsx)(`h1`,{children:qe.name}),(0,z.jsxs)(`p`,{children:[`Version `,qe.version,` · by `,qe.author]}),(0,z.jsx)(`p`,{className:`about-id`,children:qe.id})]})]}),(0,z.jsx)(`p`,{className:`about-lede`,children:qe.description}),(0,z.jsx)(`div`,{className:`about-log`,children:r.map((e,t)=>(0,z.jsx)(V,{release:e,newest:t===0},e.version))})]}),(0,z.jsxs)(`nav`,{className:`about-links`,"aria-label":`More`,children:[B.length>1&&(0,z.jsxs)(`button`,{type:`button`,onMouseDown:e=>e.preventDefault(),onClick:()=>n(!t),children:[(0,z.jsx)(te,{}),t?`Latest changes only`:`Full changelog`]}),(0,z.jsxs)(`button`,{type:`button`,onMouseDown:e=>e.preventDefault(),onClick:()=>e(`openDocs`),children:[(0,z.jsx)(C,{}),`Docs`]}),(0,z.jsxs)(`button`,{type:`button`,onMouseDown:e=>e.preventDefault(),onClick:()=>e(`openStore`),children:[(0,z.jsx)(k,{}),`Store page`]}),(0,z.jsxs)(`button`,{type:`button`,onMouseDown:e=>e.preventDefault(),onClick:()=>e(`tour`),children:[(0,z.jsx)(c,{}),`Welcome tour`]})]})]})}function V({release:e,newest:t}){return(0,z.jsxs)(`article`,{className:`about-release`,children:[(0,z.jsxs)(`h2`,{children:[t?`What's new in ${e.version}`:e.version,!t&&e.date&&(0,z.jsx)(`span`,{className:`about-date`,children:e.date})]}),e.groups.map((t,n)=>(0,z.jsxs)(`div`,{children:[t.title&&e.groups.length>1&&(0,z.jsx)(`h3`,{children:t.title}),(0,z.jsx)(`ul`,{children:t.notes.map((e,t)=>(0,z.jsx)(`li`,{children:Ge(e).map((e,t)=>t%2?(0,z.jsx)(`code`,{children:e},t):e)},t))})]},n))]})}var Ye=1;function Xe(e){(0,I.useEffect)(()=>{let t=e.current;if(!t)return;let n=()=>{t.toggleAttribute(`data-above`,t.scrollTop>Ye),t.toggleAttribute(`data-below`,t.scrollHeight-t.clientHeight-t.scrollTop>Ye)};n(),t.addEventListener(`scroll`,n,{passive:!0});let r=new ResizeObserver(n);r.observe(t);let i=new MutationObserver(n);return i.observe(t,{childList:!0,subtree:!0}),()=>{t.removeEventListener(`scroll`,n),r.disconnect(),i.disconnect()}},[e])}var Ze=4;function H(e){let t=(0,I.useRef)(null),n=(0,I.useRef)(e);return n.current=e,(0,I.useEffect)(()=>{let e=()=>t.current=null;return window.addEventListener(`blur`,e),()=>window.removeEventListener(`blur`,e)},[]),{onPointerDown(e){let n=e.target instanceof Element&&e.target.closest(`button`);t.current=e.button===0&&!n?{x:e.clientX,y:e.clientY,started:!1}:null},onPointerMove(e){let r=t.current;if(r&&!r.started){if(!(e.buttons&1)){t.current=null;return}Math.hypot(e.clientX-r.x,e.clientY-r.y)>=Ze&&(r.started=!0,n.current())}},onClickCapture(e){t.current?.started&&(e.preventDefault(),e.stopPropagation()),t.current=null}}}var Qe=new Map(Object.entries({pdf:`pdf`,doc:`doc docx pages rtf txt md markdown odt log`,sheet:`xls xlsx numbers csv tsv ods`,slides:`ppt pptx key odp`,code:`html htm css js jsx ts tsx json xml yaml yml toml rs py rb go java kt swift c cc cpp h hpp cs php sh zsh sql lua vue svelte`,audio:`mp3 m4a aac wav aiff aif flac ogg opus wma`,video:`mp4 m4v mov avi mkv webm wmv flv mpg mpeg`,image:`png jpg jpeg gif webp heic heif tiff tif bmp svg ico raw psd`,archive:`zip rar 7z tar gz tgz bz2 xz dmg iso pkg`}).flatMap(([e,t])=>t.split(` `).map(t=>[t,e])));function U(e){return e?e===`/`?`folder`:Qe.get(e)??`file`:`file`}var $e=new Set(`txt md markdown log csv tsv ini cfg conf html htm css js mjs cjs jsx ts tsx json xml yaml yml toml rs py rb go java kt swift c cc cpp h hpp cs php sh zsh bash fish sql lua vue svelte graphql proto dart scala ex exs zig`.split(` `));function et(e){return!!e&&$e.has(e)}var tt={ts:`typescript`,tsx:`typescript`,js:`javascript`,jsx:`javascript`,mjs:`javascript`,cjs:`javascript`,go:`go`,rs:`rust`,py:`python`,rb:`ruby`,java:`java`,kt:`kotlin`,swift:`swift`,c:`c`,h:`c`,cc:`cpp`,cpp:`cpp`,hpp:`cpp`,cs:`csharp`,php:`php`,sh:`bash`,zsh:`bash`,bash:`bash`,fish:`bash`,sql:`sql`,lua:`lua`,css:`css`,html:`xml`,htm:`xml`,xml:`xml`,vue:`xml`,svelte:`xml`,json:`json`,yaml:`yaml`,yml:`yaml`,toml:`ini`,ini:`ini`,cfg:`ini`,conf:`ini`,graphql:`graphql`,proto:`protobuf`,dart:`dart`,scala:`scala`,ex:`elixir`,exs:`elixir`,md:`markdown`,markdown:`markdown`};function W(e){return e&&tt[e]||null}var nt=new Set;function rt(){nt.clear()}function it({app:e,name:t,withName:n=!1}){let[r,i]=(0,I.useState)(!1),a=t||e;return a?!e||r||nt.has(e)?n?(0,z.jsx)(z.Fragment,{children:a}):(0,z.jsx)(`span`,{className:`app`,children:a}):(0,z.jsxs)(z.Fragment,{children:[(0,z.jsx)(`img`,{className:`app-icon`,src:w(e),alt:n?``:a,title:n?void 0:a,onError:()=>{nt.add(e),i(!0)}}),n&&a]}):null}function at(e){return/^(#|rgba?\(|hsla?\()/i.test(e)&&CSS.supports(`color`,e)}function G(e){return{"--paint":e}}var K={text:`Text`,link:`Link`,color:`Colour`,rich:`Rich text`,file:`File`,image:`Image`};function ot({row:e}){return e.kind===`color`&&at(e.title)?(0,z.jsx)(`span`,{className:`lead`,children:(0,z.jsx)(`span`,{className:`swatch painted`,style:G(e.title)})}):e.kind===`image`&&e.thumb?(0,z.jsx)(`span`,{className:`lead thumb`,children:(0,z.jsx)(`img`,{alt:``,src:O(e.thumb)})}):e.kind===`file`?(0,z.jsx)(`span`,{className:`lead`,children:(0,z.jsx)(s,{family:U(e.fileExt),many:(e.fileCount??0)>1})}):(0,z.jsx)(`span`,{className:`lead`,children:(0,z.jsx)(d,{kind:e.kind})})}function q({text:e,marks:t}){if(!t.length)return(0,z.jsx)(z.Fragment,{children:e});let n=[],r=0;for(let[i,a]of t)i>r&&n.push(e.slice(r,i)),n.push((0,z.jsx)(`mark`,{children:e.slice(i,a)},i)),r=a;return r<e.length&&n.push(e.slice(r)),(0,z.jsx)(z.Fragment,{children:n})}var st=null;function ct(e){return st??=document.createElement(`canvas`).getContext(`2d`),st?(st.font=getComputedStyle(e).font,st.measureText(`…`).width):12}function J(e,t){let n=[],r=document.createTreeWalker(e,NodeFilter.SHOW_TEXT);for(let e=r.nextNode();e;e=r.nextNode())n.push(e);let i=n.reduce((e,t)=>e+t.data.length,0),a=document.createRange(),o=e=>{let r=e;for(let e of n){if(r<=e.data.length)return a.setStart(n[0],0),a.setEnd(e,r),a.getBoundingClientRect().right<=t;r-=e.data.length}return!0},s=0,c=i;for(;s<c;){let e=s+c+1>>1;o(e)?s=e:c=e-1}return s}function lt(e){let t=(0,I.useRef)(null),[n,r]=(0,I.useState)(0),[i,a]=(0,I.useState)(null),[o,s]=(0,I.useState)(0);(0,I.useLayoutEffect)(()=>{r(0),a(null)},[e.text,o]);let c=e.marks.length>0;(0,I.useLayoutEffect)(()=>{let e=t.current;if(!e||!c)return;let n=new ResizeObserver(()=>s(e.clientWidth));return n.observe(e),()=>n.disconnect()},[c]);let l=Be(e,n),u=i===null?l:Pe(l,i);return(0,I.useLayoutEffect)(()=>{let o=t.current;if(!o||!e.marks.length||i!==null)return;let s=o.scrollWidth>o.clientWidth,c=o.getBoundingClientRect().right-(s?ct(o):0),u=o.querySelectorAll(`mark`),d=u[Math.min(N(l),u.length)-1];if(d&&d.getBoundingClientRect().right>c+.5){let t=ke(e,n);if(t!==null){r(t);return}}s&&a(J(o,c+.5))}),{title:t,shown:u}}var ut=(0,I.memo)(function({row:e,index:t,selected:n,shortcut:r,query:i,used:a,now:o,popped:s,onPick:c,onPaste:l}){let u=(0,I.useMemo)(()=>Le(e,i,a),[e,i,a]),{title:d,shown:f}=lt(u),p=H(()=>{c(t),T({kind:`drag`,id:e.id}).catch(()=>{})});return(0,z.jsxs)(`div`,{id:`row-${t}`,"data-id":e.id,className:`row`,role:`option`,"aria-selected":n,onMouseDown:e=>e.preventDefault(),onClick:()=>c(t),onDoubleClick:t=>l(t.altKey,e),...p,children:[(0,z.jsx)(`span`,{className:[`cap`,e.pin?`pin`:``,r?``:`blank`].filter(Boolean).join(` `),children:r?`⌘${r.toUpperCase()}`:``}),(0,z.jsx)(ot,{row:e}),(0,z.jsx)(`span`,{className:`title`,ref:d,children:f.text?(0,z.jsx)(q,{text:f.text,marks:f.marks}):K[e.kind]}),u.note&&(0,z.jsx)(`span`,{className:`found-in`,children:u.note}),e.math&&(0,z.jsx)(`span`,{className:`math-short`,title:e.math.startsWith(`∑`)?`Math in this copy`:`Worked out`,children:e.math}),!e.pin&&(e.app||e.appName)&&(0,z.jsxs)(z.Fragment,{children:[(0,z.jsx)(it,{app:e.app,name:e.appName}),(0,z.jsx)(`span`,{className:`dot`,"aria-hidden":`true`,children:`·`})]}),e.pin?(0,z.jsx)(`span`,{className:s?`when pop`:`when`,"aria-label":`Pinned`,children:(0,z.jsx)(_,{})}):(0,z.jsx)(`span`,{className:`when`,children:M(e.last,o)})]})},dt);function dt(e,t){for(let n of Object.keys(t))if(n!==`now`&&e[n]!==t[n])return!1;return M(e.row.last,e.now)===M(t.row.last,t.now)}function ft({actions:e,onClose:t}){let[n,r]=(0,I.useState)(``),[i,a]=(0,I.useState)(0),[o,s]=(0,I.useState)(null),c=(0,I.useRef)(null),l=(0,I.useRef)(null),u=(0,I.useRef)(null);Xe(u);let d=(0,I.useMemo)(()=>{let t=De(e,e=>e.label,n);return[...t.filter(e=>!e.danger),...t.filter(e=>e.danger)]},[e,n]),f=d[Math.min(i,d.length-1)];(0,I.useEffect)(()=>c.current?.focus(),[]),(0,I.useLayoutEffect)(()=>{let e=u.current;e&&(e.scrollTop=e.scrollHeight)},[n]),(0,I.useEffect)(()=>{let e=e=>{let n=e.target;l.current?.contains(n)||n?.closest(`[data-menu-toggle]`)||t()};return document.addEventListener(`pointerdown`,e,!0),window.addEventListener(`blur`,t),()=>{document.removeEventListener(`pointerdown`,e,!0),window.removeEventListener(`blur`,t)}},[t]),(0,I.useEffect)(()=>{o&&f?.id!==o&&s(null)},[o,f]);let p=e=>{let t=Math.max(0,Math.min(d.length-1,Math.min(i,d.length-1)+e)),n=d[t];n&&(a(t),document.getElementById(`action-${n.id}`)?.scrollIntoView({block:`nearest`}))},m=e=>{if(e){if(e.confirm&&o!==e.id){s(e.id);return}t(),e.run()}},h=e=>{if(e.stopPropagation(),e.nativeEvent.isComposing||e.keyCode===229)return;let n=e.key;if(n===`ArrowUp`)p(1);else if(n===`ArrowDown`)p(-1);else if(n===`Enter`)m(f);else if(n===`Escape`&&o)s(null);else if(n===`Escape`||e.metaKey&&n.toLowerCase()===`k`)t();else return;e.preventDefault()},g=d.findIndex(e=>e.danger);return(0,z.jsxs)(`div`,{ref:l,className:`menu`,role:`dialog`,"aria-label":`Actions`,children:[(0,z.jsxs)(`div`,{ref:u,id:`menu-list`,className:`menu-list`,role:`listbox`,"aria-label":`Actions`,children:[!d.length&&(0,z.jsx)(`div`,{className:`menu-empty`,children:`No action by that name`}),d.map((e,t)=>[(0,z.jsxs)(`div`,{id:`action-${e.id}`,role:`option`,"aria-selected":e===f,className:[`menu-item`,e.danger?`danger`:``,o===e.id?`armed`:``].filter(Boolean).join(` `),onMouseDown:e=>e.preventDefault(),onMouseMove:()=>a(t),onClick:()=>m(e),children:[e.glyph,(0,z.jsx)(`span`,{className:`menu-label`,children:o===e.id?e.confirm:(0,z.jsx)(q,{text:e.label,marks:Ve(e.label,n)?.marks??[]})}),e.keys&&o!==e.id&&(0,z.jsx)(`kbd`,{className:`cap quiet`,children:e.keys})]},e.id),t===g&&t>0?(0,z.jsx)(`div`,{className:`menu-line`,role:`separator`},`line`):null]).reverse()]}),(0,z.jsx)(`input`,{ref:c,className:`menu-filter`,value:n,onChange:e=>{r(e.target.value),a(0)},onKeyDown:h,placeholder:`Search actions`,autoComplete:`off`,spellCheck:!1,"aria-label":`Search actions`,"aria-controls":`menu-list`,"aria-activedescendant":f?`action-${f.id}`:void 0})]})}var pt=240,mt=170,ht=600,gt=`cubic-bezier(.2, .8, .2, 1)`;function _t(){return!window.matchMedia(`(prefers-reduced-motion: reduce)`).matches}function vt(e){return e?Array.from(e.querySelectorAll(`.row[data-id]`)):[]}function yt(e){let t=new Map;for(let n of vt(e))t.set(n.dataset.id??``,n.getBoundingClientRect().top);return t}function bt(e,t){for(let n of vt(e)){let e=t.get(n.dataset.id??``);if(e===void 0){n.animate([{opacity:0,height:`0px`,transform:`translateX(-16px)`},{opacity:1,height:`${n.offsetHeight}px`,transform:`none`}],{duration:pt,easing:gt});continue}let r=e-n.getBoundingClientRect().top;Math.abs(r)<1||n.animate([{transform:`translateY(${r}px)`},{transform:`none`}],{duration:pt,easing:gt})}}async function xt(e,t=0){if(!e||!_t())return()=>{};let n=e.animate([{opacity:1,height:`${e.offsetHeight}px`,transform:`none`},{opacity:0,height:`0px`,transform:`translateX(-16px)`}],{duration:mt,delay:t,easing:`ease-in`,fill:`forwards`});return await n.finished.catch(()=>{}),()=>n.cancel()}function St(e){if(!e)return;for(let t of e.getAnimations())t.id===`hail`&&t.cancel();let t=e.getAttribute(`aria-selected`)===`true`,n=t?`rgba(255, 255, 255, 0.8)`:getComputedStyle(e).getPropertyValue(`--cb-accent`).trim()||`#378add`,r={boxShadow:`inset 0 0 0 2px transparent`,easing:`ease-in-out`},i={boxShadow:`inset 0 0 0 2px ${n}`,easing:`ease-in-out`};if(e.animate([r,{...i,offset:.2},{...r,offset:.5},{...i,offset:.7},r],{duration:ht,id:`hail`}),!t||!_t())return;let a=1+Math.min(.025,8/Math.max(e.offsetWidth,1));e.animate([{transform:`none`,easing:gt},{transform:`scale(${a})`,offset:.4,easing:`ease-in-out`},{transform:`none`}],{duration:ht/2,id:`hail`})}async function Ct(e){let t=e.length>1?Math.min(18,240/e.length):0,n=await Promise.all(e.map((e,n)=>xt(e,n*t)));return()=>n.forEach(e=>e())}function wt({characters:e,words:t,paragraphs:n}){let r=(e,t)=>`${e.toLocaleString()} ${e===1?t:`${t}s`}`;return[r(e,`character`),r(t,`word`),r(n,`paragraph`)]}function Tt(e){let t=e.replace(/^https?:\/\//i,``);/^[^/?#]+\/$/.test(t)&&(t=t.slice(0,-1));try{t=decodeURI(t)}catch{}return t}function Et(e,t){if(!e)return;let n=e.replace(/[\t\n\r]/g,``).trim();return t.find(e=>e.url===n)}function Dt(e,t){let n=[];for(let{url:e}of t)n.push({text:e,url:e}),/^https:\/\/www\./i.test(e)&&n.push({text:e.slice(8),url:e});if(!n.length||!e)return[e];let r=[],i=0,a=0;for(;a<e.length;){let t=null;for(let r of n){let n=e.indexOf(r.text,a);for(;n>=0&&Ot(e,n);)n=e.indexOf(r.text,n+1);n<0||(!t||n<t.start||n===t.start&&r.text.length>t.text.length)&&(t={start:n,...r})}if(!t)break;t.start>i&&r.push(e.slice(i,t.start)),r.push({text:t.text,url:t.url}),i=a=t.start+t.text.length}return i<e.length&&r.push(e.slice(i)),r}function Ot(e,t){let n=e[t-1];return n!==void 0&&/[\p{L}\p{N}.@/\-_+]/u.test(n)}function kt({links:e,count:t,onOpen:n}){let r=(0,I.useRef)(null);Xe(r);let i=`${t} ${t===1?`link`:`links`}`;return(0,z.jsxs)(`section`,{className:`links`,"aria-label":i,children:[(0,z.jsx)(`header`,{className:`links-head`,children:t>e.length?`First ${e.length} of ${i}`:i}),(0,z.jsx)(`ul`,{ref:r,children:e.map(e=>(0,z.jsx)(`li`,{children:(0,z.jsxs)(`button`,{type:`button`,className:`link-line`,title:e.url,"aria-label":`Open ${e.text??Tt(e.url)} in the browser`,onMouseDown:e=>e.preventDefault(),onClick:()=>n(e.url),children:[(0,z.jsx)(d,{kind:`link`}),(0,z.jsxs)(`span`,{className:`link-text`,children:[e.text&&(0,z.jsx)(`span`,{className:`link-words`,children:e.text}),(0,z.jsx)(`span`,{className:`link-address`,children:Tt(e.url)})]}),(0,z.jsx)(p,{})]})},e.url))})]})}var At=(function(){let e=typeof document<`u`&&document.createElement(`link`).relList;return e&&e.supports&&e.supports(`modulepreload`)?`modulepreload`:`preload`})(),jt=function(e,t){return new URL(e,t).href},Mt={},Y=function(e,t,n){let r=Promise.resolve();if(t&&t.length>0){let e=document.getElementsByTagName(`link`),i=document.querySelector(`meta[property=csp-nonce]`),a=i?.nonce||i?.getAttribute(`nonce`);function o(e){return Promise.all(e.map(e=>Promise.resolve(e).then(e=>({status:`fulfilled`,value:e}),e=>({status:`rejected`,reason:e}))))}function s(e){return import.meta.resolve?import.meta.resolve(e):new URL(e,import.meta.url).href}r=o(t.map(t=>{if(t=jt(t,n),t=s(t),t in Mt)return;Mt[t]=!0;let r=t.endsWith(`.css`);for(let n=e.length-1;n>=0;n--){let i=e[n];if(i.href===t&&(!r||i.rel===`stylesheet`))return}let i=document.createElement(`link`);if(i.rel=r?`stylesheet`:At,r||(i.as=`script`),i.crossOrigin=``,i.href=t,a&&i.setAttribute(`nonce`,a),document.head.appendChild(i),r)return new Promise((e,n)=>{i.addEventListener(`load`,e),i.addEventListener(`error`,()=>n(Error(`Unable to preload CSS for ${t}`)))})}).filter(e=>e!==void 0))}function i(e){let t=new Event(`vite:preloadError`,{cancelable:!0});if(t.payload=e,window.dispatchEvent(t),!t.defaultPrevented)throw e}return r.then(t=>{for(let e of t||[])e.status===`rejected`&&i(e.reason);return e().catch(i)})},Nt=null;function Pt(){return Nt??=Promise.all([Y(()=>import(`./katex-C6KMj_Gt.js`),[],import.meta.url),Y(()=>Promise.resolve({}),__vite__mapDeps([0]),import.meta.url)]).then(([e])=>e.default.render),Nt}function X({tex:e,className:t}){let n=(0,I.useRef)(null);return(0,I.useLayoutEffect)(()=>{let t=n.current;if(!t)return;let r=!0;return Pt().then(n=>{r&&n(e,t,{throwOnError:!1,output:`htmlAndMathml`})}).catch(()=>{r&&(t.textContent=e)}),()=>{r=!1}},[e]),(0,z.jsx)(`span`,{ref:n,className:t?`tex ${t}`:`tex`})}var Ft={expression:`Expression`,percentage:`Percentage`,linear:`Linear equation`,quadratic:`Quadratic equation`,equation:`Equation`,check:`Check`},It=`math`,Lt=`math-on`;function Rt({list:e,text:t,body:n,onCopy:r}){let i=(0,I.useRef)(null);Xe(i);let[a,o]=(0,I.useState)(null);zt(n,e,t,a);let s=e.filter(e=>e.answers?.length).map(e=>e.answers.map(e=>e.copy).join(`, `)).join(`
`),c=`${e.length} found`;return(0,z.jsxs)(`section`,{className:`math`,"aria-label":`Math, ${c}`,children:[(0,z.jsxs)(`header`,{className:`math-head`,children:[(0,z.jsxs)(`span`,{children:[`Math · `,c]}),s&&r&&(0,z.jsxs)(`button`,{type:`button`,className:`bare math-all`,title:`Copy every answer`,onMouseDown:e=>e.preventDefault(),onClick:()=>r(s),children:[(0,z.jsx)(h,{}),`Copy all`]})]}),(0,z.jsx)(`div`,{className:`math-list`,ref:i,children:e.map((e,t)=>(0,z.jsxs)(`div`,{className:`math-card`,onMouseEnter:()=>o(t),onMouseLeave:()=>o(e=>e===t?null:e),children:[(0,z.jsxs)(`div`,{className:`math-top`,children:[(0,z.jsx)(`span`,{className:`math-kind`,children:Ft[e.sort]}),e.holds!==void 0&&(0,z.jsx)(`span`,{className:e.holds?`math-verdict pass`:`math-verdict fail`,children:e.holds?`✓ True`:`✕ False`})]}),(0,z.jsx)(X,{className:`math-tex`,tex:e.tex}),!!e.answers?.length&&(0,z.jsx)(`div`,{className:`math-answers`,children:e.answers.map(e=>(0,z.jsxs)(`button`,{type:`button`,className:`math-answer`,title:`Copy ${e.copy}`,"aria-label":`Copy ${e.copy}`,onMouseDown:e=>e.preventDefault(),onClick:()=>r?.(e.copy),children:[(0,z.jsx)(X,{tex:e.tex}),(0,z.jsx)(h,{})]},e.copy))}),e.note&&(0,z.jsx)(`div`,{className:`math-note`,children:e.note})]},`${e.from}:${e.to}`))})]})}function zt(e,t,n,r){let i=typeof CSS<`u`&&`highlights`in CSS?CSS.highlights:null;(0,I.useLayoutEffect)(()=>{let a=e.current;if(!i||!a)return;let o=Bt(a,t.map(e=>n.slice(e.from,e.to))),s=o.filter(e=>!!e);s.length&&i.set(It,new Highlight(...s));let c=r===null?null:o[r];return c?i.set(Lt,new Highlight(c)):i.delete(Lt),()=>{i.delete(It),i.delete(Lt)}},[e,t,n,r,i])}function Bt(e,t){let n=[],r=``,i=document.createTreeWalker(e,NodeFilter.SHOW_TEXT);for(let e=i.nextNode();e;e=i.nextNode())for(let t=0;t<e.data.length;t++)/\s/.test(e.data[t])||(n.push([e,t]),r+=e.data[t]);let a=0;return t.map(e=>{let t=e.replace(/\s+/g,``),i=t?r.indexOf(t,a):-1;if(i<0)return null;a=i+t.length;let[o,s]=[n[i],n[a-1]],c=document.createRange();return c.setStart(o[0],o[1]),c.setEnd(s[0],s[1]+1),c})}function Vt(e,t){return{className:`link live`,role:`link`,tabIndex:-1,title:e,onClick:()=>{window.getSelection()?.isCollapsed!==!1&&t(e)}}}function Ht(e,t,n){if(!n||!t.length)return e;let r=Dt(e,t);return r.length===1&&typeof r[0]==`string`?e:(0,I.createElement)(I.Fragment,null,...r.map((e,t)=>typeof e==`string`?e:(0,I.createElement)(`span`,{key:t,...Vt(e.url,n)},e.text)))}function Ut({expansions:e,grip:t,onCopy:n,onOpen:r}){let i=(0,I.useRef)(null);Xe(i);let[a,o]=(0,I.useState)(new Set),s=e=>o(t=>{let n=new Set(t);return n.delete(e)||n.add(e),n}),{mixed:c}=Wt(e);return(0,z.jsxs)(`section`,{className:`snippet`,"aria-label":`Expands to`,children:[t,(0,z.jsx)(`div`,{ref:i,className:`snippet-scroll`,children:e.map((e,t)=>(0,z.jsxs)(`div`,{className:`expansion`,children:[(0,z.jsxs)(`header`,{className:`snippet-head`,children:[(0,z.jsxs)(`button`,{type:`button`,className:`snippet-toggle`,"aria-expanded":!a.has(t),"aria-controls":`expansion-${t}`,title:a.has(t)?`Show what it expands to`:`Fold it away`,onMouseDown:e=>e.preventDefault(),onClick:()=>s(t),children:[(0,z.jsx)(we,{}),(0,z.jsxs)(`span`,{className:`snippet-from`,children:[`Expands to`,e.profiles.length?` · ${e.profiles.join(`, `)}`:``]}),c&&e.dynamic&&(0,z.jsx)(`span`,{className:`snippet-mark`,title:`May change each time it's shown`,"aria-label":`May change`,children:(0,z.jsx)(_e,{})})]}),n&&(0,z.jsx)(`button`,{type:`button`,className:`bare`,title:`Copy`,"aria-label":`Copy what it expands to`,onMouseDown:e=>e.preventDefault(),onClick:()=>n(e.text),children:(0,z.jsx)(h,{})})]}),!a.has(t)&&(0,z.jsx)(`div`,{id:`expansion-${t}`,className:`body snippet-text`,children:Ht(e.text,e.links,r)})]},t))}),(0,z.jsx)(Gt,{expansions:e})]})}function Wt(e){let t=e.filter(e=>e.dynamic).length;return{count:t,mixed:t>0&&t<e.length}}function Gt({expansions:e}){let{count:t,mixed:n}=Wt(e);return t?(0,z.jsxs)(`p`,{className:`snippet-fresh`,children:[n&&(0,z.jsx)(_e,{}),t>1?`May change each time they're shown`:`May change each time it's shown`]}):null}function Kt(e,{from:t,to:n}){let[r,i]=qt(t,n)?[t,n]:[n,t];return!qt(e,r)&&!qt(i,e)}function qt(e,t){return e[0]<t[0]||e[0]===t[0]&&e[1]<t[1]}function Jt(e,t){let n=0;return e.lines.forEach((e,r)=>{let i=Math.max(1,e.words.length);for(let e=0;e<i;e++)Kt([r,e],t)&&n++}),n}function Yt({layout:e,picture:t,picked:n,onPick:r}){let[i,a]=(0,I.useState)(null),[o,s]=(0,I.useState)(null);if((0,I.useLayoutEffect)(()=>{let e=t.current;if(!e)return;let n=()=>e.offsetWidth&&e.offsetHeight?a({left:e.offsetLeft,top:e.offsetTop,width:e.offsetWidth,height:e.offsetHeight}):a(null);n();let r=new ResizeObserver(n);return r.observe(e),e.addEventListener(`load`,n),()=>{r.disconnect(),e.removeEventListener(`load`,n)}},[t]),(0,I.useEffect)(()=>{if(!o)return;let e=()=>s(null);return window.addEventListener(`pointerup`,e),window.addEventListener(`blur`,e),()=>{window.removeEventListener(`pointerup`,e),window.removeEventListener(`blur`,e)}},[o]),!i||!e.width||!e.height)return null;let c=([t,n,r,i])=>({left:`${t/e.width*100}%`,top:`${n/e.height*100}%`,width:`${r/e.width*100}%`,height:`${i/e.height*100}%`}),l=e=>t=>{t.button===0&&(t.stopPropagation(),t.preventDefault(),t.shiftKey&&n?r({from:n.from,to:e}):r({from:e,to:e}),s(t.shiftKey&&n?n.from:e))},u=e=>t=>{o&&t.buttons&1&&r({from:o,to:e})};return(0,z.jsx)(`div`,{className:`image-text`,style:i,"aria-hidden":`true`,children:e.lines.flatMap((e,t)=>{let i=e.words.length?e.words:[{text:e.text,frame:e.frame}];return i.map((e,a)=>{let o=[t,a],s=n?Kt(o,n):!1;return(0,z.jsx)(`span`,{className:s?`word on`:`word`,style:c(e.frame),onPointerDown:l(o),onPointerEnter:u(o),onDoubleClick:()=>r({from:[t,0],to:[t,i.length-1]})},`${t}.${a}`)})})})}var Xt=`pdfFit`,Zt={pane:`height`,zoomed:`width`},Qt=e=>e===`width`||e===`height`;function $t(e){let t=e??{};return{pane:Qt(t.pane)?t.pane:Zt.pane,zoomed:Qt(t.zoomed)?t.zoomed:Zt.zoomed}}function en(){try{return $t(JSON.parse(localStorage.getItem(Xt)??`null`))}catch{return Zt}}function tn(){try{localStorage.setItem(Xt,JSON.stringify(nn))}catch{}}var nn=en();function rn(e){return e?nn.zoomed:nn.pane}function an(e){nn=$t(e),tn()}function on(e,t){nn={...nn,[e?`zoomed`:`pane`]:t},tn(),T({kind:`pdfFit`,zoomed:e,fit:t}).catch(()=>{})}var sn=[1,1.5,2,3];function cn(e,t,n,r){let i=t===`height`&&n.height>0?Math.min(n.width,n.height/e):n.width,a=Math.floor(i*r);return{width:a,height:Math.floor(a*e)}}var ln=16e6,un=null;function dn(){return un??=Promise.all([Y(()=>import(`./pdf-BLFDzHGQ.js`),[],import.meta.url),Y(()=>import(`./pdf.worker-BkZ2vcTL.js`),[],import.meta.url),Y(()=>import(`./pdfFonts-BQcGIil6.js`),[],import.meta.url)]).then(([e,{default:t},{ShippedFonts:n}])=>(e.GlobalWorkerOptions.workerPort=new t,{lib:e,fonts:n})),un.catch(()=>un=null),un}var fn=Promise.resolve();function pn({src:e,name:t,onFail:n,flow:i=!1}){let a=(0,I.useRef)(null),o=(0,I.useRef)(null),[s,c]=(0,I.useState)(null),[l,u]=(0,I.useState)(1),[d,p]=(0,I.useState)(0),[m,h]=(0,I.useState)(0),[g,_]=(0,I.useState)(0),[y,b]=(0,I.useState)(()=>rn(i));(0,I.useEffect)(()=>b(rn(i)),[i]);let ee=e=>{b(e),on(i,e)},te=(0,I.useRef)(n);te.current=n,(0,I.useEffect)(()=>{let t=!0,n=null;return(async()=>{try{let{lib:r,fonts:i}=await dn();if(await fn,!t)return;n=r.getDocument({url:e,useWasm:!1,disableFontFace:!0,useSystemFonts:!1,standardFontDataUrl:`standard_fonts/`,BinaryDataFactory:i,disableStream:!0,disableRange:!1,rangeChunkSize:524288,disableAutoFetch:!0});let a=await n.promise;t&&c(a)}catch{t&&te.current()}})(),()=>{if(t=!1,c(null),n){let e=n;fn=fn.then(()=>e.destroy()).catch(()=>{})}}},[e]),(0,I.useEffect)(()=>{let e=a.current;if(!e)return;let t=new ResizeObserver(([e])=>{h(Math.floor(e?.contentRect.width??0)),_(Math.floor(e?.contentRect.height??0))});return t.observe(e),()=>t.disconnect()},[]),(0,I.useEffect)(()=>{let e=o.current;if(i||!s||!e||!m)return;let t=!0,n=null;return(async()=>{try{let r=await s.getPage(l);if(!t)return;let i=r.getViewport({scale:1}),a=cn(i.height/i.width,y,{width:m,height:g},sn[d]);n=gn(r,e,a.width/i.width),await n.promise,r.cleanup()}catch{}})(),()=>{t=!1,n?.cancel()}},[s,l,d,m,g,i,y]);let ne=(0,I.useRef)(l);ne.current=l,(0,I.useEffect)(()=>{let e=a.current;if(!i||!e||!s)return;let t=e.querySelector(`[data-page="${ne.current}"]`);t&&ne.current>1&&e.scrollTo(e.scrollLeft,t.offsetTop-mn)},[i,d,s,y]);let x=s?.numPages??0,S=e=>{let t=Math.min(Math.max(l+e,1),x);u(t);let n=a.current;if(n){if(i){let e=n.querySelector(`[data-page="${t}"]`);n.scrollTo(n.scrollLeft,e?e.offsetTop-mn:0)}else n.scrollTo(0,0)}},ie=e=>p(t=>Math.min(Math.max(t+e,0),sn.length-1)),C=e=>e.preventDefault();return(0,z.jsxs)(`div`,{className:`player pdf`,children:[(0,z.jsx)(`div`,{className:`pdf-sheet`,ref:a,onScroll:i?()=>u(_n(a.current)):void 0,children:i?s&&m>0&&(0,z.jsx)(vn,{doc:s,room:{width:m,height:Math.max(0,g-2*mn)},fit:y,zoom:sn[d],root:a,name:t}):(0,z.jsx)(`canvas`,{ref:o,role:`img`,"aria-label":s?`${t}, page ${l} of ${x}`:t,hidden:!s})}),(0,z.jsxs)(`div`,{className:`pdf-bar`,children:[(0,z.jsx)(`button`,{type:`button`,className:`vbtn`,"aria-label":`Previous page`,disabled:l<=1,onMouseDown:C,onClick:()=>S(-1),children:(0,z.jsx)(r,{})}),(0,z.jsx)(`span`,{className:`clock`,children:x?`${l} / ${x}`:`…`}),(0,z.jsx)(`button`,{type:`button`,className:`vbtn`,"aria-label":`Next page`,disabled:l>=x,onMouseDown:C,onClick:()=>S(1),children:(0,z.jsx)(we,{})}),(0,z.jsx)(`span`,{className:`pdf-gap`}),(0,z.jsx)(`button`,{type:`button`,className:`vbtn`,"aria-label":y===`width`?`Fit height`:`Fit width`,title:y===`width`?`Fit height: the whole page in view`:`Fit width`,disabled:!s,onMouseDown:C,onClick:()=>ee(y===`width`?`height`:`width`),children:y===`width`?(0,z.jsx)(f,{}):(0,z.jsx)(v,{})}),(0,z.jsx)(`button`,{type:`button`,className:`vbtn`,"aria-label":`Zoom out`,disabled:!s||d<=0,onMouseDown:C,onClick:()=>ie(-1),children:(0,z.jsx)(re,{})}),(0,z.jsxs)(`span`,{className:`clock`,children:[Math.round(sn[d]*100),`%`]}),(0,z.jsx)(`button`,{type:`button`,className:`vbtn`,"aria-label":`Zoom in`,disabled:!s||d>=sn.length-1,onMouseDown:C,onClick:()=>ie(1),children:(0,z.jsx)(A,{})})]})]})}var mn=8,hn=`150% 0px`;function gn(e,t,n){let r=e.getViewport({scale:n}),i=Math.min(window.devicePixelRatio||1,Math.sqrt(ln/(r.width*r.height))),a=e.getViewport({scale:n*i});return t.width=Math.floor(a.width),t.height=Math.floor(a.height),t.style.width=`${Math.floor(r.width)}px`,t.style.height=`${Math.floor(r.height)}px`,e.render({canvas:t,viewport:a})}function _n(e){if(!e)return 1;let t=e.scrollTop+e.clientHeight/3,n=1;for(let r of e.querySelectorAll(`[data-page]`)){if(r.offsetTop>t)break;n=Number(r.dataset.page)}return n}function vn({doc:e,room:t,fit:n,zoom:r,root:i,name:a}){let[o,s]=(0,I.useState)(1.414);return(0,I.useEffect)(()=>{let t=!0;return e.getPage(1).then(e=>{let n=e.getViewport({scale:1});t&&s(n.height/n.width)}).catch(()=>{}),()=>{t=!1}},[e]),(0,z.jsx)(`div`,{className:`pdf-flow`,children:Array.from({length:e.numPages},(s,c)=>(0,z.jsx)(yn,{doc:e,number:c+1,sizeOf:e=>cn(e??o,n,t,r),root:i,name:a},c+1))})}function yn({doc:e,number:t,sizeOf:n,root:r,name:i}){let a=(0,I.useRef)(null),o=(0,I.useRef)(null),[s,c]=(0,I.useState)(!1),[l,u]=(0,I.useState)(null),d=n(l),f=(0,I.useRef)(n);return f.current=n,(0,I.useEffect)(()=>{let e=a.current;if(!e)return;let t=new IntersectionObserver(([e])=>c(!!e?.isIntersecting),{root:r.current,rootMargin:hn});return t.observe(e),()=>t.disconnect()},[r]),(0,I.useEffect)(()=>{let n=o.current;if(!n)return;if(!s){n.width=0,n.height=0;return}let r=!0,i=null;return(async()=>{try{let a=await e.getPage(t);if(!r)return;let o=a.getViewport({scale:1});u(o.height/o.width),i=gn(a,n,f.current(o.height/o.width).width/o.width),await i.promise,a.cleanup()}catch{}})(),()=>{r=!1,i?.cancel()}},[e,t,d.width,s]),(0,z.jsx)(`div`,{ref:a,className:`pdf-page`,"data-page":t,style:{width:d.width,height:d.height},children:(0,z.jsx)(`canvas`,{ref:o,role:`img`,"aria-label":`${i}, page ${t}`,hidden:!s})})}var bn=100,xn=2;function Sn({value:e}){return(0,z.jsx)(`div`,{className:`json-tree`,role:`tree`,children:(0,z.jsx)(Cn,{label:null,value:e,depth:0,last:!0})})}function Cn({label:e,value:t,depth:n,last:r}){let i=typeof t==`object`&&!!t,[a,o]=(0,I.useState)(n<xn),[s,c]=(0,I.useState)(bn),l=r?``:`,`,u=e!==null&&(0,z.jsxs)(z.Fragment,{children:[(0,z.jsx)(`span`,{className:`json-key`,children:e}),(0,z.jsx)(`span`,{className:`json-punct`,children:`: `})]});if(!i)return(0,z.jsxs)(`div`,{className:`json-row`,role:`treeitem`,style:{paddingLeft:Tn(n)},children:[(0,z.jsx)(`span`,{className:`json-caret`}),u,(0,z.jsx)(wn,{value:t}),(0,z.jsx)(`span`,{className:`json-punct`,children:l})]});let d=Array.isArray(t),f=d?t.map((e,t)=>[String(t),e]):Object.entries(t),[p,m]=d?[`[`,`]`]:[`{`,`}`];return(0,z.jsxs)(z.Fragment,{children:[(0,z.jsxs)(`div`,{className:`json-row json-branch`,role:`treeitem`,"aria-expanded":f.length?a:void 0,style:{paddingLeft:Tn(n)},onMouseDown:e=>e.preventDefault(),onClick:()=>f.length&&o(!a),children:[(0,z.jsx)(`span`,{className:`json-caret`,children:f.length?a?`▾`:`▸`:``}),u,(0,z.jsx)(`span`,{className:`json-punct`,children:p}),!a&&(0,z.jsxs)(z.Fragment,{children:[f.length>0&&(0,z.jsx)(`span`,{className:`json-count`,children:d?`${f.length} items`:`${f.length} keys`}),(0,z.jsxs)(`span`,{className:`json-punct`,children:[m,l]})]})]}),a&&(0,z.jsxs)(z.Fragment,{children:[f.slice(0,s).map(([e,t],r)=>(0,z.jsx)(Cn,{label:d?null:JSON.stringify(e),value:t,depth:n+1,last:r===f.length-1},e)),f.length>s&&(0,z.jsxs)(`div`,{className:`json-row json-more`,style:{paddingLeft:Tn(n+1)},onMouseDown:e=>e.preventDefault(),onClick:()=>c(s+bn),children:[`… `,(f.length-s).toLocaleString(),` more`]}),(0,z.jsxs)(`div`,{className:`json-row`,style:{paddingLeft:Tn(n)},children:[(0,z.jsx)(`span`,{className:`json-caret`}),(0,z.jsxs)(`span`,{className:`json-punct`,children:[m,l]})]})]})]})}function wn({value:e}){return e===null?(0,z.jsx)(`span`,{className:`json-null`,children:`null`}):typeof e==`string`?(0,z.jsx)(`span`,{className:`json-string`,children:JSON.stringify(e)}):typeof e==`number`?(0,z.jsx)(`span`,{className:`json-number`,children:String(e)}):(0,z.jsx)(`span`,{className:`json-bool`,children:String(e)})}function Tn(e){return`${e*14}px`}var En={b:`b`,strong:`strong`,i:`i`,em:`em`,u:`u`,ins:`u`,s:`s`,strike:`s`,del:`del`,mark:`mark`,code:`code`,kbd:`kbd`,pre:`pre`,sup:`sup`,sub:`sub`,small:`small`,p:`p`,div:`div`,br:`br`,hr:`hr`,blockquote:`blockquote`,ul:`ul`,ol:`ol`,li:`li`,h1:`h1`,h2:`h2`,h3:`h3`,h4:`h4`,h5:`h5`,h6:`h6`,table:`table`,thead:`thead`,tbody:`tbody`,tr:`tr`,td:`td`,th:`th`,span:`span`,font:`span`,a:`span`,section:`div`,article:`div`,header:`div`,footer:`div`,figure:`div`,figcaption:`div`},Dn=new Set([`script`,`style`,`head`,`title`,`template`,`noscript`,`svg`,`math`,`iframe`,`object`,`img`,`video`,`audio`,`canvas`,`button`,`input`,`select`,`textarea`]),On=3e3,kn=40,An;function jn(e){if(!e||(An??=document.createElement(`canvas`).getContext(`2d`),!An))return;An.fillStyle=`#000`,An.fillStyle=e;let t=/^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(String(An.fillStyle));if(!t)return;let[n=0,r=0,i=0]=t.slice(1).map(e=>parseInt(e,16));return Math.max(n,r,i)-Math.min(n,r,i)>=40?`rgb(${n}, ${r}, ${i})`:void 0}function Mn(e){let t=e.style,n={},r=t?.fontWeight;r&&(n.fontWeight=r===`bold`||r===`bolder`||Number(r)>=600?`bold`:`normal`),t?.fontStyle===`italic`||t?.fontStyle===`oblique`?n.fontStyle=`italic`:t?.fontStyle===`normal`&&(n.fontStyle=`normal`);let i=t?.textDecorationLine||t?.textDecoration||``,a=[`underline`,`line-through`].filter(e=>i.includes(e));a.length&&(n.textDecorationLine=a.join(` `));let o=t?.fontFamily||(e.tagName===`FONT`?e.getAttribute(`face`):null)||``;o&&(n.fontFamily=`${o}, -apple-system, system-ui, sans-serif`);let s=jn(t?.color||(e.tagName===`FONT`?e.getAttribute(`color`)??``:``));return s&&(n.color=s),Object.keys(n).length?n:void 0}function Nn({html:e,fallback:t,maxNodes:n=On,links:r=[],onOpen:i,bodyRef:a}){let o=new DOMParser().parseFromString(e,`text/html`),s=0,c=!1,l=(e,t,a,o=!1)=>{if(++s>n)return null;if(e.nodeType===Node.TEXT_NODE){let t=e.textContent??``;return t.trim()&&(c=!0),o?t:Ht(t,r,i)}if(e.nodeType!==Node.ELEMENT_NODE||t>kn)return null;let u=e,d=u.tagName.toLowerCase();if(d===`input`&&u.getAttribute(`type`)===`checkbox`)return c=!0,u.hasAttribute(`checked`)?`☑ `:`☐ `;if(Dn.has(d))return null;let f=Array.from(u.childNodes,(e,n)=>l(e,t+1,n,o||d===`a`)),p=En[d];if(!p)return(0,I.createElement)(`span`,{key:a,style:Mn(u)},...f);if(p===`br`||p===`hr`)return(0,I.createElement)(p,{key:a});let m={key:a,style:Mn(u)};if(d===`a`){let e=i&&Et(u.getAttribute(`href`),r);Object.assign(m,e?Vt(e.url,i):{className:`link`})}return(0,I.createElement)(p,m,...f)},u=l(o.body,0,0);return c?(0,z.jsx)(`div`,{ref:a,className:`body rich-html`,children:u}):t}var Pn=65536,Fn=1048576,In=2e4;function Ln({src:e,json:t,markdown:n,language:r,onFail:i}){let[a,o]=(0,I.useState)(null),[s,c]=(0,I.useState)(!1),[l,u]=(0,I.useState)(null),d=(0,I.useRef)(i);d.current=i,(0,I.useEffect)(()=>{let n=new AbortController,r=t?Fn:Pn;return(async()=>{try{let i=await fetch(e,{headers:{Range:`bytes=0-${r-1}`},signal:n.signal});if(i.status===416)return o({text:``,cut:!1,tree:void 0});if(!i.ok)throw Error(String(i.status));let a=new Uint8Array(await i.arrayBuffer());if(a.includes(0))throw Error(`binary`);let s=Number(i.headers.get(`Content-Range`)?.split(`/`)[1])||a.length,c=new TextDecoder().decode(a),l=t&&s<=Fn?zn(c):void 0,u=c.length>Pn||s>a.length,d=c.slice(0,Pn);u&&(d=d.slice(0,d.lastIndexOf(`
`)+1)||d),o({text:d,cut:u,tree:l})}catch{n.signal.aborted||d.current()}})(),()=>n.abort()},[e,t]);let[f,p]=(0,I.useState)(null);(0,I.useEffect)(()=>{let e=a?.text;if(!n||!e)return;let t=!0;return Y(async()=>{let{markdownHtml:e}=await import(`./markdown-ZAH5kwRn.js`);return{markdownHtml:e}},[],import.meta.url).then(({markdownHtml:n})=>t&&p({text:e,html:n(e)})).catch(()=>{}),()=>{t=!1}},[n,a?.text]);let m=f&&f.text===a?.text?f:null,h=(0,I.useMemo)(()=>m&&(0,z.jsx)(Nn,{html:m.html,maxNodes:In,fallback:(0,z.jsx)(`pre`,{children:m.text})}),[m]),g=a?.tree===void 0?n&&a?.text?`doc`:null:`tree`,_=g===`tree`&&!s,v=g===`doc`&&!s&&!!h,y=a&&!_&&!v?a.text:``;if((0,I.useEffect)(()=>{if(!y||!r)return;let e=!0;return Y(async()=>{let{highlight:e}=await import(`./highlight-C7gy0f0K.js`);return{highlight:e}},__vite__mapDeps([1,2]),import.meta.url).then(({highlight:e})=>e(y,r)).then(t=>e&&u({text:y,nodes:t})).catch(()=>{}),()=>{e=!1}},[y,r]),!a)return(0,z.jsx)(`div`,{className:`file-text`});let b=e=>e.preventDefault();return(0,z.jsxs)(`div`,{className:`file-text`,children:[_?(0,z.jsx)(Sn,{value:a.tree}):v?(0,z.jsx)(`div`,{className:`file-doc`,children:h}):g===`doc`&&!s?(0,z.jsx)(`div`,{className:`file-doc`}):r&&y?(0,z.jsxs)(`div`,{className:`code-scroll`,children:[(0,z.jsx)(`div`,{className:`gutter`,"aria-hidden":`true`,children:Rn(y)}),(0,z.jsx)(`pre`,{className:`code`,children:l?.text===y?l.nodes:y})]}):(0,z.jsx)(`pre`,{children:y||`Empty file`}),(g||a.cut)&&(0,z.jsxs)(`div`,{className:`file-text-more`,children:[a.cut&&!_&&(0,z.jsxs)(`span`,{children:[`First `,Math.round(Pn/1024),` KB of the file`]}),g&&(0,z.jsxs)(`span`,{className:`file-text-modes`,role:`group`,"aria-label":`Show as`,children:[(0,z.jsx)(`button`,{type:`button`,"aria-pressed":!s,onMouseDown:b,onClick:()=>c(!1),children:g===`tree`?`Tree`:`Preview`}),(0,z.jsx)(`button`,{type:`button`,"aria-pressed":s,onMouseDown:b,onClick:()=>c(!0),children:g===`tree`?`Text`:`Code`})]})]})]})}function Rn(e){let t=1;for(let n=e.indexOf(`
`);n!==-1;n=e.indexOf(`
`,n+1))t++;return e.endsWith(`
`)&&t--,Array.from({length:t},(e,t)=>t+1).join(`
`)}function zn(e){try{return JSON.parse(e)}catch{return}}var Bn=String.raw`[+-]?(?:\d+(?:\.\d+)?|\.\d+)`,Vn=new RegExp(String.raw`^(${Bn})(%|deg|grad|rad|turn)?$|^none$`,`i`),Hn=(e,t,n)=>Math.min(n,Math.max(t,e));function Un(e){let t=Vn.exec(e);return t?t[1]?{n:Number(t[1]),unit:(t[2]??``).toLowerCase()}:{n:0,unit:``}:null}function Wn(e){if(e===void 0)return 1;let t=Un(e);return!t||t.unit&&t.unit!==`%`?null:Hn(t.unit===`%`?t.n/100:t.n,0,1)}function Gn(e){if(e.includes(`,`)){let t=e.split(`,`).map(e=>e.trim());return t.length!==3&&t.length!==4?null:{three:t.slice(0,3),alpha:t[3]}}let[t,n,r]=e.split(`/`).map(e=>e.trim());if(r!==void 0||t===void 0)return null;let i=t.split(/\s+/);return i.length===3?{three:i,alpha:n}:null}function Kn(e,t,n){let r=t=>(t+e/30)%12,i=t*Math.min(n,1-n),a=e=>n-i*Math.max(-1,Math.min(r(e)-3,9-r(e),1));return[a(0)*255,a(8)*255,a(4)*255]}function qn(e){let t=e.trim(),n=/^#([0-9a-f]{3,4}|[0-9a-f]{6}|[0-9a-f]{8})$/i.exec(t)?.[1];if(n){let e=n.length<=4?[...n].map(e=>e+e).join(``):n,t=t=>parseInt(e.slice(t*2,t*2+2),16);return{r:t(0),g:t(1),b:t(2),a:e.length===8?t(3)/255:1}}let r=/^(rgba?|hsla?)\((.*)\)$/i.exec(t);if(!r)return null;let i=Gn(r[2].trim());if(!i)return null;let a=Wn(i.alpha),o=i.three.map(Un);if(a===null||o.some(e=>!e))return null;let[s,c,l]=o;if(r[1].toLowerCase().startsWith(`rgb`)){let e=e=>e.unit&&e.unit!==`%`?NaN:Hn(e.unit===`%`?e.n/100*255:e.n,0,255),[t,n,r]=[e(s),e(c),e(l)];return[t,n,r].some(Number.isNaN)?null:{r:t,g:n,b:r,a}}let u={"":1,deg:1,grad:.9,rad:180/Math.PI,turn:360}[s.unit];if(u===void 0||[c,l].some(e=>e.unit&&e.unit!==`%`))return null;let[d,f,p]=Kn((s.n*u%360+360)%360,Hn(c.n/100,0,1),Hn(l.n/100,0,1));return{r:d,g:f,b:p,a}}var Jn=e=>Hn(Math.round(e),0,255),Yn=e=>Jn(e).toString(16).padStart(2,`0`).toUpperCase(),Xn=(e,t=0)=>Number(e.toFixed(t)),Zn=e=>e.a<1?` / ${Xn(e.a,2)}`:``;function Qn(e){return`#${Yn(e.r)}${Yn(e.g)}${Yn(e.b)}${e.a<1?Yn(e.a*255):``}`}function $n(e){return`rgb(${Jn(e.r)} ${Jn(e.g)} ${Jn(e.b)}${Zn(e)})`}function er(e){let[t,n,r]=[e.r/255,e.g/255,e.b/255],i=Math.max(t,n,r),a=Math.min(t,n,r),o=(i+a)/2,s=i-a,c=0,l=0;return s&&(l=s/(1-Math.abs(2*o-1)),c=i===t?(n-r)/s%6:i===n?(r-t)/s+2:(t-n)/s+4,c=(c*60+360)%360),`hsl(${Xn(c)} ${Xn(l*100)}% ${Xn(o*100)}%${Zn(e)})`}function tr(e,t){let n=(t,n)=>t*e.a+n*(1-e.a);return{r:n(e.r,t.r),g:n(e.g,t.g),b:n(e.b,t.b),a:1}}var nr={r:255,g:255,b:255,a:1},rr={r:0,g:0,b:0,a:1};function ir(e){let t=e=>{let t=e/255;return t<=.04045?t/12.92:((t+.055)/1.055)**2.4};return .2126*t(e.r)+.7152*t(e.g)+.0722*t(e.b)}function ar(e,t){let[n,r]=[ir(e),ir(t)];return(Math.max(n,r)+.05)/(Math.min(n,r)+.05)}var or=`search`,sr=1e5,cr=`.card-head, .card-foot, button, input`;function lr(e,t,n,r){(0,I.useEffect)(()=>{let r=e.current,i=typeof CSS<`u`&&`highlights`in CSS?CSS.highlights:null,a=()=>i?.delete(or);if(!r||!Oe(t).length){a();return}let o=!1,s=0,c=()=>{s=0;let e=ur(r,t,n);i&&(e.length?i.set(or,new Highlight(...e)):i.delete(or));let a=e[0];a&&!o&&(o=!0,fr(a,r))},l=()=>{s||=window.setTimeout(c,16)};l();let u=new MutationObserver(l);return u.observe(r,{childList:!0,subtree:!0,characterData:!0}),()=>{u.disconnect(),window.clearTimeout(s),a()}},[e,t,n,r])}function ur(e,t,n){let r=[],i=``,a=document.createTreeWalker(e,NodeFilter.SHOW_TEXT,{acceptNode:e=>e.parentElement?.closest(cr)?NodeFilter.FILTER_REJECT:NodeFilter.FILTER_ACCEPT});for(let e=a.nextNode();e&&i.length<sr;e=a.nextNode()){let t=e.data;t&&(r.push({node:e,start:i.length}),i+=t)}if(!r.length)return[];let o=[];for(let[e,a]of F(i,t,n)){let t=dr(r,e),n=dr(r,a);if(!t||!n)continue;let i=document.createRange();i.setStart(t.node,t.offset),i.setEnd(n.node,n.offset),o.push(i)}return o}function dr(e,t){let n=0,r=e.length-1;for(;n<r;){let i=n+r+1>>1;e[i].start<t?n=i:r=i-1}let i=e[n];return i?{node:i.node,offset:Math.min(t-i.start,i.node.data.length)}:null}function fr(e,t){for(let n=e.startContainer.parentElement;n&&t.contains(n);n=n.parentElement){let r=e.getBoundingClientRect();if(!r.width&&!r.height)return;let i=getComputedStyle(n),a=n.getBoundingClientRect();if(/(auto|scroll)/.test(i.overflowY)&&n.scrollHeight>n.clientHeight&&(r.top<a.top||r.bottom>a.bottom)&&(n.scrollTop+=r.top-a.top-n.clientHeight/3),/(auto|scroll)/.test(i.overflowX)&&n.scrollWidth>n.clientWidth&&(r.left<a.left||r.right>a.right)&&(n.scrollLeft+=r.left-a.left-n.clientWidth/4),n===t)break}}var pr=typeof document<`u`&&document.visibilityState===`hidden`,mr=pr,hr=0,gr=new Set,_r=new Set;function Z(){return pr}function Q(){return hr}function vr(e){return pr?(gr.add(e),()=>gr.delete(e)):(e(),()=>{})}function yr(e){return _r.add(e),()=>_r.delete(e)}function br(){if(!pr)return;pr=!1,mr=!1;let e=[...gr];gr.clear();for(let t of e)t()}function xr(){window.addEventListener(`lumi:hidden`,()=>{pr=!0,mr=!1,hr+=1;for(let e of[..._r])e()}),window.addEventListener(`lumi:shown`,br),document.addEventListener(`visibilitychange`,()=>{mr&&document.visibilityState===`visible`&&br()})}var Sr=90,Cr=400,$=new Map,wr=64,Tr=e=>`${e.id}:${+!!e.ocr}`,Er=new Map;function Dr(){$.clear(),Er.clear()}function Or(e){return!!e}function kr({row:e,covered:n=!1,revealCap:r,revealAllCap:a,onShow:o,onOpen:c,onCopyColor:l,onCopySnippet:u,onCopyMath:f,onCopyWords:p,query:m=``,used:h=`exact`,zoomed:g=!1,onZoom:_,split:v}){let y=(0,I.useRef)(null),b=(0,I.useRef)(null);lr(y,m,h,e?.id);let[ee,te]=(0,I.useState)(null),[ne,re]=(0,I.useState)(null),[x,S]=(0,I.useState)(null);(0,I.useEffect)(()=>S(null),[e?.id]),(0,I.useEffect)(()=>{g||S(null)},[g]);let[C,ae]=(0,I.useState)(0);(0,I.useEffect)(()=>{let e=()=>{$.clear(),ae(e=>e+1)},t=[`lumi:profiles`,`lumi:settings`,`lumi:snippets`];for(let n of t)window.addEventListener(n,e);return()=>{for(let n of t)window.removeEventListener(n,e)}},[]);let[oe,w]=(0,I.useState)(null);(0,I.useEffect)(()=>{if(!e||n||e.kind===`image`&&!e.ocr)return;let t=Tr(e),r=$.get(t);if(r&&(te(r),!r.snippets?.some(e=>e.dynamic)))return;let i=!0,a=Q(),o=setTimeout(()=>i&&re(e.id),Cr),s=setTimeout(async()=>{try{let{text:n,html:r,counts:o,ocr:s,fileSize:c,fileToken:l,files:u,fileCount:d,links:f,linkCount:p,snippets:m,layout:h,math:g}=await ie({kind:`preview`,id:e.id});if(!(n||r||s)){i&&re(e.id);return}let _={id:e.id,text:n,html:r,counts:o,ocr:s,fileSize:c,fileToken:l,files:u,fileCount:d,links:f,linkCount:p,snippets:m,layout:h,math:g};a===Q()&&($.delete(t),$.set(t,_),$.size>wr&&$.delete($.keys().next().value)),i&&te(_)}catch(t){i&&!(t instanceof j)&&re(e.id)}},Sr);return()=>{i=!1,clearTimeout(s),clearTimeout(o)}},[e,n,C]);let[se,ce]=(0,I.useState)(null),[le,ue]=(0,I.useState)(null),de=(0,I.useRef)(null);(0,I.useEffect)(()=>ue(null),[e?.id]);let T=ee?.id===e?.id?ee:null;(0,I.useEffect)(()=>{if(!e||n||e.kind!==`image`||!e.ocr||!T)return;if(T.layout){ce({id:e.id,layout:T.layout});return}let t=Er.get(e.id);if(t){ce({id:e.id,layout:t});return}let r=!0,i=Q(),a=setTimeout(()=>{ie({kind:`layout`,id:e.id}).then(({layout:t})=>{t&&(i===Q()&&(Er.set(e.id,t),Er.size>wr&&Er.delete(Er.keys().next().value)),r&&ce({id:e.id,layout:t}))}).catch(()=>{})},Sr);return()=>{r=!1,clearTimeout(a)}},[e,n,T]);let fe=se&&se.id===e?.id?se.layout:null,E=le&&le.id===e?.id&&fe?le.picked:null;if((0,I.useEffect)(()=>{if(!E||!e)return;let t=t=>{let n=t.metaKey&&!t.ctrlKey&&!t.altKey&&t.key.toLowerCase()===`c`;(n||t.key===`Escape`)&&(n&&window.getSelection()?.isCollapsed===!1||(t.preventDefault(),t.stopPropagation(),n?p?.(e.id,E):ue(null)))};return window.addEventListener(`keydown`,t,!0),()=>window.removeEventListener(`keydown`,t,!0)},[E,e,p]),!e)return(0,z.jsx)(`aside`,{className:`preview empty-card`});let D=ee?.id===e.id?ee:$.get(Tr(e))??null,pe=e.kind===`rich`&&!D&&ne!==e.id,me=D?.text||e.title,he=e.kind===`rich`?D?.html:null,ge=e.kind===`image`?D?.ocr:null,_e=e.kind===`image`&&!!e.ocr,k=_e&&g&&x===e.id,ve=oe?.id===e.id?`${oe.w} × ${oe.h} px`:null,ye=e.kind===`file`&&D?.fileSize!=null?Kr(D.fileSize):null,be=(e.kind===`text`||e.kind===`rich`)&&D?.links?D.links:[],xe=e.kind===`rich`?be:[],Se=c?t=>c(e.id,t):void 0,A=(e.kind===`text`||e.kind===`rich`)&&D?.snippets?D.snippets:[],Ce=(e.kind===`text`||e.kind===`rich`)&&D?.math?D.math:[],we=(e.kind===`text`||e.kind===`rich`)&&!n&&D?.counts?D.counts:null,Te=e.appName||e.app,Ee=e.count>1?`${e.count}×`:`once`,M=(0,z.jsxs)(`header`,{className:`card-head`,children:[e.kind===`file`?(0,z.jsx)(s,{family:U(e.fileExt),many:(e.fileCount??0)>1}):(0,z.jsx)(d,{kind:e.kind}),(0,z.jsxs)(`span`,{children:[K[e.kind],Te?` · `:``,(0,z.jsx)(it,{app:e.app,name:e.appName,withName:!0},e.app??``)]}),(ve||ye)&&!n&&(0,z.jsx)(`span`,{className:`dims`,children:[ve,ye].filter(Boolean).join(` · `)}),_&&Or(e)&&!k&&(0,z.jsx)(`button`,{type:`button`,className:`bare zoom`,"aria-pressed":g,title:g?`Back to the list (⌘Y)`:`Give it the whole panel (⌘Y)`,"aria-label":g?`Back to the list`:`Expand preview`,onMouseDown:e=>e.preventDefault(),onClick:_,children:g?(0,z.jsx)(i,{}):(0,z.jsx)(t,{})})]}),De=(0,z.jsxs)(`footer`,{className:`card-foot`,children:[we&&(0,z.jsx)(`div`,{className:`card-counts`,children:wt(we).map((e,t)=>(0,z.jsxs)(`span`,{children:[t>0&&`\xA0· `,(0,z.jsx)(`span`,{className:`count`,children:e})]},t))}),`Copied `,Ie(e.last),` · `,Ee]});return n?(0,z.jsx)(`aside`,{className:`preview`,"aria-live":`polite`,children:(0,z.jsxs)(`div`,{className:`card`,ref:y,children:[M,(0,z.jsx)(Ar,{keys:r,allKeys:a,onShow:()=>o?.(e.id)}),De]})}):(0,z.jsx)(`aside`,{className:`preview`,"aria-live":`polite`,children:(0,z.jsxs)(`div`,{className:`card`,ref:y,children:[M,e.kind===`image`&&e.thumb&&!k&&(0,z.jsxs)(Ir,{id:e.id,className:`picture`,children:[(0,z.jsx)(`img`,{ref:de,alt:`Copied image`,src:O(e.thumb),draggable:!1,onLoad:t=>{let{naturalWidth:n,naturalHeight:r}=t.currentTarget;n&&r&&w({id:e.id,w:n,h:r})}}),fe&&(0,z.jsx)(Yt,{layout:fe,picture:de,picked:E,onPick:t=>ue(t&&{id:e.id,picked:t})},e.id)]}),_e&&(!g||k)&&(0,z.jsxs)(`section`,{className:`ocr-read`,children:[v&&!k&&e.thumb&&(0,z.jsx)(jr,{...v}),(0,z.jsxs)(`header`,{className:`ocr-head`,children:[E&&fe?(0,z.jsxs)(`span`,{className:`ocr-picked`,children:[Jt(fe,E)===1?`1 word`:`${Jt(fe,E)} words`,` selected`,(0,z.jsx)(`button`,{type:`button`,className:`bare`,title:`Copy the selected words (⌘C)`,onMouseDown:e=>e.preventDefault(),onClick:()=>p?.(e.id,E),children:`Copy`})]}):(0,z.jsx)(`span`,{children:fe?`Text in image · select it on the picture`:`Text in image`}),(0,z.jsx)(`button`,{type:`button`,className:`bare`,"aria-pressed":k,title:k?`Back to the list (⎋)`:`Give the text the whole panel`,"aria-label":k?`Back to the list`:`Expand text`,onMouseDown:e=>e.preventDefault(),onClick:()=>{if(k){_?.();return}S(e.id),g||_?.()},children:k?(0,z.jsx)(i,{}):(0,z.jsx)(t,{})})]}),(0,z.jsx)(`div`,{className:`body ocr`,children:ge??``})]}),e.kind===`file`&&(e.fileCount??0)<=1&&!D?.files?.length&&(0,z.jsx)(Lr,{id:e.id,family:U(e.fileExt),ext:e.fileExt??``,text:et(e.fileExt),token:D?.fileToken??null,name:e.title,onSize:(t,n)=>w({id:e.id,w:t,h:n}),whole:g},e.id),(0,z.jsxs)(Mr,{on:e.kind===`text`||e.kind===`rich`,even:A.length>0,children:[e.kind===`color`&&at(e.title)?(0,z.jsx)(Pr,{color:e.title,onCopy:l}):D?.files?.length?(0,z.jsx)(zr,{id:e.id,files:D.files,count:D.fileCount||D.files.length}):e.kind===`file`&&(e.fileCount??0)<=1?(0,z.jsx)(Vr,{path:me.split(`
`)[0]}):pe?(0,z.jsx)(`div`,{className:`body rich`}):he?(0,z.jsx)(Nn,{html:he,links:xe,onOpen:Se,bodyRef:b,fallback:(0,z.jsx)(`div`,{ref:b,className:`body rich`,children:Ht(me,xe,Se)})},e.id):e.kind===`link`&&c?(0,z.jsx)(Fr,{text:me,onOpen:()=>c(e.id)}):e.kind!==`image`&&(0,z.jsx)(`div`,{ref:b,className:e.kind===`rich`?`body rich`:`body`,children:Ht(me,xe,Se)}),A.length>0&&(0,z.jsx)(Ut,{grip:v&&(0,z.jsx)(jr,{...v}),expansions:A,onCopy:u?t=>u(e.id,t):void 0,onOpen:c?t=>c(e.id,t,!0):void 0},`snippets:${e.id}`),Ce.length>0&&(0,z.jsx)(Rt,{list:Ce,text:me,body:b,onCopy:f?t=>f(e.id,t):void 0},`math:${e.id}`),be.length>0&&Se&&(0,z.jsx)(kt,{links:be,count:D?.linkCount||be.length,onOpen:Se},`links:${e.id}`)]}),De]})})}function Ar({keys:e,allKeys:t,onShow:n}){return(0,z.jsxs)(`button`,{type:`button`,className:`cover`,onMouseDown:e=>e.preventDefault(),onClick:n,children:[(0,z.jsx)(`span`,{className:`cover-lines`,"aria-hidden":`true`}),(0,z.jsxs)(`span`,{className:`cover-note`,children:[(0,z.jsx)(g,{}),(0,z.jsx)(`span`,{className:`cover-title`,children:`Content hidden`}),(0,z.jsx)(`span`,{className:`cover-hint`,children:e?(0,z.jsxs)(z.Fragment,{children:[`Click or press `,(0,z.jsx)(`kbd`,{className:`cap quiet`,children:e}),` to show`]}):`Click to show`}),t&&(0,z.jsxs)(`span`,{className:`cover-hint`,children:[(0,z.jsx)(`kbd`,{className:`cap quiet`,children:t}),` shows every item`]})]})]})}function jr(e){return(0,z.jsx)(`div`,{className:`split-grip`,role:`separator`,"aria-orientation":`horizontal`,"aria-label":`Resize the two parts`,title:`Drag to resize · double-click to reset`,...e})}function Mr({on:e,even:t,children:n}){return e?(0,z.jsx)(`div`,{className:t?`texts even`:`texts`,children:n}):(0,z.jsx)(z.Fragment,{children:n})}var Nr={r:30,g:30,b:30,a:1};function Pr({color:e,onCopy:t}){let n=qn(e);if(!n)return(0,z.jsx)(`div`,{className:`chip painted`,style:G(e)});let r=tr(n,nr),i=ar(nr,r),a=ar(rr,r),o=e=>t?.(e);return(0,z.jsxs)(z.Fragment,{children:[(0,z.jsx)(`div`,{className:`chip painted`,style:G(e),children:(0,z.jsx)(`span`,{className:`chip-code`,style:{color:i>=a?`#fff`:`#000`},children:e})}),(0,z.jsxs)(`section`,{className:`color-info`,children:[(0,z.jsx)(`h3`,{children:`Formats`}),[[`HEX`,Qn(n)],[`RGB`,$n(n)],[`HSL`,er(n)]].map(([e,t])=>(0,z.jsxs)(`button`,{className:`format`,title:`Copy`,onClick:()=>o(t),children:[(0,z.jsx)(`span`,{className:`format-label`,children:e}),(0,z.jsx)(`span`,{className:`format-text`,children:t}),(0,z.jsx)(h,{})]},e)),(0,z.jsx)(`h3`,{children:`Text on it`}),(0,z.jsx)(`div`,{className:`text-on`,children:[[`White`,nr,i],[`Black`,rr,a]].map(([e,t,n])=>(0,z.jsxs)(`div`,{className:n>=Math.max(i,a)?`best`:void 0,title:`${e} text`,children:[(0,z.jsx)(`span`,{className:`sample`,style:{background:Qn(r),color:Qn(t)},children:`Aa`}),(0,z.jsxs)(`span`,{className:`ratio`,children:[n.toFixed(1),`:1`]}),(0,z.jsx)(`span`,{className:n>=4.5?`grade pass`:`grade fail`,children:n>=4.5?`AA`:`✕ AA`})]},e))}),n.a<1&&(0,z.jsxs)(z.Fragment,{children:[(0,z.jsxs)(`h3`,{children:[`Over light and dark · `,Math.round(n.a*100),`%`]}),(0,z.jsx)(`div`,{className:`over`,children:[[`Light`,nr],[`Dark`,Nr]].map(([t,r])=>{let i=Qn(tr(n,r));return(0,z.jsxs)(`button`,{className:`format`,title:`Copy`,onClick:()=>o(i),children:[(0,z.jsx)(`span`,{className:`over-swatch`,style:{background:Qn(r)},children:(0,z.jsx)(`span`,{style:{background:e}})}),(0,z.jsx)(`span`,{className:`format-label`,children:t}),(0,z.jsx)(`span`,{className:`format-text`,children:i}),(0,z.jsx)(h,{})]},t)})})]})]})]})}function Fr({text:e,onOpen:t}){return(0,z.jsx)(`div`,{className:`body link`,role:`link`,tabIndex:-1,title:`Open in browser`,onClick:()=>{window.getSelection()?.isCollapsed!==!1&&t()},children:e})}function Ir({id:e,className:t,family:n,children:r}){let i=H(()=>{T({kind:`drag`,id:e}).catch(()=>{})});return(0,z.jsx)(`div`,{className:t,"data-family":n,onMouseDown:e=>e.preventDefault(),...i,children:r})}function Lr({id:e,family:t,ext:n,token:r,name:i,text:a,onSize:o,whole:c=!1}){let[l,u]=(0,I.useState)(!1),d=(0,I.useMemo)(()=>r?ae(r):null,[r]),f=l?null:d;return f&&a?(0,z.jsx)(Ln,{src:f,json:n===`json`,markdown:n===`md`||n===`markdown`,language:W(n),onFail:()=>u(!0)}):f&&t===`image`?(0,z.jsx)(Ir,{id:e,className:`picture`,children:(0,z.jsx)(`img`,{alt:i,src:f,decoding:`async`,draggable:!1,onLoad:e=>{let{naturalWidth:t,naturalHeight:n}=e.currentTarget;t&&n&&o(t,n)},onError:()=>u(!0)})}):f&&t===`video`?(0,z.jsx)(Rr,{src:f,play:c,onError:()=>u(!0)}):f&&t===`audio`?(0,z.jsxs)(`div`,{className:`player audio`,children:[(0,z.jsx)(s,{family:t}),(0,z.jsx)(`audio`,{src:f,controls:!0,preload:`none`,onError:()=>u(!0)})]}):f&&t===`pdf`?(0,z.jsx)(pn,{src:f,name:i,flow:c,onFail:()=>u(!0)}):(0,z.jsxs)(Ir,{id:e,className:`file-tile`,family:t,children:[(0,z.jsx)(s,{family:t}),(0,z.jsx)(`span`,{children:t===`folder`?`FOLDER`:n?n.toUpperCase():`FILE`})]})}function Rr({src:e,play:t=!1,onError:n}){let r=(0,I.useRef)(null),[i,a]=(0,I.useState)(!1),[o,s]=(0,I.useState)(!0),[c,l]=(0,I.useState)(0),[u,d]=(0,I.useState)(0),f=e=>e.preventDefault(),p=()=>{let e=r.current;e&&(e.paused?e.play().catch(n):e.pause())};return(0,I.useEffect)(()=>{let e=r.current;if(!t||!e)return;let n=()=>{e.paused&&e.play().catch(()=>{})};return n(),e.addEventListener(`canplay`,n,{once:!0}),()=>e.removeEventListener(`canplay`,n)},[t,e]),(0,z.jsxs)(`div`,{className:`player video`,children:[(0,z.jsx)(`video`,{ref:r,src:e,muted:!0,playsInline:!0,preload:`metadata`,onClick:p,onPlay:()=>a(!0),onPause:()=>a(!1),onEnded:()=>a(!1),onTimeUpdate:e=>l(e.currentTarget.currentTime),onLoadedMetadata:e=>d(e.currentTarget.duration||0),onVolumeChange:e=>s(e.currentTarget.muted),onError:n}),(0,z.jsxs)(`div`,{className:`vbar`,children:[(0,z.jsx)(`button`,{type:`button`,className:`vbtn`,"aria-label":i?`Pause`:`Play`,onMouseDown:f,onClick:p,children:i?(0,z.jsx)(x,{}):(0,z.jsx)(se,{})}),(0,z.jsx)(`input`,{type:`range`,className:`seek`,"aria-label":`Seek`,min:0,max:u||0,step:`any`,value:Math.min(c,u||0),disabled:!u,onChange:e=>{r.current&&(r.current.currentTime=Number(e.target.value))}}),(0,z.jsxs)(`span`,{className:`clock`,children:[Gr(c),` / `,Gr(u)]}),(0,z.jsx)(`button`,{type:`button`,className:`vbtn`,"aria-label":o?`Unmute`:`Mute`,onMouseDown:f,onClick:()=>r.current&&(r.current.muted=!r.current.muted),children:(0,z.jsx)(oe,{muted:o})})]})]})}function zr({id:e,files:t,count:n}){let r=t.filter(e=>e.folder).length,i=t.length-r,a=[i&&`${i} ${i===1?`file`:`files`}`,r&&`${r} ${r===1?`folder`:`folders`}`].filter(Boolean);return(0,z.jsxs)(`section`,{className:`file-list`,"aria-label":`${n} files`,children:[(0,z.jsxs)(`header`,{className:`file-list-head`,children:[a.join(` · `),n>t.length&&` · first ${t.length} of ${n}`]}),(0,z.jsx)(`ul`,{children:t.map((t,n)=>(0,z.jsx)(Br,{id:e,at:n,file:t},n))})]})}function Br({id:e,at:t,file:n}){let r=H(()=>{T({kind:`drag`,id:e,file:t}).catch(()=>{})});return(0,z.jsxs)(`li`,{title:n.dir?`${n.dir}/${n.name}`:n.name,onMouseDown:e=>e.preventDefault(),...r,children:[(0,z.jsx)(s,{family:n.folder?`folder`:U(Ur(n.name))}),(0,z.jsxs)(`span`,{className:`file-list-text`,children:[(0,z.jsx)(Hr,{name:n.name,folder:!!n.folder}),n.dir&&(0,z.jsx)(`span`,{className:`file-list-dir`,children:Wr(n.dir)})]}),n.size!=null&&(0,z.jsx)(`span`,{className:`file-list-size`,children:Kr(n.size)})]})}function Vr({path:e}){let t=e.length>1?e.replace(/\/+$/,``):e,n=t.lastIndexOf(`/`),r=t.slice(n+1)||t,i=n>0?t.slice(0,n):n===0?`/`:``;return(0,z.jsxs)(`div`,{className:`file-where`,title:e,children:[(0,z.jsx)(`div`,{className:`file-where-name`,children:r}),i&&(0,z.jsxs)(`div`,{className:`file-where-dir`,children:[(0,z.jsx)(Ee,{}),(0,z.jsx)(`span`,{children:Wr(i)})]})]})}function Hr({name:e,folder:t}){let n=t?-1:e.lastIndexOf(`.`);return n<=0?(0,z.jsx)(`span`,{className:`file-list-name`,children:(0,z.jsx)(`span`,{className:`file-list-stem`,children:e})}):(0,z.jsxs)(`span`,{className:`file-list-name`,children:[(0,z.jsx)(`span`,{className:`file-list-stem`,children:e.slice(0,n)}),(0,z.jsx)(`span`,{className:`file-list-ext`,children:e.slice(n)})]})}function Ur(e){let t=e.lastIndexOf(`.`);return t>0?e.slice(t+1).toLowerCase():void 0}function Wr(e){return e.replace(/^\/Users\/[^/]+(?=\/|$)/,`~`)}function Gr(e){let t=Math.max(0,Math.floor(Number.isFinite(e)?e:0)),n=Math.floor(t/3600),r=Math.floor(t%3600/60),i=String(t%60).padStart(2,`0`);return n?`${n}:${String(r).padStart(2,`0`)}:${i}`:`${r}:${i}`}function Kr(e){if(e<1e3)return`${e} ${e===1?`byte`:`bytes`}`;let t=[`KB`,`MB`,`GB`,`TB`],n=e/1e3,r=0;for(;n>=1e3&&r<t.length-1;)n/=1e3,r++;let i=r===0?0:1;return`${n.toLocaleString(void 0,{maximumFractionDigits:i})} ${t[r]}`}var qr=`previewWidth`,Jr=180;function Yr(){try{let e=Number(localStorage.getItem(qr));return Number.isFinite(e)&&e>=Jr?e:230}catch{return 230}}function Xr(e){try{localStorage.setItem(qr,String(e))}catch{}}function Zr(e){Xr(e),T({kind:`previewWidth`,width:e}).catch(()=>{})}function Qr(e,t){return Math.round(Math.max(Jr,Math.min(e,t-240)))}function $r(){let[e,t]=(0,I.useState)(Yr),n=(0,I.useRef)(null),r=(0,I.useCallback)(t=>{t.preventDefault();let r=t.currentTarget.closest(`.body-grid`)?.getBoundingClientRect().width??620;n.current={x:t.clientX,width:e,total:r,now:e},t.currentTarget.setPointerCapture(t.pointerId)},[e]),i=(0,I.useCallback)(e=>{let r=n.current;r&&(r.now=Qr(r.width+r.x-e.clientX,r.total),t(r.now))},[]),a=(0,I.useCallback)(e=>{let t=n.current;t&&(n.current=null,e.currentTarget.releasePointerCapture(e.pointerId),t.now!==t.width&&Zr(t.now))},[]),o=(0,I.useCallback)(()=>{t(230),Zr(230)},[]);return{width:e,adopt:(0,I.useCallback)(e=>{e==null||n.current||(t(e),Xr(e))},[]),grip:{onPointerDown:r,onPointerMove:i,onPointerUp:a,onDoubleClick:o}}}var ei=o(),ti=`previewSplit`,ni=40,ri=2e3,ii=e=>typeof e==`number`&&Number.isFinite(e)&&e>=ni&&e<=ri;function ai(){try{let e=Number(localStorage.getItem(ti)??NaN);return ii(e)?e:null}catch{return null}}function oi(e){try{e==null?localStorage.removeItem(ti):localStorage.setItem(ti,String(e))}catch{}}function si(e){oi(e),T({kind:`previewSplit`,height:e}).catch(()=>{})}function ci(e,t,n,r){return Math.round(Math.max(n,Math.min(e+t,e+r)))}function li(e){let t=Number.parseFloat(getComputedStyle(e).minHeight);return Math.max(0,e.getBoundingClientRect().height-(Number.isFinite(t)?t:0))}function ui(){let[e,t]=(0,I.useState)(ai),n=(0,I.useRef)(null),r=(0,I.useCallback)(e=>{e.preventDefault();let r=e.currentTarget,i=r.parentElement,a=i?.previousElementSibling;if(!i||!a)return;(0,ei.flushSync)(()=>t(Math.round(a.getBoundingClientRect().height)));let o=a.getBoundingClientRect().height,s=0;for(let e=i;e&&!e.classList.contains(`card-foot`);e=e.nextElementSibling)s+=li(e);let c=o-li(a);n.current={y:e.clientY,start:o,floor:c,room:s,now:Math.round(o)},r.setPointerCapture(e.pointerId)},[]),i=(0,I.useCallback)(e=>{let r=n.current;r&&(r.now=ci(r.start,e.clientY-r.y,r.floor,r.room),t(r.now))},[]),a=(0,I.useCallback)(e=>{let t=n.current;t&&(n.current=null,e.currentTarget.releasePointerCapture(e.pointerId),t.now!==Math.round(t.start)&&ii(t.now)&&si(t.now))},[]),o=(0,I.useCallback)(()=>{t(null),si(null)},[]);return{height:e,adopt:(0,I.useCallback)(e=>{if(n.current)return;let r=ii(e)?e:null;t(r),oi(r)},[]),grip:{onPointerDown:r,onPointerMove:i,onPointerUp:a,onDoubleClick:o}}}function di(){return{onPointerDown:(0,I.useCallback)(e=>{e.button!==0||e.target.closest(`button`)||(e.preventDefault(),fetch(`/__lumi__/drag`,{method:`POST`}).catch(()=>{}))},[])}}var fi=new Set,pi={on:!1,all:!1,except:fi,confirmed:!1};function mi(e,t){return t===e.on?e:{on:t,all:!1,except:fi,confirmed:!1}}function hi(e,t){return e.on&&e.all===e.except.has(t)}function gi(e){return e!==`color`}function _i(e,t){return gi(t.kind)&&hi(e,t.id)}function vi(e,t,n){if(!e.on||hi(e,t)!==n)return e;let r=new Set(e.except);return r.has(t)?r.delete(t):r.add(t),{...e,except:r}}function yi(e,t){return vi(e,t,!0)}function bi(e,t){return vi(e,t,!1)}function xi(e,t){return hi(e,t)?yi(e,t):bi(e,t)}function Si(e){return e.on?e.all&&!e.except.size?wi(e):{...e,all:!0,except:fi}:e}function Ci(e){return e.on&&e.all&&!e.except.size}function wi(e){return e.all||e.except.size||e.confirmed?{...e,all:!1,except:fi,confirmed:!1}:e}function Ti(e){return e.confirmed?e:{...e,confirmed:!0}}function Ei(e,t){return!e.on||!t?e:{...e,all:t.all,except:new Set(t.except),confirmed:t.confirmed}}function Di(e){return{all:e.all,except:[...e.except],confirmed:e.confirmed}}function Oi(e,t,n){return t&&e.on&&!e.confirmed&&!n}var ki={on:!1,here:!1,known:!0},Ai={on:!0,here:!1,known:!1};function ji(e,t,n){let r=t?.on??!1;if(n.hidden)return r?Ai:ki;let i=t?.unlocked===!0;return{on:r,here:n.opening?i:e.here||i,known:!0}}function Mi(e){return e.on&&!e.here}function Ni(e){return e.known&&Mi(e)}function Pi(e){return e.on&&!Mi(e)}function Fi(e,t){if(!e)return t;let n=new Map(e.map(e=>[e.id,e])),r=e.length===t.length,i=t.map((t,i)=>{let a=n.get(t.id),o=a&&Ii(a,t)?a:t;return o!==e[i]&&(r=!1),o});return r?e:i}function Ii(e,t){let n=e,r=t,i=new Set([...Object.keys(n),...Object.keys(r)]);for(let e of i)if(!Li(n[e],r[e]))return!1;return!0}function Li(e,t){return e===t?!0:Array.isArray(e)&&Array.isArray(t)?e.length===t.length&&e.every((e,n)=>Li(e,t[n])):!1}function Ri(){let[r,a]=(0,I.useState)(null),[o,s]=(0,I.useState)(``),[c,f]=(0,I.useState)(`mixed`),v=(0,I.useRef)(`mixed`),[b,te]=(0,I.useState)(()=>le(ge)),[re,x]=(0,I.useState)(()=>le(fe)),[ie,C]=(0,I.useState)(()=>le(ye)),[ae,oe]=(0,I.useState)(()=>le(Se)),[w,se]=(0,I.useState)(`all`),[ue,D]=(0,I.useState)(null),[me,O]=(0,I.useState)(``),[_e,k]=(0,I.useState)(()=>Date.now()),[A,we]=(0,I.useState)(!1),[j,M]=(0,I.useState)(pi),[De,Oe]=(0,I.useState)(!1),[N,ke]=(0,I.useState)(Ai),P=Mi(N),F=Ni(N);(0,I.useEffect)(()=>{j.on&&!Z()&&T({kind:`shown`,...Di(j)}).catch(()=>{})},[j]);let[Pe,Ie]=(0,I.useState)(null),Le=(0,I.useRef)(!1),[Be,Ve]=(0,I.useState)(!1),[He,Ue]=(0,I.useState)(!1),[L,We]=(0,I.useState)(!1),R=(0,I.useRef)(null),Ge=$r(),Ke=ui(),qe=di(),B=(0,I.useRef)(null);Xe(B);let V=(0,I.useRef)(null),[Ye,Ze]=(0,I.useState)(null),H=(0,I.useRef)(!1),Qe=(0,I.useRef)([]),U=(0,I.useRef)([]),$e=Ge.adopt,et=Ke.adopt,tt=(0,I.useRef)(`all`);tt.current=w;let{rows:W,used:nt}=(0,I.useMemo)(()=>je((r??[]).filter(e=>ze(e,w)),o,c),[r,o,w,c]),rt=(0,I.useMemo)(()=>Ae(W),[W]),it=Fe(W,o),at=ue??it,G=W[at],K=He&&Or(G);(0,I.useEffect)(()=>{He&&!Or(G)&&Ue(!1)},[He,G]);let ot=(0,I.useCallback)((e,t,n)=>{let r=Z(),i=e.lock?.on??!1;Bi=i?{...e,items:[]}:e,a(t=>r&&i?null:Fi(t,e.items)),r||k(Date.now()),n&&e.clear&&Ve(!0),$e(e.previewWidth),et(e.previewSplit),an(e.pdfFit),Yi(e.appearance,e.theme,e.solid);let o=de(e.pinKey,e.revealKey,e.revealAllKey,e.lockKey);if(te(o.pin),x(o.reveal),C(o.revealAll),oe(o.lock),v.current=e.searchMode??`mixed`,f(v.current),M(t=>Ei(mi(t,e.privacy??!1),e.shown)),Oe(e.privacyConfirm??!1),ke(t=>ji(t,e.lock,{opening:n,hidden:r})),t){let n=Me(e.items.filter(e=>ze(e,tt.current)),R.current?.value??``,v.current).findIndex(e=>e.id===t);n>=0&&D(n)}},[$e,et]),q=(0,I.useCallback)(async(e,t=!1,n=null)=>{let r=Q(),i=await(n??T({kind:`list`,opening:t}));r===Q()&&ot(i,e,t)},[ot]);(0,I.useLayoutEffect)(()=>{Z()&&Bi&&ot(Bi,null,!1)},[ot]),(0,I.useEffect)(()=>(R.current?.focus(),Z()&&!Bi&&q(null).catch(()=>{}),vr(()=>{k(Date.now()),q(null,!0,Ui()).catch(e=>O(Te(e))).finally(()=>{R.current?.focus(),Ki()})})),[q]);let st=(0,I.useRef)(null);st.current=at===it?null:G?.id??null;let ct=(0,I.useRef)(N.on);ct.current=N.on,(0,I.useEffect)(()=>{let e=!1,t=!1,n=async()=>{if(e){t=!0;return}e=!0;try{do t=!1,await q(st.current).catch(()=>{});while(t)}finally{e=!1}},r=e=>{let t=e.detail;(qi(t,`history`)||qi(t,`privacy`))&&(Z()&&ct.current||n())},i=()=>{n(),Ki()};return window.addEventListener(`lumi:message`,r),window.addEventListener(`lumi:settings`,i),()=>{window.removeEventListener(`lumi:message`,r),window.removeEventListener(`lumi:settings`,i)}},[q]),(0,I.useEffect)(()=>{ue!==null&&ue>=W.length&&D(W.length?W.length-1:null)},[ue,W.length]),(0,I.useEffect)(()=>{document.getElementById(`row-${at}`)?.scrollIntoView({block:`nearest`})},[at,W]);let J=(0,I.useCallback)(async e=>{O(``);try{await e()}catch(e){O(Te(e))}},[]);(0,I.useEffect)(()=>{let e=e=>{if(!qi(e.detail,`summoned`))return;let t=K||L?null:B.current?.querySelector(`.row[aria-selected="true"]`);t?.scrollIntoView({block:`nearest`}),St(document.querySelector(`.menu-item[aria-selected="true"], .menu-filter`)??t??(L?null:document.querySelector(`.search`)))};return window.addEventListener(`lumi:message`,e),()=>window.removeEventListener(`lumi:message`,e)},[K,L]);let lt=(0,I.useCallback)((e,t=G)=>{t&&J(()=>T({kind:`paste`,id:t.id,plain:e,pinned:A}))},[J,G,A]),dt=(0,I.useCallback)(e=>{D(e),R.current?.focus()},[]),pt=(0,I.useRef)(lt);pt.current=lt;let mt=(0,I.useCallback)((e,t)=>pt.current(e,t),[]),ht=(0,I.useCallback)(()=>{let e=!A;J(async()=>{await T({kind:`pinPanel`,pinned:e}),we(e)})},[J,A]),gt=(0,I.useCallback)(async e=>{if(Le.current)return!1;Le.current=!0,O(``);try{let t=await ce(e);return t||O(`Not confirmed`),t}catch(e){return O(Te(e)),!1}finally{Le.current=!1}},[]),vt=(0,I.useCallback)(e=>{if(!Oi(j,De,Pi(N))){M(e);return}(async()=>{await gt(`show hidden clipboard content`)&&M(t=>e(Ti(t)))})()},[gt,N,De,j]),xt=(0,I.useCallback)(()=>{G&&gi(G.kind)&&(_i(j,G)?vt(e=>yi(e,G.id)):M(e=>xi(e,G.id)))},[G,vt,j]),wt=(0,I.useCallback)(e=>vt(t=>yi(t,e)),[vt]),Tt=(0,I.useCallback)(()=>{Ci(j)?M(Si):vt(Si)},[vt,j]),Et=(0,I.useCallback)(async()=>{let e=Q();await gt(`open your clipboard history`)&&e===Q()&&(M(Ti),ke(e=>({...e,here:!0})),await T({kind:`unlocked`}).catch(()=>{}),await q(st.current).catch(()=>{}))},[gt,q]),Dt=(0,I.useCallback)(()=>{ke(e=>({...e,here:!1})),M(wi),T({kind:`lock`}).catch(()=>{})},[]);(0,I.useEffect)(()=>{(Wi??=Ce()).then(Ie)},[]);let Ot=(0,I.useRef)(!1);(0,I.useEffect)(()=>{!F||r===null||Pe!==!0||Ot.current||Z()||(Ot.current=!0,Et())},[F,r,Pe,Et]),(0,I.useEffect)(()=>{P?document.querySelector(`main.panel`)?.focus():R.current?.focus()},[P]);let kt=(0,I.useCallback)(()=>{if(!G)return;let e=G.id;J(async()=>{V.current=_t()?yt(B.current):null;try{let{pin:t}=await T({kind:`pin`,id:e});Qe.current.push({kind:`pin`,id:e,was:G.pin,now:t}),U.current=[],Ze(t?e:null),await q(e)}catch(e){throw V.current=null,e}})},[J,G,q]),At=(0,I.useCallback)(e=>e.map(e=>B.current?.querySelector(`.row[data-id="${CSS.escape(e)}"]`)).filter(e=>!!e),[]),jt=(0,I.useCallback)((e,t)=>{H.current||J(async()=>{H.current=!0;let n=await Ct(At(e));try{let e=await t();e.length&&Qe.current.push({kind:`delete`,ids:e}),U.current=[],await q(null)}catch(e){throw n(),e}finally{H.current=!1}})},[J,q,At]),Mt=(0,I.useCallback)(()=>{if(!G)return;let e=G.id;jt([e],async()=>(await T({kind:`delete`,id:e}),[e]))},[G,jt]),Y=(0,I.useCallback)(e=>{let t=(r??[]).filter(t=>!(e&&t.pin)).map(e=>e.id);t.length&&jt(t,async()=>(await T({kind:e?`clear`:`clearAll`})).ids)},[jt,r]);(0,I.useEffect)(()=>{Be&&r!==null&&!P&&(Ve(!1),Y(!0))},[Be,r,Y,P]),(0,I.useEffect)(()=>{let e=e=>{qi(e.detail,`clear`)&&Ve(!0)};return window.addEventListener(`lumi:message`,e),()=>window.removeEventListener(`lumi:message`,e)},[]);let Nt=(0,I.useCallback)(()=>{let e=Qe.current.pop();e&&J(async()=>{V.current=_t()?yt(B.current):null;try{if(e.kind===`pin`){let{pin:t}=await T({kind:`setPin`,id:e.id,pin:e.was});Ze(t?e.id:null),U.current.push({...e,now:t??e.now})}else{let{count:t}=await T({kind:`restore`,ids:e.ids});t&&U.current.push(e),t<e.ids.length&&O(e.ids.length===1?`That item was copied again since, so the newer one stays.`:`Some items were copied again since, so the newer ones stay.`)}await q(e.kind===`pin`?e.id:e.ids[0]??null)}catch(e){throw V.current=null,e}})},[J,q]),Pt=(0,I.useCallback)(()=>{let e=U.current.pop();e&&!H.current&&J(async()=>{if(e.kind===`pin`){V.current=_t()?yt(B.current):null;try{let{pin:t}=await T({kind:`setPin`,id:e.id,pin:e.now});Ze(t?e.id:null),Qe.current.push({...e,now:t}),await q(e.id)}catch(e){throw V.current=null,e}return}H.current=!0;let t=await Ct(At(e.ids));try{await T({kind:`delete`,ids:e.ids}),Qe.current.push(e),await q(null)}catch(e){throw t(),e}finally{H.current=!1}})},[J,q,At]),X=(0,I.useCallback)(()=>{J(()=>T({kind:`settings`}))},[J]),Ft=(0,I.useCallback)(e=>void J(()=>T(e===`tour`?{kind:e}:{kind:e,pinned:A})),[J,A]),[It,Lt]=(0,I.useState)(!1),Rt=(0,I.useCallback)(()=>{Lt(!1),R.current?.focus()},[]),zt=re?he(re):void 0,Bt=ie?he(ie):void 0,Vt=ae?he(ae):void 0,Ht=(0,I.useMemo)(()=>{let a=G,o=(e,t)=>()=>{a&&J(()=>T(e===`copy`?{kind:e,id:a.id,plain:t,pinned:A}:{kind:e,id:a.id,pinned:A}))},s=(r??[]).filter(e=>!e.pin).length,c=r?.length??0,u=a&&(a.kind===`text`||a.kind===`rich`||a.kind===`link`);return P?[...Pe&&F?[{id:`unlock`,label:`Unlock history`,glyph:(0,z.jsx)(ve,{open:!0}),keys:`↩`,run:()=>void Et()}]:[],{id:`settings`,label:`Settings…`,glyph:(0,z.jsx)(n,{}),keys:`⌘,`,run:X},{id:`about`,label:L?`Back to the history`:`About Clipboard Manager`,glyph:(0,z.jsx)(l,{}),run:()=>We(!L)}]:[...a&&!L?[{id:`paste`,label:`Paste`,glyph:(0,z.jsx)(ne,{}),keys:`↩`,run:()=>lt(!1,a)},...u?[{id:`plain`,label:`Paste as plain text`,glyph:(0,z.jsx)(e,{}),keys:`⌥↩`,run:()=>lt(!0,a)}]:[],...K||Or(a)?[{id:`zoom`,label:K?`Back to the list`:`Expand preview`,glyph:K?(0,z.jsx)(i,{}):(0,z.jsx)(t,{}),keys:`⌘Y`,run:()=>Ue(!K)}]:[],{id:`copy`,label:`Copy`,glyph:(0,z.jsx)(h,{}),run:o(`copy`)},...a.kind===`file`?[{id:`copyPath`,label:(a.fileCount??0)>1?`Copy paths`:`Copy path`,glyph:(0,z.jsx)(h,{}),run:o(`copyPath`)}]:[],...a.ocr?[{id:`copyText`,label:`Copy text in image`,glyph:(0,z.jsx)(be,{}),run:o(`copyText`)}]:[],...a.kind===`link`?[{id:`open`,label:`Open in browser`,glyph:(0,z.jsx)(p,{}),run:o(`open`)}]:[],...a.kind===`file`?[{id:`reveal`,label:`Show in Finder`,glyph:(0,z.jsx)(Ee,{}),run:o(`reveal`)}]:[],...a.kind===`image`?[{id:`saveImage`,label:`Save image as…`,glyph:(0,z.jsx)(pe,{}),run:()=>void J(()=>T({kind:`saveImage`,id:a.id,name:Zi(a.last)}))}]:[],{id:`pin`,label:a.pin?`Unpin`:`Pin`,glyph:(0,z.jsx)(_,{}),keys:he(b),run:kt},...j.on&&gi(a.kind)?[_i(j,a)?{id:`showContent`,label:`Show content`,glyph:(0,z.jsx)(m,{}),keys:zt,run:xt}:{id:`hideContent`,label:`Hide content`,glyph:(0,z.jsx)(g,{}),keys:zt,run:xt}]:[]]:[],...j.on&&!L?[Ci(j)?{id:`hideAll`,label:`Hide all content`,glyph:(0,z.jsx)(g,{}),keys:Bt,run:Tt}:{id:`showAll`,label:`Show all content`,glyph:(0,z.jsx)(m,{}),keys:Bt,run:Tt}]:[],...N.on?[{id:`lockNow`,label:`Lock history now`,glyph:(0,z.jsx)(ve,{}),keys:Vt,run:Dt}]:[],{id:`settings`,label:`Settings…`,glyph:(0,z.jsx)(n,{}),keys:`⌘,`,run:X},{id:`about`,label:L?`Back to the history`:`About Clipboard Manager`,glyph:(0,z.jsx)(l,{}),run:()=>We(!L)},...a&&!L?[{id:`delete`,label:`Delete entry`,glyph:(0,z.jsx)(xe,{}),keys:`⌘⌥⌫`,danger:!0,run:Mt}]:[],...s&&s<c?[{id:`clear`,label:`Delete all unpinned…`,glyph:(0,z.jsx)(xe,{}),danger:!0,confirm:`Press ↩ again to delete ${s} ${s===1?`entry`:`entries`}`,run:()=>Y(!0)}]:[],...c?[{id:`clearAll`,label:`Delete all…`,glyph:(0,z.jsx)(xe,{}),danger:!0,confirm:`Press ↩ again to delete all ${c} ${c===1?`entry`:`entries`}`,run:()=>Y(!1)}]:[]]},[L,J,Pe,G,N.on,Vt,Dt,F,P,X,lt,b,A,Mt,Y,Bt,zt,r,kt,Tt,xt,Et,j,K]);(0,I.useLayoutEffect)(()=>{let e=V.current;e&&(V.current=null,bt(B.current,e))},[W]),(0,I.useEffect)(()=>{if(!Ye)return;let e=setTimeout(()=>Ze(null),400);return()=>clearTimeout(e)},[Ye]);let Ut=e=>{se(e),D(null),O(``)},Wt=e=>{let t=Re.indexOf(w);Ut(Re[(t+e+Re.length)%Re.length]??`all`)},Gt=(e,t=!1)=>{let n=W.length;n&&D(r=>{let i=r??it;return t?((i+e)%n+n)%n:Math.max(0,Math.min(n-1,i+e))})},Kt=()=>document.querySelector(`.menu-filter`)??R.current,qt=e=>{e.target.closest(`input, textarea, select, video, audio, .menu`)||window.getSelection()?.isCollapsed!==!1&&Kt()?.focus()},Jt=e=>{if(!e.metaKey&&!e.ctrlKey&&(e.key.length===1||e.keyCode===229)&&!(e.target instanceof HTMLInputElement||e.target instanceof HTMLTextAreaElement)&&Kt()?.focus(),e.nativeEvent.isComposing||e.keyCode===229)return;let t=e.metaKey&&!e.ctrlKey,n=e.key;if(P&&!L){if(n===`Escape`)It?Rt():T({kind:`close`}).catch(()=>{});else if(n===`Enter`)F&&Et();else if(t&&n.toLowerCase()===`k`)Lt(!0);else if(t&&n===`,`)X();else if(!e.metaKey&&!e.ctrlKey&&!e.altKey)return;e.preventDefault();return}if(L){if(n===`Escape`)It?Rt():We(!1);else if(t&&n.toLowerCase()===`k`)Lt(!0);else if(t&&n===`,`)X();else return;e.preventDefault();return}if(S(e,b))kt();else if(re&&S(e,re))xt();else if(ie&&S(e,ie))Tt();else if(ae&&S(e,ae))N.on&&Dt();else if(n===`ArrowDown`)Gt(1,!0);else if(n===`ArrowUp`)Gt(-1,!0);else if(n===`PageDown`)Gt(8);else if(n===`PageUp`)Gt(-8);else if(n===`Enter`)lt(e.altKey);else if(n===`Tab`)Wt(e.shiftKey?-1:1);else if(n===`Escape`)It?Rt():K?Ue(!1):o?(s(``),D(null)):w===`all`?T({kind:`close`}).catch(()=>{}):Ut(`all`);else if(t&&n.toLowerCase()===`k`)Lt(!0);else if(t&&n===`,`)X();else if(t&&e.altKey&&n===`Backspace`)Mt();else if(t&&!e.shiftKey&&n.toLowerCase()===`z`&&Qe.current.length)Nt();else if(t&&e.shiftKey&&n.toLowerCase()===`z`&&U.current.length)Pt();else if(t&&e.shiftKey&&!e.altKey&&n.toLowerCase()===`p`)ht();else if(t&&!e.shiftKey&&!e.altKey&&n.toLowerCase()===`y`)(K||Or(G))&&Ue(!K);else if(t&&/^[1-9a-z]$/i.test(n)){let t=n.toLowerCase(),r=W.findIndex(e=>rt.get(e.id)===t);if(r<0)return;D(r),lt(e.altKey,W[r])}else return;e.preventDefault()},Yt=r!==null&&!W.length;return(0,z.jsxs)(`main`,{className:[`panel`,K&&!L?`zoomed`:``,L?`about-up`:``,P?`locked`:``].filter(Boolean).join(` `),tabIndex:-1,onKeyDown:Jt,onClick:qt,children:[(0,z.jsxs)(`header`,{className:`crumbs`,...qe,children:[(0,z.jsx)(u,{}),(0,z.jsx)(`span`,{className:`brand`,children:`Lumi`}),(0,z.jsx)(`span`,{className:`sep`,children:`›`}),(0,z.jsx)(`span`,{children:`Clipboard Manager`}),(0,z.jsx)(`span`,{className:`sep`,children:`›`}),(0,z.jsx)(`span`,{className:`here`,children:L?`About`:Ne[w]}),(0,z.jsx)(`nav`,{className:`filters`,"aria-label":`Show`,children:Re.map(e=>(0,z.jsx)(`button`,{type:`button`,className:e===w?`cap quiet on`:`cap quiet`,"aria-pressed":e===w,title:Ne[e],"aria-label":Ne[e],onMouseDown:e=>e.preventDefault(),onClick:()=>Ut(e),children:e===`all`?Ne[e]:(0,z.jsx)(d,{kind:e})},e))}),(0,z.jsx)(`button`,{type:`button`,className:A?`keep on`:`keep`,"aria-pressed":A,title:A?`Pinned: stays open while you work elsewhere (⌘⇧P)`:`Keep the panel open while you work elsewhere (⌘⇧P)`,"aria-label":`Keep the panel open`,onMouseDown:e=>e.preventDefault(),onClick:ht,children:(0,z.jsx)(ee,{})})]}),(0,z.jsxs)(`div`,{className:`search`,"aria-hidden":L||void 0,children:[(0,z.jsx)(E,{}),(0,z.jsx)(`input`,{ref:R,value:o,onChange:e=>{s(e.target.value),D(null),O(``),Ue(!1),We(!1)},placeholder:P?F?`History locked`:``:`Search history`,disabled:P,autoComplete:`off`,spellCheck:!1,"aria-label":`Search history`,"aria-controls":`list`,"aria-activedescendant":G?`row-${at}`:void 0})]}),L&&(0,z.jsx)(Je,{onLink:Ft}),F&&!L&&(0,z.jsx)(zi,{canAsk:Pe,onUnlock:()=>void Et(),onSettings:X}),P&&!F&&!L&&(0,z.jsx)(`div`,{className:`waiting`,"aria-hidden":`true`}),!P&&(0,z.jsxs)(`section`,{className:`body-grid`,style:{gridTemplateColumns:Yt?`minmax(0, 1fr)`:K?`0 minmax(0, 1fr)`:`minmax(0, 1fr) min(${Ge.width}px, calc(100% - 240px))`},children:[(0,z.jsxs)(`div`,{ref:B,id:`list`,className:`list`,role:`listbox`,"aria-label":`Clipboard history`,children:[r!==null&&Yt&&(0,z.jsxs)(`div`,{className:`empty`,children:[r.length>0&&o?(0,z.jsx)(E,{}):(0,z.jsx)(y,{}),(0,z.jsx)(`span`,{children:Ji(r.length,o,w,c)})]}),W.map((e,t)=>[t>0&&W[t-1]?.pin&&!e.pin?(0,z.jsx)(`div`,{className:`divider`,role:`separator`},`divider`):null,(0,z.jsx)(ut,{row:e,index:t,selected:t===at,shortcut:rt.get(e.id),query:o,used:nt,now:_e,popped:Ye===e.id,onPick:dt,onPaste:mt},e.id)])]}),(0,z.jsxs)(`div`,{className:`preview-slot`,hidden:Yt,"data-split":Ke.height==null?void 0:``,style:Ke.height==null?void 0:{"--split":`${Ke.height}px`},children:[(0,z.jsx)(`div`,{className:`grip`,role:`separator`,"aria-orientation":`vertical`,"aria-label":`Resize preview`,title:`Drag to resize · double-click to reset`,...Ge.grip}),(0,z.jsx)(kr,{row:G,covered:G?_i(j,G):!1,revealCap:zt,revealAllCap:Bt,onShow:wt,query:o,used:nt,onOpen:(e,t,n)=>void J(()=>T({kind:`open`,id:e,url:t,snippet:n,pinned:A})),onCopyColor:e=>void J(()=>T({kind:`copyColor`,text:e,pinned:A})),onCopySnippet:(e,t)=>void J(()=>T({kind:`copySnippet`,id:e,text:t,pinned:A})),onCopyMath:(e,t)=>void J(()=>T({kind:`copyMath`,id:e,text:t,pinned:A})),onCopyWords:(e,{from:t,to:n})=>void J(()=>T({kind:`copyText`,id:e,from:t,to:n,pinned:A})),zoomed:K,onZoom:()=>Ue(!K),split:Ke.grip})]})]}),me&&(0,z.jsx)(`p`,{className:`notice`,role:`status`,children:me}),It&&(0,z.jsx)(ft,{actions:Ht,onClose:Rt}),(0,z.jsxs)(`footer`,{className:`hints`,children:[L?(0,z.jsxs)(`span`,{children:[(0,z.jsx)(`kbd`,{className:`cap quiet`,children:`⎋`}),` back to the history`]}):P?(0,z.jsxs)(z.Fragment,{children:[Pe&&F&&(0,z.jsxs)(`span`,{children:[(0,z.jsx)(`kbd`,{className:`cap quiet`,children:`↩`}),` unlock`]}),(0,z.jsxs)(`span`,{children:[(0,z.jsx)(`kbd`,{className:`cap quiet`,children:`⎋`}),` close`]})]}):(0,z.jsxs)(z.Fragment,{children:[(0,z.jsxs)(`span`,{children:[(0,z.jsx)(`kbd`,{className:`cap quiet`,children:`↩`}),` paste`]}),(0,z.jsxs)(`span`,{children:[(0,z.jsx)(`kbd`,{className:`cap quiet`,children:`⌥↩`}),` plain`]}),(0,z.jsxs)(`span`,{children:[(0,z.jsx)(`kbd`,{className:`cap quiet`,children:he(b)}),` pin`]}),(0,z.jsxs)(`span`,{children:[(0,z.jsx)(`kbd`,{className:`cap quiet`,children:`⌘⌥⌫`}),` delete`]}),(0,z.jsxs)(`span`,{children:[(0,z.jsx)(`kbd`,{className:`cap quiet`,children:`⇥`}),` filter`]})]}),(0,z.jsxs)(`button`,{type:`button`,className:`exit`,"data-menu-toggle":!0,onMouseDown:e=>e.preventDefault(),onClick:()=>It?Rt():Lt(!0),children:[(0,z.jsx)(`kbd`,{className:`cap quiet`,children:`⌘K`}),` actions`]})]})]})}function zi({canAsk:e,onUnlock:t,onSettings:n}){return(0,z.jsxs)(`section`,{className:`lock-card`,"aria-live":`polite`,children:[(0,z.jsx)(ve,{}),(0,z.jsx)(`h2`,{children:`Clipboard history is locked`}),e===!1?(0,z.jsxs)(`p`,{children:[`Unlocking asks “Is it you?”, which needs a password on this Mac. Turn the lock off in`,` `,(0,z.jsx)(`button`,{type:`button`,className:`link`,onMouseDown:e=>e.preventDefault(),onClick:n,children:`Settings`}),`.`]}):(0,z.jsxs)(z.Fragment,{children:[(0,z.jsx)(`p`,{children:`Confirm it’s you to see and paste what you copied.`}),(0,z.jsxs)(`button`,{type:`button`,className:`unlock`,onMouseDown:e=>e.preventDefault(),onClick:t,children:[`Unlock `,(0,z.jsx)(`kbd`,{className:`cap quiet`,children:`↩`})]})]})]})}var Bi=null,Vi=null;function Hi(){Vi=T({kind:`list`,opening:!0}),Vi.catch(()=>{})}function Ui(){let e=Vi;return Vi=null,e}var Wi=null,Gi=!1;function Ki(){Gi||Z()||(Gi=!0,(async()=>{try{for(let e=0;e<400&&!Z();e++){let{more:e}=await ue({kind:`readImages`});if(!e)break}}catch{}finally{Gi=!1}})())}function qi(e,t){return typeof e==`object`&&!!e&&e.kind===t}function Ji(e,t,n,r){return e?P(t,r)?`Not a regular expression yet`:t?`Nothing matches that search`:`No ${Ne[n].toLowerCase()} yet`:`Copy something and it shows up here`}function Yi(e,t,n){let r=document.documentElement;r.dataset.material=e??`popover`;let i=e===`hud`?`dark`:t;i===`light`||i===`dark`?r.dataset.theme=i:delete r.dataset.theme,r.style.setProperty(`--solid`,String(Xi(n)))}function Xi(e){return typeof e==`number`&&Number.isFinite(e)?Math.min(100,Math.max(0,e))/100:0}function Zi(e){let t=new Date(e),n=e=>String(e).padStart(2,`0`);return`Image ${t.getFullYear()}-${n(t.getMonth()+1)}-${n(t.getDate())} at ${n(t.getHours())}.${n(t.getMinutes())}.${n(t.getSeconds())}`}xr(),yr(()=>{Dr(),rt()}),Z()||Hi();function Qi(){let[e,t]=(0,I.useState)(Q);return(0,I.useEffect)(()=>{let e=yr(()=>t(Q()));return t(Q()),e},[]),(0,z.jsx)(Ri,{},e)}var $i=document.getElementById(`root`);$i&&(0,He.createRoot)($i).render((0,z.jsx)(I.StrictMode,{children:(0,z.jsx)(Qi,{})}));export{Y as t};
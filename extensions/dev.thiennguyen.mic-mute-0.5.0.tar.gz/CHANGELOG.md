# Changelog

## [0.5.0] - 2026-11-18

### Added

- **Mic Mute in Applications**: open it from Spotlight, the Dock or Launchpad. While Mic Mute is switched off, it opens Mic Mute's page in Lumi, where you can switch it on; it never switches itself on.
- Needs Lumi 1.89.0.

## [0.4.1] - 2026-11-17

### Changed

- **The menu bar icon shows the microphone alone while your microphones are on**, without the orange dot, which looked like macOS's sign that an app is recording. Muted is still the red slash.

## [0.4.0] - 2026-11-12

### Added

- **Mute when the screen locks**, in Settings: locking your Mac, or switching to another user, mutes every microphone that is on, and they stay muted after you come back until you press ⌥⌘M. A card at the top right says so when you unlock; turn off **Show a card when you unlock** to have the menu bar icon alone say it. Off unless you turn it on.
- Needs Lumi 1.81.0.

## [0.3.0] - 2026-11-11

### Added

- **A welcome tour** when you install Mic Mute, or update from an earlier version: the key — tried right there, tapped or held, with your own microphones — the menu bar icon and its panel, and what shows while you talk. Lumi's About page for Mic Mute opens it again.
- **A panel from the menu bar icon.** A click opens a round button that mutes or unmutes every microphone, each microphone with what it is now — one Mic Mute can't mute, such as an iPhone, saying so; the one your Mac is using marked, and a click on another making it the one your Mac uses, as in Sound settings — and Settings. A right-click still switches it without opening anything.
- **The menu bar icon in colour**: a red slash while your microphones are muted, an orange dot while they are on, and orange bars moving while you talk.
- **A card at the top right while you hold ⌥⌘M**, from the moment it is a hold rather than a tap, so a tap never flashes it: orange while you talk, and red if your Mac stops listening to the key before you let go — a password field taking the keyboard, say — since your microphones are muted again while you may still be talking. A tap of ⌥⌘M, a right-click or the menu's row says **Muted** or **Unmuted** on the same card; with the glow or the icon alone, Lumi's alert says it as before.
- **Or a glow round the screen while you hold ⌥⌘M**: an orange edge on every display, which clicks go through and a screen share never shows.
- **Hold ⌥⌘M while your microphones are on, too**: they stay on while you hold it and are muted when you let go — a hold always ends muted, and the card says so ("Let go to mute") when they were on. A tap still switches them, as before.
- **While talking**, in Settings: the card, the glow, or the moving icon alone, each shown as a small picture of your screen to choose from.
- **Change ⌥⌘M in Settings**, beside While talking: click the key and press another. Settings is now the one tab for everything Mic Mute asks, and Mic Mute's page opens on it; the separate Shortcuts tab is gone.
- **The panel and the card are light or dark as macOS is**, like the menu bar above them, whatever Lumi's own Appearance says.

## [0.2.0] - 2026-11-10

### Added

- **Hold ⌥⌘M to talk.** While your microphones are muted, holding ⌥⌘M turns them on for as long as you hold it, and letting go mutes them again. A quick tap still unmutes them, as before.
- Needs Lumi 1.79.0.

## [0.1.0] - 2026-11-09

### Added

- **⌥⌘M mutes every microphone on your Mac** — built-in, USB and Bluetooth — and pressing it again puts each one back as it was. A right-click on the menu bar icon, or **Mute Every Microphone** in its menu, does the same.
- **A microphone you plug in while muted is muted too**, and so is one unmuted somewhere else, until you unmute from Mic Mute.
- **The menu bar icon says which it is**: a microphone, or a microphone crossed out.
- **A microphone Lumi cannot mute is named**, such as an iPhone used as a microphone, so it is never taken for muted.
- **Mute virtual microphones too**, in Settings, off by default: meeting apps' own virtual microphones are left alone unless you turn it on.
- Needs Lumi 1.77.0.

# Changelog

## 0.2.32

- In the light appearance, the tab in front in the menu bar's menu and the pill's menu is tinted a stronger blue and named in a deeper one, so it reads as chosen and its title is as easy to read as the rows around it. Before, a faint tint came out grey over the menu's glass, and the blue title on it was the hardest row to read.

## 0.2.31

- The number on the pill's tab button is the number of tabs its menu lists. A tab on History, Settings or About counted there though the menu leaves those pages out, so two sites and History read 3 over a menu of two; and a tab closed from that menu after Lumi restarted left the number as it was.

## 0.2.30

- The website link on Floating Browser's About page in Lumi opens its page on lumikeys.app. It opened a page that no longer exists.
- The lumikeys.app link at the end of Floating Browser's page in the Extension Store opens the extensions on lumikeys.app. It opened a page that no longer exists.

## 0.2.29

- A new demo video on Floating Browser's page in the Extension Store, and its pictures and words brought up to date: the pill at the browser's corner, Now Playing in the menu bar's menu, a tab's menu and ⌘⇧T, Maximize, and ⌃⌥⌘P to find the pill.

## 0.2.28

- Minimize puts the pill at the foot of the browser, at its bottom-right corner, and the browser comes back over the pill — its bottom-right corner on the pill's, wherever the pill was dragged, on whichever display. By the edge of the screen either stands inside it, against that edge. Before, the pill opened wherever it had last been left and the browser came back where it stood, each with a place of its own.
- Needs Lumi 1.75.0.

## 0.2.27

- Compact Mode and Mute All in the menu bar's menu move the moment they are pressed. Before, a switch waited for the browser to be told and the menu drawn again before it moved, and read as slow; two quick presses now also end where the switch was last drawn.

## 0.2.26

- With Mute All on, a tab's speaker — or Unmute Tab in its menu — lets that tab be heard again while the others stay silent, and Mute All in the menu bar unticks, since not every tab is silent any more; pressed again it silences every tab. Before, the speaker only muted the tab a second time, and the one way to hear anything was to turn Mute All off for every tab.

## 0.2.25

- Now Playing in the menu bar's menu shows how far it has played of how long it is, at the end of the artist's line, and its band can be pressed or dragged to go elsewhere in what plays, as the pill's can, the time there shown over it; its button changes once the site has paused or played, as the pill's does, rather than guessing first.
- Now Playing's bars and the played length of its band are drawn in the menu's ink — white in Dark Mode, black in Light — as macOS's own Now Playing draws its band, the play button the one blue there; the blue sank into the dark glass.
- In Dark Mode the tab in front in that menu is a deeper blue with its title in white, as a chosen row in a macOS sidebar is; the light tint ran a muddy grey-blue on the dark glass, with blue words on it hard to read.

## 0.2.24

- The menu under Floating Browser's icon in the menu bar is drawn as the browser's own menu is. What plays stands at the top as Now Playing — its picture, title and artist, how far it has played, and a button to pause it or play it on — with its bars dancing beside the heading while it plays, and the other tabs below it, each with its site's icon and a × to close it: always on the tab in front, which is tinted blue, and on the others under the pointer. Compact Mode and Mute All are switches, and every other row has its icon.
- History, Settings and About are no longer listed in the menu bar's menu or the pill's: they are the browser's own pages, not tabs anybody went to.
- Quit is called Quit Floating Browser.

## 0.2.23

- With the browser minimized to its pill, its shortcut that hides it and shows it again plays on what was playing, as it does with the browser itself on screen. Before, the music stopped with the pill and stayed stopped when the pill came back.

## 0.2.22

- **Locate the mini panel** (⌃⌥⌘P): the minimized browser's pill shakes and a blue ring breathes out from it twice, so you can find it on whichever display it is. With Reduce Motion on, its edge flashes instead.

## 0.2.21

- A tab behind lit under the pointer is lit in the shape of the tab in front — as tall, its top corners rounded and its foot curving out at either side — and stands further from the tabs beside it, the hairlines beside it gone as they always meant to be.

## 0.2.20

- A right-click or a ⌃-click on a tab opens its menu, as Chrome's does: New Tab to the Right, Reload, Duplicate, Mute Tab, Close Tab, Close Other Tabs and Close Tabs to the Right. The tab is not chosen; what cannot be done is dimmed.
- Tabs closed at once — Close Other Tabs, Close Tabs to the Right, or Close — come back together with one ⌘⇧T, each at its place, the one that was in front in front again.
- With the tabs scrolling, New Tab stands clear of the strip's end rather than over the last tab in sight, where it sat against that tab's close button. Each end fades only by as much of the tabs as has gone past it, so a tab in full sight is never faded.

## 0.2.19

- A long title on the pill no longer has half its first letter faded while it rests at its start: each edge fades only by as much of the title as has gone past it, growing as the title moves, and its last letter comes to rest at the end in the clear.

## 0.2.18

- With more tabs than the strip holds, it scrolls, as Safari's and Firefox's do: the tabs no longer run under New Tab and the window's buttons, and each keeps room for its icon and the start of its title — the tab in front too, beside its close button. The tab in front stays in sight, an end with tabs out of sight fades, a mouse's wheel turns the strip, and a tab dragged to an end takes the strip along with it.
- A tab's speaker stands just after its icon, and neither moves as the tab comes in front or starts to play: a tab playing behind shows its title too, in place of an empty space kept for its close button, which comes over the end of its title under the pointer, as on any tab behind.
- A title with too little room for a letter and an ellipsis fades out at its end, as Chrome's do, rather than leaving its room empty.

## 0.2.17

- A click on the pill brings the browser back on the tab the pill shows: with Prioritize Now Playing Tab on, the one playing, not the one left in front.
- A narrow tab behind shows as much of its title as fits, cut with an ellipsis, in place of its icon alone.
- Nothing in a tab moves as the pointer comes and goes: a tab behind draws its close button over the end of its title, or in the place kept for it beside its speaker, and every tab in the strip is one width.
- A narrow tab closes up the space between its icon, speaker and close button before leaving any out: the tab in front keeps its icon while it plays.
- The Floating Browser icon at the window's top left moves the window when dragged; a click still opens its menu.
- A tab behind no longer spins for ever after Lumi restarts or the browser is put away: it shows its icon, and loads when you open it.

## 0.2.16

- **⌘⇧T** opens the tab you closed last again, where it was and with its Back and Forward, as in Chrome and Safari. Press it again for the one before.

## 0.2.15

- History, Settings and About open as tabs of their own, like any other: listed in the icon's menu, the menu bar's and the pill's, kept across a restart, and closed as any tab. Bringing the browser back shows the tab that was in front, never a page left over it.

## 0.2.14

- **Visualizer** is off until you turn it on in Settings, and Lumi listens to nothing until then. It is off after this update too: turn it on again if you want the bars to follow the music.

## 0.2.13

- **Visualizer**, in Settings and on until you turn it off: the pill's three bars follow the music while a site plays, in place of dancing by themselves. Off, Lumi listens to nothing and the bars dance as before. Needs Lumi 1.73.0.

## 0.2.12

- About says what Floating Browser is in a line and lists what is new in its last three versions, in place of the About window's buttons.
- About no longer stays over a page put in front of it, where its Done pressed the page instead.

## 0.2.11

- About Floating Browser, in the icon's menu and at lumi://about: what it is, who made it and what is new in its last versions.

## 0.2.10

- The icon's menu works with the keys as the pill's menu does: the arrows light a row and Return or Space chooses it, typing a row's first letters lights it, ← and → step the zoom on its row, and the ⌘-keys it shows — ⌘T, ⌘Y, ⌘, and ⌘+, ⌘−, ⌘0 — work while it is up.

## 0.2.9

- The icon's menu opens in a panel of its own under the icon, over the page, so a small browser no longer cuts it off (Lumi 1.72.0).

## 0.2.8

- Zoom In, Zoom Out and Actual Size: a Zoom row in the icon's menu, and ⌘+, ⌘− and ⌘0. Each site keeps its own zoom, in every tab and at every later visit (Lumi 1.72.0).
- Compact Mode, Desktop Site and Zoom have icons in the icon's menu, as its other rows do, and the pill's menu draws Close with the browser's ×.
- The pill's light behind Lumi's mark is a circle, at the centre of the pill's rounded end.
- The browser can be made smaller: 368 by 200 at the least, from 400 by 260.

## 0.2.7

- Compact Mode's title has its site's icon before it, as the tab strip shows it — the globe before one is found, a spinner while the page loads.
- Compact Mode's title stays in the middle of its bar however long it is, and no longer shifts as Back and Reload open out under the pointer.

## 0.2.6

- Maximize, between Minimize and Close: the browser fills its screen, and Restore puts it back where it was. Double-click the tab strip, or Compact Mode's bar, to do the same (Lumi 1.71.0).

## 0.2.5

- The Welcome tour takes the Appearance chosen in Settings too, its title bar with it, as the browser, its pill, its menus and the tip already do (Lumi 1.70.0).

## 0.2.4

- The tip over the pill goes with it: drag the pill and the tip stays beside it, pointing at it — below it when you leave the pill at the top of the screen — until you click Got It or the pill (Lumi 1.69.0).
- The pill rings while its tip is up, and a click on it puts the tip away; both were missed after a minimize that opened the tip.

## 0.2.3

- Prioritize Now Playing Tab, in Settings: on, as before, the minimized pill shows the tab playing audio or video; off, it always shows the tab you were looking at, while the other plays on.

## 0.2.2

- Floating Browser's page in the Extension Store says what it does: what you get, how your browsing stays private, and how to start.

## 0.2.1

- A short demo video on Floating Browser's page in the Extension Store and on lumikeys.app — the browser over your work, Compact Mode, the pill playing on in the corner — to watch before you install.

## 0.2.0

- ⌘W on the last tab leaves a new tab, so the browser stays open; ⌘W again on that new tab closes the browser, as × does, without asking.
- What plays on the pill: the track's title over its artist, a band along the pill's foot that fills as it plays — press or drag it to go to another place — and on a hover the time played and a button to pause it or play it on. Paused, a play triangle stands where the bars dance (Lumi 1.67.0).
- Artwork in the pill: where a site gives what it plays a cover, the minimized pill shows it in place of the site's icon, the site's icon a small badge on its corner (Lumi 1.67.0).
- Settings (⌘,), in the icon's menu, opens as a tab of its own, as History does — one such tab at a time. It sets the cover's shape on the pill — Spinning Record, which turns while the track plays, Circle or Square — and Tint with Artwork Colour, which washes the pill and its band in the cover's colour, with a preview of the pill as set. The pill follows a change at once, and the choice is kept on this Mac.
- Appearance, in Settings: Light, Dark or System, as in Lumi's own Settings. The browser, its pill, its menus and the tip change at once and stay that way after Lumi restarts; the Welcome tour follows macOS.
- History and Settings stand at an address of their own, as Chrome's pages do: the address bar shows `lumi://history` or `lumi://settings` while one is in front, and typing either in any tab opens it.
- In Compact Mode, History and Settings have a Done button, since no tab is drawn to close them.
- The menu bar icon's last row says Quit, which is what it does: every tab closed and the icon taken away until the shortcut brings it back.
- × closes the browser and its tabs, as closing a window does, and it opens on a new tab next time. It asks first while a tab holds a page; tick Don't ask again to stop it, and Ask Before Closing in Settings to have it ask again. The shortcut still puts it away with your tabs kept.
- YouTube opens on its desktop layout, whose player shows the pointer and its controls as you move the mouse; its phone layout hid both over a playing video until you clicked.
- A site you switch between its phone and desktop layouts stays as you switched it: it opens that way every time, in any tab, after Lumi restarts too.
- Close in the pill's menu is the browser's ×: while a tab holds a page the browser comes back from the pill and asks first, as the × does.
- The shortcuts swap places: ⌃⌥⌘H opens Floating Browser and puts it away, and ⌃⌥⌘B minimizes it to its pill and brings it back. The tip over the pill names the key Minimize has, and leaves it out when it has none.

## 0.1.0

- A small browser that floats over every app, at the top-right corner of the screen, opened and put away by ⌃⌥⌘B — minimized to its pill too, the pill with it — and opened again the way you put it away, as the browser or as its pill.
- It goes with you to every desktop, and stays over apps in full screen (Lumi 1.65.0).
- Up to four tabs along the top, the one in front holding the address bar, as in Chrome. Drag a tab along the strip to put it somewhere else.
- An address bar that also searches, with Back, Forward and Reload. A lock at its start, as in Chrome, says the page's connection is secure; press it to read so.
- The address bar suggests as you type, from your history and well-known sites, and completes the address in place, as in Chrome.
- Your browsing history, kept on this Mac: History (⌘Y), in the icon's menu, lists the pages you visited by day, to search, open again or remove one by one, or clear.
- ⌘-click or middle-click a link to open it in a new tab behind this one — with ⇧, in front — and a link that opens a new window opens in a new tab. With four tabs open it offers this tab or your browser instead (Lumi 1.65.0).
- A new tab opens on a search box under Lumi's mark, as in Chrome, with the address bar's suggestions and shortcuts to Google, YouTube, Facebook, Outlook, Wikipedia and GitHub; you type straight into it.
- The start page's shortcuts are yours, as in Chrome: drag one to move it, use its ⋮ (or right-click it) to edit or remove it, Add Shortcut for up to ten, and Restore Default Shortcuts for the first six. They stay after Lumi restarts.
- Phone or desktop layouts, per tab: phone by default, since the window is narrow. Switch with the toolbar's button or Desktop Site in the icon's menu.
- Open in your browser, for anything more.
- An icon of its own in the menu bar: your tabs, Compact Mode, Mute All, Close All Tabs, and Close, which puts it away until you call it again.
- Its menu shows each tab with its site's icon and a speaker while it makes sound, and works as any Mac menu, keys included. Right-click the icon for the Mac's own menu.
- The icon at the left of the tab strip lists your tabs, with Compact Mode, Desktop Site and History.
- Compact Mode, from that icon or the menu bar: one slim bar instead of the tabs and the toolbar, with the page's title and Close. Click the title to type an address; point at the bar for Back and Reload, ⇧ making Back go forward.
- Each tab shows its site's own icon, as in Chrome, fetched from the site itself; those of Google's and Microsoft's apps, YouTube, Facebook, Wikipedia, GitHub and GitLab come with the browser, so they show at once, signed in or not.
- A speaker on a tab making sound, as in Chrome: press it to mute that tab. The menu bar menu marks it too (Lumi 1.65.0).
- Drag it by its tab strip or toolbar, resize it by its edges; it opens where you left it. Pages run to its edges, as in Chrome.
- Minimize (− beside Close, or ⌘M) moves it to a small pill in the corner of the screen, with the page's title, how many tabs are open and a ring while a page loads; whatever plays in it plays on, bars dancing on the pill to say so (a muted speaker when it is silenced). Click the pill to bring the browser back, drag it to another corner, or click the icon at its left for your tabs or Close. The first time after the Welcome tour, a tip over the pill points at it.
- Its tabs stay as they were while it is put away, and show at once when it comes back; anything playing in them pauses until then (Lumi 1.65.0).
- Your tabs are still there after Lumi restarts. Sites remember you between openings, kept apart from your other browsers.
- ⌃⌥⌘H minimizes it from any app, and brings it back from the pill; with the browser away, it opens it.
- A Welcome tour when it is installed or updated, a step for each thing it does, where its shortcut can be recorded again. Its About page in Lumi opens it again.

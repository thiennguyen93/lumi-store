// The menu under Floating Browser's item in the menu bar — and the pill's
// menu of the tabs, the same page in a window of its own (`tabs`), which the
// component gives the tabs' rows and Close, the browser's ×, alone
// (`rows_of`). The rows are the component's (`menu_rows`, src/lib.rs), the
// same ones macOS's own menu is drawn from for the right-click and
// VoiceOver: asked for when the page loads and told again (`lumi:message`)
// whenever they change — the panel keeps its page while put away, so it
// draws and sizes itself for the next opening while nobody is looking, and
// opens on its first frame at the size its rows want.
//
// Drawn as the browser's own menu is drawn rather than as a macOS menu: a
// site's icon on each tab's row, the tab in front tinted in the accent and
// its × always there — the others' under the pointer — an icon beside every
// other row and a switch for Compact Mode and Mute All. In the item's menu,
// what plays stands at the top, as Now Playing (`now`, told by the browser's
// page through the component): its picture, title and artist, its clock and
// a play button, and its tab is not listed again under Other Tabs.
//
// Worked as a macOS menu is:
// - one row lit at a time, by the pointer or by the arrows alike — ↓ from
//   nothing lights the first row and ↑ the last, and both go round; nothing
//   is lit when it opens, and the pointer leaving the menu puts the light
//   out;
// - a row is chosen when the button comes up on it, so a press can slide
//   from one row to another; Return or Space chooses the lit row, or closes
//   the menu when none is;
// - typing a row's first letters lights it, the letters forgotten after a
//   second's pause;
// - a chosen row blinks once before the menu goes, so the eye sees which;
// - a row that cannot be chosen never lights.
// A switch, a tab's × and Now Playing's button leave the menu up, to show
// what they changed.
//
// Escape and a press anywhere else put it away (Lumi's, for this panel).

"use strict";

const menu = document.getElementById("menu");

// Which menu this page is — the icon's (`menu`) or the pill's (`tabs`) — as
// Lumi names the window in the page's address, for menu.css: the pill's is
// narrower, its titles cut sooner, and shows no Now Playing — the pill does.
document.documentElement.dataset.window = new URLSearchParams(location.search).get("window") || "";
const pillsMenu = document.documentElement.dataset.window === "tabs";

/** The rows as last told: `{id, label, checked, disabled, url, icon, sound,
 *  glyph}` each, or `{separator: true}`. */
let rows = [];
/** What plays, as the browser's page last told it (`nowFrom`), or null. */
let now = null;
/** The rows' indices in the order they are drawn — Now Playing's tab first
 *  — which the arrows and type-ahead go along. */
let order = [];
/** The index in `rows` of the row lit now, or -1. */
let lit = -1;
/** A row was chosen: the blink is under way and the menu about to go. */
let choosing = false;
/** Type-ahead: what was typed so far, and when the last letter was. */
let typed = "";
let typedAt = 0;
/** The size the panel was last asked to be, so a redraw that changes
 *  nothing asks nothing. */
let asked = "";
/** Now Playing's clock, moving its band while the menu is up. */
let ticking = 0;

/** How long the letters typed are remembered, as macOS's type select. */
const TYPED_FOR = 1000;
/** The blink: the light out, then on again, each this long. */
const BLINK = 70;
/** How often Now Playing's band moves on while it plays. */
const TICK = 500;

/** One of this extension's own requests (`run_ui`). */
async function call(request) {
  const answer = await fetch("/__lumi__/call", { method: "POST", body: JSON.stringify(request) });
  const text = await answer.text();
  if (!answer.ok) throw new Error(text);
  return text ? JSON.parse(text) : null;
}

// ---- Drawing -----------------------------------------------------------------

const SVG = "http://www.w3.org/2000/svg";

/** An icon of `paths` (SVG path data) in a `box`-square view. */
function glyph(className, box, paths) {
  const picture = document.createElementNS(SVG, "svg");
  picture.setAttribute("class", className);
  picture.setAttribute("viewBox", `0 0 ${box} ${box}`);
  picture.setAttribute("aria-hidden", "true");
  for (const each of paths) {
    const path = document.createElementNS(SVG, "path");
    path.setAttribute("d", each);
    picture.append(path);
  }
  return picture;
}

/** Lucide's (ISC), the browser's own: the globe for a site with no icon
 *  found, the speakers the browser's tabs draw, its ×, and each row's icon
 *  by the Lucide name the component gives it (`glyph`), the name macOS's
 *  menu draws for the same row. */
const GLOBE = ["M2 12a10 10 0 1 0 20 0 10 10 0 1 0-20 0", "M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20", "M2 12h20"];
const SPEAKER =
  "M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z";
const SOUND = [SPEAKER, "M16 9a5 5 0 0 1 0 6", "M19.364 18.364a9 9 0 0 0 0-12.728"];
const SILENT = [SPEAKER, "M22 9l-6 6", "M16 9l6 6"];
const CLOSE = ["M18 6 6 18", "m6 6 12 12"];
const GLYPHS = {
  "app-window": ["M4 4h16a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z", "M10 4v4", "M2 8h20", "M6 4v4"],
  "panel-top": ["M5 3h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z", "M3 9h18"],
  "volume-x": SILENT,
  "square-x": ["M5 3h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z", "m15 9-6 6", "m9 9 6 6"],
  power: ["M12 2v10", "M18.4 6.6a9 9 0 1 1-12.77.04"],
  x: CLOSE,
};
/** Now Playing's button: filled, white on the accent. */
const PLAY = ["M7 4.5v15a1 1 0 0 0 1.5.86l12.5-7.5a1 1 0 0 0 0-1.72L8.5 3.64A1 1 0 0 0 7 4.5z"];
const PAUSE = ["M6 4h3.5a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1z", "M14.5 4H18a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1h-3.5a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1z"];

/** An icon the browser found: one the package carries (`icons/…`), or a
 *  picture as a `data:` URL — nothing else is drawn. */
function pictureAllowed(icon) {
  return typeof icon === "string" && (/^icons\/[\w.-]+$/.test(icon) || /^data:image\/[\w.+-]+;base64,/.test(icon));
}

/** A tab's icon as the browser found it, or the globe. */
function iconOf(icon, className = "favicon") {
  if (pictureAllowed(icon)) {
    const picture = document.createElement("img");
    picture.className = className;
    picture.alt = "";
    picture.draggable = false;
    picture.src = icon;
    picture.addEventListener("error", () => picture.replaceWith(glyph("globe", 24, GLOBE)));
    return picture;
  }
  return glyph("globe", 24, GLOBE);
}

const isTab = (row) => Boolean(row) && typeof row.url === "string";
/** Compact Mode and Mute All: a check that is not a tab's, drawn as a
 *  switch, which flips with the menu left up. */
const isSwitch = (row) => Boolean(row) && !isTab(row) && typeof row.checked === "boolean";

function rowElement(row, index) {
  const element = document.createElement("div");
  element.className = "row";
  element.id = `row-${index}`;
  element.dataset.index = String(index);
  if (row.disabled) element.setAttribute("aria-disabled", "true");
  const title = document.createElement("span");
  title.className = "title";
  title.textContent = row.label;
  if (isTab(row)) {
    element.classList.add("tab");
    element.classList.toggle("cur", row.checked === true);
    element.setAttribute("role", "menuitemradio");
    element.setAttribute("aria-checked", String(row.checked === true));
    element.append(iconOf(row.icon), title);
    if (row.sound === "playing" || row.sound === "muted") {
      element.append(glyph("sound", 24, row.sound === "muted" ? SILENT : SOUND));
      element.setAttribute("aria-description", row.sound === "muted" ? "Muted" : "Playing");
    }
    // Its ×, drawn over the end of its title rather than taking a place of
    // its own, so nothing in the row moves as the pointer comes and goes.
    const shut = document.createElement("span");
    shut.className = "shut";
    shut.dataset.shut = String(index);
    shut.setAttribute("role", "button");
    shut.setAttribute("aria-label", "Close Tab");
    shut.append(glyph("x", 24, CLOSE));
    element.append(shut);
    return element;
  }
  const paths = typeof row.glyph === "string" && Object.prototype.hasOwnProperty.call(GLYPHS, row.glyph) ? GLYPHS[row.glyph] : null;
  element.append(paths ? glyph("glyph", 24, paths) : Object.assign(document.createElement("span"), { className: "glyph" }), title);
  if (isSwitch(row)) {
    const on = switchedOn(row);
    element.setAttribute("role", "menuitemcheckbox");
    element.setAttribute("aria-checked", String(on));
    const knob = document.createElement("span");
    knob.className = "switch";
    knob.classList.toggle("on", on);
    element.append(knob);
  } else {
    element.setAttribute("role", "menuitem");
  }
  return element;
}

/** A section's name over its rows, Now Playing's with three bars that move
 *  while it plays — none at all paused, where three still bars read as a
 *  More button. */
function sectionElement(name, bars) {
  const element = document.createElement("div");
  element.className = "section";
  element.setAttribute("aria-hidden", "true");
  const label = document.createElement("span");
  label.className = "name";
  label.textContent = name;
  element.append(label);
  if (bars) {
    const eq = document.createElement("span");
    eq.className = "eq";
    eq.classList.toggle("go", now.playing);
    eq.append(document.createElement("i"), document.createElement("i"), document.createElement("i"));
    element.append(eq);
  }
  return element;
}

/** Now Playing, standing for its tab's row (`index`): chosen, it opens the
 *  browser on that tab, as the row would. */
function cardElement(row, index) {
  const element = document.createElement("div");
  element.className = "row card";
  element.id = `row-${index}`;
  element.dataset.index = String(index);
  element.setAttribute("role", "menuitem");
  element.setAttribute("aria-label", [now.title, now.artist].filter(Boolean).join(", "));
  const art = document.createElement("span");
  art.className = "art";
  if (/^data:image\/png;base64,[A-Za-z0-9+/=]+$/.test(now.artwork)) {
    const cover = document.createElement("img");
    cover.className = "cover";
    cover.alt = "";
    cover.draggable = false;
    cover.src = now.artwork;
    art.append(cover, iconOf(now.icon || row.icon, "badge"));
  } else {
    art.classList.add("plain");
    art.append(iconOf(now.icon || row.icon));
  }
  const what = document.createElement("span");
  what.className = "what";
  const title = document.createElement("span");
  title.className = "np-title";
  title.textContent = now.title;
  // The artist, and at that line's end how far it has played of how long it
  // is — the artist cut short for it, never the time (`tick` keeps it).
  const line = document.createElement("span");
  line.className = "np-line";
  const artist = document.createElement("span");
  artist.className = "np-artist";
  artist.textContent = now.artist;
  line.append(artist);
  if (now.duration > 0 && Number.isFinite(now.position)) {
    const time = document.createElement("span");
    time.className = "np-time";
    line.append(time);
  }
  what.append(title, line);
  // Its band, pressed or dragged to go elsewhere in what plays, as the
  // pill's is (Seeking, below): a taller place to press than the line, the
  // line thicker and a knob on it under the pointer.
  if (now.duration > 0 && Number.isFinite(now.position)) {
    const seek = document.createElement("span");
    seek.className = "seek";
    seek.setAttribute("role", "slider");
    seek.setAttribute("aria-label", "Playback position");
    const band = document.createElement("span");
    band.className = "band";
    band.append(document.createElement("i"));
    const knob = document.createElement("span");
    knob.className = "knob";
    seek.append(band, knob);
    what.append(seek);
  }
  const play = document.createElement("span");
  play.className = "play";
  play.setAttribute("role", "button");
  play.setAttribute("aria-label", now.playing ? "Pause" : "Play");
  play.append(glyph("", 24, now.playing ? PAUSE : PLAY));
  element.append(art, what, play);
  return element;
}

/** The menu drawn from the rows and what plays, and the panel sized to it.
 *  The lit row stays lit across a redraw — a switch flipped, a tab closed —
 *  wherever it is drawn now. */
function draw() {
  const litId = lit >= 0 && rows[lit] ? rows[lit].id : null;
  const playing = !pillsMenu && now ? rows.findIndex((row) => isTab(row) && row.url === now.url) : -1;
  const children = [];
  order = [];
  const put = (index, element) => {
    order.push(index);
    children.push(element);
  };
  const plain = (index) => {
    const row = rows[index];
    if (!row.separator) return rowElement(row, index);
    const line = document.createElement("div");
    line.className = "separator";
    line.setAttribute("role", "separator");
    return line;
  };
  if (playing >= 0) {
    children.push(sectionElement("Now playing", true));
    put(playing, cardElement(rows[playing], playing));
    const others = rows.map((_, index) => index).filter((index) => isTab(rows[index]) && index !== playing);
    if (others.length > 0) children.push(sectionElement("Other tabs", false));
    for (const index of others) put(index, plain(index));
    rows.forEach((row, index) => {
      if (!isTab(row)) put(index, plain(index));
    });
  } else {
    rows.forEach((_, index) => put(index, plain(index)));
  }
  menu.replaceChildren(...children);
  lit = -1;
  menu.removeAttribute("aria-activedescendant");
  if (litId !== null) light(rows.findIndex((row) => row.id === litId));
  tick();
  size();
}

/** The panel asked to be the menu's size: as wide as its widest row and as
 *  tall as its rows. Asked while it is put away too, so the next opening is
 *  already that size (`keep-alive`). */
function size() {
  const box = menu.getBoundingClientRect();
  const width = Math.ceil(box.width);
  const height = Math.ceil(box.height);
  const wanted = `${width}x${height}`;
  if (wanted === asked || height === 0) return;
  asked = wanted;
  fetch("/__lumi__/size", { method: "POST", body: JSON.stringify({ width, height }) }).catch(() => {
    asked = "";
  });
}

// ---- Now Playing's clock -------------------------------------------------------

/** Where what plays is now: where Lumi last said, moved on at its rate since
 *  then while it plays. */
function position() {
  if (!now || !Number.isFinite(now.position)) return null;
  const moved = now.playing ? ((Date.now() - now.at) / 1000) * now.rate : 0;
  return Math.max(0, Math.min(now.duration, now.position + moved));
}

/** The band, its knob and the time drawn at where what plays is — or,
 *  while the band is dragged, where the drag is. */
function tick() {
  const seek = menu.querySelector(".seek");
  if (!seek || !now || !(now.duration > 0)) return;
  const at = scrub ? scrub.share * now.duration : position();
  if (at === null) return;
  const share = `${(at / now.duration) * 100}%`;
  seek.querySelector(".band i").style.width = share;
  seek.querySelector(".knob").style.left = share;
  seek.setAttribute("aria-valuetext", `${clock(at)} of ${clock(now.duration)}`);
  const time = menu.querySelector(".np-time");
  if (time) time.textContent = `${clock(at)} / ${clock(now.duration)}`;
}

/** Seconds as a player writes them: 3:07, or 1:02:09. */
function clock(seconds) {
  const whole = Math.max(0, Math.floor(seconds));
  const hours = Math.floor(whole / 3600);
  const minutes = Math.floor((whole % 3600) / 60);
  const rest = String(whole % 60).padStart(2, "0");
  return hours ? `${hours}:${String(minutes).padStart(2, "0")}:${rest}` : `${minutes}:${rest}`;
}

// ---- Seeking -----------------------------------------------------------------

// Now Playing's band, as the pill's: pressed, what plays goes there; held
// and dragged, it is sought roughly as the drag passes, at most every
// SEEK_EVERY, and exactly where it is let go, Lumi's tip over the knob
// naming the time there. The band stays where it was let go until the site
// says where it is, so it does not run back for the moment that takes.

/** How often a drag along the band asks for a rough seek. */
const SEEK_EVERY = 120;

/** The drag under way: its pointer, the share of the length it is at, and
 *  when it last asked for a seek — or null. */
let scrub = null;

/** The share of the length under the pointer at `x` on `seek`. */
function shareAt(seek, x) {
  const box = seek.getBoundingClientRect();
  return Math.min(1, Math.max(0, (x - box.left) / box.width));
}

function seekTo(share, exact) {
  if (!now || !(now.duration > 0)) return;
  call({ kind: "seek", tab: now.tab, position: share * now.duration, exact }).catch(() => {});
}

/** Lumi's tip over the knob: the time there and the length. */
function tipAt(seek) {
  const box = seek.querySelector(".knob").getBoundingClientRect();
  fetch("/__lumi__/tip", {
    method: "POST",
    body: JSON.stringify({
      text: `${clock(scrub.share * now.duration)} / ${clock(now.duration)}`,
      x: box.left,
      y: box.top,
      width: box.width,
      height: box.height,
    }),
  }).catch(() => {});
}

function endScrub(seek) {
  const was = scrub;
  scrub = null;
  menu.querySelector(".seek")?.classList.remove("scrubbing");
  fetch("/__lumi__/tip", { method: "DELETE" }).catch(() => {});
  if (!was || !now) return;
  if (seek) {
    seekTo(was.share, true);
    now = { ...now, position: was.share * now.duration, at: Date.now() };
  }
  if (was.redraw) draw();
  else tick();
}

menu.addEventListener("pointerdown", (event) => {
  const seek = event.target instanceof Element ? event.target.closest(".seek") : null;
  if (!seek || event.button !== 0 || !now) return;
  event.preventDefault();
  seek.setPointerCapture(event.pointerId);
  seek.classList.add("scrubbing");
  scrub = { pointer: event.pointerId, share: shareAt(seek, event.clientX), sought: 0 };
  tick();
  tipAt(seek);
});

menu.addEventListener("pointermove", (event) => {
  if (!scrub || event.pointerId !== scrub.pointer) return;
  const seek = menu.querySelector(".seek");
  if (!seek) return;
  scrub.share = shareAt(seek, event.clientX);
  tick();
  tipAt(seek);
  if (Date.now() - scrub.sought >= SEEK_EVERY) {
    scrub.sought = Date.now();
    seekTo(scrub.share, false);
  }
});

menu.addEventListener("pointercancel", () => endScrub(false));

// ---- The lit row -------------------------------------------------------------

function choosable(index) {
  const row = rows[index];
  return Boolean(row && !row.separator && !row.disabled && document.getElementById(`row-${index}`));
}

function light(index) {
  if (index === lit) return;
  const before = menu.querySelector(".row.on");
  if (before) before.classList.remove("on");
  lit = choosable(index) ? index : -1;
  if (lit < 0) {
    menu.removeAttribute("aria-activedescendant");
    return;
  }
  const element = document.getElementById(`row-${lit}`);
  element.classList.add("on");
  menu.setAttribute("aria-activedescendant", element.id);
}

/** The next row that can be chosen, `by` 1 or -1 from the lit one along the
 *  rows as drawn, round the ends: from none, the first going down and the
 *  last going up. */
function step(by) {
  const count = order.length;
  let at = lit < 0 ? (by > 0 ? -1 : count) : order.indexOf(lit);
  for (let tries = 0; tries < count; tries += 1) {
    at = (at + by + count) % count;
    if (choosable(order[at])) return light(order[at]);
  }
}

/** The first or the last row that can be chosen. */
function end(last) {
  lit = -1;
  const along = last ? [...order].reverse() : order;
  const index = along.find(choosable);
  if (index !== undefined) light(index);
}

/** A title as type-ahead compares it: no case, no accents — "huong"
 *  finds "Hương". */
function folded(text) {
  return text
    .normalize("NFD")
    .replace(/\p{M}/gu, "")
    .replace(/đ/g, "d")
    .replace(/Đ/g, "D")
    .toLowerCase();
}

function typeAhead(letter) {
  const moment = performance.now();
  typed = moment - typedAt > TYPED_FOR ? letter : typed + letter;
  typedAt = moment;
  const wanted = folded(typed);
  const index = order.find((at) => choosable(at) && folded(rows[at].label).startsWith(wanted));
  if (index !== undefined) light(index);
}

// ---- Choosing ----------------------------------------------------------------

/** Switches drawn moved on the press, before the component has answered:
 *  row id → the way drawn. Drawn only once the component's menu came back,
 *  a press waited on a whole run of it — keeping the tabs, drawing macOS's
 *  menu, telling the browser — and read as a slow switch. A menu told
 *  meanwhile may still say the way it was (the browser's page keeping its
 *  tabs, or the answer to a press before), and drawn as told the switch
 *  would jump back and forth; so the way drawn holds until SETTLE after its
 *  own run has ended, or at once if that run failed, and then what the
 *  component says stands — a switch that did not move is shown so. */
const flipped = new Map();
const SETTLE = 1000;
/** Presses on the switches, one run after another in the order made, so
 *  the last drawn is the last kept: Lumi runs several of an extension's at
 *  once, and two presses quicker than a run could otherwise end the wrong
 *  way round. */
let switching = Promise.resolve();

/** The way a switch is drawn: as pressed, while that holds, or as told. */
function switchedOn(row) {
  return flipped.has(row.id) ? flipped.get(row.id) : row.checked === true;
}

/** A press's way let go once its run is over — unless a later press holds
 *  the switch — and the switch drawn as the component says, if not so. */
function settleFlip(id, on) {
  if (flipped.get(id) !== on) return;
  flipped.delete(id);
  const row = rows.find((each) => each.id === id);
  if (row && row.checked === on) return;
  if (scrub) scrub.redraw = true;
  else draw();
}

/** The row at `index` chosen: a switch flips with the menu left up; any
 *  other row blinks, then the component runs it and puts the menu away
 *  (`choose`). */
function choose(index) {
  if (choosing || !choosable(index)) return;
  const row = rows[index];
  if (isSwitch(row)) {
    light(index);
    // Moved the moment it is pressed, sliding as macOS's switch does; the
    // component is told which way, never to flip, so it ends where drawn.
    const on = !switchedOn(row);
    flipped.set(row.id, on);
    const element = document.getElementById(`row-${index}`);
    element.setAttribute("aria-checked", String(on));
    const knob = element.querySelector(".switch");
    if (knob) knob.classList.toggle("on", on);
    const request = { kind: "toggle", row: row.id, checked: on };
    switching = switching.catch(() => {}).then(() => call(request));
    switching.then(
      () => setTimeout(() => settleFlip(row.id, on), SETTLE),
      () => settleFlip(row.id, on),
    );
    return;
  }
  choosing = true;
  light(index);
  const element = document.getElementById(`row-${index}`);
  element.classList.remove("on");
  setTimeout(() => {
    element.classList.add("on");
    setTimeout(() => {
      call({ kind: "choose", row: row.id }).catch(() => {
        choosing = false;
      });
    }, BLINK);
  }, BLINK);
}

/** A tab's × pressed: that tab closed, the menu left up; the component
 *  draws it again without the tab. */
function closeTabAt(index) {
  const row = rows[index];
  if (isTab(row)) call({ kind: "close-tab", row: row.id }).catch(() => {});
}

/** Now Playing's button: what plays paused, or played on, as the pill's
 *  button asks — said as which, never toggled, and drawn only once the site
 *  says it plays or not, which the browser's page tells the moment it is
 *  done: a guess drawn first was put back by the next word about the site,
 *  which still said what was, and the button flickered (bubble.js). */
function playOrPause() {
  if (!now) return;
  call({ kind: "play", tab: now.tab, playing: !now.playing }).catch(() => {});
}

/** The menu put away with nothing chosen. */
function dismiss() {
  call({ kind: "dismiss" }).catch(() => {});
}

function rowAt(event) {
  const element = event.target instanceof Element ? event.target.closest(".row") : null;
  return element ? Number(element.dataset.index) : -1;
}

// The pointer lights the row under it — none over a separator, a section's
// name, a row that cannot be chosen or the glass around them — and the
// light goes out as it leaves the menu.
menu.addEventListener("pointermove", (event) => {
  if (!choosing) light(rowAt(event));
});
document.documentElement.addEventListener("pointerleave", () => {
  if (!choosing) light(-1);
});

// Chosen where the button comes up, as macOS chooses: a press may slide from
// row to row first. The right button chooses too, as in a macOS menu. A
// tab's × and Now Playing's button are presses of their own.
menu.addEventListener("pointerup", (event) => {
  if (event.button !== 0 && event.button !== 2) return;
  if (choosing) return;
  const target = event.target instanceof Element ? event.target : null;
  if (scrub && event.pointerId === scrub.pointer) {
    endScrub(true);
    return;
  }
  if (target && target.closest(".seek")) return;
  const shut = target && target.closest("[data-shut]");
  if (shut) {
    closeTabAt(Number(shut.dataset.shut));
    return;
  }
  if (target && target.closest(".play")) {
    playOrPause();
    return;
  }
  const index = rowAt(event);
  if (choosable(index)) choose(index);
});
addEventListener("contextmenu", (event) => event.preventDefault());

document.addEventListener("keydown", (event) => {
  if (event.isComposing || event.keyCode === 229) return;
  if (choosing) {
    event.preventDefault();
    return;
  }
  if (event.metaKey || event.ctrlKey) return;
  switch (event.key) {
    case "ArrowDown":
      step(1);
      break;
    case "ArrowUp":
      step(-1);
      break;
    case "Home":
    case "PageUp":
      end(false);
      break;
    case "End":
    case "PageDown":
      end(true);
      break;
    case "Enter":
      if (lit >= 0) choose(lit);
      else dismiss();
      break;
    case " ":
      // A space inside letters being typed is one of them.
      if (typed && performance.now() - typedAt <= TYPED_FOR) typeAhead(" ");
      else if (lit >= 0) choose(lit);
      else dismiss();
      break;
    case "Escape":
      dismiss();
      break;
    default:
      if (event.key.length === 1 && !event.altKey) typeAhead(event.key);
      else return;
  }
  event.preventDefault();
});

// ---- Told by the component -------------------------------------------------------

/** The rows out of a model as the component sends it: what is not a row is
 *  left out. */
function rowsFrom(model) {
  const given = model && model.v === 1 && Array.isArray(model.rows) ? model.rows.slice(0, 24) : [];
  return given.filter((row) => row && (row.separator === true || (typeof row.id === "string" && typeof row.label === "string")));
}

/** What plays, as the browser's page tells it (`nowPlayingState` in
 *  browser.js), read before anything of it is drawn — its words come from
 *  web sites — or null. */
function nowFrom(said) {
  if (!said || said.v !== 1 || typeof said.url !== "string" || typeof said.tab !== "string" || said.tab.length > 64) return null;
  const text = (value) => (typeof value === "string" ? value.slice(0, 300) : "");
  const number = (value) => (Number.isFinite(value) ? value : null);
  return {
    url: said.url,
    tab: said.tab,
    title: text(said.title),
    artist: text(said.artist),
    icon: pictureAllowed(said.icon) ? said.icon : "",
    artwork: typeof said.artwork === "string" ? said.artwork : "",
    duration: number(said.duration) ?? 0,
    position: number(said.position),
    rate: number(said.rate) ?? 0,
    playing: said.playing === true,
    at: number(said.at) ?? Date.now(),
  };
}

// Drawn again as it is told — except under a drag along the band, which
// a redraw would take from under the pointer: drawn once it is let go.
addEventListener("lumi:message", (event) => {
  const said = event.detail;
  if (said && said.kind === "menu") {
    rows = rowsFrom(said.menu);
  } else if (said && said.kind === "now-playing" && !pillsMenu) {
    now = nowFrom(said.now);
  } else {
    return;
  }
  if (scrub) scrub.redraw = true;
  else draw();
});

// Every opening starts with nothing lit and nothing typed, as a macOS menu
// opens; put away, the blink and the light are over, and the clock stops.
addEventListener("lumi:hidden", () => {
  endScrub(false);
  choosing = false;
  typed = "";
  light(-1);
  clearInterval(ticking);
  ticking = 0;
});

addEventListener("lumi:shown", () => {
  choosing = false;
  typed = "";
  light(-1);
  menu.focus();
  tick();
  clearInterval(ticking);
  ticking = setInterval(tick, TICK);
});

call({ kind: "menu" })
  .then((model) => {
    rows = rowsFrom(model);
    draw();
  })
  .catch(() => {
    rows = [];
    draw();
  });

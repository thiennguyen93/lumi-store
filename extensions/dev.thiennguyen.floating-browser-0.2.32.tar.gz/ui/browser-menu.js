// The icon's menu, in a panel of its own under the icon it was opened from
// (`browser-menu.html`), worked by the keys as the pill's menu is (`menu.js`,
// the keyboard, below). The browser's page holds every fact the menu shows
// and does all it asks: it sends a model of the menu (`model`, below) through
// the component whenever the menu is up and something in it changed, and
// this page draws it, asks the panel to be its height, and hands each press
// back as a command — `{"do": …}` — for the browser's page to carry out
// (`browser.js`, The icon's menu). A row that is done with the menu puts it
// away with the press (`close`); a switch, a zoom step or a tab's × leaves
// it up, and the model that comes back draws what they changed.

"use strict";

const $ = (id) => document.getElementById(id);

/** One of this extension's own requests (`run_ui`). */
async function call(request) {
  const answer = await fetch("/__lumi__/call", { method: "POST", body: JSON.stringify(request) });
  const text = await answer.text();
  if (!answer.ok) throw new Error(text);
  return text ? JSON.parse(text) : null;
}

/** Lucide's (ISC), the browser's own: the same glyphs as its window. */
const ICONS = {
  close: '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
  globe: '<circle cx="12" cy="12" r="10"/><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/><path d="M2 12h20"/>',
  clock: '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
  plus: '<path d="M5 12h14"/><path d="M12 5v14"/>',
  minus: '<path d="M5 12h14"/>',
  desktop: '<rect width="20" height="14" x="2" y="3" rx="2"/><path d="M8 21h8"/><path d="M12 17v4"/>',
  compact: '<rect width="18" height="18" x="3" y="3" rx="2"/><path d="M3 9h18"/>',
  info: '<circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/>',
  reload: '<path d="M21 12a9 9 0 1 1-9-9c2.52 0 4.93 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/>',
  copy: '<rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/>',
  sound:
    '<path d="M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z"/><path d="M16 9a5 5 0 0 1 0 6"/><path d="M19.364 18.364a9 9 0 0 0 0-12.728"/>',
  silent:
    '<path d="M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z"/><path d="M22 9l-6 6"/><path d="M16 9l6 6"/>',
  zoom: '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/><path d="M11 8v6"/><path d="M8 11h6"/>',
  settings: '<path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/>',
};

function icon(name) {
  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute("viewBox", "0 0 24 24");
  svg.setAttribute("fill", "none");
  svg.setAttribute("stroke", "currentColor");
  svg.setAttribute("stroke-width", "2");
  svg.setAttribute("stroke-linecap", "round");
  svg.setAttribute("stroke-linejoin", "round");
  svg.setAttribute("aria-hidden", "true");
  // Constant markup from the table above, never from a site.
  svg.innerHTML = ICONS[name];
  return svg;
}

/** What the browser's page does for a press: `command`, and the menu put
 *  away first when `close`. */
function send(command, close) {
  call({ kind: "command", command, close }).catch(() => {});
}

// ---- Drawing -------------------------------------------------------------------

/** A tab's mark: a spinner while it loads, its site's icon once the browser
 *  found one — one the package carries (`icons/…`) or a picture as a `data:`
 *  URL, nothing else — the globe before. */
function markOf(tab) {
  if (tab.loading === true) {
    const spinner = document.createElement("span");
    spinner.className = "spinner";
    return spinner;
  }
  const found = typeof tab.icon === "string" ? tab.icon : "";
  if (!/^icons\/[\w.-]+$/.test(found) && !/^data:image\/[\w.+-]+;base64,/.test(found)) return icon("globe");
  const picture = document.createElement("img");
  picture.className = "favicon";
  picture.alt = "";
  picture.draggable = false;
  picture.src = found;
  picture.addEventListener("error", () => picture.replaceWith(icon("globe")));
  return picture;
}

function setSwitch(row, on) {
  row.setAttribute("aria-checked", String(on));
  row.querySelector(".switch").classList.toggle("on", on);
}

/** The menu as the browser's page says it is: `{v: 1, tabs: [{id, label,
 *  icon, loading, current}], newTab, most, compact, desktop, zoom: {level,
 *  enabled, out, in, reset}}`. What is not as it should be is left out. */
function draw(model) {
  if (!model || model.v !== 1) return;
  if (Array.isArray(model.rows)) {
    drawRows(model.rows);
    return;
  }
  show($("menu"));
  // The lit row by what it is, so the light stays on it as the rows are
  // drawn again — a tab's by its id.
  const litKey = lit ? lit.dataset.tab ? `tab:${lit.dataset.tab}` : lit.id : null;
  const tabs = Array.isArray(model.tabs) ? model.tabs.slice(0, 8) : [];
  const rows = tabs
    .filter((tab) => tab && typeof tab.id === "string" && typeof tab.label === "string")
    .map((tab) => {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "menu-row";
      button.setAttribute("role", "menuitemradio");
      button.setAttribute("aria-checked", String(tab.current === true));
      button.classList.toggle("current", tab.current === true);
      button.dataset.tab = tab.id;
      const mark = markOf(tab);
      const label = document.createElement("span");
      label.className = "row-label";
      label.textContent = tab.label;
      const shut = document.createElement("span");
      shut.className = "row-shut";
      shut.dataset.shut = tab.id;
      shut.setAttribute("aria-hidden", "true");
      shut.append(icon("close"));
      button.append(mark, label, shut);
      return button;
    });
  const add = document.createElement("button");
  add.type = "button";
  add.className = "menu-row";
  add.id = "menu-new-tab";
  add.disabled = model.newTab !== true;
  const label = document.createElement("span");
  label.className = "row-label";
  label.textContent = model.newTab === true ? "New Tab" : `${Number(model.most) || 4} tabs at most`;
  const keys = document.createElement("span");
  keys.className = "keys";
  keys.textContent = "⌘T";
  add.append(icon("plus"), label, keys);
  $("menu-tabs").replaceChildren(...rows, add);
  setSwitch($("compact-row"), model.compact === true);
  setSwitch($("desktop-row"), model.desktop === true);
  const zoom = model.zoom && typeof model.zoom === "object" ? model.zoom : {};
  const level = Number.isFinite(zoom.level) ? zoom.level : 100;
  $("zoom-level").textContent = `${Math.round(level)}%`;
  $("zoom-level").disabled = zoom.reset !== true;
  $("zoom-out").disabled = zoom.out !== true;
  $("zoom-in").disabled = zoom.in !== true;
  $("zoom-row").classList.toggle("off", zoom.enabled !== true);
  if (litKey) {
    const again = litKey.startsWith("tab:")
      ? [...$("menu-tabs").querySelectorAll("[data-tab]")].find((row) => `tab:${row.dataset.tab}` === litKey)
      : document.getElementById(litKey);
    lit = null;
    light(again && choosable().includes(again) ? again : null);
  }
  size();
}

/** The command each row `drawRows` drew hands back. */
const commands = new WeakMap();

/** A menu the browser's page lays out row by row — a tab's: `[{label, keys,
 *  icon, disabled, command} | {sep: true}]`, `command` an object handed back
 *  as it is when the row is chosen, `icon` a name from the table above, and
 *  `keys` the ⌘-key the row shows, which chooses it too. Its words are the
 *  browser's own; what is not as it should be is left out. */
function drawRows(rows) {
  show($("rows"));
  const litKey = lit ? lit.dataset.key : null;
  const drawn = rows.slice(0, 24).flatMap((row) => {
    if (row && row.sep === true) {
      const sep = document.createElement("div");
      sep.className = "menu-sep";
      return [sep];
    }
    if (!row || typeof row.label !== "string" || !row.command || typeof row.command !== "object" || typeof row.command.do !== "string") {
      return [];
    }
    const button = document.createElement("button");
    button.type = "button";
    button.className = "menu-row";
    button.setAttribute("role", "menuitem");
    button.disabled = row.disabled === true;
    button.dataset.key = row.command.do;
    const ico = document.createElement("span");
    ico.className = "row-ico";
    if (typeof row.icon === "string" && Object.prototype.hasOwnProperty.call(ICONS, row.icon)) ico.append(icon(row.icon));
    const label = document.createElement("span");
    label.className = "row-label";
    label.textContent = row.label;
    button.append(ico, label);
    if (typeof row.keys === "string" && row.keys) {
      const keys = document.createElement("span");
      keys.className = "keys";
      keys.textContent = row.keys;
      button.dataset.keys = row.keys;
      button.append(keys);
    }
    commands.set(button, row.command);
    return [button];
  });
  $("rows").replaceChildren(...drawn);
  if (litKey) {
    const again = [...$("rows").querySelectorAll(".menu-row")].find((row) => row.dataset.key === litKey);
    lit = null;
    light(again && choosable().includes(again) ? again : null);
  }
  size();
}

/** One menu or the other in the panel: `which`, the light put out as it
 *  changes. */
function show(which) {
  if (menu === which && !which.hidden) return;
  $("menu").hidden = which !== $("menu");
  $("rows").hidden = which !== $("rows");
  menu = which;
  light(null);
}

/** The size last asked of the panel, so the same is not asked again. */
let asked = "";

/** The panel asked to be the menu's size. Asked while it is put away too,
 *  so the next opening is already that size (`keep-alive`). */
function size() {
  const box = menu.getBoundingClientRect();
  const width = Math.ceil(box.width);
  const height = Math.ceil(box.height);
  const wanted = `${width}x${height}`;
  if (wanted === asked || height === 0) return;
  asked = wanted;
  fetch("/__lumi__/size", { method: "POST", body: JSON.stringify({ width, height }) }).catch(() => {
    asked = "";
  });
}

// ---- Presses -------------------------------------------------------------------

$("menu-tabs").addEventListener("click", (event) => {
  const shut = event.target.closest("[data-shut]");
  if (shut) {
    send({ do: "close-tab", id: shut.dataset.shut }, false);
    return;
  }
  if (event.target.closest("#menu-new-tab")) {
    send({ do: "new-tab" }, true);
    return;
  }
  const row = event.target.closest("[data-tab]");
  if (row) send({ do: "select", id: row.dataset.tab }, true);
});

$("compact-row").addEventListener("click", () => send({ do: "compact" }, false));
$("desktop-row").addEventListener("click", () => send({ do: "desktop" }, false));
$("zoom-out").addEventListener("click", () => send({ do: "zoom", step: -1 }, false));
$("zoom-level").addEventListener("click", () => send({ do: "zoom", step: 0 }, false));
$("zoom-in").addEventListener("click", () => send({ do: "zoom", step: 1 }, false));
$("view-history").addEventListener("click", () => send({ do: "history" }, true));
$("view-settings").addEventListener("click", () => send({ do: "settings" }, true));
$("view-about").addEventListener("click", () => send({ do: "about" }, true));
$("menu-close").addEventListener("click", () => send({ do: "close" }, true));
$("rows").addEventListener("click", (event) => {
  const row = event.target.closest(".menu-row");
  if (row && !row.disabled && commands.has(row)) send(commands.get(row), true);
});

// ---- The keyboard ----------------------------------------------------------------

// As the pill's menu and the menu bar item's behave (`menu.js`), which behave
// as a macOS menu does:
// - one row lit at a time, by the pointer or by the arrows alike — ↓ from
//   nothing lights the first row and ↑ the last, and both go round; nothing
//   is lit when it opens, and the pointer leaving the menu puts the light
//   out;
// - Return or Space chooses the lit row, which blinks once first, or puts
//   the menu away when none is; Escape puts it away;
// - typing a row's first letters lights it, the letters forgotten after a
//   second's pause;
// - a row that cannot be chosen never lights.
// Two are this menu's own: ← and → step the zoom while its row is lit,
// since that row is three buttons, not one; and the ⌘-keys the rows show
// (⌘T, ⌘Y, ⌘,) do what their rows do, with ⌘+, ⌘− and ⌘0 for the zoom —
// the menu holds the keyboard while it is up, so the browser's own never
// hear them.

/** How long the letters typed are remembered, as macOS's type select. */
const TYPED_FOR = 1000;
/** The blink: the light out, then on again, each this long. */
const BLINK = 70;

/** The menu up in the panel: the icon's, or one laid out row by row. */
let menu = $("menu");

/** The row lit, or null. */
let lit = null;
/** Type-ahead: what was typed so far, and when the last letter was. */
let typed = "";
let typedAt = 0;
/** A row chosen and blinking: nothing else is chosen until it is done. */
let choosing = false;

/** Every row that can light, in order, its rows that cannot left out. */
function choosable() {
  return [...menu.querySelectorAll(".menu-row, .zoom-row")].filter((row) => !row.disabled && !row.classList.contains("off"));
}

function light(row) {
  if (row === lit) return;
  if (lit) lit.classList.remove("on");
  lit = row || null;
  if (lit) lit.classList.add("on");
}

/** The next row that can be chosen, `by` 1 or -1 from the lit one, round the
 *  ends: from none, the first going down and the last going up. */
function step(by) {
  const rows = choosable();
  if (rows.length === 0) return;
  const at = rows.indexOf(lit);
  light(rows[at < 0 ? (by > 0 ? 0 : rows.length - 1) : (at + by + rows.length) % rows.length]);
}

/** A row's words as type-ahead compares them: no case, no accents — "huong"
 *  finds "Hương". */
function folded(text) {
  return text.normalize("NFD").replace(/\p{M}/gu, "").replace(/đ/g, "d").replace(/Đ/g, "D").toLowerCase();
}

function typeAhead(letter) {
  const now = performance.now();
  typed = now - typedAt > TYPED_FOR ? letter : typed + letter;
  typedAt = now;
  const wanted = folded(typed);
  const row = choosable().find((each) => folded(each.querySelector(".row-label")?.textContent || "").startsWith(wanted));
  if (row) light(row);
}

/** The lit row chosen with the keys: a blink, then what a click on it does.
 *  The zoom's row is its three buttons, chosen one by one. */
function choose(row) {
  if (choosing || !row || row.id === "zoom-row") return;
  choosing = true;
  row.classList.remove("on");
  setTimeout(() => {
    row.classList.add("on");
    setTimeout(() => {
      choosing = false;
      row.click();
    }, BLINK);
  }, BLINK);
}

function dismiss() {
  call({ kind: "dismiss" }).catch(() => {});
}

for (const each of [$("menu"), $("rows")]) {
  each.addEventListener("pointermove", (event) => {
    const row = event.target.closest(".menu-row, .zoom-row");
    light(row && choosable().includes(row) ? row : null);
  });
  each.addEventListener("pointerleave", () => light(null));
}

document.addEventListener("keydown", (event) => {
  if (event.isComposing || choosing) return;
  if (event.metaKey && !event.ctrlKey && !event.altKey) {
    const key = event.key.toLowerCase();
    // A menu laid out row by row: the row showing the key.
    if (menu === $("rows")) {
      event.preventDefault();
      const row = [...menu.querySelectorAll(".menu-row")].find((each) => each.dataset.keys === `⌘${key.toUpperCase()}`);
      if (row && !row.disabled) row.click();
      return;
    }
    const zoom = { "=": 1, "+": 1, "-": -1, 0: 0 }[key];
    if (zoom !== undefined) {
      event.preventDefault();
      send({ do: "zoom", step: zoom }, false);
      return;
    }
    const row = { t: $("menu-new-tab"), y: $("view-history"), ",": $("view-settings") }[key];
    if (row) {
      event.preventDefault();
      if (!row.disabled) row.click();
    }
    return;
  }
  if (event.ctrlKey || event.altKey) return;
  switch (event.key) {
    case "Escape":
      dismiss();
      break;
    case "ArrowDown":
      step(1);
      break;
    case "ArrowUp":
      step(-1);
      break;
    case "ArrowLeft":
    case "ArrowRight":
      if (lit && lit.id === "zoom-row") send({ do: "zoom", step: event.key === "ArrowLeft" ? -1 : 1 }, false);
      break;
    case "Enter":
    case " ":
      if (lit) choose(lit);
      else dismiss();
      break;
    default:
      if (event.key.length !== 1) return;
      typeAhead(event.key);
  }
  event.preventDefault();
});

// Nothing lit as it opens, the letters typed before forgotten.
addEventListener("lumi:shown", () => {
  light(null);
  typed = "";
});

// ---- The model -----------------------------------------------------------------

addEventListener("lumi:message", (event) => {
  const said = event.detail;
  if (said && said.kind === "model") draw(said.model);
});

for (const [id, name] of [
  ["compact-row", "compact"],
  ["desktop-row", "desktop"],
  ["zoom-row", "zoom"],
  ["view-history", "clock"],
  ["view-settings", "settings"],
  ["view-about", "info"],
  ["menu-close", "close"],
]) {
  $(id).querySelector(".row-ico").append(icon(name));
}
$("zoom-out").append(icon("minus"));
$("zoom-in").append(icon("plus"));

// Loaded — at Lumi's start, out of sight (`preload`), or at the first
// opening: the browser's page told, which sends the menu as it stands, since
// a model sent before this page ran reached nobody.
call({ kind: "ready" }).catch(() => {});

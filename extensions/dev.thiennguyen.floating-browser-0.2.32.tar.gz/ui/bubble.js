// The minimized browser's pill. It knows only what the browser page handed
// over as it went out of the way — which site to show, whether anything
// makes sound, and what it plays — asked of the component once the page
// loads (`bubble`) and told again as it changes (`lumi:message`). A press on
// Lumi's signature opens the tabs in a menu of their own above the pill
// (`tabs`), to come back on one; a press anywhere else brings the browser
// back as it was (`restore`); a press that moves is a drag of the pill,
// which Lumi keeps where it is left. Its bottom edge seeks what plays
// (`seek`), and the button the time shows beside on a hover pauses or plays
// it (`play`), which the browser's page asks of Lumi for the site.
"use strict";

const pill = document.getElementById("bubble");
const tabsButton = document.getElementById("tabs");
const restoreButton = document.getElementById("restore");
const site = document.getElementById("site");
const title = document.getElementById("title");
const run = document.getElementById("title-run");
const artist = document.getElementById("artist");
const artistRun = document.getElementById("artist-run");
const badge = document.getElementById("badge");
const time = document.getElementById("time");
const played = document.getElementById("played");
const zone = document.getElementById("zone");
const knob = document.getElementById("knob");
const playButton = document.getElementById("play");
const still = matchMedia("(prefers-reduced-motion: reduce)");
const root = document.documentElement;

/** This page drawn as Settings' preview of the pill (`bubble.html?preview`,
 *  framed by the browser's page): a made-up track with a made-up cover,
 *  the look as the browser's page tells it, and nothing asked of Lumi —
 *  its requests would be the browser window's, and a size asked from there
 *  would resize the browser. */
const preview = new URLSearchParams(location.search).has("preview");

/** The pill's window: as wide as its title needs (`fit`), from Lumi's
 *  floor for a panel up to the manifest's width, and the manifest's height
 *  — asked for as the page loads too, since the window opens at the
 *  manifest's size. INSET is how far bubble.css stands the
 *  pill in from the window's edges. */
const WIDEST = 220;
const NARROWEST = 120;
const HEIGHT = 48;
const INSET = 4;

/** How fast a long line travels, in points a second, and how long it rests
 *  at each end — the 18% at either end of `swing` in bubble.css. */
const SWING_SPEED = 30;
const SWING_REST = 0.18;

/** How far the pointer goes before a press is a drag, in points: the
 *  browser's own title bar's number. */
const DRAG_AFTER = 4;

/** The band's playhead stands this far in from each end of the pill at the
 *  track's start and end, inside the pill's curve, so the knob never stands
 *  outside its outline. */
const HEAD_INSET = 11;

/** How often a drag along the band seeks while it moves, in milliseconds:
 *  each is the component's run and the browser page's ask of Lumi, and the
 *  site moves at once. The release seeks exactly. */
const SEEK_EVERY = 120;

async function call(request) {
  if (preview) throw new Error("a preview asks nothing");
  const answer = await fetch("/__lumi__/call", { method: "POST", body: JSON.stringify(request) });
  const text = await answer.text();
  if (!answer.ok) throw new Error(text);
  return text ? JSON.parse(text) : null;
}

/** An icon the browser page drew for a tab: one it carries under `icons/`,
 *  or a picture it found, as data. Anything else is no icon — the address
 *  came from a page, and a pill shows only what its own page could. */
function iconAllowed(icon) {
  if (typeof icon !== "string") return false;
  if (/^icons\/[a-z0-9-]+\.(svg|png|ico)$/.test(icon)) return true;
  return /^data:image\/(png|x-icon|vnd\.microsoft\.icon|svg\+xml|gif|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(icon);
}

/** An `<img>` of `src`, gone if it does not load. */
function picture(src, className) {
  const image = document.createElement("img");
  image.alt = "";
  image.draggable = false;
  if (className) image.className = className;
  image.src = src;
  image.addEventListener("error", () => image.remove());
  return image;
}

// ---- The look: how the cover is drawn ----------------------------------------

/** The look as set in Settings, on the root so the knob outside the pill
 *  wears the tint too: the cover's shape, and whether the pill takes its
 *  colour. Drawn only while there is a cover (`art`, above): a site that
 *  gives none shows the pill as it always was, whatever is set. */
function applyLook(said) {
  const shape = said && ["record", "circle", "square"].includes(said.shape) ? said.shape : "record";
  for (const each of ["record", "circle", "square"]) root.classList.toggle(`shape-${each}`, each === shape);
  root.classList.toggle("tinted", Boolean(said && said.tint === true));
}
applyLook(null);

/** The cover's colour: its pixels averaged, each weighted by how saturated
 *  it is, so the colour of a cover wins over its blacks and whites — read
 *  once per cover, off a canvas. A `data:` picture leaves the canvas
 *  readable; the page's policy has no `blob:`, so it is never one. */
let tintedFor = "";
function tintFrom(src) {
  if (src === tintedFor) return;
  tintedFor = src;
  root.style.removeProperty("--art");
  root.style.removeProperty("--art-strong");
  root.classList.remove("art-tint");
  if (!src) return;
  const image = new Image();
  image.onload = () => {
    if (tintedFor !== src) return;
    const canvas = document.createElement("canvas");
    canvas.width = canvas.height = 24;
    const pen2 = canvas.getContext("2d", { willReadFrequently: true });
    pen2.drawImage(image, 0, 0, 24, 24);
    let r = 0;
    let g = 0;
    let b = 0;
    let weights = 0;
    try {
      const { data } = pen2.getImageData(0, 0, 24, 24);
      for (let i = 0; i < data.length; i += 4) {
        if (data[i + 3] < 128) continue;
        const max = Math.max(data[i], data[i + 1], data[i + 2]);
        const min = Math.min(data[i], data[i + 1], data[i + 2]);
        const weight = 0.15 + (max - min) / 255;
        r += data[i] * weight;
        g += data[i + 1] * weight;
        b += data[i + 2] * weight;
        weights += weight;
      }
    } catch {
      return;
    }
    if (!weights) return;
    const rgb = [r / weights, g / weights, b / weights];
    root.style.setProperty("--art", `rgb(${rgb.map((each) => Math.round(each)).join(" ")})`);
    root.style.setProperty("--art-strong", strong(rgb));
    root.classList.add("art-tint");
  };
  image.src = src;
}

/** The cover's colour as the band, the bars and the knob wear it: its hue,
 *  saturated enough to be a colour, and light or dark enough to read on the
 *  pill in either appearance (`--art-light`, `--art-dark` in bubble.css). */
function strong([r, g, b]) {
  const [red, green, blue] = [r / 255, g / 255, b / 255];
  const max = Math.max(red, green, blue);
  const min = Math.min(red, green, blue);
  let hue = 0;
  if (max !== min) {
    const d = max - min;
    hue = max === red ? ((green - blue) / d) % 6 : max === green ? (blue - red) / d + 2 : (red - green) / d + 4;
    hue *= 60;
    if (hue < 0) hue += 360;
  }
  const saturation = max === min ? 0 : Math.max(0.55, (max - min) / (1 - Math.abs(max + min - 1)));
  return `${hue.toFixed(0)} ${(saturation * 100).toFixed(0)}%`;
}

/** A number of seconds as a clock reads it: 3:07, or 1:04:09 past an hour. */
function clock(seconds) {
  const whole = Math.max(0, Math.floor(seconds));
  const hours = Math.floor(whole / 3600);
  const minutes = Math.floor((whole % 3600) / 60);
  const rest = String(whole % 60).padStart(2, "0");
  return hours ? `${hours}:${String(minutes).padStart(2, "0")}:${rest}` : `${minutes}:${rest}`;
}

/** What the site plays, as the browser's page last handed it on: its
 *  length, where it was when told and how fast it moves on from there, on
 *  the wall clock both pages share — or `null` while it plays nothing with
 *  a length. And which of the browser's tabs it plays in, for a seek. */
let media = null;
let tab = "";

/** Whether what the site plays plays, as the site last said — `null` while
 *  it plays nothing it could pause, a live stream included as it is not in
 *  `media`. Its own `playing`, not its clock's rate, which stays 0 for a
 *  moment after a play while the media starts. */
let moving = null;

/** A seek being dragged along the band: the pointer, the share of the
 *  track under it, and when it last sought. */
let scrub = null;

/** How many tabs the badge says: the tabs the menu a press on it opens
 *  lists, as the component counts them off that menu's rows (`tab-count`)
 *  — never the browser page's own count, which holds the tabs on Lumi's
 *  pages the menu leaves out. And the state last drawn, drawn again when
 *  the count moves; `undefined` until the first. */
let tabCount = 0;
let drawn;

function countTabs(count) {
  tabCount = Number.isInteger(count) && count > 0 ? count : 0;
  if (drawn !== undefined) draw(drawn);
}

/** Where the track is now, as a share of its length: the drag's, while one
 *  goes on, else its clock moved on at its rate. */
function shareNow() {
  if (!media) return 0;
  if (scrub) return scrub.share;
  const moved = ((Date.now() - media.at) / 1000) * media.rate;
  return Math.min(1, Math.max(0, (media.position + moved) / media.duration));
}

/** The band, the knob and the time as the track stands now. */
function drawTime() {
  if (!media) return;
  const share = shareNow();
  const width = pill.offsetWidth;
  const head = HEAD_INSET + share * (width - 2 * HEAD_INSET);
  played.style.width = `${head}px`;
  knob.style.left = `${innerWidth - INSET - width + head}px`;
  time.textContent = clock(share * media.duration);
}

/** The band kept moving while the track plays, four times a second — a
 *  point a second or so on the band, and the time by the second. */
let ticking = 0;
function tick() {
  clearInterval(ticking);
  ticking = 0;
  drawTime();
  if (media && media.rate > 0) ticking = setInterval(drawTime, 250);
}

function draw(state) {
  drawn = state;
  const now = state && typeof state === "object" ? state : {};
  const playing = now.playing === true;
  pill.classList.toggle("playing", playing);
  pill.classList.toggle("muted", now.muted === true);
  // A ring in the icon's place while the page loads, as its tab has. Built
  // again only when what it shows changes: a title arriving mid-load would
  // otherwise start the ring over, and every message load the icon again.
  const icon = iconAllowed(now.icon) ? now.icon : "";
  // The track's cover, where the site gives one: in the icon's place, the
  // site's icon a badge on its corner. Lumi's own PNG and nothing else.
  const mediaSaid = now.media && typeof now.media === "object" ? now.media : null;
  const art =
    mediaSaid && typeof mediaSaid.artwork === "string" && /^data:image\/png;base64,[A-Za-z0-9+/=]+$/.test(mediaSaid.artwork) ? mediaSaid.artwork : "";
  const shows = now.loading === true ? "loading" : art ? `art\n${icon}\n${art}` : icon;
  if (site.dataset.shows !== shows) {
    site.dataset.shows = shows;
    site.replaceChildren();
    if (shows === "loading") {
      const ring = document.createElement("span");
      ring.className = "spinner";
      site.append(ring);
    } else {
      if (art) site.append(picture(art, "cover"));
      if (icon) site.append(picture(icon, art ? "fav" : ""));
    }
    root.classList.toggle("art", Boolean(art) && shows !== "loading");
    tintFrom(art);
  }
  // What plays, where the site names it: its title over its artist, in
  // place of the page's title, and its length, position and speed for the
  // band. A live stream has no length, and no band.
  const said = now.media && typeof now.media === "object" ? now.media : null;
  const timed =
    said && Number.isFinite(said.duration) && said.duration > 0 && Number.isFinite(said.position) && Number.isFinite(said.rate);
  media = timed
    ? { duration: said.duration, position: said.position, rate: said.rate, at: Number.isFinite(said.at) ? said.at : Date.now() }
    : null;
  tab = typeof now.tab === "string" ? now.tab : "";
  pill.classList.toggle("timed", Boolean(media));
  moving = said && Number.isFinite(said.rate) ? (typeof said.playing === "boolean" ? said.playing : said.rate > 0) : null;
  showMoving();
  zone.hidden = !media;
  if (!media && scrub) endScrub(false);
  const page = typeof now.title === "string" && now.title.trim() ? now.title.trim() : "";
  const track = said && typeof said.title === "string" && said.title.trim() ? said.title.trim() : "";
  const by = said && typeof said.artist === "string" && said.artist.trim() ? said.artist.trim() : "";
  const name = track || page;
  const count = tabCount;
  badge.hidden = count < 2;
  badge.textContent = String(count);
  const what = by ? `${name} by ${by}` : name;
  const label = playing
    ? `Show Floating Browser, playing ${what || "a site"}`
    : shows === "loading"
      ? `Show Floating Browser, loading ${what || "a page"}`
      : what
        ? `Show Floating Browser, on ${what}`
        : "Show Floating Browser";
  restoreButton.setAttribute("aria-label", count > 1 ? `${label}, ${count} tabs` : label);
  tabsButton.setAttribute("aria-label", count > 1 ? `${count} Tabs` : "Tabs");
  if (run.textContent !== (name || "New Tab")) run.textContent = name || "New Tab";
  if (artistRun.textContent !== by) artistRun.textContent = by;
  artist.hidden = !by;
  tick();
  // The sound's bars come and go with the title, so the room is asked
  // again whatever changed.
  fit();
}

/** Whether it plays, as the pill shows it: the record turning or still,
 *  the play triangle where the bars stood while paused, and the button
 *  saying what a press on it does. */
function showMoving() {
  pill.classList.toggle("controls", moving !== null);
  root.classList.toggle("turning", moving === true);
  document.body.classList.toggle("paused", moving === false);
  playButton.hidden = moving === null;
  playButton.setAttribute("aria-label", moving ? "Pause" : "Play");
  hearFor();
}

// ---- The bars -----------------------------------------------------------------

// With Visualizer on in Settings — off where every Mac starts — the three bars
// follow the site's sound once Lumi hears it: what Lumi itself plays, heard
// for how loud alone (`audio-levels`, Lumi 1.73.0) — asked of the component
// as the sound starts and stopped as it stops — three bands told about eight
// times a second as `lumi:audio-levels`, eased by Lumi. With it off nothing
// is heard at all, and they dance by themselves as they always did; so they
// do until a reading with sound in it arrives, so a Mac where Lumi cannot
// hear its own sound — macOS refused, a dev run, whose sites macOS credits
// to the terminal — shows them as it always has. Never under Reduce Motion,
// where they stand still.

const bars = [...document.querySelectorAll("#sound i")];

/** The hearing's id once Lumi answered, "" while it is asked, null with
 *  none; whether one is wanted now; and whether Lumi refused it, which is
 *  not asked again until the sound has stopped and started again — each ask
 *  is the component's run and macOS's permission asked once more. */
let hearing = null;
let wanted = false;
let refused = false;

/** Whether Visualizer is on, as the look kept says — off until the look is
 *  read, so a pill whose site already plays hears nothing the person
 *  switched off before its look arrives. */
let visualizing = false;

/** The look's Visualizer, read as the look arrives and as it changes — the
 *  component's look, already held to its rules (`look_of`): on only when it
 *  says `true`. */
function visualize(said) {
  visualizing = Boolean(said && said.visualizer === true);
  hearFor();
}

function hearFor() {
  wanted =
    visualizing && !preview && !still.matches && pill.classList.contains("playing") && !pill.classList.contains("muted") && moving !== false;
  if (!wanted) refused = false;
  if (wanted && hearing === null && !refused) {
    hearing = "";
    call({ kind: "levels" })
      .then((answer) => {
        hearing = answer && typeof answer.id === "string" ? answer.id : null;
        refused = hearing === null;
        if (hearing && !wanted) stopHearing();
      })
      .catch(() => {
        hearing = null;
        refused = true;
      });
  } else if (!wanted && hearing) {
    stopHearing();
  }
}

function stopHearing() {
  hearing = null;
  heard(false);
  call({ kind: "levels-stop" }).catch(() => {});
}

/** The bars drawn from what Lumi hears, or dancing by themselves again. */
function heard(on) {
  pill.classList.toggle("heard", on);
  if (!on) for (const bar of bars) bar.style.removeProperty("--h");
}

addEventListener("lumi:audio-levels", (event) => {
  const said = event.detail ?? {};
  if (!hearing || said.id !== hearing) return;
  if (said.kind === "level" && Array.isArray(said.bands)) {
    if (!pill.classList.contains("heard") && !said.bands.some((band) => band > 0)) return;
    heard(true);
    bars.forEach((bar, at) => {
      const band = Math.min(15, Math.max(0, Number(said.bands[at]) || 0));
      bar.style.setProperty("--h", `${3 + Math.round((band / 15) * 11)}px`);
    });
  } else if (said.kind === "ended" || said.kind === "failed") {
    hearing = null;
    heard(false);
  }
});

still.addEventListener("change", hearFor);

/** The window width the pill wants now (0 before the first `draw`), the
 *  last one asked of Lumi, whether the pill has been shown at its width yet,
 *  and the lines and room `swing` last measured. */
let target = 0;
let asked = 0;
let shown = false;
let swungFor = "";

const pen = document.createElement("canvas").getContext("2d");

/** How wide `line`'s text is in its own font. */
function widthOf(line, text) {
  const style = getComputedStyle(line);
  pen.font = `${style.fontWeight} ${style.fontSize} ${style.fontFamily}`;
  return pen.measureText(text).width;
}

/** The pill as wide as its longer line needs beside its icons and the
 *  sound, from NARROWEST to WIDEST, where a longer line swings. Measured
 *  with each line's own font, not off the lines, which are as wide as the
 *  room the pill leaves them — and everything else in the pill keeps its
 *  width, so what is not the lines' is the pill less the lines, mid-move or
 *  not. */
function fit() {
  const text = Math.max(widthOf(title, run.textContent), artist.hidden ? 0 : widthOf(artist, artistRun.textContent));
  const others = pill.getBoundingClientRect().width - title.parentElement.getBoundingClientRect().width;
  target = Math.min(WIDEST, Math.max(NARROWEST, Math.ceil(others + text + 1) + 2 * INSET));
  settle();
}

/** Window and pill brought to `target` a step at a time, each on the one
 *  before having happened — a resize, the pill's move ending — and asked
 *  again by both: growing, the window first and the pill into it;
 *  shrinking, the pill first and the window after it. So the window is
 *  never narrower than the pill, which would cut it, and wider only while
 *  the pill moves. The width it opens at is taken at once. */
function settle() {
  if (!target) return;
  if (innerWidth < target) return ask();
  const width = target - 2 * INSET;
  pill.classList.toggle("instant", !shown);
  pill.style.width = `${width}px`;
  if (Math.abs(pill.getBoundingClientRect().width - width) > 0.5) return;
  if (innerWidth > target) return ask();
  shown = true;
  pill.classList.remove("instant");
  drawTime();
  const room = `${run.textContent}\n${artistRun.textContent}\n${title.clientWidth}`;
  if (room !== swungFor) {
    swungFor = room;
    swing();
  }
}

/** The window at `target` wide, asked of Lumi once a width: its answer is
 *  the resize, which `settle`s again. */
function ask() {
  if (asked === target) return;
  asked = target;
  if (preview) {
    parent.postMessage({ preview: "size", width: target }, location.origin);
    return;
  }
  fetch("/__lumi__/size", { method: "POST", body: JSON.stringify({ width: target, height: HEIGHT }) })
    .then((answer) => {
      if (!answer.ok) asked = 0;
    })
    .catch(() => {
      asked = 0;
    });
}

/** The title, too long for its room, swings to show its end and back, at
 *  SWING_SPEED with a rest at each end; one that fits stands still, and so
 *  does it under Reduce Motion, cut with an ellipsis. The artist never
 *  swings: two lines moving at once under the title read as noise (the
 *  owner's call, 2026-10-30), and an ellipsis says enough of a name. */
function swing() {
  artist.classList.remove("swinging");
  for (const line of [title]) {
    line.classList.remove("swinging");
    const over = line.scrollWidth - line.clientWidth;
    if (line.hidden || over <= 1 || still.matches) continue;
    // On the line, for its run's move and its edges' fades alike
    // (bubble.css): its last letter comes to rest at its end, which no
    // longer fades once nothing is past it.
    const travel = over / SWING_SPEED;
    line.style.setProperty("--over", `${over}px`);
    line.style.setProperty("--swing-time", `${(travel / (1 - 2 * SWING_REST)).toFixed(2)}s`);
    line.classList.add("swinging");
  }
}

still.addEventListener("change", swing);

addEventListener("lumi:message", (event) => {
  const said = event.detail;
  if (said && said.kind === "bubble") draw(said.bubble);
  if (said && said.kind === "tab-count") countTabs(said.count);
  if (said && said.kind === "look") {
    applyLook(said.look);
    visualize(said.look);
  }
  if (said && said.kind === "tabs-closed") tabsShown(false);
  if (said && said.kind === "tip") tipShown(true);
  if (said && said.kind === "tip-gone") tipShown(false);
  if (said && said.kind === "find") find();
});

// ---- Seeking -----------------------------------------------------------------

/** The share of the track under the pointer at `x`, along the run the
 *  playhead takes between the pill's two curves. */
function shareAt(x) {
  const box = pill.getBoundingClientRect();
  const span = box.width - 2 * HEAD_INSET;
  return Math.min(1, Math.max(0, (x - box.left - HEAD_INSET) / span));
}

/** Ask for the track at `share`: roughly while a drag passes over it,
 *  exactly where it is let go. */
function seekTo(share, exact) {
  if (!media || !tab) return;
  call({ kind: "seek", tab, position: share * media.duration, exact }).catch(() => {});
}

/** Lumi's tip over the knob, naming where the drag is: the time there and
 *  the length. */
function tipAt(share) {
  const box = knob.getBoundingClientRect();
  fetch("/__lumi__/tip", {
    method: "POST",
    body: JSON.stringify({
      text: `${clock(share * media.duration)} / ${clock(media.duration)}`,
      x: box.left,
      y: box.top,
      width: box.width,
      height: box.height,
    }),
  }).catch(() => {});
}

function endScrub(seek) {
  const was = scrub;
  scrub = null;
  document.body.classList.remove("scrubbing");
  fetch("/__lumi__/tip", { method: "DELETE" }).catch(() => {});
  if (!was || !media) return;
  if (seek) {
    seekTo(was.share, true);
    // Where it was let go, until the site says where it is: the band does
    // not run back for the moment that takes.
    media = { ...media, position: was.share * media.duration, at: Date.now() };
  }
  if (!zone.matches(":hover")) document.body.classList.remove("seeking");
  tick();
}

zone.addEventListener("pointerenter", () => document.body.classList.add("seeking"));
zone.addEventListener("pointerleave", () => {
  if (!scrub) document.body.classList.remove("seeking");
});

zone.addEventListener("pointerdown", (event) => {
  if (event.button !== 0 || !media) return;
  event.preventDefault();
  zone.setPointerCapture(event.pointerId);
  scrub = { pointer: event.pointerId, share: shareAt(event.clientX), sought: 0 };
  document.body.classList.add("seeking", "scrubbing");
  drawTime();
  tipAt(scrub.share);
});

zone.addEventListener("pointermove", (event) => {
  if (!scrub || event.pointerId !== scrub.pointer) return;
  scrub.share = shareAt(event.clientX);
  drawTime();
  tipAt(scrub.share);
  if (Date.now() - scrub.sought >= SEEK_EVERY) {
    scrub.sought = Date.now();
    seekTo(scrub.share, false);
  }
});

zone.addEventListener("pointerup", (event) => {
  if (scrub && event.pointerId === scrub.pointer) endScrub(true);
});
zone.addEventListener("pointercancel", () => endScrub(false));

// ---- Pausing and playing -------------------------------------------------------

/** The play button pressed: what plays paused, or played on, by the
 *  browser's page, which asks Lumi for the site. Said as which, never
 *  toggled, so a press lands as the button said whatever the site did in
 *  between. Nothing is drawn ahead of the site: the button changes when the
 *  site says it plays or not, which Lumi tells the moment it is done — a
 *  pill that guessed first was put back by the next word about the site
 *  that still said what was, and the button flickered. */
function togglePlay() {
  if (moving === null || !tab) return;
  call({ kind: "play", tab, playing: !moving }).catch(() => {});
}

// ---- The tabs, the tip and the press ------------------------------------------

/** The tabs' menu is up: asked for, and not told gone since (`tabs-closed`,
 *  however it went). */
let tabsUp = false;

/** The tip over the pill is up (`tip`, its first minimize after the Welcome
 *  tour): the pill rings while it is, and a click on the pill puts it away.
 *  A drag does not: the tip goes along with the pill (the manifest's
 *  `follow`) and is still there to be read where the pill was left. Asked
 *  as the page loads too, since the tip opens while this page is still
 *  loading, and the word sent then reaches nobody. */
let tipUp = false;

function tipShown(up) {
  tipUp = up;
  pill.classList.toggle("ring", up);
}

/** Locate the mini panel (⌃⌥⌘P, `find-pill` in lib.rs): the pill shakes
 *  and rings — its edge flashes under Reduce Motion — so the person finds
 *  it, small as it is (bubble.css, `#bubble.find`). Asked again while it
 *  runs, it starts over; done, the class goes, so the next ask runs it. */
function find() {
  pill.classList.remove("find");
  void pill.offsetWidth;
  pill.classList.add("find");
}

pill.addEventListener("animationend", (event) => {
  if (event.target !== pill || !pill.classList.contains("find")) return;
  // The last of what `find` runs: the ring's second breath, or the flash.
  if (event.animationName === "find-ring" || event.animationName === "find-flash") pill.classList.remove("find");
});

function tabsShown(up) {
  tabsUp = up;
  tabsButton.setAttribute("aria-expanded", String(up));
}

/** The signature pressed: the tabs' menu opened beside the pill, where Lumi
 *  places it — or put away, when it was up as the press began. That press
 *  took the keyboard from the menu, so Lumi has put it away or is about to,
 *  and the click leaves it away rather than opening it again. */
function toggleTabs(wasUp) {
  if (wasUp) {
    tabsShown(false);
    call({ kind: "tabs-close" }).catch(() => {});
    return;
  }
  tabsShown(true);
  call({ kind: "tabs" }).catch(() => tabsShown(false));
}

// A press that stays put is a click; one that moves past DRAG_AFTER hands
// the window to macOS to drag, and the click that may follow is not one —
// on the signature as anywhere else on the pill. Which button the press
// began on decides what the click does, and whether the menu was up then.
let held = null;

pill.addEventListener("pointerdown", (event) => {
  if (event.button !== 0) return;
  const onTabs = event.target instanceof Element && event.target.closest("#tabs") !== null;
  const onPlay = event.target instanceof Element && event.target.closest("#play") !== null;
  held = { pointer: event.pointerId, x: event.clientX, y: event.clientY, dragged: false, onTabs, onPlay, tabsWereUp: tabsUp };
  pill.setPointerCapture(event.pointerId);
});

pill.addEventListener("pointermove", (event) => {
  if (!held || held.dragged || event.pointerId !== held.pointer) return;
  if (Math.hypot(event.clientX - held.x, event.clientY - held.y) < DRAG_AFTER) return;
  held.dragged = true;
  fetch("/__lumi__/drag", { method: "POST" }).catch(() => {});
});

pill.addEventListener("pointercancel", () => {
  held = null;
});

pill.addEventListener("click", (event) => {
  const press = held;
  held = null;
  if (press && press.dragged) return;
  if (tipUp) {
    tipShown(false);
    call({ kind: "tip-close" }).catch(() => {});
  }
  // Return or Space on a button is a click with no press before it.
  const onTabs = press ? press.onTabs : event.target instanceof Element && event.target.closest("#tabs") !== null;
  if (onTabs) {
    toggleTabs(press ? press.tabsWereUp : tabsUp);
    return;
  }
  const onPlay = press ? press.onPlay : event.target instanceof Element && event.target.closest("#play") !== null;
  if (onPlay) {
    togglePlay();
    return;
  }
  // Back on the tab the pill shows — the one making sound, with Prioritize
  // Now Playing Tab on — so a press opens what it promised.
  call({ kind: "restore", tab }).catch(() => {});
});

addEventListener("resize", settle);
pill.addEventListener("transitionend", (event) => {
  if (event.target === pill && event.propertyName === "width") settle();
});

if (preview) {
  root.classList.add("preview");
  addEventListener("message", (event) => {
    if (!(event.origin === location.origin && event.source === parent && event.data)) return;
    applyLook(event.data.look);
    // Told as Settings comes to the front: a frame loaded while Settings
    // was hidden measured its lines at nothing, so they are measured again.
    fit();
  });
  // Two tabs, so Settings' preview shows the badge.
  tabCount = 2;
  draw(sample());
  parent.postMessage({ preview: "ready" }, location.origin);
} else {
  call({ kind: "look" })
    .then((look) => {
      applyLook(look);
      visualize(look);
    })
    .catch(() => {});
  call({ kind: "bubble" })
    .then(draw)
    .catch(() => draw(null));
  call({ kind: "tab-count" })
    .then((said) => countTabs(said && said.count))
    .catch(() => {});
  // Only ever up from here: an answer read before the tip opened can come
  // back after the `tip` word that opening sent, and must not undo it.
  call({ kind: "tip" })
    .then((tip) => {
      if (tip && tip.up === true) tipShown(true);
    })
    .catch(() => {});
}

/** Settings' preview: a track playing, with a cover drawn here — a warm
 *  gradient and a sun — so each shape and the tint read as they will. */
function sample() {
  const canvas = document.createElement("canvas");
  canvas.width = canvas.height = 96;
  const paint = canvas.getContext("2d");
  const sky = paint.createLinearGradient(0, 0, 96, 96);
  sky.addColorStop(0, "#f59e0b");
  sky.addColorStop(1, "#db2777");
  paint.fillStyle = sky;
  paint.fillRect(0, 0, 96, 96);
  paint.fillStyle = "rgba(253, 230, 138, 0.85)";
  paint.beginPath();
  paint.arc(60, 38, 20, 0, Math.PI * 2);
  paint.fill();
  paint.fillStyle = "rgba(124, 45, 18, 0.55)";
  paint.fillRect(0, 66, 96, 30);
  return {
    v: 1,
    title: "",
    icon: "icons/youtube.png",
    playing: true,
    muted: false,
    loading: false,
    tab: "",
    media: { duration: 213, position: 74, rate: 1, playing: true, title: "Golden Hour", artist: "Floating Browser", artwork: canvas.toDataURL("image/png"), at: Date.now() },
  };
}

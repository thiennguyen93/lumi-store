const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./highlight-BiJ1vwgy.js","./keys-CyxpcUd8.js"])))=>i.map(i=>d[i]);
import{A as e,B as t,C as n,D as r,E as i,F as a,G as o,H as s,K as c,L as l,M as u,O as d,P as f,Q as p,R as m,S as h,T as g,U as _,V as v,W as y,X as b,Y as x,Z as ee,b as te,c as S,ct as C,d as w,et as ne,g as T,h as E,it as D,j as O,k as re,l as ie,lt as k,m as ae,nt as A,q as oe,rt as j,s as se,st as M,t as ce,tt as le,v as ue,x as de,y as N,z as P}from"./keys-CyxpcUd8.js";import{_ as F,a as fe,d as I,f as pe,g as L,h as me,i as R,l as he,m as ge,n as _e,o as ve,p as ye,r as z,s as be,t as xe,u as Se,v as B,y as V}from"./search-ofP3FpOZ.js";var H=k(),Ce=M(),we=`# Changelog

## [0.69.0] - 2026-10-03

### Added

- Select text right on a copied image in the preview: press on a word and drag across the words you want, or double-click a line. **⌘C** or **Copy** copies just those words; **⎋** lets them go. A press between words still drags the image out.

### Fixed

- Images whose text was never read are read now, when the panel opens or when **Search text in images** is turned on, so every image can be found by its words. This covers images copied while that setting was off, while Lumi was quitting, or in a quick run of copies.

## [0.68.0] - 2026-10-03

### Added

- Icons beside every row of Clipboard Manager's menu in Lumi's menu bar.

### Changed

- **Pause Recording** in the menu bar reads **Resume Recording** while paused, in place of a tick.
- Needs Lumi 1.34.0.

## [0.67.0] - 2026-10-02

### Added

- Clipboard Manager in Lumi's menu bar menu: **Show Clipboard History**, **Pause Recording**, **Delete All Unpinned…** and **Settings…**.
- **Pause Recording** stops keeping what you copy until you untick it. Nothing copied while paused is recorded.
- **Delete All Unpinned…** opens the panel and deletes there, so ⌘Z still brings everything back.

### Fixed

- The preview's width and split, and what a PDF fits, are kept between openings of the panel. They were never saved before.

### Changed

- Needs Lumi 1.33.0, and declares \`menu\`, the capability its menu bar rows need. The menu shows nothing you copied.

## [0.66.1] - 2026-10-02

### Changed

- With the panel pinned and you working in another app, Show clipboard history gives it the keyboard back the moment you press it, before the selected item blinks: Clipboard Manager now asks Lumi where the panel stands instead of finding out from the panel. Needs Lumi 1.31.0.

## [0.66.0] - 2026-10-02

### Added

- Two more commands, Hide clipboard history and Toggle clipboard history, for keys of your own in Lumi's Settings. The shortcut the extension comes with stays on Show clipboard history.

### Changed

- Show clipboard history only ever brings the panel up. Pressed while the panel is already up, pinned or not, it no longer puts it away: the panel takes the keyboard back if you were working in another app, and the selected item blinks so you know you can search or move through the list. Escape, Hide or Toggle put it away.

## [0.65.1] - 2026-10-02

### Fixed

- A long copy's scroll bar no longer covers its last letters. Every scroll bar in the preview — the copy, what it expands to, the text read in an image, the list of links — now sits in one line along the right edge.

## [0.65.0] - 2026-10-02

### Added

- Drag the line across the preview up or down to give more room to either side: the picture or the text read in it, or a copy or what it expands to. The line stays where you leave it for both kinds, so it holds still as you move through the list. Double-click the line to put it back where it was.

## [0.64.0] - 2026-10-02

### Added

- With the panel pinned and you working in another app, the shortcut gives the panel the keyboard back where it stands, and the selected item now blinks to say so, so you know you can search or move through the list right away. With the ⌘K menu up, its chosen action blinks instead. Press the shortcut again to put the panel away.

## [0.63.26] - 2026-10-02

### Added

- Copy one of your snippet triggers, such as \`;addr\`, and the preview shows what it expands to: its web addresses read as plain text and turn into links under the pointer, a button copies it, and clicking its heading folds it away. A snippet that comes out the same every time is remembered with the copy. One that changes, such as a date, is expanded again each time the panel shows it.
- Settings has a new Snippets section. Match snippets switches it on or off. Look in picks the profile you're using (the default), every profile, or Selected Profiles. Once Selected Profiles is chosen, its submenu lists every profile with a search field on top, to find them by name and tick them however many you have. An open panel, pinned or not, follows at once when you switch, rename or remove a profile, change these settings or edit a snippet in Lumi, and a snippet that can change is expanded again each time you come back to it. Needs Lumi 1.31.0.

## [0.62.1] - 2026-10-01

### Fixed

- The ⌘K actions menu's search field fits inside the menu instead of running past its right edge.

## [0.62.0] - 2026-10-01

### Added

- The ⌘K actions menu highlights the letters you typed in each action it found, the way the history search does.

## [0.61.0] - 2026-10-01

### Added

- The ⌘K actions menu takes shorthand: string together the starts of an action's words, as in "delall" for "Delete all…" or "sif" for "Show in Finder". The closest match comes first, right above the search field.

## [0.60.8] - 2026-10-01

### Fixed

- Searching the ⌘K actions menu matches the start of a word: "de" finds the Delete actions, no longer "Show in Finder" for the "de" inside "Finder".

## [0.60.7] - 2026-10-01

### Changed

- The ⌘K actions menu reads from the bottom up: Paste sits right above the search field, the delete actions furthest from it. The arrow keys move the way they point.

## [0.60.6] - 2026-10-01

### Changed

- The ⌘K actions menu has its search field at the bottom, next to the ⌘K that opens it. The field stays in place while you type and the list narrows above it.

## [0.60.5] - 2026-10-01

### Fixed

- The ⌘K actions menu shows all its actions instead of cutting the last one in half. When the panel is too short for them all, the list scrolls, fades at the edge that has more, and the arrow keys keep the chosen action in view.

## [0.60.4] - 2026-10-01

### Changed

- The panel opens faster with a long history: it reads the history once, and brings items kept by older versions up to date only once.

## [0.60.3] - 2026-10-01

### Fixed

- What you copy while the panel is open, pinned or not, shows up in it straight away.

## [0.60.2] - 2026-10-01

### Changed

- A copy's links are found once, when it is copied, instead of each time its preview is shown.

## [0.60.1] - 2026-10-01

### Added

- Links in rich text can be clicked in the preview. Plain text stays plain, to select and copy; its links are listed under it.

## [0.59.0] - 2026-10-01

### Added

- Text and rich text show the links they contain under their preview, each opened in the browser with a click.

### Fixed

- Links in rich text copied from TextEdit or Pages no longer drop out of the preview.

## [0.58.3] - 2026-09-30

### Changed

- The extension's homepage is now its page on lumikeys.app.

## [0.58.2] - 2026-09-30

### Changed

- About's Docs opens this extension's page on lumikeys.app, and Store page opens the extensions list there.

## [0.58.1] - 2026-09-30

### Changed

- About's buttons stay at the bottom of the panel while the changelog scrolls above them.

## [0.58.0] - 2026-09-30

### Added

- About in the ⌘K menu: the extension's version, what's new, the full changelog, and links to the docs, the store page and the Welcome tour, right in the panel.

## [0.57.0] - 2026-09-30

### Added

- Colours written as \`rgb()\`, \`rgba()\`, \`hsl()\` or \`hsla()\` are recognised as colours.
- A copied colour's preview lists it in the other formats (hex, \`rgb()\`, \`hsl()\`) to copy from.

## [0.54.11] - 2026-09-30

### Changed

- Long lists fade at the edge while there is more to scroll.

### Fixed

- The text-recognition panel no longer collapses when it has little to show.

## [0.54.6] - 2026-09-30

### Added

- Each panel remembers how you like PDFs fitted.

## [0.54.2] - 2026-09-30

### Fixed

- ⌘Y expands the preview, so an item pinned to Y moves to another letter.

## [0.53.3] - 2026-09-30

### Added

- A zoomed view for PDF previews.

## [0.52.4] - 2026-09-30

### Changed

- Simpler wording in the Welcome tour.

## [0.52.3] - 2026-09-30

### Added

- ⌘⇧P pins the panel, so it stays open while you paste one item after another.

### Changed

- Pinning an item is ⌘P by default (it was ⌥P).

## [0.51.6] - 2026-09-30

### Changed

- File icons are easier to tell apart in light and dark mode.

## [0.51.5] - 2026-09-30

### Added

- Images in the preview can be dragged into other apps.

## [0.51.4] - 2026-09-30

### Added

- Choosing an app in Settings suggests matches as you type its name or bundle id.

## [0.51.2] - 2026-09-30

### Fixed

- Search no longer loses letter case the first time it reads the history.

## [0.51.1] - 2026-09-30

### Fixed

- Search keeps text cased as it was copied.

## [0.51.0] - 2026-09-30

### Added

- A sixth step in the Welcome tour, on privacy.

## [0.50.0] - 2026-09-30

### Changed

- Searching the text recognised in images is separate from searching what you copied.

## [0.49.1] - 2026-09-30

### Changed

- The Welcome tour has five steps.

### Fixed

- Keyboard focus in the Welcome tour.

## [0.46.15] - 2026-09-30

### Changed

- The Welcome window's example copies lumikeys.app.

## [0.46.14] - 2026-09-30

### Added

- Screenshots for the Extension Store.

## [0.46.13] - 2026-09-29

### Added

- Links in the preview can be clicked.

## [0.46.11] - 2026-09-29

### Changed

- Renamed to Clipboard Manager.
- Better search.

## [0.46.8] - 2026-09-29

### Changed

- The Welcome window is redesigned around a live preview of the panel.

## [0.46.0] - 2026-09-29

### Added

- A Welcome tour.

## [0.45.6] - 2026-09-29

### Changed

- An empty history shows an icon and a clearer layout.

## [0.45.2] - 2026-09-29

### Fixed

- Escape closes an open menu before it closes the panel.

## [0.45.1] - 2026-09-29

### Added

- A Copy path action for files.

## [0.43.0] - 2026-09-29

### Added

- Items can be dragged out of the history into other apps.

## [0.42.0] - 2026-09-29

### Added

- Copies of several files show a list of them in the preview, with highlighting.

## [0.39.0] - 2026-09-29

### Added

- JSON is previewed as a tree, and text files are previewed.

## [0.37.0] - 2026-09-29

### Added

- Previews for copied image files, with their size in pixels and on disk.

## [0.36.0] - 2026-09-29

### Added

- Previews for PDFs.

## [0.30.0] - 2026-09-29

### Added

- Copied files show an icon for their type, their path and their extension.

## [0.28.0] - 2026-09-29

### Added

- The preview shows a copied file's size.
- Each item shows the icon of the app it was copied from, with the name on hover.

## [0.26.2] - 2026-09-29

### Added

- Save image as… in the actions menu for images. Needs Lumi 1.26.0.

### Fixed

- Rich text previews no longer go blank or flash as plain text.

## [0.25.2] - 2026-09-29

### Fixed

- Text recognised in images is left out of search when reading images is off.

## [0.23.0] - 2026-09-29

### Added

- The text recognised in a copied image is shown in its preview.

## [0.22.1] - 2026-09-29

### Added

- The key used for pinning can be changed.

## [0.21.0] - 2026-09-29

### Changed

- Deleting an item takes ⌘⌥⌫, so it is not done by accident.

## [0.19.0] - 2026-09-29

### Added

- A Settings page, and a choice of how long history is kept.

## [0.15.1] - 2026-09-29

### Added

- Rich text is previewed with its formatting.

## [0.13.1] - 2026-09-29

### Changed

- The About page is now the Dashboard tab.

## [0.12.0] - 2026-09-29

### Added

- A choice of glass material for the panel.

## [0.10.0] - 2026-09-29

### Added

- A menu entry and a shortcut for Settings.

## [0.9.3] - 2026-09-29

### Added

- Text in copied images is recognised, so they can be found by what they say.
- Clear all.
- Actions for links and files.

## [0.8.0] - 2026-09-29

### Added

- Undo for deleted items, which also restores their pins.

## [0.5.2] - 2026-09-29

### Added

- First release: a history of what you copy — text, links, images and files — with a panel to search it and paste an item back.
`,Te=`# Clipboard Manager's manifest.
#
# Listed in extensions.toml, and held back by \`min-lumi-version\` alone: the
# \`clipboard-history\` and \`input\` capabilities, \`events\` and the panel \`kind\`
# all arrive with lumi:ext 0.3 in Lumi 1.25.0, and an older Lumi shows this
# as needing an update rather than installing it. 1.26.0 since Save image
# as…: \`storage.blob-save\` is a new import, and a component that imports it
# does not load on a Lumi without it at all. 1.29.0 since the panel's pin, for
# the same reason: \`ui.set-pinned\`. 1.31.0 since snippets — and Show and
# Toggle ask \`ui.window-state\`, which arrives there too. 1.33.0 for the
# menu bar rows (\`menu\`), and 1.34.0 since they wear icons:
# \`menu.set-rows\`.
[extension]
id = "dev.thiennguyen.clipboard"
name = "Clipboard Manager"
version = "0.69.0"
description = "Keep what you copy — text, links, images and files — and paste it back from a panel."
author = "Thien Nguyen"
summary = "Remembers what you copy on this Mac and brings it back with one shortcut: search, pick, and it is pasted into the app you were typing in. Text, rich text, links, colours, files and images, with pins for what you keep reaching for. Anything a password manager marks as secret is never recorded — Lumi drops it before this extension hears of it — and the history is stored encrypted with a key Lumi keeps in your Keychain. Nothing leaves your Mac: the extension has no network access."
homepage = "https://lumikeys.app/extensions/dev.thiennguyen.clipboard/"
min-lumi-version = "1.34.0"
# \`clipboard-history\`: hears each copy (the review sheet says so).
# \`clipboard\`: puts a chosen item back on the pasteboard.
# \`input\` + \`accessibility\`: pastes it into the app in front — the same
# two a Lumi flow needs to type by pasting.
# \`snippets\`: a copy that is one of your snippet triggers shows what it
# expands to — Lumi matches and expands it, as typing would. 1.31.0 for it.
capabilities = ["clipboard", "clipboard-history", "input", "accessibility", "snippets", "menu"]
# \`clipboard-ocr\`: the text Lumi reads in a copied image, a moment after the
# copy, so a screenshot can be found by what it says. Switched by the \`ocr\`
# setting below.
events = ["clipboard", "clipboard-ocr"]
# Pictures for this extension's page in Lumi's Extension Store. The store
# publishes them beside the package; Lumi's installer ignores the key.
screenshots = ["shots/1-history.png", "shots/2-welcome.png", "shots/3-settings.png"]
# The Settings tab is drawn by web/settings.html rather than from the
# [[settings]] below — which still decide what it can save.
settings-page = "settings.html"

# The panel's three commands. Show only ever brings it up — pressed while
# it is up, the panel takes the keyboard back and its selection blinks; only
# Escape, Hide or Toggle put it away. \`open\`, not \`show\`: the name the
# shortcut below and the keys people gave it already point at.
[[command]]
name = "open"
label = "Show clipboard history"
icon = "clipboard-list"

[[command]]
name = "hide"
label = "Hide clipboard history"
icon = "eye-off"

# Up: put away, pinned or not. Not up: shown, as Show does.
[[command]]
name = "toggle"
label = "Toggle clipboard history"
icon = "toggle-right"

# Show's key — Hide and Toggle come with none, for the person to give them
# in Lumi's Settings. Maccy's key, as the extension's own: Lumi arms it at
# install when nothing holds it, in every profile, and it goes with the
# extension. When something
# does hold it Lumi arms nothing and says who — the Welcome window's second
# step reads that and asks. Replaces the \`suggested-key\` this command had,
# which was a row proposed to the person rather than a key of its own.
[[shortcut]]
command = "open"
key = "cmd+shift+c"

# The six-step tour \`on_lifecycle\` opens when the extension is installed
# or updated: what it keeps, how it is kept private, its shortcut (armed,
# or not — and then what to do), the keys inside the panel, the preview,
# and dragging out. An ordinary declared window: the
# declaration is the grant, and the review sheet lists it.
[[window]]
name = "welcome"
title = "Welcome to Clipboard Manager"
path = "welcome.html"
width = 560
height = 460
resizable = false
maximizable = false

# The panel: borderless, floats over whatever is in front without taking
# it out of front, and takes the keyboard so the search field can be typed
# in (Vietnamese input methods included). Closes as soon as it loses the
# keyboard.
[[window]]
name = "history"
title = "Clipboard Manager"
path = "panel.html"
kind = "panel"
position = "cursor"
# macOS's popover glass behind the page — the blur Spotlight uses, light or
# dark with the system. The page leaves its background clear for it.
material = "popover"
width = 620
height = 430

# The first tab of the extension's page in Lumi: live counts from the
# history, asked of \`run-ui\` as the \`:page:dashboard\` window and pushed to
# it with \`ui.post\` after each copy, pin or delete.
[[page]]
name = "dashboard"
label = "Dashboard"
path = "dashboard.html"

# How long an unpinned row is kept after it was last copied. Pins stay.
[[settings]]
name = "keep"
label = "Keep history for"
kind = "select"
default = "3mo"

[[settings.options]]
value = "5m"
label = "5 minutes"

[[settings.options]]
value = "1h"
label = "1 hour"

[[settings.options]]
value = "1d"
label = "1 day"

[[settings.options]]
value = "1w"
label = "1 week"

[[settings.options]]
value = "1mo"
label = "1 month"

[[settings.options]]
value = "3mo"
label = "3 months"

[[settings]]
name = "pasteOnSelect"
label = "Paste the item you pick"
kind = "bool"
default = "true"

# A drag out of the panel leaves it up by default, so several items can be
# dragged out one after another.
[[settings]]
name = "closeAfterDrag"
label = "Close the panel after dragging an item out"
kind = "bool"
default = "false"

# Lumi reads for this extension only while this is on: a second or two of
# CPU per image copied.
[[settings]]
name = "ocr"
label = "Search text in images"
kind = "bool"
default = "true"

# The panel's own Pin key, while the panel is up — not a global shortcut.
# Spelled "cmd+p", "ctrl+shift+1"; the Settings tab records it. ⌘P because
# no row is ever given ⌘P (\`history::PIN_LETTERS\`), and ⌘⇧P pins the panel.
[[settings]]
name = "pinKey"
label = "Pin shortcut"
kind = "text"
default = "cmd+p"

# How the panel's search reads a query — Maccy's four modes.
[[settings]]
name = "search"
label = "Search"
kind = "segmented"
default = "mixed"

[[settings.options]]
value = "exact"
label = "Exact"

[[settings.options]]
value = "fuzzy"
label = "Fuzzy"

[[settings.options]]
value = "regexp"
label = "Regex"

[[settings.options]]
value = "mixed"
label = "Mixed"

[[settings]]
name = "sort"
label = "Order"
kind = "segmented"
default = "last"

[[settings.options]]
value = "last"
label = "Last copied"

[[settings.options]]
value = "first"
label = "First copied"

[[settings.options]]
value = "used"
label = "Most used"

# The panel's glass — macOS's own materials. The manifest's \`material\`
# above is only the default; the panel is opened on this one.
[[settings]]
name = "appearance"
label = "Appearance"
kind = "segmented"
default = "popover"

[[settings.options]]
value = "popover"
label = "Glass"

[[settings.options]]
value = "hud"
label = "Dark glass"

[[settings.options]]
value = "sidebar"
label = "Frosted"

# Light or dark for the panel; "system" follows macOS. Dark glass is dark
# whatever this says.
[[settings]]
name = "theme"
label = "Theme"
kind = "segmented"
default = "system"

[[settings.options]]
value = "dark"
label = "Dark"

[[settings.options]]
value = "light"
label = "Light"

[[settings.options]]
value = "system"
label = "System"

# One bundle id per line, e.g. com.apple.keychainaccess. Copies made while
# one of these is in front are not kept.
[[settings]]
name = "ignoreApps"
label = "Never keep copies from"
kind = "textarea"
default = ""

# One regular expression per line; a copy whose text matches is not kept.
[[settings]]
name = "ignorePatterns"
label = "Never keep text matching"
kind = "textarea"
default = ""

# Whether a copy that is one of your snippet triggers shows what it
# expands to, in the preview's "Expands to".
[[settings]]
name = "matchSnippets"
label = "Match snippets"
kind = "bool"
default = "true"

# Whose snippets it looks in, while that is on: the live profile's, every
# profile's, or the ones ticked under Selected Profiles (\`snippetProfiles\`).
[[settings]]
name = "snippetsIn"
label = "Look in"
kind = "segmented"
default = "current"

[[settings.options]]
value = "current"
label = "Current Profile"

[[settings.options]]
value = "all"
label = "All Profiles"

[[settings.options]]
value = "selected"
label = "Selected Profiles"

# The profiles Selected Profiles looks in: their ids, joined by commas.
# Ticked in the Look in menu on the Settings tab, found by name.
[[settings]]
name = "snippetProfiles"
label = "Profiles to match"
kind = "text"
default = ""
`,U=/^## \[([^\]]+)\](?:\s*-\s*(\S+))?/;function Ee(e){let t=[];for(let n of e.split(/\r?\n/)){let e=U.exec(n);if(e){t.push({version:e[1],date:e[2]??``,groups:[]});continue}let r=t.at(-1);if(r){if(n.startsWith(`### `))r.groups.push({title:n.slice(4).trim(),notes:[]});else if(/^[-*] /.test(n))r.groups.length||r.groups.push({title:``,notes:[]}),r.groups.at(-1).notes.push(n.slice(2).trim());else if(/^\s+\S/.test(n)){let e=r.groups.at(-1)?.notes;e?.length&&(e[e.length-1]+=` ${n.trim()}`)}}}return t}function De(e){return e.split("`")}function W(e){let t=t=>RegExp(`^${t}\\s*=\\s*"([^"]*)"`,`m`).exec(e)?.[1]??``;return{id:t(`id`),name:t(`name`),version:t(`version`),author:t(`author`),description:t(`description`)}}var G=p(),K=W(Te),q=Ee(we);function Oe({onLink:t}){let[n,r]=(0,H.useState)(!1),i=n?q:q.slice(0,1);return(0,G.jsxs)(`section`,{className:`about`,"aria-label":`About ${K.name}`,children:[(0,G.jsxs)(`div`,{className:`about-body`,children:[(0,G.jsxs)(`header`,{className:`about-head`,children:[(0,G.jsx)(h,{}),(0,G.jsxs)(`div`,{className:`about-title`,children:[(0,G.jsx)(`h1`,{children:K.name}),(0,G.jsxs)(`p`,{children:[`Version `,K.version,` · by `,K.author]}),(0,G.jsx)(`p`,{className:`about-id`,children:K.id})]})]}),(0,G.jsx)(`p`,{className:`about-lede`,children:K.description}),(0,G.jsx)(`div`,{className:`about-log`,children:i.map((e,t)=>(0,G.jsx)(ke,{release:e,newest:t===0},e.version))})]}),(0,G.jsxs)(`nav`,{className:`about-links`,"aria-label":`More`,children:[q.length>1&&(0,G.jsxs)(`button`,{type:`button`,onMouseDown:e=>e.preventDefault(),onClick:()=>r(!n),children:[(0,G.jsx)(e,{}),n?`Latest changes only`:`Full changelog`]}),(0,G.jsxs)(`button`,{type:`button`,onMouseDown:e=>e.preventDefault(),onClick:()=>t(`openDocs`),children:[(0,G.jsx)(w,{}),`Docs`]}),(0,G.jsxs)(`button`,{type:`button`,onMouseDown:e=>e.preventDefault(),onClick:()=>t(`openStore`),children:[(0,G.jsx)(x,{}),`Store page`]}),(0,G.jsxs)(`button`,{type:`button`,onMouseDown:e=>e.preventDefault(),onClick:()=>t(`tour`),children:[(0,G.jsx)(f,{}),`Welcome tour`]})]})]})}function ke({release:e,newest:t}){return(0,G.jsxs)(`article`,{className:`about-release`,children:[(0,G.jsxs)(`h2`,{children:[t?`What's new in ${e.version}`:e.version,!t&&e.date&&(0,G.jsx)(`span`,{className:`about-date`,children:e.date})]}),e.groups.map((t,n)=>(0,G.jsxs)(`div`,{children:[t.title&&e.groups.length>1&&(0,G.jsx)(`h3`,{children:t.title}),(0,G.jsx)(`ul`,{children:t.notes.map((e,t)=>(0,G.jsx)(`li`,{children:De(e).map((e,t)=>t%2?(0,G.jsx)(`code`,{children:e},t):e)},t))})]},n))]})}var J=1;function Ae(e){(0,H.useEffect)(()=>{let t=e.current;if(!t)return;let n=()=>{t.toggleAttribute(`data-above`,t.scrollTop>J),t.toggleAttribute(`data-below`,t.scrollHeight-t.clientHeight-t.scrollTop>J)};n(),t.addEventListener(`scroll`,n,{passive:!0});let r=new ResizeObserver(n);r.observe(t);let i=new MutationObserver(n);return i.observe(t,{childList:!0,subtree:!0}),()=>{t.removeEventListener(`scroll`,n),r.disconnect(),i.disconnect()}},[e])}var Y=4;function je(e){let t=(0,H.useRef)(null),n=(0,H.useRef)(e);return n.current=e,(0,H.useEffect)(()=>{let e=()=>t.current=null;return window.addEventListener(`blur`,e),()=>window.removeEventListener(`blur`,e)},[]),{onPointerDown(e){let n=e.target instanceof Element&&e.target.closest(`button`);t.current=e.button===0&&!n?{x:e.clientX,y:e.clientY,started:!1}:null},onPointerMove(e){let r=t.current;if(r&&!r.started){if(!(e.buttons&1)){t.current=null;return}Math.hypot(e.clientX-r.x,e.clientY-r.y)>=Y&&(r.started=!0,n.current())}},onClickCapture(e){t.current?.started&&(e.preventDefault(),e.stopPropagation()),t.current=null}}}var Me=new Map(Object.entries({pdf:`pdf`,doc:`doc docx pages rtf txt md markdown odt log`,sheet:`xls xlsx numbers csv tsv ods`,slides:`ppt pptx key odp`,code:`html htm css js jsx ts tsx json xml yaml yml toml rs py rb go java kt swift c cc cpp h hpp cs php sh zsh sql lua vue svelte`,audio:`mp3 m4a aac wav aiff aif flac ogg opus wma`,video:`mp4 m4v mov avi mkv webm wmv flv mpg mpeg`,image:`png jpg jpeg gif webp heic heif tiff tif bmp svg ico raw psd`,archive:`zip rar 7z tar gz tgz bz2 xz dmg iso pkg`}).flatMap(([e,t])=>t.split(` `).map(t=>[t,e])));function X(e){return e?e===`/`?`folder`:Me.get(e)??`file`:`file`}var Ne=new Set(`txt md markdown log csv tsv ini cfg conf html htm css js mjs cjs jsx ts tsx json xml yaml yml toml rs py rb go java kt swift c cc cpp h hpp cs php sh zsh bash fish sql lua vue svelte graphql proto dart scala ex exs zig`.split(` `));function Pe(e){return!!e&&Ne.has(e)}var Fe={ts:`typescript`,tsx:`typescript`,js:`javascript`,jsx:`javascript`,mjs:`javascript`,cjs:`javascript`,go:`go`,rs:`rust`,py:`python`,rb:`ruby`,java:`java`,kt:`kotlin`,swift:`swift`,c:`c`,h:`c`,cc:`cpp`,cpp:`cpp`,hpp:`cpp`,cs:`csharp`,php:`php`,sh:`bash`,zsh:`bash`,bash:`bash`,fish:`bash`,sql:`sql`,lua:`lua`,css:`css`,html:`xml`,htm:`xml`,xml:`xml`,vue:`xml`,svelte:`xml`,json:`json`,yaml:`yaml`,yml:`yaml`,toml:`ini`,ini:`ini`,cfg:`ini`,conf:`ini`,graphql:`graphql`,proto:`protobuf`,dart:`dart`,scala:`scala`,ex:`elixir`,exs:`elixir`,md:`markdown`,markdown:`markdown`};function Ie(e){return e&&Fe[e]||null}var Le=new Set;function Re({app:e,name:t,withName:n=!1}){let[r,i]=(0,H.useState)(!1),a=t||e;return a?!e||r||Le.has(e)?n?(0,G.jsx)(G.Fragment,{children:a}):(0,G.jsx)(`span`,{className:`app`,children:a}):(0,G.jsxs)(G.Fragment,{children:[(0,G.jsx)(`img`,{className:`app-icon`,src:ne(e),alt:n?``:a,title:n?void 0:a,onError:()=>{Le.add(e),i(!0)}}),n&&a]}):null}function ze(e){return/^(#|rgba?\(|hsla?\()/i.test(e)&&CSS.supports(`color`,e)}function Z(e){return{"--paint":e}}var Be={text:`Text`,link:`Link`,color:`Colour`,rich:`Rich text`,file:`File`,image:`Image`};function Ve({row:e}){return e.kind===`color`&&ze(e.title)?(0,G.jsx)(`span`,{className:`lead`,children:(0,G.jsx)(`span`,{className:`swatch painted`,style:Z(e.title)})}):e.kind===`image`&&e.thumb?(0,G.jsx)(`span`,{className:`lead thumb`,children:(0,G.jsx)(`img`,{alt:``,src:le(e.thumb)})}):e.kind===`file`?(0,G.jsx)(`span`,{className:`lead`,children:(0,G.jsx)(g,{family:X(e.fileExt),many:(e.fileCount??0)>1})}):(0,G.jsx)(`span`,{className:`lead`,children:(0,G.jsx)(a,{kind:e.kind})})}function He({text:e,marks:t}){if(!t.length)return(0,G.jsx)(G.Fragment,{children:e});let n=[],r=0;for(let[i,a]of t)i>r&&n.push(e.slice(r,i)),n.push((0,G.jsx)(`mark`,{children:e.slice(i,a)},i)),r=a;return r<e.length&&n.push(e.slice(r)),(0,G.jsx)(G.Fragment,{children:n})}var Q=null;function Ue(e){return Q??=document.createElement(`canvas`).getContext(`2d`),Q?(Q.font=getComputedStyle(e).font,Q.measureText(`…`).width):12}function We(e,t){let n=[],r=document.createTreeWalker(e,NodeFilter.SHOW_TEXT);for(let e=r.nextNode();e;e=r.nextNode())n.push(e);let i=n.reduce((e,t)=>e+t.data.length,0),a=document.createRange(),o=e=>{let r=e;for(let e of n){if(r<=e.data.length)return a.setStart(n[0],0),a.setEnd(e,r),a.getBoundingClientRect().right<=t;r-=e.data.length}return!0},s=0,c=i;for(;s<c;){let e=s+c+1>>1;o(e)?s=e:c=e-1}return s}function Ge(e){let t=(0,H.useRef)(null),[n,r]=(0,H.useState)(0),[i,a]=(0,H.useState)(null),[o,s]=(0,H.useState)(0);(0,H.useLayoutEffect)(()=>{r(0),a(null)},[e.text,o]),(0,H.useLayoutEffect)(()=>{let e=t.current;if(!e)return;let n=new ResizeObserver(()=>s(e.clientWidth));return n.observe(e),()=>n.disconnect()},[]);let c=F(e,n),l=i===null?c:ve(c,i);return(0,H.useLayoutEffect)(()=>{let o=t.current;if(!o||!e.marks.length||i!==null)return;let s=o.scrollWidth>o.clientWidth,l=o.getBoundingClientRect().right-(s?Ue(o):0),u=o.querySelectorAll(`mark`),d=u[Math.min(I(c),u.length)-1];if(d&&d.getBoundingClientRect().right>l+.5){let t=pe(e,n);if(t!==null){r(t);return}}s&&a(We(o,l+.5))}),{title:t,shown:l}}function Ke({row:e,index:t,selected:n,shortcut:r,found:i,popped:a,onPick:o,onPaste:s}){let{title:c,shown:l}=Ge(i),u=je(()=>{o(t),A({kind:`drag`,id:e.id}).catch(()=>{})});return(0,G.jsxs)(`div`,{id:`row-${t}`,"data-id":e.id,className:`row`,role:`option`,"aria-selected":n,onMouseDown:e=>e.preventDefault(),onClick:()=>o(t),onDoubleClick:e=>s(e.altKey),...u,children:[(0,G.jsx)(`span`,{className:[`cap`,e.pin?`pin`:``,r?``:`blank`].filter(Boolean).join(` `),children:r?`⌘${r.toUpperCase()}`:``}),(0,G.jsx)(Ve,{row:e}),(0,G.jsx)(`span`,{className:`title`,ref:c,children:l.text?(0,G.jsx)(He,{text:l.text,marks:l.marks}):Be[e.kind]}),i.note&&(0,G.jsx)(`span`,{className:`found-in`,children:i.note}),!e.pin&&(e.app||e.appName)&&(0,G.jsxs)(G.Fragment,{children:[(0,G.jsx)(Re,{app:e.app,name:e.appName}),(0,G.jsx)(`span`,{className:`dot`,"aria-hidden":`true`,children:`·`})]}),e.pin?(0,G.jsx)(`span`,{className:a?`when pop`:`when`,"aria-label":`Pinned`,children:(0,G.jsx)(v,{})}):(0,G.jsx)(`span`,{className:`when`,children:L(e.last)})]})}function qe({actions:e,onClose:t}){let[n,r]=(0,H.useState)(``),[i,a]=(0,H.useState)(0),[o,s]=(0,H.useState)(null),c=(0,H.useRef)(null),l=(0,H.useRef)(null),u=(0,H.useRef)(null);Ae(u);let d=(0,H.useMemo)(()=>{let t=fe(e,e=>e.label,n);return[...t.filter(e=>!e.danger),...t.filter(e=>e.danger)]},[e,n]),f=d[Math.min(i,d.length-1)];(0,H.useEffect)(()=>c.current?.focus(),[]),(0,H.useLayoutEffect)(()=>{let e=u.current;e&&(e.scrollTop=e.scrollHeight)},[n]),(0,H.useEffect)(()=>{let e=e=>{let n=e.target;l.current?.contains(n)||n?.closest(`[data-menu-toggle]`)||t()};return document.addEventListener(`pointerdown`,e,!0),window.addEventListener(`blur`,t),()=>{document.removeEventListener(`pointerdown`,e,!0),window.removeEventListener(`blur`,t)}},[t]),(0,H.useEffect)(()=>{o&&f?.id!==o&&s(null)},[o,f]);let p=e=>{let t=Math.max(0,Math.min(d.length-1,Math.min(i,d.length-1)+e)),n=d[t];n&&(a(t),document.getElementById(`action-${n.id}`)?.scrollIntoView({block:`nearest`}))},m=e=>{if(e){if(e.confirm&&o!==e.id){s(e.id);return}t(),e.run()}},h=e=>{if(e.stopPropagation(),e.nativeEvent.isComposing||e.keyCode===229)return;let n=e.key;if(n===`ArrowUp`)p(1);else if(n===`ArrowDown`)p(-1);else if(n===`Enter`)m(f);else if(n===`Escape`&&o)s(null);else if(n===`Escape`||e.metaKey&&n.toLowerCase()===`k`)t();else return;e.preventDefault()},g=d.findIndex(e=>e.danger);return(0,G.jsxs)(`div`,{ref:l,className:`menu`,role:`dialog`,"aria-label":`Actions`,children:[(0,G.jsxs)(`div`,{ref:u,id:`menu-list`,className:`menu-list`,role:`listbox`,"aria-label":`Actions`,children:[!d.length&&(0,G.jsx)(`div`,{className:`menu-empty`,children:`No action by that name`}),d.map((e,t)=>[(0,G.jsxs)(`div`,{id:`action-${e.id}`,role:`option`,"aria-selected":e===f,className:[`menu-item`,e.danger?`danger`:``,o===e.id?`armed`:``].filter(Boolean).join(` `),onMouseDown:e=>e.preventDefault(),onMouseMove:()=>a(t),onClick:()=>m(e),children:[e.glyph,(0,G.jsx)(`span`,{className:`menu-label`,children:o===e.id?e.confirm:(0,G.jsx)(He,{text:e.label,marks:B(e.label,n)?.marks??[]})}),e.keys&&o!==e.id&&(0,G.jsx)(`kbd`,{className:`cap quiet`,children:e.keys})]},e.id),t===g&&t>0?(0,G.jsx)(`div`,{className:`menu-line`,role:`separator`},`line`):null]).reverse()]}),(0,G.jsx)(`input`,{ref:c,className:`menu-filter`,value:n,onChange:e=>{r(e.target.value),a(0)},onKeyDown:h,placeholder:`Search actions`,autoComplete:`off`,spellCheck:!1,"aria-label":`Search actions`,"aria-controls":`menu-list`,"aria-activedescendant":f?`action-${f.id}`:void 0})]})}var Je=240,Ye=170,Xe=600,Ze=`cubic-bezier(.2, .8, .2, 1)`;function Qe(){return!window.matchMedia(`(prefers-reduced-motion: reduce)`).matches}function $e(e){return e?Array.from(e.querySelectorAll(`.row[data-id]`)):[]}function et(e){let t=new Map;for(let n of $e(e))t.set(n.dataset.id??``,n.getBoundingClientRect().top);return t}function tt(e,t){for(let n of $e(e)){let e=t.get(n.dataset.id??``);if(e===void 0){n.animate([{opacity:0,height:`0px`,transform:`translateX(-16px)`},{opacity:1,height:`${n.offsetHeight}px`,transform:`none`}],{duration:Je,easing:Ze});continue}let r=e-n.getBoundingClientRect().top;Math.abs(r)<1||n.animate([{transform:`translateY(${r}px)`},{transform:`none`}],{duration:Je,easing:Ze})}}async function nt(e,t=0){if(!e||!Qe())return()=>{};let n=e.animate([{opacity:1,height:`${e.offsetHeight}px`,transform:`none`},{opacity:0,height:`0px`,transform:`translateX(-16px)`}],{duration:Ye,delay:t,easing:`ease-in`,fill:`forwards`});return await n.finished.catch(()=>{}),()=>n.cancel()}function rt(e){if(!e)return;for(let t of e.getAnimations())t.id===`hail`&&t.cancel();let t=e.getAttribute(`aria-selected`)===`true`,n=t?`rgba(255, 255, 255, 0.8)`:getComputedStyle(e).getPropertyValue(`--cb-accent`).trim()||`#378add`,r={boxShadow:`inset 0 0 0 2px transparent`,easing:`ease-in-out`},i={boxShadow:`inset 0 0 0 2px ${n}`,easing:`ease-in-out`};if(e.animate([r,{...i,offset:.2},{...r,offset:.5},{...i,offset:.7},r],{duration:Xe,id:`hail`}),!t||!Qe())return;let a=1+Math.min(.025,8/Math.max(e.offsetWidth,1));e.animate([{transform:`none`,easing:Ze},{transform:`scale(${a})`,offset:.4,easing:`ease-in-out`},{transform:`none`}],{duration:Xe/2,id:`hail`})}async function it(e){let t=e.length>1?Math.min(18,240/e.length):0,n=await Promise.all(e.map((e,n)=>nt(e,n*t)));return()=>n.forEach(e=>e())}function at(e){let t=e.replace(/^https?:\/\//i,``);/^[^/?#]+\/$/.test(t)&&(t=t.slice(0,-1));try{t=decodeURI(t)}catch{}return t}function ot(e,t){if(!e)return;let n=e.replace(/[\t\n\r]/g,``).trim();return t.find(e=>e.url===n)}function st(e,t){let n=[];for(let{url:e}of t)n.push({text:e,url:e}),/^https:\/\/www\./i.test(e)&&n.push({text:e.slice(8),url:e});if(!n.length||!e)return[e];let r=[],i=0,a=0;for(;a<e.length;){let t=null;for(let r of n){let n=e.indexOf(r.text,a);for(;n>=0&&ct(e,n);)n=e.indexOf(r.text,n+1);n<0||(!t||n<t.start||n===t.start&&r.text.length>t.text.length)&&(t={start:n,...r})}if(!t)break;t.start>i&&r.push(e.slice(i,t.start)),r.push({text:t.text,url:t.url}),i=a=t.start+t.text.length}return i<e.length&&r.push(e.slice(i)),r}function ct(e,t){let n=e[t-1];return n!==void 0&&/[\p{L}\p{N}.@/\-_+]/u.test(n)}function lt({links:e,count:t,onOpen:r}){let i=(0,H.useRef)(null);Ae(i);let o=`${t} ${t===1?`link`:`links`}`;return(0,G.jsxs)(`section`,{className:`links`,"aria-label":o,children:[(0,G.jsx)(`header`,{className:`links-head`,children:t>e.length?`First ${e.length} of ${o}`:o}),(0,G.jsx)(`ul`,{ref:i,children:e.map(e=>(0,G.jsx)(`li`,{children:(0,G.jsxs)(`button`,{type:`button`,className:`link-line`,title:e.url,"aria-label":`Open ${e.text??at(e.url)} in the browser`,onMouseDown:e=>e.preventDefault(),onClick:()=>r(e.url),children:[(0,G.jsx)(a,{kind:`link`}),(0,G.jsxs)(`span`,{className:`link-text`,children:[e.text&&(0,G.jsx)(`span`,{className:`link-words`,children:e.text}),(0,G.jsx)(`span`,{className:`link-address`,children:at(e.url)})]}),(0,G.jsx)(n,{})]})},e.url))})]})}function ut(e,t){return{className:`link live`,role:`link`,tabIndex:-1,title:e,onClick:()=>{window.getSelection()?.isCollapsed!==!1&&t(e)}}}function dt(e,t,n){if(!n||!t.length)return e;let r=st(e,t);return r.length===1&&typeof r[0]==`string`?e:(0,H.createElement)(H.Fragment,null,...r.map((e,t)=>typeof e==`string`?e:(0,H.createElement)(`span`,{key:t,...ut(e.url,n)},e.text)))}function ft({expansions:e,grip:t,onCopy:n,onOpen:r}){let i=(0,H.useRef)(null);Ae(i);let[a,s]=(0,H.useState)(new Set),c=e=>s(t=>{let n=new Set(t);return n.delete(e)||n.add(e),n}),{mixed:l}=pt(e);return(0,G.jsxs)(`section`,{className:`snippet`,"aria-label":`Expands to`,children:[t,(0,G.jsx)(`div`,{ref:i,className:`snippet-scroll`,children:e.map((e,t)=>(0,G.jsxs)(`div`,{className:`expansion`,children:[(0,G.jsxs)(`header`,{className:`snippet-head`,children:[(0,G.jsxs)(`button`,{type:`button`,className:`snippet-toggle`,"aria-expanded":!a.has(t),"aria-controls":`expansion-${t}`,title:a.has(t)?`Show what it expands to`:`Fold it away`,onMouseDown:e=>e.preventDefault(),onClick:()=>c(t),children:[(0,G.jsx)(E,{}),(0,G.jsxs)(`span`,{className:`snippet-from`,children:[`Expands to`,e.profiles.length?` · ${e.profiles.join(`, `)}`:``]}),l&&e.dynamic&&(0,G.jsx)(`span`,{className:`snippet-mark`,title:`May change each time it's shown`,"aria-label":`May change`,children:(0,G.jsx)(o,{})})]}),n&&(0,G.jsx)(`button`,{type:`button`,className:`bare`,title:`Copy`,"aria-label":`Copy what it expands to`,onMouseDown:e=>e.preventDefault(),onClick:()=>n(e.text),children:(0,G.jsx)(N,{})})]}),!a.has(t)&&(0,G.jsx)(`div`,{id:`expansion-${t}`,className:`body snippet-text`,children:dt(e.text,e.links,r)})]},t))}),(0,G.jsx)(mt,{expansions:e})]})}function pt(e){let t=e.filter(e=>e.dynamic).length;return{count:t,mixed:t>0&&t<e.length}}function mt({expansions:e}){let{count:t,mixed:n}=pt(e);return t?(0,G.jsxs)(`p`,{className:`snippet-fresh`,children:[n&&(0,G.jsx)(o,{}),t>1?`May change each time they're shown`:`May change each time it's shown`]}):null}function ht(e,{from:t,to:n}){let[r,i]=gt(t,n)?[t,n]:[n,t];return!gt(e,r)&&!gt(i,e)}function gt(e,t){return e[0]<t[0]||e[0]===t[0]&&e[1]<t[1]}function _t(e,t){let n=0;return e.lines.forEach((e,r)=>{let i=Math.max(1,e.words.length);for(let e=0;e<i;e++)ht([r,e],t)&&n++}),n}function vt({layout:e,picture:t,picked:n,onPick:r}){let[i,a]=(0,H.useState)(null),[o,s]=(0,H.useState)(null);if((0,H.useLayoutEffect)(()=>{let e=t.current;if(!e)return;let n=()=>e.offsetWidth&&e.offsetHeight?a({left:e.offsetLeft,top:e.offsetTop,width:e.offsetWidth,height:e.offsetHeight}):a(null);n();let r=new ResizeObserver(n);return r.observe(e),e.addEventListener(`load`,n),()=>{r.disconnect(),e.removeEventListener(`load`,n)}},[t]),(0,H.useEffect)(()=>{if(!o)return;let e=()=>s(null);return window.addEventListener(`pointerup`,e),window.addEventListener(`blur`,e),()=>{window.removeEventListener(`pointerup`,e),window.removeEventListener(`blur`,e)}},[o]),!i||!e.width||!e.height)return null;let c=([t,n,r,i])=>({left:`${t/e.width*100}%`,top:`${n/e.height*100}%`,width:`${r/e.width*100}%`,height:`${i/e.height*100}%`}),l=e=>t=>{t.button===0&&(t.stopPropagation(),t.preventDefault(),t.shiftKey&&n?r({from:n.from,to:e}):r({from:e,to:e}),s(t.shiftKey&&n?n.from:e))},u=e=>t=>{o&&t.buttons&1&&r({from:o,to:e})};return(0,G.jsx)(`div`,{className:`image-text`,style:i,"aria-hidden":`true`,children:e.lines.flatMap((e,t)=>{let i=e.words.length?e.words:[{text:e.text,frame:e.frame}];return i.map((e,a)=>{let o=[t,a],s=n?ht(o,n):!1;return(0,G.jsx)(`span`,{className:s?`word on`:`word`,style:c(e.frame),onPointerDown:l(o),onPointerEnter:u(o),onDoubleClick:()=>r({from:[t,0],to:[t,i.length-1]})},`${t}.${a}`)})})})}var yt=`pdfFit`,bt={pane:`height`,zoomed:`width`},xt=e=>e===`width`||e===`height`;function St(e){let t=e??{};return{pane:xt(t.pane)?t.pane:bt.pane,zoomed:xt(t.zoomed)?t.zoomed:bt.zoomed}}function Ct(){try{return St(JSON.parse(localStorage.getItem(yt)??`null`))}catch{return bt}}function wt(){try{localStorage.setItem(yt,JSON.stringify(Tt))}catch{}}var Tt=Ct();function Et(e){return e?Tt.zoomed:Tt.pane}function Dt(e){Tt=St(e),wt()}function Ot(e,t){Tt={...Tt,[e?`zoomed`:`pane`]:t},wt(),A({kind:`pdfFit`,zoomed:e,fit:t}).catch(()=>{})}var kt=(function(){let e=typeof document<`u`&&document.createElement(`link`).relList;return e&&e.supports&&e.supports(`modulepreload`)?`modulepreload`:`preload`})(),At=function(e,t){return new URL(e,t).href},jt={},Mt=function(e,t,n){let r=Promise.resolve();if(t&&t.length>0){let e=document.getElementsByTagName(`link`),i=document.querySelector(`meta[property=csp-nonce]`),a=i?.nonce||i?.getAttribute(`nonce`);function o(e){return Promise.all(e.map(e=>Promise.resolve(e).then(e=>({status:`fulfilled`,value:e}),e=>({status:`rejected`,reason:e}))))}function s(e){return import.meta.resolve?import.meta.resolve(e):new URL(e,import.meta.url).href}r=o(t.map(t=>{if(t=At(t,n),t=s(t),t in jt)return;jt[t]=!0;let r=t.endsWith(`.css`);for(let n=e.length-1;n>=0;n--){let i=e[n];if(i.href===t&&(!r||i.rel===`stylesheet`))return}let i=document.createElement(`link`);if(i.rel=r?`stylesheet`:kt,r||(i.as=`script`),i.crossOrigin=``,i.href=t,a&&i.setAttribute(`nonce`,a),document.head.appendChild(i),r)return new Promise((e,n)=>{i.addEventListener(`load`,e),i.addEventListener(`error`,()=>n(Error(`Unable to preload CSS for ${t}`)))})}).filter(e=>e!==void 0))}function i(e){let t=new Event(`vite:preloadError`,{cancelable:!0});if(t.payload=e,window.dispatchEvent(t),!t.defaultPrevented)throw e}return r.then(t=>{for(let e of t||[])e.status===`rejected`&&i(e.reason);return e().catch(i)})},Nt=[1,1.5,2,3];function Pt(e,t,n,r){let i=t===`height`&&n.height>0?Math.min(n.width,n.height/e):n.width,a=Math.floor(i*r);return{width:a,height:Math.floor(a*e)}}var Ft=16e6,It=null;function Lt(){return It??=Promise.all([Mt(()=>import(`./pdf-CKCo85IH.js`),[],import.meta.url),Mt(()=>import(`./pdf.worker-BkZ2vcTL.js`),[],import.meta.url),Mt(()=>import(`./pdfFonts-BQcGIil6.js`),[],import.meta.url)]).then(([e,{default:t},{ShippedFonts:n}])=>(e.GlobalWorkerOptions.workerPort=new t,{lib:e,fonts:n})),It.catch(()=>It=null),It}var Rt=Promise.resolve();function zt({src:e,name:t,onFail:n,flow:a=!1}){let o=(0,H.useRef)(null),s=(0,H.useRef)(null),[c,l]=(0,H.useState)(null),[u,d]=(0,H.useState)(1),[f,p]=(0,H.useState)(0),[h,g]=(0,H.useState)(0),[_,v]=(0,H.useState)(0),[b,x]=(0,H.useState)(()=>Et(a));(0,H.useEffect)(()=>x(Et(a)),[a]);let ee=e=>{x(e),Ot(a,e)},te=(0,H.useRef)(n);te.current=n,(0,H.useEffect)(()=>{let t=!0,n=null;return(async()=>{try{let{lib:r,fonts:i}=await Lt();if(await Rt,!t)return;n=r.getDocument({url:e,useWasm:!1,disableFontFace:!0,useSystemFonts:!1,standardFontDataUrl:`standard_fonts/`,BinaryDataFactory:i,disableStream:!0,disableRange:!1,rangeChunkSize:524288,disableAutoFetch:!0});let a=await n.promise;t&&l(a)}catch{t&&te.current()}})(),()=>{if(t=!1,l(null),n){let e=n;Rt=Rt.then(()=>e.destroy()).catch(()=>{})}}},[e]),(0,H.useEffect)(()=>{let e=o.current;if(!e)return;let t=new ResizeObserver(([e])=>{g(Math.floor(e?.contentRect.width??0)),v(Math.floor(e?.contentRect.height??0))});return t.observe(e),()=>t.disconnect()},[]),(0,H.useEffect)(()=>{let e=s.current;if(a||!c||!e||!h)return;let t=!0,n=null;return(async()=>{try{let r=await c.getPage(u);if(!t)return;let i=r.getViewport({scale:1}),a=Pt(i.height/i.width,b,{width:h,height:_},Nt[f]);n=Ht(r,e,a.width/i.width),await n.promise,r.cleanup()}catch{}})(),()=>{t=!1,n?.cancel()}},[c,u,f,h,_,a,b]);let S=(0,H.useRef)(u);S.current=u,(0,H.useEffect)(()=>{let e=o.current;if(!a||!e||!c)return;let t=e.querySelector(`[data-page="${S.current}"]`);t&&S.current>1&&e.scrollTo(e.scrollLeft,t.offsetTop-Bt)},[a,f,c,b]);let C=c?.numPages??0,w=e=>{let t=Math.min(Math.max(u+e,1),C);d(t);let n=o.current;if(n){if(a){let e=n.querySelector(`[data-page="${t}"]`);n.scrollTo(n.scrollLeft,e?e.offsetTop-Bt:0)}else n.scrollTo(0,0)}},ne=e=>p(t=>Math.min(Math.max(t+e,0),Nt.length-1)),T=e=>e.preventDefault();return(0,G.jsxs)(`div`,{className:`player pdf`,children:[(0,G.jsx)(`div`,{className:`pdf-sheet`,ref:o,onScroll:a?()=>d(Ut(o.current)):void 0,children:a?c&&h>0&&(0,G.jsx)(Wt,{doc:c,room:{width:h,height:Math.max(0,_-2*Bt)},fit:b,zoom:Nt[f],root:o,name:t}):(0,G.jsx)(`canvas`,{ref:s,role:`img`,"aria-label":c?`${t}, page ${u} of ${C}`:t,hidden:!c})}),(0,G.jsxs)(`div`,{className:`pdf-bar`,children:[(0,G.jsx)(`button`,{type:`button`,className:`vbtn`,"aria-label":`Previous page`,disabled:u<=1,onMouseDown:T,onClick:()=>w(-1),children:(0,G.jsx)(ae,{})}),(0,G.jsx)(`span`,{className:`clock`,children:C?`${u} / ${C}`:`…`}),(0,G.jsx)(`button`,{type:`button`,className:`vbtn`,"aria-label":`Next page`,disabled:u>=C,onMouseDown:T,onClick:()=>w(1),children:(0,G.jsx)(E,{})}),(0,G.jsx)(`span`,{className:`pdf-gap`}),(0,G.jsx)(`button`,{type:`button`,className:`vbtn`,"aria-label":b===`width`?`Fit height`:`Fit width`,title:b===`width`?`Fit height: the whole page in view`:`Fit width`,disabled:!c,onMouseDown:T,onClick:()=>ee(b===`width`?`height`:`width`),children:b===`width`?(0,G.jsx)(i,{}):(0,G.jsx)(r,{})}),(0,G.jsx)(`button`,{type:`button`,className:`vbtn`,"aria-label":`Zoom out`,disabled:!c||f<=0,onMouseDown:T,onClick:()=>ne(-1),children:(0,G.jsx)(m,{})}),(0,G.jsxs)(`span`,{className:`clock`,children:[Math.round(Nt[f]*100),`%`]}),(0,G.jsx)(`button`,{type:`button`,className:`vbtn`,"aria-label":`Zoom in`,disabled:!c||f>=Nt.length-1,onMouseDown:T,onClick:()=>ne(1),children:(0,G.jsx)(y,{})})]})]})}var Bt=8,Vt=`150% 0px`;function Ht(e,t,n){let r=e.getViewport({scale:n}),i=Math.min(window.devicePixelRatio||1,Math.sqrt(Ft/(r.width*r.height))),a=e.getViewport({scale:n*i});return t.width=Math.floor(a.width),t.height=Math.floor(a.height),t.style.width=`${Math.floor(r.width)}px`,t.style.height=`${Math.floor(r.height)}px`,e.render({canvas:t,viewport:a})}function Ut(e){if(!e)return 1;let t=e.scrollTop+e.clientHeight/3,n=1;for(let r of e.querySelectorAll(`[data-page]`)){if(r.offsetTop>t)break;n=Number(r.dataset.page)}return n}function Wt({doc:e,room:t,fit:n,zoom:r,root:i,name:a}){let[o,s]=(0,H.useState)(1.414);return(0,H.useEffect)(()=>{let t=!0;return e.getPage(1).then(e=>{let n=e.getViewport({scale:1});t&&s(n.height/n.width)}).catch(()=>{}),()=>{t=!1}},[e]),(0,G.jsx)(`div`,{className:`pdf-flow`,children:Array.from({length:e.numPages},(s,c)=>(0,G.jsx)(Gt,{doc:e,number:c+1,sizeOf:e=>Pt(e??o,n,t,r),root:i,name:a},c+1))})}function Gt({doc:e,number:t,sizeOf:n,root:r,name:i}){let a=(0,H.useRef)(null),o=(0,H.useRef)(null),[s,c]=(0,H.useState)(!1),[l,u]=(0,H.useState)(null),d=n(l),f=(0,H.useRef)(n);return f.current=n,(0,H.useEffect)(()=>{let e=a.current;if(!e)return;let t=new IntersectionObserver(([e])=>c(!!e?.isIntersecting),{root:r.current,rootMargin:Vt});return t.observe(e),()=>t.disconnect()},[r]),(0,H.useEffect)(()=>{let n=o.current;if(!n)return;if(!s){n.width=0,n.height=0;return}let r=!0,i=null;return(async()=>{try{let a=await e.getPage(t);if(!r)return;let o=a.getViewport({scale:1});u(o.height/o.width),i=Ht(a,n,f.current(o.height/o.width).width/o.width),await i.promise,a.cleanup()}catch{}})(),()=>{r=!1,i?.cancel()}},[e,t,d.width,s]),(0,G.jsx)(`div`,{ref:a,className:`pdf-page`,"data-page":t,style:{width:d.width,height:d.height},children:(0,G.jsx)(`canvas`,{ref:o,role:`img`,"aria-label":`${i}, page ${t}`,hidden:!s})})}var Kt=100,qt=2;function Jt({value:e}){return(0,G.jsx)(`div`,{className:`json-tree`,role:`tree`,children:(0,G.jsx)(Yt,{label:null,value:e,depth:0,last:!0})})}function Yt({label:e,value:t,depth:n,last:r}){let i=typeof t==`object`&&!!t,[a,o]=(0,H.useState)(n<qt),[s,c]=(0,H.useState)(Kt),l=r?``:`,`,u=e!==null&&(0,G.jsxs)(G.Fragment,{children:[(0,G.jsx)(`span`,{className:`json-key`,children:e}),(0,G.jsx)(`span`,{className:`json-punct`,children:`: `})]});if(!i)return(0,G.jsxs)(`div`,{className:`json-row`,role:`treeitem`,style:{paddingLeft:Zt(n)},children:[(0,G.jsx)(`span`,{className:`json-caret`}),u,(0,G.jsx)(Xt,{value:t}),(0,G.jsx)(`span`,{className:`json-punct`,children:l})]});let d=Array.isArray(t),f=d?t.map((e,t)=>[String(t),e]):Object.entries(t),[p,m]=d?[`[`,`]`]:[`{`,`}`];return(0,G.jsxs)(G.Fragment,{children:[(0,G.jsxs)(`div`,{className:`json-row json-branch`,role:`treeitem`,"aria-expanded":f.length?a:void 0,style:{paddingLeft:Zt(n)},onMouseDown:e=>e.preventDefault(),onClick:()=>f.length&&o(!a),children:[(0,G.jsx)(`span`,{className:`json-caret`,children:f.length?a?`▾`:`▸`:``}),u,(0,G.jsx)(`span`,{className:`json-punct`,children:p}),!a&&(0,G.jsxs)(G.Fragment,{children:[f.length>0&&(0,G.jsx)(`span`,{className:`json-count`,children:d?`${f.length} items`:`${f.length} keys`}),(0,G.jsxs)(`span`,{className:`json-punct`,children:[m,l]})]})]}),a&&(0,G.jsxs)(G.Fragment,{children:[f.slice(0,s).map(([e,t],r)=>(0,G.jsx)(Yt,{label:d?null:JSON.stringify(e),value:t,depth:n+1,last:r===f.length-1},e)),f.length>s&&(0,G.jsxs)(`div`,{className:`json-row json-more`,style:{paddingLeft:Zt(n+1)},onMouseDown:e=>e.preventDefault(),onClick:()=>c(s+Kt),children:[`… `,(f.length-s).toLocaleString(),` more`]}),(0,G.jsxs)(`div`,{className:`json-row`,style:{paddingLeft:Zt(n)},children:[(0,G.jsx)(`span`,{className:`json-caret`}),(0,G.jsxs)(`span`,{className:`json-punct`,children:[m,l]})]})]})]})}function Xt({value:e}){return e===null?(0,G.jsx)(`span`,{className:`json-null`,children:`null`}):typeof e==`string`?(0,G.jsx)(`span`,{className:`json-string`,children:JSON.stringify(e)}):typeof e==`number`?(0,G.jsx)(`span`,{className:`json-number`,children:String(e)}):(0,G.jsx)(`span`,{className:`json-bool`,children:String(e)})}function Zt(e){return`${e*14}px`}var Qt={b:`b`,strong:`strong`,i:`i`,em:`em`,u:`u`,ins:`u`,s:`s`,strike:`s`,del:`del`,mark:`mark`,code:`code`,kbd:`kbd`,pre:`pre`,sup:`sup`,sub:`sub`,small:`small`,p:`p`,div:`div`,br:`br`,hr:`hr`,blockquote:`blockquote`,ul:`ul`,ol:`ol`,li:`li`,h1:`h1`,h2:`h2`,h3:`h3`,h4:`h4`,h5:`h5`,h6:`h6`,table:`table`,thead:`thead`,tbody:`tbody`,tr:`tr`,td:`td`,th:`th`,span:`span`,font:`span`,a:`span`,section:`div`,article:`div`,header:`div`,footer:`div`,figure:`div`,figcaption:`div`},$t=new Set([`script`,`style`,`head`,`title`,`template`,`noscript`,`svg`,`math`,`iframe`,`object`,`img`,`video`,`audio`,`canvas`,`button`,`input`,`select`,`textarea`]),en=3e3,tn=40,nn;function rn(e){if(!e||(nn??=document.createElement(`canvas`).getContext(`2d`),!nn))return;nn.fillStyle=`#000`,nn.fillStyle=e;let t=/^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(String(nn.fillStyle));if(!t)return;let[n=0,r=0,i=0]=t.slice(1).map(e=>parseInt(e,16));return Math.max(n,r,i)-Math.min(n,r,i)>=40?`rgb(${n}, ${r}, ${i})`:void 0}function an(e){let t=e.style,n={},r=t?.fontWeight;r&&(n.fontWeight=r===`bold`||r===`bolder`||Number(r)>=600?`bold`:`normal`),t?.fontStyle===`italic`||t?.fontStyle===`oblique`?n.fontStyle=`italic`:t?.fontStyle===`normal`&&(n.fontStyle=`normal`);let i=t?.textDecorationLine||t?.textDecoration||``,a=[`underline`,`line-through`].filter(e=>i.includes(e));a.length&&(n.textDecorationLine=a.join(` `));let o=t?.fontFamily||(e.tagName===`FONT`?e.getAttribute(`face`):null)||``;o&&(n.fontFamily=`${o}, -apple-system, system-ui, sans-serif`);let s=rn(t?.color||(e.tagName===`FONT`?e.getAttribute(`color`)??``:``));return s&&(n.color=s),Object.keys(n).length?n:void 0}function on({html:e,fallback:t,maxNodes:n=en,links:r=[],onOpen:i}){let a=new DOMParser().parseFromString(e,`text/html`),o=0,s=!1,c=(e,t,a,l=!1)=>{if(++o>n)return null;if(e.nodeType===Node.TEXT_NODE){let t=e.textContent??``;return t.trim()&&(s=!0),l?t:dt(t,r,i)}if(e.nodeType!==Node.ELEMENT_NODE||t>tn)return null;let u=e,d=u.tagName.toLowerCase();if(d===`input`&&u.getAttribute(`type`)===`checkbox`)return s=!0,u.hasAttribute(`checked`)?`☑ `:`☐ `;if($t.has(d))return null;let f=Array.from(u.childNodes,(e,n)=>c(e,t+1,n,l||d===`a`)),p=Qt[d];if(!p)return(0,H.createElement)(`span`,{key:a,style:an(u)},...f);if(p===`br`||p===`hr`)return(0,H.createElement)(p,{key:a});let m={key:a,style:an(u)};if(d===`a`){let e=i&&ot(u.getAttribute(`href`),r);Object.assign(m,e?ut(e.url,i):{className:`link`})}return(0,H.createElement)(p,m,...f)},l=c(a.body,0,0);return s?(0,G.jsx)(`div`,{className:`body rich-html`,children:l}):t}var sn=65536,cn=1048576,ln=2e4;function un({src:e,json:t,markdown:n,language:r,onFail:i}){let[a,o]=(0,H.useState)(null),[s,c]=(0,H.useState)(!1),[l,u]=(0,H.useState)(null),d=(0,H.useRef)(i);d.current=i,(0,H.useEffect)(()=>{let n=new AbortController,r=t?cn:sn;return(async()=>{try{let i=await fetch(e,{headers:{Range:`bytes=0-${r-1}`},signal:n.signal});if(i.status===416)return o({text:``,cut:!1,tree:void 0});if(!i.ok)throw Error(String(i.status));let a=new Uint8Array(await i.arrayBuffer());if(a.includes(0))throw Error(`binary`);let s=Number(i.headers.get(`Content-Range`)?.split(`/`)[1])||a.length,c=new TextDecoder().decode(a),l=t&&s<=cn?fn(c):void 0,u=c.length>sn||s>a.length,d=c.slice(0,sn);u&&(d=d.slice(0,d.lastIndexOf(`
`)+1)||d),o({text:d,cut:u,tree:l})}catch{n.signal.aborted||d.current()}})(),()=>n.abort()},[e,t]);let[f,p]=(0,H.useState)(null);(0,H.useEffect)(()=>{let e=a?.text;if(!n||!e)return;let t=!0;return Mt(async()=>{let{markdownHtml:e}=await import(`./markdown-ZAH5kwRn.js`);return{markdownHtml:e}},[],import.meta.url).then(({markdownHtml:n})=>t&&p({text:e,html:n(e)})).catch(()=>{}),()=>{t=!1}},[n,a?.text]);let m=f&&f.text===a?.text?f:null,h=(0,H.useMemo)(()=>m&&(0,G.jsx)(on,{html:m.html,maxNodes:ln,fallback:(0,G.jsx)(`pre`,{children:m.text})}),[m]),g=a?.tree===void 0?n&&a?.text?`doc`:null:`tree`,_=g===`tree`&&!s,v=g===`doc`&&!s&&!!h,y=a&&!_&&!v?a.text:``;if((0,H.useEffect)(()=>{if(!y||!r)return;let e=!0;return Mt(async()=>{let{highlight:e}=await import(`./highlight-BiJ1vwgy.js`);return{highlight:e}},__vite__mapDeps([0,1]),import.meta.url).then(({highlight:e})=>e(y,r)).then(t=>e&&u({text:y,nodes:t})).catch(()=>{}),()=>{e=!1}},[y,r]),!a)return(0,G.jsx)(`div`,{className:`file-text`});let b=e=>e.preventDefault();return(0,G.jsxs)(`div`,{className:`file-text`,children:[_?(0,G.jsx)(Jt,{value:a.tree}):v?(0,G.jsx)(`div`,{className:`file-doc`,children:h}):g===`doc`&&!s?(0,G.jsx)(`div`,{className:`file-doc`}):r&&y?(0,G.jsxs)(`div`,{className:`code-scroll`,children:[(0,G.jsx)(`div`,{className:`gutter`,"aria-hidden":`true`,children:dn(y)}),(0,G.jsx)(`pre`,{className:`code`,children:l?.text===y?l.nodes:y})]}):(0,G.jsx)(`pre`,{children:y||`Empty file`}),(g||a.cut)&&(0,G.jsxs)(`div`,{className:`file-text-more`,children:[a.cut&&!_&&(0,G.jsxs)(`span`,{children:[`First `,Math.round(sn/1024),` KB of the file`]}),g&&(0,G.jsxs)(`span`,{className:`file-text-modes`,role:`group`,"aria-label":`Show as`,children:[(0,G.jsx)(`button`,{type:`button`,"aria-pressed":!s,onMouseDown:b,onClick:()=>c(!1),children:g===`tree`?`Tree`:`Preview`}),(0,G.jsx)(`button`,{type:`button`,"aria-pressed":s,onMouseDown:b,onClick:()=>c(!0),children:g===`tree`?`Text`:`Code`})]})]})]})}function dn(e){let t=1;for(let n=e.indexOf(`
`);n!==-1;n=e.indexOf(`
`,n+1))t++;return e.endsWith(`
`)&&t--,Array.from({length:t},(e,t)=>t+1).join(`
`)}function fn(e){try{return JSON.parse(e)}catch{return}}var pn=String.raw`[+-]?(?:\d+(?:\.\d+)?|\.\d+)`,mn=new RegExp(String.raw`^(${pn})(%|deg|grad|rad|turn)?$|^none$`,`i`),hn=(e,t,n)=>Math.min(n,Math.max(t,e));function gn(e){let t=mn.exec(e);return t?t[1]?{n:Number(t[1]),unit:(t[2]??``).toLowerCase()}:{n:0,unit:``}:null}function _n(e){if(e===void 0)return 1;let t=gn(e);return!t||t.unit&&t.unit!==`%`?null:hn(t.unit===`%`?t.n/100:t.n,0,1)}function vn(e){if(e.includes(`,`)){let t=e.split(`,`).map(e=>e.trim());return t.length!==3&&t.length!==4?null:{three:t.slice(0,3),alpha:t[3]}}let[t,n,r]=e.split(`/`).map(e=>e.trim());if(r!==void 0||t===void 0)return null;let i=t.split(/\s+/);return i.length===3?{three:i,alpha:n}:null}function yn(e,t,n){let r=t=>(t+e/30)%12,i=t*Math.min(n,1-n),a=e=>n-i*Math.max(-1,Math.min(r(e)-3,9-r(e),1));return[a(0)*255,a(8)*255,a(4)*255]}function bn(e){let t=e.trim(),n=/^#([0-9a-f]{3,4}|[0-9a-f]{6}|[0-9a-f]{8})$/i.exec(t)?.[1];if(n){let e=n.length<=4?[...n].map(e=>e+e).join(``):n,t=t=>parseInt(e.slice(t*2,t*2+2),16);return{r:t(0),g:t(1),b:t(2),a:e.length===8?t(3)/255:1}}let r=/^(rgba?|hsla?)\((.*)\)$/i.exec(t);if(!r)return null;let i=vn(r[2].trim());if(!i)return null;let a=_n(i.alpha),o=i.three.map(gn);if(a===null||o.some(e=>!e))return null;let[s,c,l]=o;if(r[1].toLowerCase().startsWith(`rgb`)){let e=e=>e.unit&&e.unit!==`%`?NaN:hn(e.unit===`%`?e.n/100*255:e.n,0,255),[t,n,r]=[e(s),e(c),e(l)];return[t,n,r].some(Number.isNaN)?null:{r:t,g:n,b:r,a}}let u={"":1,deg:1,grad:.9,rad:180/Math.PI,turn:360}[s.unit];if(u===void 0||[c,l].some(e=>e.unit&&e.unit!==`%`))return null;let[d,f,p]=yn((s.n*u%360+360)%360,hn(c.n/100,0,1),hn(l.n/100,0,1));return{r:d,g:f,b:p,a}}var xn=e=>hn(Math.round(e),0,255),Sn=e=>xn(e).toString(16).padStart(2,`0`).toUpperCase(),Cn=(e,t=0)=>Number(e.toFixed(t)),wn=e=>e.a<1?` / ${Cn(e.a,2)}`:``;function Tn(e){return`#${Sn(e.r)}${Sn(e.g)}${Sn(e.b)}${e.a<1?Sn(e.a*255):``}`}function En(e){return`rgb(${xn(e.r)} ${xn(e.g)} ${xn(e.b)}${wn(e)})`}function Dn(e){let[t,n,r]=[e.r/255,e.g/255,e.b/255],i=Math.max(t,n,r),a=Math.min(t,n,r),o=(i+a)/2,s=i-a,c=0,l=0;return s&&(l=s/(1-Math.abs(2*o-1)),c=i===t?(n-r)/s%6:i===n?(r-t)/s+2:(t-n)/s+4,c=(c*60+360)%360),`hsl(${Cn(c)} ${Cn(l*100)}% ${Cn(o*100)}%${wn(e)})`}function On(e,t){let n=(t,n)=>t*e.a+n*(1-e.a);return{r:n(e.r,t.r),g:n(e.g,t.g),b:n(e.b,t.b),a:1}}var kn={r:255,g:255,b:255,a:1},An={r:0,g:0,b:0,a:1};function jn(e){let t=e=>{let t=e/255;return t<=.04045?t/12.92:((t+.055)/1.055)**2.4};return .2126*t(e.r)+.7152*t(e.g)+.0722*t(e.b)}function Mn(e,t){let[n,r]=[jn(e),jn(t)];return(Math.max(n,r)+.05)/(Math.min(n,r)+.05)}var Nn=`search`,Pn=1e5,Fn=`.card-head, .card-foot, button, input`;function In(e,t,n,r){(0,H.useEffect)(()=>{let r=e.current,i=typeof CSS<`u`&&`highlights`in CSS?CSS.highlights:null,a=()=>i?.delete(Nn);if(!r||!V(t).length){a();return}let o=!1,s=0,c=()=>{s=0;let e=Ln(r,t,n);i&&(e.length?i.set(Nn,new Highlight(...e)):i.delete(Nn));let a=e[0];a&&!o&&(o=!0,zn(a,r))},l=()=>{s||=window.setTimeout(c,16)};l();let u=new MutationObserver(l);return u.observe(r,{childList:!0,subtree:!0,characterData:!0}),()=>{u.disconnect(),window.clearTimeout(s),a()}},[e,t,n,r])}function Ln(e,t,n){let r=[],i=``,a=document.createTreeWalker(e,NodeFilter.SHOW_TEXT,{acceptNode:e=>e.parentElement?.closest(Fn)?NodeFilter.FILTER_REJECT:NodeFilter.FILTER_ACCEPT});for(let e=a.nextNode();e&&i.length<Pn;e=a.nextNode()){let t=e.data;t&&(r.push({node:e,start:i.length}),i+=t)}if(!r.length)return[];let o=[];for(let[e,a]of he(i,t,n)){let t=Rn(r,e),n=Rn(r,a);if(!t||!n)continue;let i=document.createRange();i.setStart(t.node,t.offset),i.setEnd(n.node,n.offset),o.push(i)}return o}function Rn(e,t){let n=0,r=e.length-1;for(;n<r;){let i=n+r+1>>1;e[i].start<t?n=i:r=i-1}let i=e[n];return i?{node:i.node,offset:Math.min(t-i.start,i.node.data.length)}:null}function zn(e,t){for(let n=e.startContainer.parentElement;n&&t.contains(n);n=n.parentElement){let r=e.getBoundingClientRect();if(!r.width&&!r.height)return;let i=getComputedStyle(n),a=n.getBoundingClientRect();if(/(auto|scroll)/.test(i.overflowY)&&n.scrollHeight>n.clientHeight&&(r.top<a.top||r.bottom>a.bottom)&&(n.scrollTop+=r.top-a.top-n.clientHeight/3),/(auto|scroll)/.test(i.overflowX)&&n.scrollWidth>n.clientWidth&&(r.left<a.left||r.right>a.right)&&(n.scrollLeft+=r.left-a.left-n.clientWidth/4),n===t)break}}var Bn=90,Vn=400,$=new Map,Hn=64,Un=e=>`${e.id}:${+!!e.ocr}`,Wn=new Map;function Gn(e){return!!e}function Kn({row:e,onOpen:t,onCopyColor:n,onCopySnippet:r,onCopyWords:i,query:o=``,used:s=`exact`,zoomed:c=!1,onZoom:l,split:u}){let d=(0,H.useRef)(null);In(d,o,s,e?.id);let[f,p]=(0,H.useState)(null),[m,h]=(0,H.useState)(null),[_,v]=(0,H.useState)(null);(0,H.useEffect)(()=>v(null),[e?.id]),(0,H.useEffect)(()=>{c||v(null)},[c]);let[y,b]=(0,H.useState)(0);(0,H.useEffect)(()=>{let e=()=>{$.clear(),b(e=>e+1)},t=[`lumi:profiles`,`lumi:settings`,`lumi:snippets`];for(let n of t)window.addEventListener(n,e);return()=>{for(let n of t)window.removeEventListener(n,e)}},[]);let[x,ee]=(0,H.useState)(null);(0,H.useEffect)(()=>{if(!e||e.kind===`image`&&!e.ocr)return;let t=Un(e),n=$.get(t);if(n&&(p(n),!n.snippets?.some(e=>e.dynamic)))return;let r=!0,i=setTimeout(()=>r&&h(e.id),Vn),a=setTimeout(async()=>{try{let{text:n,html:i,ocr:a,fileSize:o,fileToken:s,files:c,fileCount:l,links:u,linkCount:d,snippets:f,layout:m}=await A({kind:`preview`,id:e.id});if(!(n||i||a)){r&&h(e.id);return}let g={id:e.id,text:n,html:i,ocr:a,fileSize:o,fileToken:s,files:c,fileCount:l,links:u,linkCount:d,snippets:f,layout:m};$.delete(t),$.set(t,g),$.size>Hn&&$.delete($.keys().next().value),r&&p(g)}catch{r&&h(e.id)}},Bn);return()=>{r=!1,clearTimeout(a),clearTimeout(i)}},[e,y]);let[te,S]=(0,H.useState)(null),[C,w]=(0,H.useState)(null),ne=(0,H.useRef)(null);(0,H.useEffect)(()=>w(null),[e?.id]);let T=f?.id===e?.id?f:null;(0,H.useEffect)(()=>{if(!e||e.kind!==`image`||!e.ocr||!T)return;if(T.layout){S({id:e.id,layout:T.layout});return}let t=Wn.get(e.id);if(t){S({id:e.id,layout:t});return}let n=!0;return A({kind:`layout`,id:e.id}).then(({layout:t})=>{t&&(Wn.set(e.id,t),Wn.size>Hn&&Wn.delete(Wn.keys().next().value),n&&S({id:e.id,layout:t}))}).catch(()=>{}),()=>{n=!1}},[e,T]);let E=te&&te.id===e?.id?te.layout:null,D=C&&C.id===e?.id&&E?C.picked:null;if((0,H.useEffect)(()=>{if(!D||!e)return;let t=t=>{let n=t.metaKey&&!t.ctrlKey&&!t.altKey&&t.key.toLowerCase()===`c`;(n||t.key===`Escape`)&&(n&&window.getSelection()?.isCollapsed===!1||(t.preventDefault(),t.stopPropagation(),n?i?.(e.id,D):w(null)))};return window.addEventListener(`keydown`,t,!0),()=>window.removeEventListener(`keydown`,t,!0)},[D,e,i]),!e)return(0,G.jsx)(`aside`,{className:`preview empty-card`});let O=f?.id===e.id?f:$.get(Un(e))??null,re=e.kind===`rich`&&!O&&m!==e.id,ie=O?.text||e.title,k=e.kind===`rich`?O?.html:null,ae=e.kind===`image`?O?.ocr:null,oe=e.kind===`image`&&!!e.ocr,j=oe&&c&&_===e.id,se=x?.id===e.id?`${x.w} × ${x.h} px`:null,M=e.kind===`file`&&O?.fileSize!=null?cr(O.fileSize):null,ce=(e.kind===`text`||e.kind===`rich`)&&O?.links?O.links:[],N=e.kind===`rich`?ce:[],P=t?n=>t(e.id,n):void 0,F=(e.kind===`text`||e.kind===`rich`)&&O?.snippets?O.snippets:[],fe=e.appName||e.app,I=e.count>1?`${e.count}×`:`once`;return(0,G.jsx)(`aside`,{className:`preview`,"aria-live":`polite`,children:(0,G.jsxs)(`div`,{className:`card`,ref:d,children:[(0,G.jsxs)(`header`,{className:`card-head`,children:[e.kind===`file`?(0,G.jsx)(g,{family:X(e.fileExt),many:(e.fileCount??0)>1}):(0,G.jsx)(a,{kind:e.kind}),(0,G.jsxs)(`span`,{children:[Be[e.kind],fe?` · `:``,(0,G.jsx)(Re,{app:e.app,name:e.appName,withName:!0},e.app??``)]}),(se||M)&&(0,G.jsx)(`span`,{className:`dims`,children:[se,M].filter(Boolean).join(` · `)}),l&&Gn(e)&&!j&&(0,G.jsx)(`button`,{type:`button`,className:`bare zoom`,"aria-pressed":c,title:c?`Back to the list (⌘Y)`:`Give it the whole panel (⌘Y)`,"aria-label":c?`Back to the list`:`Expand preview`,onMouseDown:e=>e.preventDefault(),onClick:l,children:c?(0,G.jsx)(ue,{}):(0,G.jsx)(de,{})})]}),e.kind===`image`&&e.thumb&&!j&&(0,G.jsxs)(Qn,{id:e.id,className:`picture`,children:[(0,G.jsx)(`img`,{ref:ne,alt:`Copied image`,src:le(e.thumb),draggable:!1,onLoad:t=>{let{naturalWidth:n,naturalHeight:r}=t.currentTarget;n&&r&&ee({id:e.id,w:n,h:r})}}),E&&(0,G.jsx)(vt,{layout:E,picture:ne,picked:D,onPick:t=>w(t&&{id:e.id,picked:t})},e.id)]}),oe&&(!c||j)&&(0,G.jsxs)(`section`,{className:`ocr-read`,children:[u&&!j&&e.thumb&&(0,G.jsx)(qn,{...u}),(0,G.jsxs)(`header`,{className:`ocr-head`,children:[D&&E?(0,G.jsxs)(`span`,{className:`ocr-picked`,children:[_t(E,D)===1?`1 word`:`${_t(E,D)} words`,` selected`,(0,G.jsx)(`button`,{type:`button`,className:`bare`,title:`Copy the selected words (⌘C)`,onMouseDown:e=>e.preventDefault(),onClick:()=>i?.(e.id,D),children:`Copy`})]}):(0,G.jsx)(`span`,{children:E?`Text in image · select it on the picture`:`Text in image`}),(0,G.jsx)(`button`,{type:`button`,className:`bare`,"aria-pressed":j,title:j?`Back to the list (⎋)`:`Give the text the whole panel`,"aria-label":j?`Back to the list`:`Expand text`,onMouseDown:e=>e.preventDefault(),onClick:()=>{if(j){l?.();return}v(e.id),c||l?.()},children:j?(0,G.jsx)(ue,{}):(0,G.jsx)(de,{})})]}),(0,G.jsx)(`div`,{className:`body ocr`,children:ae??``})]}),e.kind===`file`&&(e.fileCount??0)<=1&&!O?.files?.length&&(0,G.jsx)($n,{id:e.id,family:X(e.fileExt),ext:e.fileExt??``,text:Pe(e.fileExt),token:O?.fileToken??null,name:e.title,onSize:(t,n)=>ee({id:e.id,w:t,h:n}),whole:c},e.id),(0,G.jsxs)(Jn,{on:e.kind===`text`||e.kind===`rich`,even:F.length>0,children:[e.kind===`color`&&ze(e.title)?(0,G.jsx)(Xn,{color:e.title,onCopy:n}):O?.files?.length?(0,G.jsx)(tr,{id:e.id,files:O.files,count:O.fileCount||O.files.length}):e.kind===`file`&&(e.fileCount??0)<=1?(0,G.jsx)(rr,{path:ie.split(`
`)[0]}):re?(0,G.jsx)(`div`,{className:`body rich`}):k?(0,G.jsx)(on,{html:k,links:N,onOpen:P,fallback:(0,G.jsx)(`div`,{className:`body rich`,children:dt(ie,N,P)})},e.id):e.kind===`link`&&t?(0,G.jsx)(Zn,{text:ie,onOpen:()=>t(e.id)}):e.kind!==`image`&&(0,G.jsx)(`div`,{className:e.kind===`rich`?`body rich`:`body`,children:dt(ie,N,P)}),F.length>0&&(0,G.jsx)(ft,{grip:u&&(0,G.jsx)(qn,{...u}),expansions:F,onCopy:r?t=>r(e.id,t):void 0,onOpen:t?n=>t(e.id,n,!0):void 0},`snippets:${e.id}`),ce.length>0&&P&&(0,G.jsx)(lt,{links:ce,count:O?.linkCount||ce.length,onOpen:P},`links:${e.id}`)]}),(0,G.jsxs)(`footer`,{className:`card-foot`,children:[`Copied `,z(e.last),` · `,I]})]})})}function qn(e){return(0,G.jsx)(`div`,{className:`split-grip`,role:`separator`,"aria-orientation":`horizontal`,"aria-label":`Resize the two parts`,title:`Drag to resize · double-click to reset`,...e})}function Jn({on:e,even:t,children:n}){return e?(0,G.jsx)(`div`,{className:t?`texts even`:`texts`,children:n}):(0,G.jsx)(G.Fragment,{children:n})}var Yn={r:30,g:30,b:30,a:1};function Xn({color:e,onCopy:t}){let n=bn(e);if(!n)return(0,G.jsx)(`div`,{className:`chip painted`,style:Z(e)});let r=On(n,kn),i=Mn(kn,r),a=Mn(An,r),o=e=>t?.(e);return(0,G.jsxs)(G.Fragment,{children:[(0,G.jsx)(`div`,{className:`chip painted`,style:Z(e),children:(0,G.jsx)(`span`,{className:`chip-code`,style:{color:i>=a?`#fff`:`#000`},children:e})}),(0,G.jsxs)(`section`,{className:`color-info`,children:[(0,G.jsx)(`h3`,{children:`Formats`}),[[`HEX`,Tn(n)],[`RGB`,En(n)],[`HSL`,Dn(n)]].map(([e,t])=>(0,G.jsxs)(`button`,{className:`format`,title:`Copy`,onClick:()=>o(t),children:[(0,G.jsx)(`span`,{className:`format-label`,children:e}),(0,G.jsx)(`span`,{className:`format-text`,children:t}),(0,G.jsx)(N,{})]},e)),(0,G.jsx)(`h3`,{children:`Text on it`}),(0,G.jsx)(`div`,{className:`text-on`,children:[[`White`,kn,i],[`Black`,An,a]].map(([e,t,n])=>(0,G.jsxs)(`div`,{className:n>=Math.max(i,a)?`best`:void 0,title:`${e} text`,children:[(0,G.jsx)(`span`,{className:`sample`,style:{background:Tn(r),color:Tn(t)},children:`Aa`}),(0,G.jsxs)(`span`,{className:`ratio`,children:[n.toFixed(1),`:1`]}),(0,G.jsx)(`span`,{className:n>=4.5?`grade pass`:`grade fail`,children:n>=4.5?`AA`:`✕ AA`})]},e))}),n.a<1&&(0,G.jsxs)(G.Fragment,{children:[(0,G.jsxs)(`h3`,{children:[`Over light and dark · `,Math.round(n.a*100),`%`]}),(0,G.jsx)(`div`,{className:`over`,children:[[`Light`,kn],[`Dark`,Yn]].map(([t,r])=>{let i=Tn(On(n,r));return(0,G.jsxs)(`button`,{className:`format`,title:`Copy`,onClick:()=>o(i),children:[(0,G.jsx)(`span`,{className:`over-swatch`,style:{background:Tn(r)},children:(0,G.jsx)(`span`,{style:{background:e}})}),(0,G.jsx)(`span`,{className:`format-label`,children:t}),(0,G.jsx)(`span`,{className:`format-text`,children:i}),(0,G.jsx)(N,{})]},t)})})]})]})]})}function Zn({text:e,onOpen:t}){return(0,G.jsx)(`div`,{className:`body link`,role:`link`,tabIndex:-1,title:`Open in browser`,onClick:()=>{window.getSelection()?.isCollapsed!==!1&&t()},children:e})}function Qn({id:e,className:t,family:n,children:r}){let i=je(()=>{A({kind:`drag`,id:e}).catch(()=>{})});return(0,G.jsx)(`div`,{className:t,"data-family":n,onMouseDown:e=>e.preventDefault(),...i,children:r})}function $n({id:e,family:t,ext:n,token:r,name:i,text:a,onSize:o,whole:s=!1}){let[c,l]=(0,H.useState)(!1),u=(0,H.useMemo)(()=>r?j(r):null,[r]),d=c?null:u;return d&&a?(0,G.jsx)(un,{src:d,json:n===`json`,markdown:n===`md`||n===`markdown`,language:Ie(n),onFail:()=>l(!0)}):d&&t===`image`?(0,G.jsx)(Qn,{id:e,className:`picture`,children:(0,G.jsx)(`img`,{alt:i,src:d,decoding:`async`,draggable:!1,onLoad:e=>{let{naturalWidth:t,naturalHeight:n}=e.currentTarget;t&&n&&o(t,n)},onError:()=>l(!0)})}):d&&t===`video`?(0,G.jsx)(er,{src:d,play:s,onError:()=>l(!0)}):d&&t===`audio`?(0,G.jsxs)(`div`,{className:`player audio`,children:[(0,G.jsx)(g,{family:t}),(0,G.jsx)(`audio`,{src:d,controls:!0,preload:`none`,onError:()=>l(!0)})]}):d&&t===`pdf`?(0,G.jsx)(zt,{src:d,name:i,flow:s,onFail:()=>l(!0)}):(0,G.jsxs)(Qn,{id:e,className:`file-tile`,family:t,children:[(0,G.jsx)(g,{family:t}),(0,G.jsx)(`span`,{children:t===`folder`?`FOLDER`:n?n.toUpperCase():`FILE`})]})}function er({src:e,play:n=!1,onError:r}){let i=(0,H.useRef)(null),[a,o]=(0,H.useState)(!1),[s,c]=(0,H.useState)(!0),[l,u]=(0,H.useState)(0),[d,f]=(0,H.useState)(0),p=e=>e.preventDefault(),m=()=>{let e=i.current;e&&(e.paused?e.play().catch(r):e.pause())};return(0,H.useEffect)(()=>{let e=i.current;if(!n||!e)return;let t=()=>{e.paused&&e.play().catch(()=>{})};return t(),e.addEventListener(`canplay`,t,{once:!0}),()=>e.removeEventListener(`canplay`,t)},[n,e]),(0,G.jsxs)(`div`,{className:`player video`,children:[(0,G.jsx)(`video`,{ref:i,src:e,muted:!0,playsInline:!0,preload:`metadata`,onClick:m,onPlay:()=>o(!0),onPause:()=>o(!1),onEnded:()=>o(!1),onTimeUpdate:e=>u(e.currentTarget.currentTime),onLoadedMetadata:e=>f(e.currentTarget.duration||0),onVolumeChange:e=>c(e.currentTarget.muted),onError:r}),(0,G.jsxs)(`div`,{className:`vbar`,children:[(0,G.jsx)(`button`,{type:`button`,className:`vbtn`,"aria-label":a?`Pause`:`Play`,onMouseDown:p,onClick:m,children:a?(0,G.jsx)(t,{}):(0,G.jsx)(_,{})}),(0,G.jsx)(`input`,{type:`range`,className:`seek`,"aria-label":`Seek`,min:0,max:d||0,step:`any`,value:Math.min(l,d||0),disabled:!d,onChange:e=>{i.current&&(i.current.currentTime=Number(e.target.value))}}),(0,G.jsxs)(`span`,{className:`clock`,children:[sr(l),` / `,sr(d)]}),(0,G.jsx)(`button`,{type:`button`,className:`vbtn`,"aria-label":s?`Unmute`:`Mute`,onMouseDown:p,onClick:()=>i.current&&(i.current.muted=!i.current.muted),children:(0,G.jsx)(ee,{muted:s})})]})]})}function tr({id:e,files:t,count:n}){let r=t.filter(e=>e.folder).length,i=t.length-r,a=[i&&`${i} ${i===1?`file`:`files`}`,r&&`${r} ${r===1?`folder`:`folders`}`].filter(Boolean);return(0,G.jsxs)(`section`,{className:`file-list`,"aria-label":`${n} files`,children:[(0,G.jsxs)(`header`,{className:`file-list-head`,children:[a.join(` · `),n>t.length&&` · first ${t.length} of ${n}`]}),(0,G.jsx)(`ul`,{children:t.map((t,n)=>(0,G.jsx)(nr,{id:e,at:n,file:t},n))})]})}function nr({id:e,at:t,file:n}){let r=je(()=>{A({kind:`drag`,id:e,file:t}).catch(()=>{})});return(0,G.jsxs)(`li`,{title:n.dir?`${n.dir}/${n.name}`:n.name,onMouseDown:e=>e.preventDefault(),...r,children:[(0,G.jsx)(g,{family:n.folder?`folder`:X(ar(n.name))}),(0,G.jsxs)(`span`,{className:`file-list-text`,children:[(0,G.jsx)(ir,{name:n.name,folder:!!n.folder}),n.dir&&(0,G.jsx)(`span`,{className:`file-list-dir`,children:or(n.dir)})]}),n.size!=null&&(0,G.jsx)(`span`,{className:`file-list-size`,children:cr(n.size)})]})}function rr({path:e}){let t=e.length>1?e.replace(/\/+$/,``):e,n=t.lastIndexOf(`/`),r=t.slice(n+1)||t,i=n>0?t.slice(0,n):n===0?`/`:``;return(0,G.jsxs)(`div`,{className:`file-where`,title:e,children:[(0,G.jsx)(`div`,{className:`file-where-name`,children:r}),i&&(0,G.jsxs)(`div`,{className:`file-where-dir`,children:[(0,G.jsx)(d,{}),(0,G.jsx)(`span`,{children:or(i)})]})]})}function ir({name:e,folder:t}){let n=t?-1:e.lastIndexOf(`.`);return n<=0?(0,G.jsx)(`span`,{className:`file-list-name`,children:(0,G.jsx)(`span`,{className:`file-list-stem`,children:e})}):(0,G.jsxs)(`span`,{className:`file-list-name`,children:[(0,G.jsx)(`span`,{className:`file-list-stem`,children:e.slice(0,n)}),(0,G.jsx)(`span`,{className:`file-list-ext`,children:e.slice(n)})]})}function ar(e){let t=e.lastIndexOf(`.`);return t>0?e.slice(t+1).toLowerCase():void 0}function or(e){return e.replace(/^\/Users\/[^/]+(?=\/|$)/,`~`)}function sr(e){let t=Math.max(0,Math.floor(Number.isFinite(e)?e:0)),n=Math.floor(t/3600),r=Math.floor(t%3600/60),i=String(t%60).padStart(2,`0`);return n?`${n}:${String(r).padStart(2,`0`)}:${i}`:`${r}:${i}`}function cr(e){if(e<1e3)return`${e} ${e===1?`byte`:`bytes`}`;let t=[`KB`,`MB`,`GB`,`TB`],n=e/1e3,r=0;for(;n>=1e3&&r<t.length-1;)n/=1e3,r++;let i=r===0?0:1;return`${n.toLocaleString(void 0,{maximumFractionDigits:i})} ${t[r]}`}var lr=`previewWidth`,ur=180;function dr(){try{let e=Number(localStorage.getItem(lr));return Number.isFinite(e)&&e>=ur?e:230}catch{return 230}}function fr(e){try{localStorage.setItem(lr,String(e))}catch{}}function pr(e){fr(e),A({kind:`previewWidth`,width:e}).catch(()=>{})}function mr(e,t){return Math.round(Math.max(ur,Math.min(e,t-240)))}function hr(){let[e,t]=(0,H.useState)(dr),n=(0,H.useRef)(null),r=(0,H.useCallback)(t=>{t.preventDefault();let r=t.currentTarget.closest(`.body-grid`)?.getBoundingClientRect().width??620;n.current={x:t.clientX,width:e,total:r,now:e},t.currentTarget.setPointerCapture(t.pointerId)},[e]),i=(0,H.useCallback)(e=>{let r=n.current;r&&(r.now=mr(r.width+r.x-e.clientX,r.total),t(r.now))},[]),a=(0,H.useCallback)(e=>{let t=n.current;t&&(n.current=null,e.currentTarget.releasePointerCapture(e.pointerId),t.now!==t.width&&pr(t.now))},[]),o=(0,H.useCallback)(()=>{t(230),pr(230)},[]);return{width:e,adopt:(0,H.useCallback)(e=>{e==null||n.current||(t(e),fr(e))},[]),grip:{onPointerDown:r,onPointerMove:i,onPointerUp:a,onDoubleClick:o}}}var gr=C(),_r=`previewSplit`,vr=40,yr=2e3,br=e=>typeof e==`number`&&Number.isFinite(e)&&e>=vr&&e<=yr;function xr(){try{let e=Number(localStorage.getItem(_r)??NaN);return br(e)?e:null}catch{return null}}function Sr(e){try{e==null?localStorage.removeItem(_r):localStorage.setItem(_r,String(e))}catch{}}function Cr(e){Sr(e),A({kind:`previewSplit`,height:e}).catch(()=>{})}function wr(e,t,n,r){return Math.round(Math.max(n,Math.min(e+t,e+r)))}function Tr(e){let t=Number.parseFloat(getComputedStyle(e).minHeight);return Math.max(0,e.getBoundingClientRect().height-(Number.isFinite(t)?t:0))}function Er(){let[e,t]=(0,H.useState)(xr),n=(0,H.useRef)(null),r=(0,H.useCallback)(e=>{e.preventDefault();let r=e.currentTarget,i=r.parentElement,a=i?.previousElementSibling;if(!i||!a)return;(0,gr.flushSync)(()=>t(Math.round(a.getBoundingClientRect().height)));let o=a.getBoundingClientRect().height,s=0;for(let e=i;e&&!e.classList.contains(`card-foot`);e=e.nextElementSibling)s+=Tr(e);let c=o-Tr(a);n.current={y:e.clientY,start:o,floor:c,room:s,now:Math.round(o)},r.setPointerCapture(e.pointerId)},[]),i=(0,H.useCallback)(e=>{let r=n.current;r&&(r.now=wr(r.start,e.clientY-r.y,r.floor,r.room),t(r.now))},[]),a=(0,H.useCallback)(e=>{let t=n.current;t&&(n.current=null,e.currentTarget.releasePointerCapture(e.pointerId),t.now!==Math.round(t.start)&&br(t.now)&&Cr(t.now))},[]),o=(0,H.useCallback)(()=>{t(null),Cr(null)},[]);return{height:e,adopt:(0,H.useCallback)(e=>{if(n.current)return;let r=br(e)?e:null;t(r),Sr(r)},[]),grip:{onPointerDown:r,onPointerMove:i,onPointerUp:a,onDoubleClick:o}}}function Dr(){return{onPointerDown:(0,H.useCallback)(e=>{e.button!==0||e.target.closest(`button`)||(e.preventDefault(),fetch(`/__lumi__/drag`,{method:`POST`}).catch(()=>{}))},[])}}function Or(){let[e,t]=(0,H.useState)(null),[r,i]=(0,H.useState)(``),[o,f]=(0,H.useState)(`mixed`),p=(0,H.useRef)(`mixed`),[m,h]=(0,H.useState)(()=>S(ce)),[g,_]=(0,H.useState)(`all`),[y,x]=(0,H.useState)(0),[ee,C]=(0,H.useState)(``),[w,ne]=(0,H.useState)(!1),[E,k]=(0,H.useState)(!1),[ae,j]=(0,H.useState)(!1),[M,le]=(0,H.useState)(!1),F=(0,H.useRef)(null),fe=hr(),I=Er(),pe=Dr(),L=(0,H.useRef)(null);Ae(L);let R=(0,H.useRef)(null),[he,ve]=(0,H.useState)(null),z=(0,H.useRef)(!1),B=(0,H.useRef)([]),V=(0,H.useRef)([]),Ce=fe.adopt,we=I.adopt,Te=(0,H.useRef)(`all`);Te.current=g;let{rows:U,used:Ee}=(0,H.useMemo)(()=>ge((e??[]).filter(e=>Se(e,g)),r,o),[e,r,g,o]),De=(0,H.useMemo)(()=>me(U),[U]),W=U[y],K=ae&&Gn(W);(0,H.useEffect)(()=>{ae&&!Gn(W)&&j(!1)},[ae,W]);let q=(0,H.useCallback)(async(e,n=!1)=>{let r=await A({kind:`list`,opening:n});if(t(r.items),n&&r.clear&&k(!0),Ce(r.previewWidth),we(r.previewSplit),Dt(r.pdfFit),Nr(r.appearance,r.theme),h(S(r.pinKey??``)??S(`cmd+p`)),p.current=r.searchMode??`mixed`,f(p.current),e){let t=ye(r.items.filter(e=>Se(e,Te.current)),F.current?.value??``,p.current).findIndex(t=>t.id===e);t>=0&&x(t)}},[Ce,we]);(0,H.useEffect)(()=>{q(null,!0).catch(e=>C(D(e))).finally(()=>{F.current?.focus(),Ar()})},[q]);let ke=(0,H.useRef)(null);ke.current=y>0?W?.id??null:null,(0,H.useEffect)(()=>{let e=!1,t=!1,n=async()=>{if(e){t=!0;return}e=!0;try{do t=!1,await q(ke.current).catch(()=>{});while(t)}finally{e=!1}},r=e=>{jr(e.detail,`history`)&&n()},i=()=>{n(),Ar()};return window.addEventListener(`lumi:message`,r),window.addEventListener(`lumi:settings`,i),()=>{window.removeEventListener(`lumi:message`,r),window.removeEventListener(`lumi:settings`,i)}},[q]),(0,H.useEffect)(()=>{y>0&&y>=U.length&&x(Math.max(0,U.length-1))},[y,U.length]),(0,H.useEffect)(()=>{document.getElementById(`row-${y}`)?.scrollIntoView({block:`nearest`})},[y,U]);let J=(0,H.useCallback)(async e=>{C(``);try{await e()}catch(e){C(D(e))}},[]);(0,H.useEffect)(()=>{let e=e=>{if(!jr(e.detail,`summoned`))return;let t=K||M?null:L.current?.querySelector(`.row[aria-selected="true"]`);t?.scrollIntoView({block:`nearest`}),rt(document.querySelector(`.menu-item[aria-selected="true"], .menu-filter`)??t??(M?null:document.querySelector(`.search`)))};return window.addEventListener(`lumi:message`,e),()=>window.removeEventListener(`lumi:message`,e)},[K,M]);let Y=(0,H.useCallback)((e,t=W)=>{t&&J(()=>A({kind:`paste`,id:t.id,plain:e,pinned:w}))},[J,W,w]),je=(0,H.useCallback)(()=>{let e=!w;J(async()=>{await A({kind:`pinPanel`,pinned:e}),ne(e)})},[J,w]),Me=(0,H.useCallback)(()=>{if(!W)return;let e=W.id;J(async()=>{R.current=Qe()?et(L.current):null;try{let{pin:t}=await A({kind:`pin`,id:e});B.current.push({kind:`pin`,id:e,was:W.pin,now:t}),V.current=[],ve(t?e:null),await q(e)}catch(e){throw R.current=null,e}})},[J,W,q]),X=(0,H.useCallback)(e=>e.map(e=>L.current?.querySelector(`.row[data-id="${CSS.escape(e)}"]`)).filter(e=>!!e),[]),Ne=(0,H.useCallback)((e,t)=>{z.current||J(async()=>{z.current=!0;let n=await it(X(e));try{let e=await t();e.length&&B.current.push({kind:`delete`,ids:e}),V.current=[],await q(null)}catch(e){throw n(),e}finally{z.current=!1}})},[J,q,X]),Pe=(0,H.useCallback)(()=>{if(!W)return;let e=W.id;Ne([e],async()=>(await A({kind:`delete`,id:e}),[e]))},[W,Ne]),Fe=(0,H.useCallback)(t=>{let n=(e??[]).filter(e=>!(t&&e.pin)).map(e=>e.id);n.length&&Ne(n,async()=>(await A({kind:t?`clear`:`clearAll`})).ids)},[Ne,e]);(0,H.useEffect)(()=>{E&&e!==null&&(k(!1),Fe(!0))},[E,e,Fe]),(0,H.useEffect)(()=>{let e=e=>{jr(e.detail,`clear`)&&k(!0)};return window.addEventListener(`lumi:message`,e),()=>window.removeEventListener(`lumi:message`,e)},[]);let Ie=(0,H.useCallback)(()=>{let e=B.current.pop();e&&J(async()=>{R.current=Qe()?et(L.current):null;try{if(e.kind===`pin`){let{pin:t}=await A({kind:`setPin`,id:e.id,pin:e.was});ve(t?e.id:null),V.current.push({...e,now:t??e.now})}else{let{count:t}=await A({kind:`restore`,ids:e.ids});t&&V.current.push(e),t<e.ids.length&&C(e.ids.length===1?`That item was copied again since, so the newer one stays.`:`Some items were copied again since, so the newer ones stay.`)}await q(e.kind===`pin`?e.id:e.ids[0]??null)}catch(e){throw R.current=null,e}})},[J,q]),Le=(0,H.useCallback)(()=>{let e=V.current.pop();e&&!z.current&&J(async()=>{if(e.kind===`pin`){R.current=Qe()?et(L.current):null;try{let{pin:t}=await A({kind:`setPin`,id:e.id,pin:e.now});ve(t?e.id:null),B.current.push({...e,now:t}),await q(e.id)}catch(e){throw R.current=null,e}return}z.current=!0;let t=await it(X(e.ids));try{await A({kind:`delete`,ids:e.ids}),B.current.push(e),await q(null)}catch(e){throw t(),e}finally{z.current=!1}})},[J,q,X]),Re=(0,H.useCallback)(()=>{J(()=>A({kind:`settings`}))},[J]),ze=(0,H.useCallback)(e=>void J(()=>A(e===`tour`?{kind:e}:{kind:e,pinned:w})),[J,w]),[Z,Be]=(0,H.useState)(!1),Ve=(0,H.useCallback)(()=>{Be(!1),F.current?.focus()},[]),He=(0,H.useMemo)(()=>{let t=W,r=(e,n)=>()=>{t&&J(()=>A(e===`copy`?{kind:e,id:t.id,plain:n,pinned:w}:{kind:e,id:t.id,pinned:w}))},i=(e??[]).filter(e=>!e.pin).length,a=e?.length??0,o=t&&(t.kind===`text`||t.kind===`rich`||t.kind===`link`);return[...t&&!M?[{id:`paste`,label:`Paste`,glyph:(0,G.jsx)(P,{}),keys:`↩`,run:()=>Y(!1,t)},...o?[{id:`plain`,label:`Paste as plain text`,glyph:(0,G.jsx)(s,{}),keys:`⌥↩`,run:()=>Y(!0,t)}]:[],...K||Gn(t)?[{id:`zoom`,label:K?`Back to the list`:`Expand preview`,glyph:K?(0,G.jsx)(ue,{}):(0,G.jsx)(de,{}),keys:`⌘Y`,run:()=>j(!K)}]:[],{id:`copy`,label:`Copy`,glyph:(0,G.jsx)(N,{}),run:r(`copy`)},...t.kind===`file`?[{id:`copyPath`,label:(t.fileCount??0)>1?`Copy paths`:`Copy path`,glyph:(0,G.jsx)(N,{}),run:r(`copyPath`)}]:[],...t.ocr?[{id:`copyText`,label:`Copy text in image`,glyph:(0,G.jsx)(c,{}),run:r(`copyText`)}]:[],...t.kind===`link`?[{id:`open`,label:`Open in browser`,glyph:(0,G.jsx)(n,{}),run:r(`open`)}]:[],...t.kind===`file`?[{id:`reveal`,label:`Show in Finder`,glyph:(0,G.jsx)(d,{}),run:r(`reveal`)}]:[],...t.kind===`image`?[{id:`saveImage`,label:`Save image as…`,glyph:(0,G.jsx)(te,{}),run:()=>void J(()=>A({kind:`saveImage`,id:t.id,name:Pr(t.last)}))}]:[],{id:`pin`,label:t.pin?`Unpin`:`Pin`,glyph:(0,G.jsx)(v,{}),keys:se(m),run:Me}]:[],{id:`settings`,label:`Settings…`,glyph:(0,G.jsx)(re,{}),keys:`⌘,`,run:Re},{id:`about`,label:M?`Back to the history`:`About Clipboard Manager`,glyph:(0,G.jsx)(O,{}),run:()=>le(!M)},...t&&!M?[{id:`delete`,label:`Delete entry`,glyph:(0,G.jsx)(b,{}),keys:`⌘⌥⌫`,danger:!0,run:Pe}]:[],...i&&i<a?[{id:`clear`,label:`Delete all unpinned…`,glyph:(0,G.jsx)(b,{}),danger:!0,confirm:`Press ↩ again to delete ${i} ${i===1?`entry`:`entries`}`,run:()=>Fe(!0)}]:[],...a?[{id:`clearAll`,label:`Delete all…`,glyph:(0,G.jsx)(b,{}),danger:!0,confirm:`Press ↩ again to delete all ${a} ${a===1?`entry`:`entries`}`,run:()=>Fe(!1)}]:[]]},[M,J,W,Re,Y,m,w,Pe,Fe,e,Me,K]);(0,H.useLayoutEffect)(()=>{let e=R.current;e&&(R.current=null,tt(L.current,e))},[U]),(0,H.useEffect)(()=>{if(!he)return;let e=setTimeout(()=>ve(null),400);return()=>clearTimeout(e)},[he]);let Q=e=>{_(e),x(0),C(``)},Ue=e=>{let t=xe.indexOf(g);Q(xe[(t+e+xe.length)%xe.length]??`all`)},We=(e,t=!1)=>{let n=U.length;n&&x(r=>t?((r+e)%n+n)%n:Math.max(0,Math.min(n-1,r+e)))},Ge=()=>document.querySelector(`.menu-filter`)??F.current,Je=e=>{e.target.closest(`input, textarea, select, video, audio, .menu`)||window.getSelection()?.isCollapsed!==!1&&Ge()?.focus()},Ye=e=>{if(!e.metaKey&&!e.ctrlKey&&(e.key.length===1||e.keyCode===229)&&!(e.target instanceof HTMLInputElement||e.target instanceof HTMLTextAreaElement)&&Ge()?.focus(),e.nativeEvent.isComposing||e.keyCode===229)return;let t=e.metaKey&&!e.ctrlKey,n=e.key;if(M){if(n===`Escape`)Z?Ve():le(!1);else if(t&&n.toLowerCase()===`k`)Be(!0);else if(t&&n===`,`)Re();else return;e.preventDefault();return}if(n===`ArrowDown`)We(1,!0);else if(n===`ArrowUp`)We(-1,!0);else if(n===`PageDown`)We(8);else if(n===`PageUp`)We(-8);else if(n===`Enter`)Y(e.altKey);else if(n===`Tab`)Ue(e.shiftKey?-1:1);else if(n===`Escape`)Z?Ve():K?j(!1):r?(i(``),x(0)):g===`all`?A({kind:`close`}).catch(()=>{}):Q(`all`);else if(t&&n.toLowerCase()===`k`)Be(!0);else if(t&&n===`,`)Re();else if(t&&e.altKey&&n===`Backspace`)Pe();else if(t&&!e.shiftKey&&n.toLowerCase()===`z`&&B.current.length)Ie();else if(t&&e.shiftKey&&n.toLowerCase()===`z`&&V.current.length)Le();else if(ie(e,m))Me();else if(t&&e.shiftKey&&!e.altKey&&n.toLowerCase()===`p`)je();else if(t&&!e.shiftKey&&!e.altKey&&n.toLowerCase()===`y`)(K||Gn(W))&&j(!K);else if(t&&/^[1-9a-z]$/i.test(n)){let t=n.toLowerCase(),r=U.findIndex(e=>De.get(e.id)===t);if(r<0)return;x(r),Y(e.altKey,U[r])}else return;e.preventDefault()},Xe=e!==null&&!U.length;return(0,G.jsxs)(`main`,{className:[`panel`,K&&!M?`zoomed`:``,M?`about-up`:``].filter(Boolean).join(` `),tabIndex:-1,onKeyDown:Ye,onClick:Je,children:[(0,G.jsxs)(`header`,{className:`crumbs`,...pe,children:[(0,G.jsx)(l,{}),(0,G.jsx)(`span`,{className:`brand`,children:`Lumi`}),(0,G.jsx)(`span`,{className:`sep`,children:`›`}),(0,G.jsx)(`span`,{children:`Clipboard Manager`}),(0,G.jsx)(`span`,{className:`sep`,children:`›`}),(0,G.jsx)(`span`,{className:`here`,children:M?`About`:_e[g]}),(0,G.jsx)(`nav`,{className:`filters`,"aria-label":`Show`,children:xe.map(e=>(0,G.jsx)(`button`,{type:`button`,className:e===g?`cap quiet on`:`cap quiet`,"aria-pressed":e===g,title:_e[e],"aria-label":_e[e],onMouseDown:e=>e.preventDefault(),onClick:()=>Q(e),children:e===`all`?_e[e]:(0,G.jsx)(a,{kind:e})},e))}),(0,G.jsx)(`button`,{type:`button`,className:w?`keep on`:`keep`,"aria-pressed":w,title:w?`Pinned: stays open while you work elsewhere (⌘⇧P)`:`Keep the panel open while you work elsewhere (⌘⇧P)`,"aria-label":`Keep the panel open`,onMouseDown:e=>e.preventDefault(),onClick:je,children:(0,G.jsx)(u,{})})]}),(0,G.jsxs)(`div`,{className:`search`,"aria-hidden":M||void 0,children:[(0,G.jsx)(oe,{}),(0,G.jsx)(`input`,{ref:F,value:r,onChange:e=>{i(e.target.value),x(0),C(``),j(!1),le(!1)},placeholder:`Search history`,autoComplete:`off`,spellCheck:!1,"aria-label":`Search history`,"aria-controls":`list`,"aria-activedescendant":W?`row-${y}`:void 0})]}),M&&(0,G.jsx)(Oe,{onLink:ze}),(0,G.jsxs)(`section`,{className:`body-grid`,style:{gridTemplateColumns:Xe?`minmax(0, 1fr)`:K?`0 minmax(0, 1fr)`:`minmax(0, 1fr) min(${fe.width}px, calc(100% - 240px))`},children:[(0,G.jsxs)(`div`,{ref:L,id:`list`,className:`list`,role:`listbox`,"aria-label":`Clipboard history`,children:[e!==null&&Xe&&(0,G.jsxs)(`div`,{className:`empty`,children:[e.length>0&&r?(0,G.jsx)(oe,{}):(0,G.jsx)(T,{}),(0,G.jsx)(`span`,{children:Mr(e.length,r,g,o)})]}),U.map((e,t)=>[t>0&&U[t-1]?.pin&&!e.pin?(0,G.jsx)(`div`,{className:`divider`,role:`separator`},`divider`):null,(0,G.jsx)(Ke,{row:e,index:t,selected:t===y,shortcut:De.get(e.id),found:be(e,r,Ee),popped:he===e.id,onPick:e=>{x(e),F.current?.focus()},onPaste:t=>Y(t,e)},e.id)])]}),(0,G.jsxs)(`div`,{className:`preview-slot`,hidden:Xe,"data-split":I.height==null?void 0:``,style:I.height==null?void 0:{"--split":`${I.height}px`},children:[(0,G.jsx)(`div`,{className:`grip`,role:`separator`,"aria-orientation":`vertical`,"aria-label":`Resize preview`,title:`Drag to resize · double-click to reset`,...fe.grip}),(0,G.jsx)(Kn,{row:W,query:r,used:Ee,onOpen:(e,t,n)=>void J(()=>A({kind:`open`,id:e,url:t,snippet:n,pinned:w})),onCopyColor:e=>void J(()=>A({kind:`copyColor`,text:e,pinned:w})),onCopySnippet:(e,t)=>void J(()=>A({kind:`copySnippet`,id:e,text:t,pinned:w})),onCopyWords:(e,{from:t,to:n})=>void J(()=>A({kind:`copyText`,id:e,from:t,to:n,pinned:w})),zoomed:K,onZoom:()=>j(!K),split:I.grip})]})]}),ee&&(0,G.jsx)(`p`,{className:`notice`,role:`status`,children:ee}),Z&&(0,G.jsx)(qe,{actions:He,onClose:Ve}),(0,G.jsxs)(`footer`,{className:`hints`,children:[M?(0,G.jsxs)(`span`,{children:[(0,G.jsx)(`kbd`,{className:`cap quiet`,children:`⎋`}),` back to the history`]}):(0,G.jsxs)(G.Fragment,{children:[(0,G.jsxs)(`span`,{children:[(0,G.jsx)(`kbd`,{className:`cap quiet`,children:`↩`}),` paste`]}),(0,G.jsxs)(`span`,{children:[(0,G.jsx)(`kbd`,{className:`cap quiet`,children:`⌥↩`}),` plain`]}),(0,G.jsxs)(`span`,{children:[(0,G.jsx)(`kbd`,{className:`cap quiet`,children:se(m)}),` pin`]}),(0,G.jsxs)(`span`,{children:[(0,G.jsx)(`kbd`,{className:`cap quiet`,children:`⌘⌥⌫`}),` delete`]}),(0,G.jsxs)(`span`,{children:[(0,G.jsx)(`kbd`,{className:`cap quiet`,children:`⇥`}),` filter`]})]}),(0,G.jsxs)(`button`,{type:`button`,className:`exit`,"data-menu-toggle":!0,onMouseDown:e=>e.preventDefault(),onClick:()=>Z?Ve():Be(!0),children:[(0,G.jsx)(`kbd`,{className:`cap quiet`,children:`⌘K`}),` actions`]})]})]})}var kr=!1;function Ar(){kr||(kr=!0,(async()=>{try{for(let e=0;e<400;e++){let{more:e}=await A({kind:`readImages`});if(!e)break}}catch{}finally{kr=!1}})())}function jr(e,t){return typeof e==`object`&&!!e&&e.kind===t}function Mr(e,t,n,r){return e?R(t,r)?`Not a regular expression yet`:t?`Nothing matches that search`:`No ${_e[n].toLowerCase()} yet`:`Copy something and it shows up here`}function Nr(e,t){let n=document.documentElement;n.dataset.material=e??`popover`;let r=e===`hud`?`dark`:t;r===`light`||r===`dark`?n.dataset.theme=r:delete n.dataset.theme}function Pr(e){let t=new Date(e),n=e=>String(e).padStart(2,`0`);return`Image ${t.getFullYear()}-${n(t.getMonth()+1)}-${n(t.getDate())} at ${n(t.getHours())}.${n(t.getMinutes())}.${n(t.getSeconds())}`}var Fr=document.getElementById(`root`);Fr&&(0,Ce.createRoot)(Fr).render((0,G.jsx)(H.StrictMode,{children:(0,G.jsx)(Or,{})}));export{Mt as t};
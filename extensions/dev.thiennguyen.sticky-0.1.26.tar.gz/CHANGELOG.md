# Changelog

## [0.1.26] - 2026-10-10

### Added

- Custom colour, after No colour wherever a note's colour is picked: a note's menu, a row's menu in Browse, a note on the desktop. Its swatch, ringed in every hue, opens a picker in the menu: a square for the shade, a strip for the hue, and the hex to type. The note takes the colour as you drag, and its paper, its ink and its top edge are drawn from it, in light and dark. Custom keeps the colour picked last for the next note, and on the Settings tab it is an eighth tile with the same picker: choose it, and new notes start in that colour.
- Font, at the start of the format bar: Aa, drawn in the font where the caret is, opens System, Rounded, Serif, Mono and Handwriting, all macOS's own. Like Bold, it changes what you have chosen, or with nothing chosen what you type next, so one note can be in several fonts. Notes on the desktop show them too. Copy as Markdown writes a font as `<span data-font="serif">…</span>`, which other Markdown apps show as the words alone.

## [0.1.25] - 2026-10-10

### Added

- Clear, a third look beside Glass and Paper: macOS's glass with no colour washed over it, the note's colour left to the dot by its title and to the top edge. A note drawn on paper stays on paper.
- Top edge, on the Settings tab: a strip of the note's colour along its top, or the title bar in that colour, on the main note and on the notes on the desktop alike. A note with no colour gets a grey one. None, the way notes were, stays the default.
- A click on a link brings up its card, pointing at it: the link's words and where it leads, which opens it in your browser or Mail, with Edit and Remove beside them. ⌘-click opens a link at once. In a locked note the card only opens it.
- Link (⌘L, or the format bar) asks for the words as well as the address, as Slack does. What you have chosen comes in as the words; in a link, its words and address are both there to change, with Remove link beside Save. A bare address gets `https://` and an email address `mailto:`; only web and mail links are taken.
- The Settings tab, under Settings → Extensions → Sticky Notes, is drawn by Sticky Notes. The colour a new note starts in is picked from the notes themselves, drawn small in the look your notes have. Glass, Paper and Clear, and the three top edges, are cards, each a note in that colour, and Float above other apps, Grow with what you write and Format bar are switches. It follows Lumi's light or dark theme, and when the window is too short for it, the scroll bar keeps to its own lane on the right instead of lying over the cards.

### Changed

- Paper look is no longer in Actions (⌘K). The look is picked on the Settings tab, now that there are three.

### Fixed

- A to-do's box sits in the middle of its first line, at any zoom, instead of a few points above the words.
- Float on Top turned on or off on the Settings tab reaches the note that is up at once, instead of the next time it is opened.

## [0.1.24] - 2026-10-09

### Changed

- Pin note in a note's menu and in the menu a right-click on a note in Browse opens shows a pin, and says Unpin note, with the pin struck through, on a note already pinned — the way Lock note and Unlock note read — instead of a tick.

## [0.1.23] - 2026-10-08

### Added

- Rename note, in Actions (⌘K), a desktop note's menu and the menu a right-click on a note in Browse opens, does what a double click on the title does. In Browse the note is named in its row — any note in the list, not only the one open — and a note on the desktop shows its new name at once. Off for a locked note.

### Fixed

- A menu with no room to open below or above where you clicked — a note's menu in Browse, Actions (⌘K), a desktop note's menu — now opens whole, moved up just enough to fit, instead of squeezed in with its colours scrolled out of sight at the top. One that fits below still opens below.

## [0.1.22] - 2026-10-08

### Added

- Name a note: double-click its title, on the main note or one on the desktop, and type what it should be called. Return or a click elsewhere keeps the name, Escape leaves it as it was. The name stays whatever the first line says, and Browse lists the note by it — a search still finds the first line too. Clear the name and the first line is the title again. A locked note keeps its name until it is unlocked.

### Fixed

- A title cut at 80 characters no longer ends in half an emoji.

## [0.1.21] - 2026-10-08

### Changed

- Sticky Notes needs Lumi 1.42.0, which resizes a note by every edge and corner and opens your notes again when it restarts. On an older Lumi, update Lumi first.

## [0.1.20] - 2026-10-08

### Added

- Every note — the main one and the ones on the desktop — resizes by any of its edges and corners, as a Mac window does: the edge you pull follows the pointer and the one across from it stays put, with the Mac's resize cursor on each. Pulling the top or the bottom of the main note sets its height by hand, as the corner did; pulling a side leaves Fit height on. Needs Lumi 1.42.0; on an older Lumi the bottom-right corner sizes it as before.
- A right-click on a note in Browse opens a menu for it: its colour, Open, Put on the desktop (or Show on the desktop, for one already there), Pin note, Lock or Unlock note, Copy as Markdown and Delete note — for any note in the list, not only the one open. A note in Recently Deleted offers Restore. The arrow keys and Return work the menu; Escape puts it away and leaves Browse open.

### Changed

- Browse keeps the note you had chosen when the list changes under it — pinned, coloured or locked from the menu — wherever it moves to.

## [0.1.19] - 2026-10-07

### Added

- Orange, a sixth colour for a note, beside the others in the Actions menu and in Settings. No colour stays last.
- Lock note, in the Actions menu and a note's menu on the desktop: a locked note can be read, chosen and copied, but not changed — no typing, no format bar, no pictures, no ticking a to-do — so a stray key or click cannot change it. The footer says Locked, a padlock sits beside its title on the desktop and in Browse, and Unlock note gives it back.

### Changed

- A search in Browse that matches no note leads with Create, without a line saying nothing matched.
- Pinned, Recent and Recently Deleted in Browse are headings with their counts that fold open and shut, and stay as you left them. Recently Deleted starts folded, and is named once where it was named twice: over the deleted notes and again on the button under them. A search shows every match, whatever is folded.
- A pinned note's ⌘1–⌘9 in Browse sits last on its line, against the edge, so the keys stand in one column whatever is written before them — On desktop, Open or a time.
- Empty sits beside Recently Deleted while it is open and asks once more — Delete 2 forever — before it deletes for good.

### Fixed

- Your notes come back when Lumi restarts: the ones on the desktop where they were, and the main note if it was open (Lumi 1.42.0; on an older Lumi, Show brings them back).
- Updating Sticky Notes brings the notes back as it lands: the ones on the desktop where they were, and the main note — open or not — for you to see. A small Sticky Notes window says the update landed while it does, then goes. An update used to leave every note off screen until Show.
- The Actions menu (⌘K) and a desktop note's menu are walked with ↑ and ↓ and chosen with Return, as a Mac menu is. The arrows used to move the caret in the note behind the menu instead.
- A message at the bottom of a narrow note no longer breaks onto a second line when it fits on one.

## [0.1.18] - 2026-10-07

### Added

- Find a Sticky Note has a key of its own, `⌃⌥⌘F`: from any app it opens the search over every note that `⌘P` opens inside one. Change or clear it on the Shortcuts tab. Updating tries the key once; if one of your shortcuts or another extension already holds it, nothing is taken and the Shortcuts tab says who.

## [0.1.17] - 2026-10-07

### Changed

- Keep on top is now Float on Top, the name macOS's Stickies gives it, and its toolbar button shows a window floating over another instead of a pin. Pin note, which keeps a note at the top of Browse with ⌘1–⌘9, is the only pin left, so the two no longer read as one.

## [0.1.16] - 2026-10-07

### Changed

- Sticky Notes behaves as a Mac window, not a web page: the title bar, the footer, the toolbar and the menus can no longer be selected as text, and a right-click opens no browser menu (Reload, AutoFill, Inspect Element). A right-click on words in a note still opens the Mac's menu for text — Copy, Look Up, Translate and the spelling.

## [0.1.15] - 2026-10-07

### Fixed

- The `/` menu lights one row at a time: the pointer chooses a row as the arrow keys do, instead of lighting a second one beside theirs. A list scrolling under a pointer that is not moving keeps the row the keys chose.
- The `/` menu's labels start in one column, headings included, and the row the keys reach scrolls into sight.

## [0.1.14] - 2026-10-07

### Changed

- Notes on the desktop stay in front of the main panel: pressing it, showing it or giving it the keyboard no longer brings it over them while Keep on top is on. Without Keep on top the main panel is above every window while it is up, notes included.

## [0.1.13] - 2026-10-07

### Changed

- New Sticky Note has an icon in Lumi's menu bar menu and the action picker, and Show Sticky Notes has its own: two notes, not the layers Lumi's Profile menu wears.
- A note on the desktop carries Lumi's mark at the left of its title bar.

## [0.1.12] - 2026-10-07

### Changed

- Putting a note back from the desktop opens Sticky Notes on it when the main panel is closed, so the note stays in sight.

## [0.1.11] - 2026-10-07

### Changed

- Close is the last item in the Actions menu, set apart from Delete note.

## [0.1.10] - 2026-10-07

### Added

- Close in the note's Actions menu, and `⌘W` to close the note, as Esc does.

## [0.1.9] - 2026-10-07

### Fixed

- A note dragged to the top of the screen now goes right up to the menu bar, on every display. It used to stop well short of it on a display with nothing above. Needs Lumi 1.41.0.

## [0.1.8] - 2026-10-07

### Changed

- The note's footer now carries Lumi's mark, so it's clear where Sticky Notes lives.

## [0.1.7] - 2026-10-07

### Fixed

- A note that ends in a picture opens with the caret on the line under it, not with the picture selected — so the first key you press no longer replaces it.

## [0.1.6] - 2026-10-07

### Fixed

- Pictures pasted with text now show and stay in the note: from Notes, TextEdit or Mail, from a web app, and from a web page — downloaded once and kept with the note. One that cannot be had becomes a link to where it was, instead of a broken box.

### Changed

- Sticky Notes now asks for network access, used only to download a picture you paste from a web page.

## [0.1.5] - 2026-10-07

### Changed

- Up to 16 notes on the desktop at once, instead of 6. Each new one opens a step down from the last, so they no longer land on top of each other.

## [0.1.4] - 2026-10-07

### Fixed

- Sticky Notes' page in Settings → Extensions offers two windows to open, the note and Welcome, instead of six more buttons that each opened an empty note on the desktop.

## [0.1.3] - 2026-10-07

### Fixed

- Menus are no longer cut off by the note: `⌘K`, the `/` menu, the link field and a desktop note's menu reach past its edge, dropping down — or opening upward at the bottom of the screen — however small the note is.

## [0.1.2] - 2026-10-07

### Fixed

- `⌘P` shows only what Browse needs: the format bar steps aside, and the bottom bar shows Browse's keys instead of the hidden note's word count. `esc` puts you back in the note, typing where you left off.
- `⇧⌘I` from Browse goes back to the note before you pick a picture, so you see it land.

## [0.1.1] - 2026-10-07

### Changed

- Needs Lumi 1.40.0, the first Lumi that brings a note on the desktop back where you left it. An older Lumi now asks you to update first, rather than installing Sticky Notes and stacking every note in a corner.

## [0.1.0] - 2026-10-07

### Added

- A note one key away: `⌃⌥⌘N` starts one, `⌃⌥⌘S` brings it back or puts it away. It floats above every app, full-screen ones included, and stays up while you work elsewhere unless you turn Keep on top off.
- Notes on the desktop: `⌘D` leaves a note beside your work until you put it back, up to six at once, each where you left it. `⌃⌥⌘S` brings them all back.
- Formatting as you type — headings, to-dos, lists, quotes, code, lines — or from the `/` menu, the format bar and the usual keys.
- Pictures: paste a screenshot, drop a file, or pick one with `⇧⌘I`.
- `⌘P` finds any note by what it says. Pin notes to the top; `⌘1`–`⌘9` open them, `⌘[` and `⌘]` go back and forward.
- Recently Deleted keeps a deleted note for 30 days.
- A colour per note, glass or paper, and a note that grows with what you write.
- Copy as Markdown, and New, Show and Find in Lumi's menu bar menu.
